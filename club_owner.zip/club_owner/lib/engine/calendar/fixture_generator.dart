class Fixture {
  const Fixture({
    required this.round,
    required this.homeId,
    required this.awayId,
  });

  final int round;
  final String homeId;
  final String awayId;

  /// Identifiant stable d'un match au sein d'une saison.
  String get key => '$round-$homeId-$awayId';
}

/// Génère un calendrier aller-retour (méthode du cercle).
///
/// Chaque équipe joue une fois par journée (sauf repos si le nombre
/// d'équipes est impair) et rencontre chaque adversaire une fois à
/// domicile et une fois à l'extérieur.
List<Fixture> generateRoundRobin(List<String> teamIds) {
  const bye = '__bye__';
  final ids = [...teamIds];
  if (ids.length.isOdd) ids.add(bye);

  final n = ids.length;
  final roundsPerLeg = n - 1;
  final firstLeg = <Fixture>[];

  for (var round = 0; round < roundsPerLeg; round++) {
    for (var i = 0; i < n ~/ 2; i++) {
      final a = ids[i];
      final b = ids[n - 1 - i];
      if (a == bye || b == bye) continue;
      final swap = (round + i) % 2 == 1;
      firstLeg.add(
        Fixture(round: round + 1, homeId: swap ? b : a, awayId: swap ? a : b),
      );
    }
    ids.insert(1, ids.removeLast());
  }

  final secondLeg = firstLeg
      .map(
        (f) => Fixture(
          round: f.round + roundsPerLeg,
          homeId: f.awayId,
          awayId: f.homeId,
        ),
      )
      .toList();

  return [...firstLeg, ...secondLeg];
}
