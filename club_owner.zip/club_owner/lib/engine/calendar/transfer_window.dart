import '../../core/utils/calendar.dart';

/// Le mercato d'été va de la fin de saison au 1er septembre ; celui
/// d'hiver couvre le mois de janvier.
bool isTransferWindowOpen({
  required int seasonNumber,
  required int round,
  required bool finished,
}) {
  if (finished) return true;
  final date = roundDate(seasonNumber, round.clamp(1, 38).toInt());
  if (date.month == 8) return true;
  if (date.month == 9 && date.day <= 1) return true;
  if (date.month == 1) return true;
  return false;
}

/// Texte d'état du mercato pour l'interface et les messages d'erreur.
String transferWindowText({
  required int seasonNumber,
  required int round,
  required bool finished,
}) {
  if (isTransferWindowOpen(
    seasonNumber: seasonNumber,
    round: round,
    finished: finished,
  )) {
    return finished
        ? "Mercato d'été ouvert."
        : (roundDate(seasonNumber, round).month == 1
              ? "Mercato d'hiver ouvert jusqu'à fin janvier."
              : "Mercato d'été ouvert jusqu'au 1er septembre.");
  }
  for (var r = round + 1; r <= 38; r++) {
    if (isTransferWindowOpen(
      seasonNumber: seasonNumber,
      round: r,
      finished: false,
    )) {
      return 'Mercato fermé. Réouverture le '
          '${formatDateFr(roundDate(seasonNumber, r))}.';
    }
  }
  return "Mercato fermé. Réouverture à la fin de la saison.";
}
