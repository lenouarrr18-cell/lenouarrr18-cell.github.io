import 'dart:math';

import '../../domain/entities/match_summary.dart';
import '../../domain/entities/team_strength.dart';
import 'match_models.dart';

/// Simulation de match en Dart pur, reproductible grâce à la graine.
///
/// Un match est découpé en [phases] séquences. À chaque séquence,
/// le milieu décide qui a le ballon, puis l'attaque face à la défense
/// décide d'un tir, et enfin l'attaque face au gardien décide du but.
class MatchEngine {
  MatchEngine({required int seed})
      : _random = Random(seed),
        _statRandom = Random(seed ^ 0x5bd1e995);

  static const int phases = 45;
  static const double homeAdvantage = 1.05;

  final Random _random;

  /// Générateur séparé pour les statistiques : le score n'en dépend pas.
  final Random _statRandom;

  MatchResult simulate({
    required TeamStrength home,
    required TeamStrength away,
  }) {
    final events = <MatchEvent>[];
    var homeGoals = 0;
    var awayGoals = 0;
    var homePhases = 0;

    for (var phase = 0; phase < phases; phase++) {
      final minute = ((phase + 0.5) * 90 / phases).round();

      final homeMidfield = home.midfield * homeAdvantage;
      final homeHasBall =
          _random.nextDouble() < homeMidfield / (homeMidfield + away.midfield);
      if (homeHasBall) homePhases++;
      final attacker = homeHasBall ? home : away;
      final defender = homeHasBall ? away : home;

      final shotChance = _clamp(
        (attacker.attack - defender.defense) / 200 + 0.3,
        0.1,
        0.6,
      );
      if (_random.nextDouble() >= shotChance) continue;

      final onTarget = _random.nextDouble() < 0.5;
      if (!onTarget) {
        events.add(
          MatchEvent(
            minute: minute,
            type: MatchEventType.miss,
            isHome: homeHasBall,
          ),
        );
        continue;
      }

      final goalChance = _clamp(
        (attacker.attack - defender.goalkeeper) / 250 + 0.32,
        0.08,
        0.6,
      );
      if (_random.nextDouble() < goalChance) {
        if (homeHasBall) {
          homeGoals++;
        } else {
          awayGoals++;
        }
        events.add(
          MatchEvent(
            minute: minute,
            type: MatchEventType.goal,
            isHome: homeHasBall,
          ),
        );
      } else {
        events.add(
          MatchEvent(
            minute: minute,
            type: MatchEventType.save,
            isHome: homeHasBall,
          ),
        );
      }
    }

    return MatchResult(
      homeGoals: homeGoals,
      awayGoals: awayGoals,
      events: List.unmodifiable(events),
      stats: _stats(home, away, events, homePhases),
    );
  }

  MatchStats _stats(
    TeamStrength home,
    TeamStrength away,
    List<MatchEvent> events,
    int homePhases,
  ) {
    final r = _statRandom;
    int count(bool isHome, bool Function(MatchEventType t) test) {
      return events.where((e) => e.isHome == isHome && test(e.type)).length;
    }

    final possession = ((homePhases / phases) * 100).round().clamp(25, 75).toInt();
    var hShots = count(true, (_) => true);
    var aShots = count(false, (_) => true);
    // Tirs bloqués par la défense, non repris dans les événements.
    hShots += r.nextInt(4) + (possession > 55 ? 2 : 0);
    aShots += r.nextInt(4) + (possession < 45 ? 2 : 0);
    final hTarget = count(true, (t) => t != MatchEventType.miss);
    final aTarget = count(false, (t) => t != MatchEventType.miss);
    final hCorners = (hShots * 0.4).round() + r.nextInt(3);
    final aCorners = (aShots * 0.4).round() + r.nextInt(3);
    final hFouls = 8 + r.nextInt(8) + (possession < 45 ? 2 : 0);
    final aFouls = 8 + r.nextInt(8) + (possession > 55 ? 2 : 0);
    final hYellow = (hFouls / 5).round() + r.nextInt(2);
    final aYellow = (aFouls / 5).round() + r.nextInt(2);
    final hRed = r.nextDouble() < 0.04 ? 1 : 0;
    final aRed = r.nextDouble() < 0.04 ? 1 : 0;
    final hOff = r.nextInt(5);
    final aOff = r.nextInt(5);
    final hPasses = (230 + possession * 4 + home.midfield / 2).round();
    final aPasses = (230 + (100 - possession) * 4 + away.midfield / 2).round();
    final hAcc = (68 + home.midfield / 8 + r.nextInt(6)).round().clamp(55, 93).toInt();
    final aAcc = (68 + away.midfield / 8 + r.nextInt(6)).round().clamp(55, 93).toInt();
    return MatchStats(
      homePossession: possession,
      homeShots: hShots,
      awayShots: aShots,
      homeOnTarget: hTarget,
      awayOnTarget: aTarget,
      homeCorners: hCorners,
      awayCorners: aCorners,
      homeFouls: hFouls,
      awayFouls: aFouls,
      homeYellow: hYellow,
      awayYellow: aYellow,
      homeRed: hRed,
      awayRed: aRed,
      homeOffsides: hOff,
      awayOffsides: aOff,
      homePasses: hPasses,
      awayPasses: aPasses,
      homePassAcc: hAcc,
      awayPassAcc: aAcc,
    );
  }

  static double _clamp(double value, double min, double max) {
    return value.clamp(min, max).toDouble();
  }
}
