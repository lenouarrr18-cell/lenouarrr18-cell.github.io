import 'dart:math';

import '../../domain/entities/club.dart';
import '../../domain/entities/lineup.dart';
import '../../domain/entities/spots.dart';
import '../../domain/entities/match_summary.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/tactic.dart';
import 'match_models.dart';

const double _len = 105;
const double _wid = 68;
const double _dt = 0.5;

/// Taille d'une image de la trajectoire (moteur v2) : 22 joueurs, le
/// ballon, l'arbitre et ses deux assistants (2 octets chacun), la hauteur
/// du ballon et l'état du jeu (1 = arrêt de jeu).
const int pitchFrameBytes = 54;

/// Une image par seconde de jeu.
const double pitchFrameSeconds = 1;

/// Version du format de trajectoire (1 : ancien, 46 octets toutes les 6 s).
const int pitchTrackVersion = 2;

/// Point cible pendant un arrêt de jeu, avec sa vitesse de marche.
class _Pt {
  _Pt(this.x, this.y, [this.speed = 3]);

  final double x;
  final double y;
  final double speed;
}

/// Remplacement annoncé, effectué à la fin de l'arrêt de jeu.
class _Swap {
  _Swap(this.team, this.out, this.inn, this.reason);

  final int team;
  final _Agent out;
  final Player inn;

  /// T tactique, I blessure.
  final String reason;
}

double _hyp(double ax, double ay, double bx, double by) {
  final dx = ax - bx;
  final dy = ay - by;
  return sqrt(dx * dx + dy * dy);
}

/// Un joueur sur le terrain, avec sa position réelle en mètres.
class _Agent {
  _Agent({
    required this.player,
    required this.team,
    required this.ax,
    required this.ay,
    required this.eff,
    required this.phase,
    this.spot = Spot.mc,
    this.role = Role.standard,
    this.instr = Instruction.none,
  }) {
    x = team == 0 ? ax : _len - ax;
    y = team == 0 ? ay : _wid - ay;
  }

  final Player player;
  final int team;

  /// Position tactique de base, dans le repère de l'équipe
  /// (0 = son but, 105 = but adverse).
  final double ax;
  final double ay;

  /// Niveau effectif (niveau x forme x staff).
  final double eff;
  final double phase;

  /// Poste, rôle et consigne individuelle : ils changent le comportement.
  final Spot spot;
  final Role role;
  final Instruction instr;

  /// Remplaçant qui reprend exactement le poste, le rôle et la consigne.
  _Agent replacedBy(Player p, double newEff) => _Agent(
        player: p,
        team: team,
        ax: ax,
        ay: ay,
        eff: newEff,
        phase: phase,
        spot: spot,
        role: role,
        instr: instr,
      );

  double get advance => role.advance + instr.advance;
  double get widthMul => role.wide * instr.wide;
  double get defWork => (role.defWork + instr.defWork).clamp(0.0, 1.0).toDouble();

  double x = 0;
  double y = 0;
  double stamina = 1;
  double dist = 0;
  bool active = true;
  int yellows = 0;
  int reds = 0;
  int goals = 0;
  int assists = 0;
  int shots = 0;
  int passes = 0;
  int passesOk = 0;
  int tackles = 0;
  int interceptions = 0;
  int saves = 0;
  int lost = 0;
  int fouls = 0;

  bool get isGk => spot == Spot.gb;
  bool get isFwd => spot.line == PlayerPosition.forward;
  bool get isMid => spot.line == PlayerPosition.midfielder;
  double get fx => team == 0 ? x : _len - x;
}

/// Simulation d'un match joueur par joueur : 22 joueurs se déplacent sur
/// un terrain de 105 x 68 m, se passent le ballon, pressent, tacleront,
/// tirent, commettent des fautes. Les buts, les statistiques, les notes et
/// les distances parcourues viennent de ce qui s'est réellement passé.
class PitchSim {
  PitchSim({required int seed}) : _r = Random(seed);

  final Random _r;
  late List<List<_Agent>> _teams;
  _Agent? _carrier;
  _Agent? _lastPasser;
  double _lastPassT = -99;
  final List<List<int>> _qOut = [[], []];
  final List<List<double>> _qWhen = [[], []];
  final List<int> _throwIns = [0, 0];
  final List<_Agent> _retired = [];
  final List<String> _subs = [];
  final List<String> _cards = [];
  final List<String> _chances = [];
  List<String> _names = const [];
  final List<double> _xg = [0, 0];
  final List<List<Player>> _bench = [[], []];
  final List<int> _subsUsed = [0, 0];
  late List<double> _teamEff;
  int _ticks = 0;
  final List<int> _track = [];
  double _t = 0;
  double _bx = _len / 2;
  double _by = _wid / 2;
  double _hold = 1;
  bool _carrying = false;
  double _tackleCd = 0;
  double _flightLeft = 0;
  double _flightTotal = 1;
  double _fsx = 0;
  double _fsy = 0;
  double _fex = 0;
  double _fey = 0;
  void Function()? _onLand;
  int _possTeam = 0;
  double _extra = 0;
  final List<int> _poss = [0, 0];
  final List<int> _score = [0, 0];
  final List<int> _shots = [0, 0];
  final List<int> _onTarget = [0, 0];
  final List<int> _corners = [0, 0];
  final List<int> _fouls = [0, 0];
  final List<int> _yellow = [0, 0];
  final List<int> _red = [0, 0];
  final List<int> _offsides = [0, 0];
  final List<MatchEvent> _events = [];
  final List<GoalCredit> _credits = [];
  late Tactic _tacticHome;
  late Tactic _tacticAway;

  // ---------- moteur v2 : arrêts de jeu, arbitres, journal ----------
  double _deadLeft = 0;
  void Function()? _deadThen;
  final Map<_Agent, _Pt> _deadPos = {};
  final List<_Swap> _swaps = [];
  final List<_Agent> _leaving = [];
  _Pt? _refFocus;
  double _rx = _len / 2 - 10;
  double _ry = _wid / 2 + 8;
  double _l1 = _len * 0.75;
  double _l2 = _len * 0.25;
  double _bz = 0;
  double _apex = 0;
  bool _over = false;

  /// Score imposé (tests, scénarios) ; sinon chaque frappe est décidée sur
  /// le terrain : qualité de l'occasion, tireur face au gardien.
  bool _scripted = false;

  /// Pelouse glissante : passes moins précises, plus de fautes.
  bool _rain = false;

  // Étalonnage des frappes jouées pour de vrai : buts attendus de chaque
  // équipe, occasions prévues, et qualité moyenne des tirs déjà pris.
  final List<double> _lambda = [1.3, 1.1];
  final List<int> _plannedShots = [10, 10];
  final List<double> _xgTaken = [0, 0];
  final List<int> _taken = [0, 0];

  /// Penalties obtenus par chaque équipe.
  final List<int> _pens = [0, 0];
  final List<String> _log = [];
  final List<String> _injured = [];

  /// Lève une erreur si une équipe n'a pas 11 titulaires.
  MatchResult simulate({
    required Club home,
    required Club away,
    int? homeGoals,
    int? awayGoals,
    bool rain = false,
  }) {
    _rain = rain;
    final h = home.starters;
    final a = away.starters;
    if (h.length != 11 || a.length != 11) {
      throw StateError('Il faut 11 titulaires par équipe.');
    }
    _tacticHome = home.tactic;
    _tacticAway = away.tactic;
    _teams = [
      _build(h, 0, home.tactic, home.staffBoost * 1.02),
      _build(a, 1, away.tactic, away.staffBoost),
    ];
    _names = [
      for (final t in _teams)
        for (final a in t) a.player.name,
    ];
    _teamEff = [
      _teams[0].fold<double>(0, (s, a) => s + a.eff) / 11,
      _teams[1].fold<double>(0, (s, a) => s + a.eff) / 11,
    ];
    _bench[0] = home.squad.where((p) => !home.starterIds.contains(p.id)).toList();
    _bench[1] = away.squad.where((p) => !away.starterIds.contains(p.id)).toList();
    final ratio = _teamEff[0] / _teamEff[1];
    _scripted = homeGoals != null || awayGoals != null;
    // Buts attendus d'un match réel : environ 2,6 par match en moyenne,
    // plus pour le favori, jamais de score fleuve par défaut.
    _lambda[0] = (1.4 * pow(ratio, 1.6)).clamp(0.3, 2.6).toDouble();
    _lambda[1] = (1.1 * pow(1 / ratio, 1.6)).clamp(0.25, 2.3).toDouble();
    homeGoals ??= _poisson(_lambda[0]);
    awayGoals ??= _poisson(_lambda[1]);
    _plan(0, homeGoals.clamp(0, 9).toInt(), ratio);
    _plan(1, awayGoals.clamp(0, 9).toInt(), 1 / ratio);
    _reset(0);

    var halfDone = false;
    // Le temps additionnel se prolonge un peu si un but prévu n'est pas
    // encore venu : il se joue sur le terrain, pas sur le papier.
    while (_t < 5400 + _extra ||
        (_pendingGoal() && _t < 5400 + _extra + 240) ||
        (_deadLeft > 0 && _t < 5400 + _extra + 60)) {
      if (!halfDone && _t >= 2700) {
        halfDone = true;
        _halfTime();
      }
      _step();
      if (_ticks % 2 == 0) _record();
      _ticks++;
      _t += _dt;
    }
    _over = true;
    _ev('FT', 0);
    _flushPlan();
    return _finish();
  }

  bool _pendingGoal() =>
      _scripted && (_qOut[0].contains(0) || _qOut[1].contains(0));

  /// Mi-temps : tout arrêt en cours est réglé, les équipes changent de côté.
  void _halfTime() {
    _swapPending();
    _deadLeft = 0;
    _deadThen = null;
    _deadPos.clear();
    _refFocus = null;
    _ev('HT', 0);
    _reset(1);
  }

  int _poisson(double l) {
    final lim = exp(-l.clamp(0.2, 4.0).toDouble());
    var k = 0;
    var p = 1.0;
    do {
      k++;
      p *= _r.nextDouble();
    } while (p > lim);
    return k - 1;
  }

  /// Prépare le scénario de tirs d'une équipe : le nombre de buts est fixé
  /// (réaliste), le terrain décide qui tire, où et comment.
  void _plan(int team, int goals, double ratio) {
    var shots = (8 + _r.nextInt(7) + (ratio - 1) * 8 + goals).round();
    shots = shots.clamp(goals + 2, 22).toInt();
    var onTarget = (shots * 0.36).round();
    if (onTarget < goals) onTarget = goals;
    final rest = shots - onTarget;
    final blocks = (rest * 0.3).round();
    final out = <int>[
      for (var i = 0; i < goals; i++) 0,
      for (var i = 0; i < onTarget - goals; i++) 1,
      for (var i = 0; i < rest - blocks; i++) 2,
      for (var i = 0; i < blocks; i++) 3,
    ]..shuffle(_r);
    _plannedShots[team] = out.length;
    final slot = 5100 / out.length;
    for (var i = 0; i < out.length; i++) {
      _qOut[team].add(out[i]);
      _qWhen[team].add(150 + i * slot + _r.nextDouble() * slot * 0.8);
    }
  }

  /// Fin de match : les tirs prévus mais jamais pris sont comptés, les
  /// buts restants sont marqués (pour que le score reste celui du scénario).
  void _flushPlan() {
    if (!_scripted) {
      // Match joué pour de vrai : les occasions non créées n'existent pas.
      for (final team in [0, 1]) {
        _qOut[team].clear();
        _qWhen[team].clear();
      }
      return;
    }
    for (final team in [0, 1]) {
      while (_qOut[team].isNotEmpty) {
        final o = _qOut[team].removeAt(0);
        _qWhen[team].removeAt(0);
        _shots[team]++;
        if (o <= 1) _onTarget[team]++;
        if (o == 0) {
          _Agent? best;
          for (final a in _teams[team]) {
            if (!a.active || a.isGk) continue;
            if (best == null ||
                (a.isFwd ? 3 : (a.isMid ? 1 : 0)) * a.eff >
                    (best.isFwd ? 3 : (best.isMid ? 1 : 0)) * best.eff) {
              best = a;
            }
          }
          if (best != null) {
            best.shots++;
            _goal(best, null);
          }
        }
      }
    }
  }

  /// Remplacements tactiques : jusqu'à 3 par équipe, à partir de la 58e
  /// minute, effectués seulement quand le ballon est arrêté (comme en vrai).
  void _maybeSubs() {
    if (_over) return;
    for (final team in [0, 1]) {
      if (_subsUsed[team] >= 3) continue;
      if (_swaps.any((w) => w.team == team)) continue;
      final due = [3500.0, 4150.0, 4700.0][_subsUsed[team]];
      if (_t < due + team * 90) continue;
      if (_bench[team].isEmpty) {
        _subsUsed[team]++;
        continue;
      }
      _Agent? out;
      var low = 2.0;
      for (final a in _teams[team]) {
        if (!a.active || a.isGk || _leaving.contains(a)) continue;
        if (a.stamina < low) {
          low = a.stamina;
          out = a;
        }
      }
      if (out == null) continue;
      final pick = _benchPick(team, out);
      if (pick == null) {
        _subsUsed[team]++;
        continue;
      }
      _announceSub(team, out, pick, 'T');
    }
  }

  Player? _benchPick(int team, _Agent out) {
    Player? pick;
    for (final p in _bench[team]) {
      if (naturalSpot(p).family == out.spot.family ||
          p.position == out.player.position) {
        pick = p;
        break;
      }
    }
    pick ??= _bench[team].firstWhere(
      (p) => p.position != PlayerPosition.goalkeeper,
      orElse: () => _bench[team].first,
    );
    if (pick.position == PlayerPosition.goalkeeper && !out.isGk) return null;
    return pick;
  }

  /// Le quatrième arbitre lève le panneau ; le joueur remplacé sort vers le
  /// banc (au milieu de la ligne de touche) pendant l'arrêt de jeu.
  void _announceSub(int team, _Agent out, Player pick, String reason) {
    _subsUsed[team]++;
    _bench[team].remove(pick);
    _swaps.add(_Swap(team, out, pick, reason));
    _ev('SBA', team, a: out.player.name, b: pick.name, x: _len / 2, y: _wid);
    _extra = min(360.0, _extra + 8);
    final speed = reason == 'I' ? 1.1 : 2.6;
    final d = _hyp(out.x, out.y, _len / 2, _wid);
    final need = (d / speed + 2).clamp(8.0, 40.0).toDouble();
    if (_deadLeft < need) _deadLeft = need;
    _place(out, _len / 2 + (team == 0 ? -2.5 : 2.5), _wid, speed);
  }

  /// Fin de l'arrêt de jeu : les remplaçants entrent, les expulsés sortent.
  void _swapPending() {
    for (final w in _swaps) {
      final team = w.team;
      final idx = _teams[team].indexOf(w.out);
      if (idx < 0) continue;
      final out = w.out;
      final pick = w.inn;
      final boost = out.eff / max(1.0, out.player.skill * out.player.form);
      final inn = out.replacedBy(
        pick,
        (pick.skill *
                pick.form *
                boost *
                spotFit(pick, out.spot) *
                fitnessFactor(pick.fitness))
            .clamp(20.0, 110.0)
            .toDouble(),
      );
      inn.x = _len / 2 + (team == 0 ? -1.0 : 1.0);
      inn.y = _wid;
      out.active = false;
      _retired.add(out);
      _teams[team][idx] = inn;
      if (_carrier == out) _carrier = null;
      _subs.add(
        '$_minute|${team == 0 ? 1 : 0}|${out.player.name}|${pick.name}',
      );
      _ev('SB', team, a: out.player.name, b: pick.name, x: _len / 2, y: _wid);
    }
    _swaps.clear();
    for (final a in _leaving) {
      a.active = false;
      if (_carrier == a) _carrier = null;
    }
    _leaving.clear();
  }

  // ---------- journal et arrêts de jeu ----------

  bool get _flip => _t >= 2700;

  int _qx(double v) =>
      ((_flip ? _len - v : v) / _len * 255).round().clamp(0, 255).toInt();

  int _qy(double v) =>
      ((_flip ? _wid - v : v) / _wid * 255).round().clamp(0, 255).toInt();

  /// Événement du journal : « seconde|code|1 si domicile|a|b|x|y »
  /// (coordonnées 0..255 dans le repère de l'écran).
  void _ev(
    String code,
    int team, {
    String a = '',
    String b = '',
    double? x,
    double? y,
  }) {
    String clean(String v) => v.replaceAll('|', ' ');
    _log.add(
      '${_t.toStringAsFixed(1)}|$code|${team == 0 ? 1 : 0}|${clean(a)}|'
      '${clean(b)}|${_qx(x ?? _bx)}|${_qy(y ?? _by)}',
    );
  }

  /// Arrête le jeu [seconds] secondes (ballon posé), puis lance [then].
  void _dead(
    double seconds,
    void Function() then, {
    double? ballX,
    double? ballY,
    bool allowSubs = true,
  }) {
    _deadLeft = max(_deadLeft, seconds);
    _deadThen = then;
    _deadPos.clear();
    _carrier = null;
    _flightLeft = 0;
    _onLand = null;
    _carrying = false;
    _bz = 0;
    if (ballX != null) _bx = ballX.clamp(0.0, _len).toDouble();
    if (ballY != null) _by = ballY.clamp(0.0, _wid).toDouble();
    if (allowSubs) _maybeSubs();
    // Les remplacés gardent leur trajet vers le banc.
    for (final w in _swaps) {
      final speed = w.reason == 'I' ? 1.1 : 2.6;
      _place(w.out, _len / 2 + (w.team == 0 ? -2.5 : 2.5), _wid, speed);
    }
    for (final a in _leaving) {
      _place(a, _len / 2, _wid, 2.2);
    }
  }

  void _place(_Agent a, double x, double y, [double speed = 3.2]) {
    if (_swaps.any((w) => w.out == a) && y != _wid) return;
    _deadPos[a] = _Pt(
      x.clamp(0.3, _len - 0.3).toDouble(),
      y.clamp(0.0, _wid).toDouble(),
      speed,
    );
  }

  /// Déplacements pendant un arrêt de jeu : chacun rejoint sa place.
  void _moveDead() {
    for (final team in _teams) {
      for (final a in team) {
        if (!a.active) continue;
        final target = _deadPos[a];
        if (target != null) {
          _walk(a, target.x, target.y, target.speed);
        } else {
          final poss = _possTeam == a.team;
          final p = _shape(a, poss);
          _walk(a, p.x, p.y, 1.6);
        }
      }
    }
  }

  void _walk(_Agent a, double tx, double ty, double v) {
    final dx = tx - a.x;
    final dy = ty - a.y;
    final d = sqrt(dx * dx + dy * dy);
    if (d < 0.05) return;
    var step = v * _dt;
    if (step > d) step = d;
    a.x = (a.x + dx / d * step).clamp(0.0, _len).toDouble();
    a.y = (a.y + dy / d * step).clamp(0.0, _wid).toDouble();
    a.dist += step;
  }

  /// L'arbitre suit l'action en diagonale ; les assistants suivent
  /// l'avant-dernier défenseur (ou le ballon s'il est plus près du but).
  void _moveOfficials() {
    double tx;
    double ty;
    final focus = _refFocus;
    if (focus != null) {
      tx = focus.x;
      ty = focus.y;
    } else {
      final dir = _possTeam == 0 ? 1.0 : -1.0;
      tx = _bx - dir * 11;
      ty = _by + (_by < _wid / 2 ? 9 : -9);
    }
    tx = tx.clamp(4.0, _len - 4).toDouble();
    ty = ty.clamp(4.0, _wid - 4).toDouble();
    final dx = tx - _rx;
    final dy = ty - _ry;
    final d = sqrt(dx * dx + dy * dy);
    if (d > 0.05) {
      final v = d > 10 ? 6.8 : (d > 3 ? 4.0 : 1.5);
      final step = min(d, v * _dt);
      _rx += dx / d * step;
      _ry += dy / d * step;
    }
    // Assistants, dans le repère de l'écran (ils restent de leur côté).
    final flip = _flip;
    double sx(double v) => flip ? _len - v : v;
    final rightDef = flip ? 0 : 1;
    List<double> xs(int team) =>
        [for (final a in _teams[team]) if (a.active) sx(a.x)]..sort();
    final r = xs(rightDef);
    final l = xs(1 - rightDef);
    final bx = sx(_bx);
    final rLine = r.length >= 2 ? r[r.length - 2] : _len * 0.75;
    final lLine = l.length >= 2 ? l[1] : _len * 0.25;
    final t1 = max(rLine, bx).clamp(_len / 2, _len - 0.5).toDouble();
    final t2 = min(lLine, bx).clamp(0.5, _len / 2).toDouble();
    _l1 += (t1 - _l1).clamp(-3.5, 3.5).toDouble();
    _l2 += (t2 - _l2).clamp(-3.5, 3.5).toDouble();
  }

  _Agent _keeper(int team) {
    for (final a in _teams[team]) {
      if (a.active && a.isGk) return a;
    }
    return _teams[team].firstWhere((a) => a.active,
        orElse: () => _teams[team].first);
  }

  /// Joueur actif de [team] le plus proche du point (gardien exclu).
  _Agent _nearest(int team, double x, double y, {bool keeper = false}) {
    _Agent? best;
    for (final a in _teams[team]) {
      if (!a.active || (a.isGk && !keeper) || _leaving.contains(a)) continue;
      if (_swaps.any((w) => w.out == a)) continue;
      if (best == null || _hyp(a.x, a.y, x, y) < _hyp(best.x, best.y, x, y)) {
        best = a;
      }
    }
    return best ?? _keeper(team);
  }

  /// Meilleur tireur de coups de pied arrêtés.
  _Agent _setPieceTaker(int team) {
    _Agent? best;
    for (final a in _teams[team]) {
      if (!a.active || a.isGk || _leaving.contains(a)) continue;
      if (_swaps.any((w) => w.out == a)) continue;
      final w = a.eff * (a.isMid ? 1.15 : (a.isFwd ? 1.05 : 0.9));
      if (best == null ||
          w > best.eff * (best.isMid ? 1.15 : (best.isFwd ? 1.05 : 0.9))) {
        best = a;
      }
    }
    return best ?? _keeper(team);
  }

  /// Le joueur prévu est-il encore là ? Sinon le plus proche du ballon.
  _Agent _still(_Agent a) =>
      a.active && !_leaving.contains(a) ? a : _nearest(a.team, _bx, _by);

  /// Coup d'envoi : position dans son camp (repère absolu).
  _Pt _kickoffSpot(_Agent a) {
    var fx = min(a.ax, 49.0);
    if (a.isFwd) fx = min(fx, 45.0);
    final fy = a.ay;
    return _Pt(a.team == 0 ? fx : _len - fx, a.team == 0 ? fy : _wid - fy, 4);
  }

  /// Touche : le ballon sort sur le côté, un joueur de [team] la joue.
  void _throwIn(int team, double x, double y) {
    final ty = y < _wid / 2 ? 0.0 : _wid;
    final tx = x.clamp(2.0, _len - 2.0).toDouble();
    _throwIns[team]++;
    final taker = _nearest(team, tx, ty);
    _possTeam = team;
    _ev('TI', team, a: taker.player.name, x: tx, y: ty);
    _dead(4.5, () {
      final t = _still(taker);
      t.x = tx;
      t.y = ty;
      _giveTo(t, 0.4);
    }, ballX: tx, ballY: ty);
    _place(taker, tx, ty, 5);
  }

  /// Six mètres : le gardien de [team] dégage.
  void _goalKick(int team) {
    final gk = _keeper(team);
    final gx = team == 0 ? 5.5 : _len - 5.5;
    final gy = _by < _wid / 2 ? _wid / 2 - 9.16 : _wid / 2 + 9.16;
    _possTeam = team;
    _ev('GK', team, a: gk.player.name, x: gx, y: gy);
    _dead(8, () {
      final k = _still(gk);
      k.x = gx;
      k.y = gy;
      _giveTo(k, 0.4);
    }, ballX: gx, ballY: gy);
    _place(gk, gx, gy, 3);
  }

  List<_Agent> _build(
    List<Player> players,
    int team,
    Tactic tactic,
    double boost,
  ) {
    final slots = layoutOf(tactic.formation);
    final xi = lineupSlots(players, tactic.formation);
    final m = tactic.style.level;
    final wf = 0.8 + 0.1 * tactic.width;
    final out = <_Agent>[];
    for (var i = 0; i < slots.length; i++) {
      final slot = slots[i];
      final p = xi[i] ?? players[i % players.length];
      final role = tactic.roleAt(i);
      final instr = tactic.instructionAt(i);
      final fit = spotFit(p, slot.spot);
      final eff = (p.skill * p.form * boost * fit * fitnessFactor(p.fitness))
          .clamp(20.0, 110.0)
          .toDouble();
      var x = slot.x * _len;
      var y = slot.y * _wid;
      if (slot.spot != Spot.gb) {
        x += m * 2.5;
        if (slot.spot.line != PlayerPosition.forward) {
          x += (tactic.lineHeight - 2) * 3.0;
        }
        x += role.advance + instr.advance;
        y = _wid / 2 + (y - _wid / 2) * wf * role.wide * instr.wide;
      }
      out.add(
        _Agent(
          player: p,
          team: team,
          ax: x.clamp(3.0, 100.0).toDouble(),
          ay: y.clamp(3.0, _wid - 3).toDouble(),
          eff: eff,
          phase: _r.nextDouble() * 6.28,
          spot: slot.spot,
          role: role,
          instr: instr,
        ),
      );
    }
    return out;
  }

  /// Remet tout le monde à sa place et donne le coup d'envoi.
  void _reset(int kickoffTeam) {
    for (final team in _teams) {
      for (final a in team) {
        if (!a.active) continue;
        final p = _kickoffSpot(a);
        a.x = p.x;
        a.y = p.y;
      }
    }
    _bx = _len / 2;
    _by = _wid / 2;
    _bz = 0;
    _flightLeft = 0;
    _onLand = null;
    final starters = _teams[kickoffTeam].where((a) => a.active && !a.isGk);
    _Agent? best;
    for (final a in starters) {
      if (best == null ||
          _hyp(a.x, a.y, _bx, _by) < _hyp(best.x, best.y, _bx, _by)) {
        best = a;
      }
    }
    if (best != null) {
      best.x = _len / 2 + (kickoffTeam == 0 ? -0.6 : 0.6);
      best.y = _wid / 2;
    }
    _carrier = best;
    _possTeam = kickoffTeam;
    _hold = 1.5;
    _carrying = false;
    _lastPasser = null;
    _refFocus = null;
    _rx = _len / 2 - 10;
    _ry = _wid / 2 + 8;
    _ev('KO', kickoffTeam, a: best?.player.name ?? '');
  }

  int get _minute => ((_t / 60).floor() + 1).clamp(1, 90).toInt();

  double _bfx(int team) => team == 0 ? _bx : _len - _bx;

  double _bfy(int team) => team == 0 ? _by : _wid - _by;

  /// Ligne de hors-jeu : avant-dernier défenseur adverse (repère de [team]).
  double _offLine(int team) {
    final line = <double>[];
    for (final o in _teams[1 - team]) {
      if (!o.active) continue;
      line.add(team == 0 ? o.x : _len - o.x);
    }
    line.sort((a, b) => b.compareTo(a));
    if (line.isEmpty) return _len;
    return line.length > 1 ? line[1] : line[0];
  }

  /// Enregistre une image (une par seconde de jeu) : 22 joueurs, ballon,
  /// arbitre, deux assistants, hauteur du ballon et état du jeu.
  void _record() {
    int qx(double v) => (v / _len * 255).round().clamp(0, 255).toInt();
    int qy(double v) => (v / _wid * 255).round().clamp(0, 255).toInt();
    // Après la mi-temps, les équipes changent de côté.
    final flip = _flip;
    double fx(double v) => flip ? _len - v : v;
    double fy(double v) => flip ? _wid - v : v;
    for (final team in _teams) {
      for (final a in team) {
        // Joueur sorti : hors du terrain (0, 0), ignoré au rejeu.
        _track.add(a.active ? max(1, qx(fx(a.x))) : 0);
        _track.add(a.active ? qy(fy(a.y)) : 0);
      }
    }
    _track.add(qx(fx(_bx)));
    _track.add(qy(fy(_by)));
    _track.add(qx(fx(_rx)));
    _track.add(qy(fy(_ry)));
    // Assistants : déjà dans le repère de l'écran (haut et bas).
    _track.add(qx(_l1));
    _track.add(0);
    _track.add(qx(_l2));
    _track.add(255);
    _track.add((_bz / 16 * 255).round().clamp(0, 255).toInt());
    _track.add(_deadLeft > 0 ? 1 : 0);
  }

  void _step() {
    if (_deadLeft > 0) {
      _deadLeft -= _dt;
      _moveDead();
      if (_deadLeft <= 0) {
        _deadLeft = 0;
        _swapPending();
        _refFocus = null;
        final then = _deadThen;
        _deadThen = null;
        _deadPos.clear();
        if (then != null) then();
      }
      _moveOfficials();
      return;
    }
    // Sécurité : le ballon ne reste jamais sans porteur.
    if (_carrier == null && _flightLeft <= 0) {
      _Agent? any;
      for (final a in _teams[_possTeam]) {
        if (a.active && !a.isGk) {
          any = a;
          break;
        }
      }
      any ??= _teams[_possTeam].firstWhere((a) => a.active);
      _giveTo(any, 1.0);
    }
    // Vol du ballon.
    if (_flightLeft > 0) {
      _flightLeft -= _dt;
      final k = 1 - (_flightLeft / _flightTotal).clamp(0.0, 1.0);
      _bx = _fsx + (_fex - _fsx) * k;
      _by = _fsy + (_fey - _fsy) * k;
      _bz = 4 * _apex * k * (1 - k);
      if (_flightLeft <= 0) {
        _bz = 0;
        final land = _onLand;
        _onLand = null;
        if (land != null) land();
      }
    } else if (_carrier != null) {
      final c = _carrier!;
      _bx = c.x;
      _by = c.y;
      _bz = 0;
      _hold -= _dt;
      _tackleCd -= _dt;
      _tryTackle(c);
      if (_carrier == c && _hold <= 0 && _flightLeft <= 0 && _deadLeft <= 0) {
        _decide(c);
      }
    }

    if (_deadLeft > 0) {
      _moveDead();
    } else {
      _poss[_carrier?.team ?? _possTeam] += 1;
      _moveAll();
    }
    _moveOfficials();
  }

  // ---------- déplacements ----------

  void _moveAll() {
    // Les presseurs : les joueurs adverses les plus proches du ballon.
    final pressers = <_Agent>{};
    for (final team in [0, 1]) {
      final carrier = _carrier;
      final needs = carrier == null || carrier.team != team;
      if (!needs) continue;
      final tactic = team == 0 ? _tacticHome : _tacticAway;
      var count = 1;
      if (tactic.pressing == Pressing.high) count = 2;
      if (tactic.pressing == Pressing.veryHigh) count = 3;
      if (tactic.playStyle == PlayStyle.intensePress) count++;
      if (tactic.transition == Transition.counterPress) count++;
      if (count > 4) count = 4;
      final sorted = _teams[team].where((a) => a.active && !a.isGk).toList()
        ..sort(
          (a, b) => _hyp(a.x, a.y, _bx, _by)
              .compareTo(_hyp(b.x, b.y, _bx, _by)),
        );
      // Pressing bas : on ne presse que dans sa moitié de terrain.
      if (tactic.pressing == Pressing.low && _bfx(team) > 60) continue;
      pressers.addAll(sorted.take(count));
    }

    for (final team in _teams) {
      for (final a in team) {
        if (!a.active) continue;
        final poss = (_carrier?.team ?? _possTeam) == a.team;
        if (a == _carrier) {
          _moveCarrier(a);
          continue;
        }
        if (pressers.contains(a)) {
          _move(a, _bx, _by, true);
          continue;
        }
        final p = _shape(a, poss);
        _move(a, p.x, p.y, poss && a.isFwd && _carrier != null);
      }
    }
  }

  /// Place de [a] dans le bloc de son équipe (repère absolu).
  _Pt _shape(_Agent a, bool poss) {
    var tx = a.ax;
    var ty = a.ay;
    if (a.isGk) {
      tx = 4 + (_bfx(a.team) - 52.5) * 0.04;
      ty = 34 + (_bfy(a.team) - 34) * 0.2;
    } else {
      tx += (_bfx(a.team) - 52.5) * 0.5;
      ty += (_bfy(a.team) - 34) * 0.22;
      final tac = a.team == 0 ? _tacticHome : _tacticAway;
      if (poss) {
        tx += a.isFwd ? 9 : (a.isMid ? 5 : 2);
      } else {
        var back = 3.0 + 6 * a.defWork;
        if (tac.transition == Transition.regroup) back += 3;
        if (a.isFwd &&
            (tac.transition == Transition.counter ||
                tac.playStyle == PlayStyle.counter)) {
          back = 0;
        }
        tx -= back;
      }
      tx += sin(_t * 0.22 + a.phase) * 5;
      ty += cos(_t * 0.17 + a.phase * 1.3) * 5;
      if (poss && a.isFwd) {
        final limit = _offLine(a.team) + 0.5;
        if (tx > limit && _r.nextDouble() < 0.9) tx = limit;
      }
    }
    tx = tx.clamp(2.0, 103.0).toDouble();
    ty = ty.clamp(2.0, 66.0).toDouble();
    return _Pt(a.team == 0 ? tx : _len - tx, a.team == 0 ? ty : _wid - ty);
  }

  void _moveCarrier(_Agent c) {
    final goalX = c.team == 0 ? _len : 0.0;
    if (_carrying) {
      final ty = 34 + (c.y - 34) * 0.7;
      _move(c, goalX, ty, true, cap: 5.4);
    } else {
      final dir = c.team == 0 ? 1.0 : -1.0;
      _move(c, c.x + dir * 3, c.y, false, cap: 1.5);
    }
  }

  void _move(
    _Agent a,
    double tx,
    double ty,
    bool sprint, {
    double? cap,
  }) {
    final dx = tx - a.x;
    final dy = ty - a.y;
    final d = sqrt(dx * dx + dy * dy);
    if (d < 1e-6) return;
    var vmax = a.isGk ? 3.2 : (sprint ? 7.0 : 3.6);
    vmax *= (0.8 + 0.2 * a.stamina) * (0.92 + a.eff / 800);
    if (cap != null && vmax > cap) vmax = cap;
    final v = min(vmax, max(a.isGk ? 0.6 : 1.5, d * 0.9));
    var step = v * _dt;
    if (step > d) step = d;
    a.x = (a.x + dx / d * step).clamp(0.0, _len).toDouble();
    a.y = (a.y + dy / d * step).clamp(0.0, _wid).toDouble();
    a.dist += step;
    if (!a.isGk) {
      final ageFactor = 1 + (a.player.age - 26) * 0.02;
      a.stamina = max(0.55, a.stamina - step * 0.00004 * ageFactor);
    }
  }

  // ---------- duels et fautes ----------

  /// Retard sur le scénario de tirs (secondes) : l'équipe pousse.
  double _late(int team) {
    final q = _qWhen[team];
    if (q.isEmpty) return 0;
    return max(0.0, _t - q.first);
  }

  bool _avail(_Agent a) =>
      a.active && !_leaving.contains(a) && !_swaps.any((w) => w.out == a);

  void _tryTackle(_Agent c) {
    if (_tackleCd > 0) return;
    _Agent? tk;
    var best = 1.8;
    for (final o in _teams[1 - c.team]) {
      if (!o.active || o.isGk) continue;
      final d = _hyp(o.x, o.y, c.x, c.y);
      if (d < best) {
        best = d;
        tk = o;
      }
    }
    if (tk == null) return;
    _tackleCd = 1.2;
    final ratio = pow(tk.eff / c.eff, 0.8).toDouble();
    var win = (0.32 * ratio * (_carrying ? 1.0 : 0.85))
        .clamp(0.06, 0.5)
        .toDouble();
    // Une équipe en retard sur son scénario récupère plus vite le ballon.
    if (_late(tk.team) > 120) win = min(0.7, win * 1.8);
    final roll = _r.nextDouble();
    if (roll < win) {
      tk.tackles++;
      c.lost++;
      _carrier = tk;
      _possTeam = tk.team;
      _hold = 0.8;
      _carrying = false;
      _lastPasser = null;
    } else if (roll < win + _foulChance(tk, c)) {
      _foul(tk, c);
    }
  }

  /// Risque de faute sur un duel. Dans sa propre surface, un défenseur
  /// prend rarement le risque (un penalty tous les trois ou quatre matchs,
  /// comme en vrai), et encore moins après un premier penalty concédé.
  double _foulChance(_Agent tk, _Agent c) {
    final ownGoalX = tk.team == 0 ? 0.0 : _len;
    final inBox =
        (c.x - ownGoalX).abs() < 16.5 && (c.y - 34).abs() < 20.15;
    if (inBox) return _pens[c.team] >= 1 ? 0.002 : 0.008;
    return _rain ? 0.09 : 0.07;
  }

  /// Faute : coup de sifflet, carton éventuel, blessure éventuelle, puis
  /// coup franc ou penalty joué sur le terrain.
  void _foul(_Agent fouler, _Agent victim) {
    final team = victim.team;
    _fouls[fouler.team]++;
    fouler.fouls++;
    _extra = min(360.0, _extra + 12);
    final fx = victim.x;
    final fy = victim.y;
    _possTeam = team;
    _ev('FL', fouler.team,
        a: fouler.player.name, b: victim.player.name, x: fx, y: fy);
    var card = '';
    final roll = _r.nextDouble();
    if (roll < 0.01) {
      card = 'R';
    } else if (roll < 0.18) {
      fouler.yellows++;
      _yellow[fouler.team]++;
      card = fouler.yellows >= 2 ? 'R2' : 'Y';
    }
    final ownGoalX = fouler.team == 0 ? 0.0 : _len;
    final inBox = (fx - ownGoalX).abs() < 16.5 && (fy - 34).abs() < 20.15;
    final injured = _r.nextDouble() < 0.035;
    final severe = injured && _r.nextDouble() < 0.45;

    if (inBox) {
      _penaltyAward(team, victim);
    } else {
      _freeKick(team, fx, fy);
    }
    var wait = 0.0;
    if (card.isNotEmpty) {
      _card(fouler, card == 'Y' ? 'Y' : 'R');
      _ev(card == 'Y' ? 'YC' : 'RC', fouler.team,
          a: fouler.player.name,
          b: card == 'R2' ? '2' : '',
          x: fouler.x,
          y: fouler.y);
      _refFocus =
          _Pt(fouler.x + (fouler.x < _len / 2 ? 1.6 : -1.6), fouler.y);
      wait += 12;
      _extra = min(360.0, _extra + 10);
      if (card != 'Y') _sendOff(fouler);
    }
    if (injured && victim.active) {
      _ev('IN', team,
          a: victim.player.name, b: severe ? 'S' : '', x: victim.x, y: victim.y);
      wait += severe ? 30 : 20;
      _extra = min(360.0, _extra + (severe ? 45 : 30));
      // Le joueur reste au sol, les soigneurs entrent.
      _place(victim, victim.x, victim.y, 0);
      if (severe) {
        _injured.add(victim.player.id);
        if (_subsUsed[team] < 3 && _bench[team].isNotEmpty && !victim.isGk) {
          final pick = _benchPick(team, victim);
          if (pick != null) _announceSub(team, victim, pick, 'I');
        }
      }
    }
    if (wait > 0) _deadLeft += wait;
  }

  void _card(_Agent a, String kind) {
    _cards.add('$_minute|${a.team == 0 ? 1 : 0}|${a.player.name}|$kind');
  }

  /// Expulsion : le joueur quitte le terrain pendant l'arrêt de jeu.
  void _sendOff(_Agent a) {
    if (!a.active || _leaving.contains(a)) return;
    a.reds++;
    _red[a.team]++;
    if (a.yellows >= 2) _yellow[a.team]--;
    _leaving.add(a);
    _place(a, _len / 2, _wid, 2.2);
    if (_carrier == a) _carrier = null;
  }

  // ---------- coups de pied arrêtés ----------

  /// Coup franc : court s'il est loin du but ; sinon mur, joueurs dans la
  /// surface, puis frappe directe ou centre.
  void _freeKick(int team, double x, double y) {
    final goalX = team == 0 ? _len : 0.0;
    final dir = team == 0 ? 1.0 : -1.0;
    final dist = _hyp(x, y, goalX, 34);
    final dangerous = dist < 33 && (y - 34).abs() < 26;
    final taker = dangerous ? _setPieceTaker(team) : _nearest(team, x, y);
    _ev('FK', team, a: taker.player.name, b: dangerous ? 'D' : '', x: x, y: y);
    if (!dangerous) {
      _dead(6, () => _restart(_still(taker), x, y), ballX: x, ballY: y);
      _place(taker, x - dir * 0.8, y, 4);
      return;
    }
    _dead(17, () => _takeDangerousFk(team, _still(taker), x, y),
        ballX: x, ballY: y);
    _place(taker, x - dir * 1.4, y + 0.8, 3);
    _buildWall(1 - team, x, y, goalX);
    _fillBox(team, goalX, taker, 4);
    final gk = _keeper(1 - team);
    _place(gk, goalX - dir * 0.8, 34 + (y - 34) * 0.12, 3);
  }

  /// Reprise simple : le joueur pose le ballon et joue.
  void _restart(_Agent t, double x, double y) {
    t.x = x;
    t.y = y;
    _giveTo(t, 0.3);
  }

  /// Mur à 9,15 m, entre le ballon et le but (3 à 5 joueurs).
  void _buildWall(int team, double x, double y, double goalX) {
    final dx = goalX - x;
    final dy = 34 - y;
    final d = max(1.0, sqrt(dx * dx + dy * dy));
    final ux = dx / d;
    final uy = dy / d;
    final cx = x + ux * 9.15;
    final cy = y + uy * 9.15;
    final size = d < 22 ? 5 : (d < 28 ? 4 : 3);
    final pool = [
      for (final a in _teams[team])
        if (_avail(a) && !a.isGk) a,
    ]..sort(
        (a, b) => _hyp(a.x, a.y, cx, cy).compareTo(_hyp(b.x, b.y, cx, cy)),
      );
    for (var i = 0; i < size && i < pool.length; i++) {
      final off = (i - (size - 1) / 2) * 0.75;
      _place(pool[i], cx - uy * off, cy + ux * off, 4);
    }
  }

  double _aerial(_Agent a) =>
      a.eff *
      (a.isFwd
          ? 1.25
          : (a.player.position == PlayerPosition.defender ? 1.15 : 0.9));

  /// [count] joueurs de [team] montent dans la surface (les meilleurs de la
  /// tête), deux restent à l'entrée ; la défense les marque à la culotte.
  void _fillBox(int team, double goalX, _Agent taker, int count) {
    final dir = team == 0 ? 1.0 : -1.0;
    final pool = [
      for (final a in _teams[team])
        if (_avail(a) && !a.isGk && a != taker && !_deadPos.containsKey(a)) a,
    ]..sort((a, b) => _aerial(b).compareTo(_aerial(a)));
    final runners = <_Agent>[];
    for (var i = 0; i < count && i < pool.length; i++) {
      final depth = 5.5 + _r.nextDouble() * 9;
      final lat = (_r.nextDouble() - 0.5) * 16;
      _place(pool[i], goalX - dir * depth, 34 + lat, 4.5);
      runners.add(pool[i]);
    }
    for (var i = count; i < count + 2 && i < pool.length; i++) {
      _place(
        pool[i],
        goalX - dir * (19 + _r.nextDouble() * 4),
        34 + (i.isEven ? -8.0 : 8.0),
        3.5,
      );
    }
    final markers = [
      for (final a in _teams[1 - team])
        if (_avail(a) && !a.isGk && !_deadPos.containsKey(a)) a,
    ];
    for (final att in runners) {
      if (markers.isEmpty) break;
      final target = _deadPos[att];
      if (target == null) continue;
      markers.sort(
        (a, b) => _hyp(a.x, a.y, target.x, target.y)
            .compareTo(_hyp(b.x, b.y, target.x, target.y)),
      );
      final m = markers.removeAt(0);
      _place(m, target.x + dir * 0.9, target.y + (_r.nextDouble() - 0.5), 4.5);
    }
  }

  void _takeDangerousFk(int team, _Agent t, double x, double y) {
    t.x = x;
    t.y = y;
    final goalX = team == 0 ? _len : 0.0;
    final dist = _hyp(x, y, goalX, 34);
    final q = _qWhen[team];
    final due = q.isNotEmpty && q.first - _t < 420;
    if (due && dist < 30 && _r.nextDouble() < 0.55) {
      _shoot(t, dist, 6, kind: 'F');
    } else {
      _cross(t, team);
    }
  }

  /// Corner : le tireur au poteau de corner, les grands dans la surface.
  void _corner(int team) {
    _corners[team]++;
    final goalX = team == 0 ? _len : 0.0;
    final dir = team == 0 ? 1.0 : -1.0;
    final cx = team == 0 ? _len - 0.3 : 0.3;
    final cy = _by < _wid / 2 ? 0.3 : _wid - 0.3;
    final taker = _setPieceTaker(team);
    _possTeam = team;
    _ev('CK', team, a: taker.player.name, x: cx, y: cy);
    _dead(14, () {
      final t = _still(taker);
      t.x = cx;
      t.y = cy;
      _cross(t, team);
    }, ballX: cx, ballY: cy);
    _place(taker, cx - dir * 0.4, cy, 5);
    _fillBox(team, goalX, taker, 5);
    final gk = _keeper(1 - team);
    _place(gk, goalX - dir * 0.8, 34 + (cy < _wid / 2 ? -1.5 : 1.5), 3);
  }

  /// Centre dans la surface vers le meilleur joueur de la tête.
  void _cross(_Agent t, int team) {
    final goalX = team == 0 ? _len : 0.0;
    _Agent? target;
    var best = -1.0;
    for (final a in _teams[team]) {
      if (!a.active || a.isGk || a == t) continue;
      if ((a.x - goalX).abs() > 18 || (a.y - 34).abs() > 20) continue;
      final w = _aerial(a) * (0.6 + _r.nextDouble());
      if (w > best) {
        best = w;
        target = a;
      }
    }
    final m = target ?? _nearest(team, goalX - (team == 0 ? 11 : -11), 34);
    _possTeam = team;
    _ev('CR', team, a: t.player.name, x: t.x, y: t.y);
    t.passes++;
    _lastPasser = t;
    _lastPassT = _t;
    final passer = t;
    _launch(t.x, t.y, m.x, m.y, 1.4, () => _aerialDuel(team, m, passer),
        apex: 5.5);
  }

  void _aerialDuel(int team, _Agent m, _Agent passer) {
    final goalX = team == 0 ? _len : 0.0;
    final gk = _keeper(1 - team);
    final q = _qWhen[team];
    final due = q.isNotEmpty && q.first - _t < 300;
    final roll = _r.nextDouble();
    if (roll < 0.16 && gk.active && gk.isGk) {
      // Sortie aérienne du gardien.
      final dx = _bx - gk.x;
      final dy = _by - gk.y;
      final d = max(0.1, sqrt(dx * dx + dy * dy));
      final step = min(d, 5.0);
      gk.x += dx / d * step;
      gk.y += dy / d * step;
      _ev('SV', 1 - team, a: gk.player.name, b: 'C');
      _giveTo(gk, 3.5);
      return;
    }
    if (due && m.active) {
      passer.passesOk++;
      _lastPasser = passer;
      _lastPassT = _t;
      _shoot(m, _hyp(m.x, m.y, goalX, 34), 1.5, kind: 'H');
      return;
    }
    // La défense dégage de la tête.
    final d = _nearest(1 - team, _bx, _by);
    d.interceptions++;
    _ev('CL', 1 - team, a: d.player.name);
    final r2 = _r.nextDouble();
    if (r2 < 0.12) {
      _corner(team);
      return;
    }
    final dirOut = team == 0 ? -1.0 : 1.0;
    final ex =
        (_bx + dirOut * (18 + _r.nextDouble() * 22)).clamp(2.0, _len - 2).toDouble();
    final ey = (_by + (_r.nextDouble() - 0.5) * 40).clamp(1.0, _wid - 1).toDouble();
    _launch(_bx, _by, ex, ey, 1.6, () {
      if (r2 < 0.27) {
        _throwIn(team, ex, ey < _wid / 2 ? 0.0 : _wid);
      } else {
        _loose(ex, ey);
      }
    }, apex: 9);
  }

  /// Ballon libre : le joueur le plus proche le récupère.
  void _loose(double x, double y) {
    _Agent? best;
    for (final side in _teams) {
      for (final a in side) {
        if (!a.active) continue;
        if (best == null || _hyp(a.x, a.y, x, y) < _hyp(best.x, best.y, x, y)) {
          best = a;
        }
      }
    }
    if (best != null) _giveTo(best, 0.6);
  }

  /// Penalty : tout le monde hors de la surface, le tireur face au gardien.
  void _penaltyAward(int team, _Agent victim) {
    _Agent? taker;
    for (final a in _teams[team]) {
      if (!_avail(a) || a.isGk) continue;
      if (taker == null || a.eff > taker.eff) taker = a;
    }
    final k = taker ?? victim;
    final goalX = team == 0 ? _len : 0.0;
    final dir = team == 0 ? 1.0 : -1.0;
    final spotX = goalX - dir * 11;
    _pens[team]++;
    _possTeam = team;
    _extra = min(360.0, _extra + 20);
    _ev('PK', team, a: k.player.name, x: spotX, y: 34);
    _dead(26, () => _takePenalty(team, _still(k)),
        ballX: spotX, ballY: 34, allowSubs: false);
    _place(k, spotX - dir * 2.2, 35.2, 2);
    final gk = _keeper(1 - team);
    _place(gk, goalX - dir * 0.3, 34, 2);
    var i = 0;
    for (final side in _teams) {
      for (final a in side) {
        if (!_avail(a) || a == k || a.isGk) continue;
        final lane = (i % 10) - 4.5;
        final depth = 18.5 + (i % 3) * 1.6;
        _place(a, goalX - dir * depth, 34 + lane * 3.2, 3);
        i++;
      }
    }
    _refFocus = _Pt(spotX - dir * 5, 34 + 9);
  }

  void _takePenalty(int team, _Agent taker) {
    final gk = _keeper(1 - team);
    final goalX = team == 0 ? _len : 0.0;
    final dir = team == 0 ? 1.0 : -1.0;
    taker.x = goalX - dir * 11.6;
    taker.y = 34;
    _xg[team] += 0.76;
    final base = 0.77 * pow(taker.eff / max(20.0, gk.eff), 0.35).toDouble();
    final pGoal = base.clamp(0.55, 0.9).toDouble();
    _shots[team]++;
    taker.shots++;
    // Le penalty remplace un tir prévu au scénario (même issue si possible).
    var wantGoal = _r.nextDouble() < pGoal;
    final qo = _qOut[team];
    final qw = _qWhen[team];
    int take(int v) {
      final i = qo.indexOf(v);
      if (i < 0) return -1;
      qo.removeAt(i);
      qw.removeAt(i);
      return v;
    }

    var consumed = -1;
    if (_scripted) {
      if (wantGoal) {
        consumed = take(0);
        if (consumed < 0) wantGoal = false;
      }
      if (!wantGoal) {
        consumed = take(1);
        if (consumed < 0) consumed = take(2);
      }
    } else if (qo.isNotEmpty) {
      // Le penalty remplace une occasion prévue ; son issue se joue ici.
      qo.removeAt(0);
      qw.removeAt(0);
    }
    final saved =
        !wantGoal && (consumed == 1 || (consumed < 0 && _r.nextDouble() < 0.6));
    final outcome = wantGoal ? 'G' : (saved ? 'S' : 'M');
    _chances.add(
      '${(_t / 60).toStringAsFixed(1)}|${team == 0 ? 1 : 0}|'
      '${taker.player.name}|$outcome|76',
    );
    _ev('PKS', team, a: taker.player.name, b: outcome);
    final side = _r.nextBool() ? 1.0 : -1.0;
    final ty = 34 + side * (wantGoal ? 2.4 : (saved ? 1.9 : 5.2));
    _launch(taker.x, taker.y, goalX, ty, 0.5, () {
      if (wantGoal) {
        _onTarget[team]++;
        _goal(taker, null);
      } else if (saved) {
        _onTarget[team]++;
        gk.saves++;
        gk.y = ty;
        _events.add(MatchEvent(
          minute: _minute,
          type: MatchEventType.save,
          isHome: team == 0,
        ));
        _ev('SV', 1 - team, a: gk.player.name);
        if (_r.nextDouble() < 0.3) {
          _corner(team);
        } else {
          _giveTo(gk, 3.5);
        }
      } else {
        _events.add(MatchEvent(
          minute: _minute,
          type: MatchEventType.miss,
          isHome: team == 0,
        ));
        _goalKick(1 - team);
      }
    }, apex: 0.6);
  }

  void _giveTo(_Agent a, double hold) {
    _carrier = a;
    _possTeam = a.team;
    final tc = a.team == 0 ? _tacticHome : _tacticAway;
    var tempo = 1.0;
    if (tc.playStyle == PlayStyle.fastTransition) tempo = 0.75;
    if (tc.playStyle == PlayStyle.possession) tempo = 1.1;
    _hold = hold * tempo;
    _carrying = false;
    _lastPasser = null;
  }

  // ---------- décisions du porteur ----------

  void _decide(_Agent c) {
    final goalX = c.team == 0 ? _len : 0.0;
    final dGoal = _hyp(c.x, c.y, goalX, 34);
    var nearest = 99.0;
    for (final o in _teams[1 - c.team]) {
      if (!o.active) continue;
      final d = _hyp(o.x, o.y, c.x, c.y);
      if (d < nearest) nearest = d;
    }

    final q = _qWhen[c.team];
    final late = _late(c.team);
    if (!c.isGk && q.isNotEmpty && _t >= q.first) {
      final reach = min(38.0, 24 + late / 6);
      final role = (c.isFwd ? 1.0 : (c.isMid ? 0.8 : 0.4)) *
          sqrt(c.role.finishing);
      if (dGoal <= reach * role + 4) {
        _shoot(c, dGoal, nearest);
        return;
      }
    }

    if (!c.isGk) {
      var pDrib = c.isFwd ? 0.30 : (c.isMid ? 0.22 : 0.12);
      pDrib *= nearest > 6 ? 1.3 : 0.8;
      // En retard sur le scénario : on accélère vers le but.
      if (late > 60) pDrib *= 1.6;
      if (_r.nextDouble() < pDrib) {
        _carrying = true;
        _hold = 1.2 + _r.nextDouble() * 1.2;
        return;
      }
    }
    _pass(c, nearest);
  }

  void _launch(
    double sx,
    double sy,
    double ex,
    double ey,
    double seconds,
    void Function() onLand, {
    double apex = 0,
  }) {
    _carrier = null;
    _fsx = sx;
    _fsy = sy;
    _fex = ex;
    _fey = ey;
    _apex = apex;
    _flightTotal = max(0.5, seconds);
    _flightLeft = _flightTotal;
    _onLand = onLand;
  }

  void _pass(_Agent c, double nearest) {
    final tc = c.team == 0 ? _tacticHome : _tacticAway;
    var directness = 1.0 + 0.15 * tc.style.level;
    switch (tc.playStyle) {
      case PlayStyle.direct:
        directness *= 1.4;
        break;
      case PlayStyle.possession:
        directness *= 0.7;
        break;
      case PlayStyle.counter:
      case PlayStyle.fastTransition:
        directness *= 1.2;
        break;
      case PlayStyle.balanced:
      case PlayStyle.intensePress:
      case PlayStyle.wings:
      case PlayStyle.central:
        break;
    }
    if (tc.transition == Transition.counter) directness *= 1.1;
    _Agent? target;
    var bestScore = -999.0;
    for (final m in _teams[c.team]) {
      if (m == c || !m.active) continue;
      final d = _hyp(c.x, c.y, m.x, m.y);
      if (d < 4 || d > (c.isGk ? 60 : 48)) continue;
      final gain = m.fx - c.fx;
      var open = 14.0;
      for (final o in _teams[1 - c.team]) {
        if (!o.active) continue;
        final od = _hyp(o.x, o.y, m.x, m.y);
        if (od < open) open = od;
      }
      var shape = 0.0;
      if (tc.playStyle == PlayStyle.wings && (m.y - 34).abs() > 20) {
        shape = 0.35;
      } else if (tc.playStyle == PlayStyle.central && (m.y - 34).abs() < 12) {
        shape = 0.35;
      }
      final score = gain * 0.05 * directness +
          open * 0.10 -
          d * 0.012 +
          shape +
          _r.nextDouble() * 0.9 / c.role.playmaking;
      if (score > bestScore) {
        bestScore = score;
        target = m;
      }
    }
    if (target == null) {
      _carrying = true;
      _hold = 1.5;
      return;
    }
    final m = target;
    final gain = m.fx - c.fx;

    // Hors-jeu sur une passe vers l'avant : le ballon part, l'assistant
    // lève son drapeau, coup franc indirect pour la défense.
    if (gain > 6 && m.fx > _offLine(c.team) && m.fx > c.fx) {
      if (_r.nextDouble() < 0.8) {
        _offsides[c.team]++;
        c.lost++;
        c.passes++;
        final d0 = _hyp(c.x, c.y, m.x, m.y);
        final rx = m.x;
        final ry = m.y;
        final team = c.team;
        final name = m.player.name;
        _launch(c.x, c.y, rx, ry, max(0.6, d0 / 17), () {
          _ev('OF', team, a: name, x: rx, y: ry);
          final def = 1 - team;
          final taker = _nearest(def, rx, ry);
          _possTeam = def;
          _dead(7, () => _restart(_still(taker), rx, ry),
              ballX: rx, ballY: ry);
          _place(taker, rx, ry, 4);
        }, apex: d0 > 26 ? min(14.0, d0 * 0.2) : 0.2);
        return;
      }
    }

    final d = _hyp(c.x, c.y, m.x, m.y);
    var pOk = 0.98 - d * 0.003 + (c.eff - 65) / 600;
    pOk += (c.role.playmaking - 1) * 0.04;
    if (tc.transition == Transition.keepBall) pOk += 0.02;
    if (tc.playStyle == PlayStyle.direct) pOk -= 0.03;
    if (nearest < 2.5) {
      pOk -= 0.10;
    } else if (nearest < 5) {
      pOk -= 0.04;
    }
    if (gain > 15) pOk -= 0.10;
    if (_rain) pOk -= 0.03;
    pOk = pOk.clamp(0.6, 0.98).toDouble();

    c.passes++;
    // Interception sur la trajectoire.
    _Agent? interceptor;
    for (final o in _teams[1 - c.team]) {
      if (!o.active) continue;
      final dx = m.x - c.x;
      final dy = m.y - c.y;
      final len2 = dx * dx + dy * dy;
      if (len2 < 1e-6) continue;
      var u = ((o.x - c.x) * dx + (o.y - c.y) * dy) / len2;
      if (u < 0.1 || u > 0.95) continue;
      u = u.clamp(0.0, 1.0).toDouble();
      final dseg = _hyp(o.x, o.y, c.x + dx * u, c.y + dy * u);
      if (dseg >= 2.5) continue;
      final p = 0.16 * (1 - dseg / 2.5) * (o.eff / 70);
      if (_r.nextDouble() < p) {
        interceptor = o;
        break;
      }
    }

    final seconds = max(0.6, d / 17);
    final apex = d > 26 ? min(14.0, d * 0.2) : 0.2;
    final sx = c.x;
    final sy = c.y;
    if (interceptor != null) {
      final o = interceptor;
      _launch(sx, sy, o.x, o.y, seconds * 0.6, () {
        o.interceptions++;
        c.lost++;
        _giveTo(o, 0.8);
      }, apex: apex * 0.5);
      return;
    }
    if (_r.nextDouble() < pOk) {
      _launch(sx, sy, m.x, m.y, seconds, () {
        c.passesOk++;
        _lastPasser = c;
        _lastPassT = _t;
        _giveTo(m, 0.6 + _r.nextDouble());
        _lastPasser = c;
      }, apex: apex);
    } else {
      _Agent? recover;
      for (final o in _teams[1 - c.team]) {
        if (!o.active) continue;
        if (recover == null ||
            _hyp(o.x, o.y, m.x, m.y) <
                _hyp(recover.x, recover.y, m.x, m.y)) {
          recover = o;
        }
      }
      final loser = recover;
      final out = _r.nextDouble() < 0.35;
      // Passe trop longue : le ballon sort en touche.
      final ex = m.x;
      final ey = out ? (m.y < _wid / 2 ? 0.0 : _wid) : m.y;
      _launch(sx, sy, ex, ey, seconds, () {
        c.lost++;
        if (out && loser != null) {
          _throwIn(loser.team, ex, ey);
        } else if (loser != null) {
          _giveTo(loser, 0.8);
        }
      }, apex: apex);
    }
  }

  // ---------- tirs et buts ----------

  void _shoot(_Agent c, double dGoal, double pressure, {String kind = 'O'}) {
    final team = c.team;
    final planned = _qOut[team].isEmpty ? 2 : _qOut[team].removeAt(0);
    if (_qWhen[team].isNotEmpty) _qWhen[team].removeAt(0);
    _shots[team]++;
    c.shots++;
    // Buts attendus : distance, angle et pression du défenseur.
    final angle = 1 - ((c.y - 34).abs() / 34).clamp(0.0, 1.0);
    var shotXg = (0.85 * exp(-dGoal / 9.0) * (0.55 + 0.45 * angle) *
            (1 - 0.35 * (1 - (pressure / 6).clamp(0.0, 1.0))))
        .clamp(0.02, 0.7)
        .toDouble();
    if (kind == 'H') shotXg *= 0.65;
    if (kind == 'F') shotXg = min(shotXg, 0.09);
    _xg[team] += shotXg;
    final outcome = _scripted ? planned : _resolve(c, shotXg);
    final letter = const ['G', 'S', 'M', 'B'][outcome.clamp(0, 3)];
    // Occasion : minute précise, équipe, tireur, issue, xG.
    _chances.add(
      '${(_t / 60).toStringAsFixed(1)}|${team == 0 ? 1 : 0}|${c.player.name}|'
      '$letter|${(shotXg * 100).round()}',
    );
    _ev('SH', team, a: c.player.name, b: '$letter$kind', x: c.x, y: c.y);
    final gk = _keeper(1 - team);
    final goalX = team == 0 ? _len : 0.0;
    final onTarget = outcome <= 1;
    final scored = outcome == 0;
    final blocked = outcome == 3;
    final sx = c.x;
    final sy = c.y;

    if (blocked) {
      _Agent? d;
      for (final o in _teams[1 - team]) {
        if (!o.active || o.isGk) continue;
        if (d == null || _hyp(o.x, o.y, sx, sy) < _hyp(d.x, d.y, sx, sy)) {
          d = o;
        }
      }
      final blocker = d ?? gk;
      final kx = sx + (goalX - sx) * 0.12;
      final ky = sy + (34 - sy) * 0.12;
      _launch(sx, sy, kx, ky, 0.5, () {
        blocker.tackles++;
        if (_r.nextDouble() < 0.35) {
          _corner(team);
        } else {
          _giveTo(blocker, 0.8);
        }
      }, apex: 0.3);
      return;
    }

    final side = _r.nextBool() ? 1.0 : -1.0;
    final ty = onTarget
        ? 34 + side * (0.6 + _r.nextDouble() * 2.8)
        : 34 + side * (4.4 + _r.nextDouble() * 7);
    final apex = kind == 'F' ? 2.6 : (kind == 'H' ? 0.8 : 0.4 + _r.nextDouble());
    final secs = kind == 'F' ? 1.0 : (dGoal > 22 ? 0.9 : 0.6);
    _launch(sx, sy, goalX, ty, secs, () {
      if (scored) {
        _onTarget[team]++;
        _goal(c, null);
      } else if (onTarget) {
        _onTarget[team]++;
        gk.saves++;
        // Plongeon du gardien.
        gk.x = goalX - (team == 0 ? 1.0 : -1.0) * 0.9;
        gk.y = ty;
        _events.add(MatchEvent(
          minute: _minute,
          type: MatchEventType.save,
          isHome: team == 0,
        ));
        _ev('SV', 1 - team, a: gk.player.name);
        if (_r.nextDouble() < 0.25) {
          _corner(team);
        } else {
          _giveTo(gk, 3.5);
        }
      } else {
        _events.add(MatchEvent(
          minute: _minute,
          type: MatchEventType.miss,
          isHome: team == 0,
        ));
        _goalKick(1 - team);
      }
    }, apex: apex);
  }

  /// Issue d'une frappe jouée pour de vrai : 0 but, 1 arrêt, 2 à côté,
  /// 3 contrée. La qualité de l'occasion (xG) est ajustée par le duel entre
  /// le tireur et le gardien.
  int _resolve(_Agent c, double xg) {
    final team = c.team;
    final gk = _keeper(1 - team);
    // Taux de conversion de base : les buts attendus de l'équipe répartis
    // sur ses occasions (environ 1 but pour 9 tirs, comme en vrai).
    final base = _lambda[team] / max(4, _plannedShots[team]);
    // Une occasion meilleure que la moyenne de l'équipe vaut plus, une
    // frappe lointaine moins ; la moyenne reste celle d'un vrai match.
    final mean = (_xgTaken[team] + 0.10 * 3) / (_taken[team] + 3);
    _xgTaken[team] += xg;
    _taken[team]++;
    final quality = pow(xg / max(0.02, mean), 0.6).clamp(0.45, 1.9).toDouble();
    final duel = pow(c.eff / max(20.0, gk.eff), 0.5).clamp(0.75, 1.3).toDouble();
    final finish = sqrt(c.role.finishing).clamp(0.85, 1.15).toDouble();
    final pGoal = (base * quality * duel * finish).clamp(0.01, 0.55).toDouble();
    final r = _r.nextDouble();
    if (r < pGoal) return 0;
    final rest = (r - pGoal) / (1 - pGoal);
    if (rest < 0.36) return 1;
    if (rest < 0.58) return 3;
    return 2;
  }

  void _goal(_Agent scorer, _Agent? unused) {
    final team = scorer.team;
    _score[team]++;
    scorer.goals++;
    String? assistId;
    var assistName = '';
    final lp = _lastPasser;
    if (lp != null &&
        lp != scorer &&
        lp.team == team &&
        _t - _lastPassT < 10) {
      lp.assists++;
      assistId = lp.player.id;
      assistName = lp.player.name;
    }
    _events.add(MatchEvent(
      minute: _minute,
      type: MatchEventType.goal,
      isHome: team == 0,
    ));
    _credits.add(GoalCredit(
      scorerId: scorer.player.id,
      assistId: assistId,
      minute: _minute,
      home: team == 0,
    ));
    if (_over) return;
    _extra = min(360.0, _extra + 35);
    final goalX = team == 0 ? _len : 0.0;
    final dir = team == 0 ? 1.0 : -1.0;
    _ev('GL', team, a: scorer.player.name, b: assistName, x: goalX, y: _by);
    // Célébration : le buteur file vers le poteau de corner, ses
    // coéquipiers le rejoignent ; puis chacun regagne son camp.
    final flagY = scorer.y < _wid / 2 ? 1.5 : _wid - 1.5;
    final cx = goalX - dir * 3;
    _dead(20, () {
      _dead(11, () => _reset(1 - team),
          ballX: _len / 2, ballY: _wid / 2, allowSubs: false);
      for (final side in _teams) {
        for (final a in side) {
          if (!_avail(a)) continue;
          final p = _kickoffSpot(a);
          _place(a, p.x, p.y, 4.2);
        }
      }
    }, ballX: goalX, ballY: _by, allowSubs: false);
    _place(scorer, cx, flagY, 6.5);
    final mates = [
      for (final a in _teams[team])
        if (_avail(a) && a != scorer && !a.isGk) a,
    ]..sort(
        (a, b) => _hyp(a.x, a.y, cx, flagY).compareTo(_hyp(b.x, b.y, cx, flagY)),
      );
    for (var i = 0; i < mates.length && i < 5; i++) {
      final ang = i * 1.25;
      _place(
        mates[i],
        cx - dir * (1.5 + cos(ang)),
        flagY + (flagY < _wid / 2 ? 1.0 : -1.0) * (1.2 + sin(ang).abs() * 1.5),
        6,
      );
    }
    _refFocus = _Pt(_len / 2, _wid / 2 + 6);
  }

  // ---------- bilan ----------

  MatchResult _finish() {
    final total = _poss[0] + _poss[1];
    final homePoss = total == 0 ? 50 : (100 * _poss[0] / total).round();
    int sum(int team, int Function(_Agent a) f) {
      var s = 0;
      for (final a in _teams[team]) {
        s += f(a);
      }
      return s;
    }

    int acc(int team) {
      final p = sum(team, (a) => a.passes);
      if (p == 0) return 0;
      return (100 * sum(team, (a) => a.passesOk) / p).round();
    }

    final stats = MatchStats(
      homePossession: homePoss.clamp(1, 99).toInt(),
      homeShots: _shots[0],
      awayShots: _shots[1],
      homeOnTarget: _onTarget[0],
      awayOnTarget: _onTarget[1],
      homeCorners: _corners[0],
      awayCorners: _corners[1],
      homeFouls: _fouls[0],
      awayFouls: _fouls[1],
      homeYellow: _yellow[0],
      awayYellow: _yellow[1],
      homeRed: _red[0],
      awayRed: _red[1],
      homeOffsides: _offsides[0],
      awayOffsides: _offsides[1],
      homePasses: sum(0, (a) => a.passes),
      awayPasses: sum(1, (a) => a.passes),
      homePassAcc: acc(0),
      awayPassAcc: acc(1),
      homeThrowIns: _throwIns[0],
      awayThrowIns: _throwIns[1],
      homeXg: (_xg[0] * 100).round(),
      awayXg: (_xg[1] * 100).round(),
    );

    final perfs = <PlayerPerf>[];
    for (final team in [0, 1]) {
      final scored = _score[team];
      final conceded = _score[1 - team];
      for (final a in [
        ..._teams[team],
        ..._retired.where((r) => r.team == team),
      ]) {
        var rating = 6.0 +
            a.goals * 0.9 +
            a.assists * 0.6 +
            a.shots * 0.05 +
            a.tackles * 0.15 +
            a.interceptions * 0.15 +
            a.saves * 0.25 -
            a.lost * 0.03 -
            a.yellows * 0.3 -
            a.reds * 1.5 -
            a.fouls * 0.05;
        if (a.passes >= 10) {
          rating += (a.passesOk / a.passes - 0.8) * 1.5;
        }
        rating += scored > conceded ? 0.4 : (scored < conceded ? -0.3 : 0.0);
        if (conceded == 0 &&
            (a.isGk || a.player.position == PlayerPosition.defender)) {
          rating += 0.4;
        }
        if (a.isGk || a.player.position == PlayerPosition.defender) {
          rating -= conceded * 0.12;
        }
        rating += (a.eff - 65) / 80 + (_r.nextDouble() - 0.5) * 0.4;
        final r = rating.clamp(3.0, 10.0).toDouble();
        perfs.add(
          PlayerPerf(
            name: a.player.name,
            pos: a.spot.label,
            home: team == 0,
            ratingTenths: (r * 10).round(),
            distanceHm: (a.dist / 100).round(),
            goals: a.goals,
            assists: a.assists,
            shots: a.shots,
            passes: a.passes,
            passesOk: a.passesOk,
            tackles: a.tackles + a.interceptions,
            saves: a.saves,
          ),
        );
      }
    }

    return MatchResult(
      homeGoals: _score[0],
      awayGoals: _score[1],
      events: List.unmodifiable(_events),
      stats: stats,
      detail: PitchDetail(
        goals: List.unmodifiable(_credits),
        perfs: List.unmodifiable(perfs),
        track: List.unmodifiable(_track),
        subs: List.unmodifiable(_subs),
        cards: List.unmodifiable(_cards),
        chances: List.unmodifiable(_chances),
        names: List.unmodifiable(_names),
        log: List.unmodifiable(_log),
        injured: List.unmodifiable(_injured),
        trackVersion: pitchTrackVersion,
      ),
    );
  }

  String _label(PlayerPosition p) {
    switch (p) {
      case PlayerPosition.goalkeeper:
        return 'GB';
      case PlayerPosition.defender:
        return 'DEF';
      case PlayerPosition.midfielder:
        return 'MIL';
      case PlayerPosition.forward:
        return 'ATT';
    }
  }
}
