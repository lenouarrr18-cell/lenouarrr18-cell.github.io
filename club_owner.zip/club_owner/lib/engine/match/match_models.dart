import 'dart:convert';
import 'dart:io' show gzip;
import 'dart:typed_data';

import '../../domain/entities/match_summary.dart';

enum MatchEventType { miss, save, goal }

class MatchEvent {
  const MatchEvent({
    required this.minute,
    required this.type,
    required this.isHome,
  });

  final int minute;
  final MatchEventType type;

  /// `true` si l'équipe à l'origine de l'action est celle qui reçoit.
  final bool isHome;
}

/// Un but avec son buteur et son passeur (identifiants de joueurs).
class GoalCredit {
  const GoalCredit({
    required this.scorerId,
    required this.minute,
    required this.home,
    this.assistId,
  });

  final String scorerId;
  final String? assistId;
  final int minute;
  final bool home;
}

/// Détail issu de la simulation sur le terrain (22 joueurs).
class PitchDetail {
  const PitchDetail({
    required this.goals,
    required this.perfs,
    this.track = const [],
    this.subs = const [],
    this.cards = const [],
    this.chances = const [],
    this.names = const [],
    this.log = const [],
    this.injured = const [],
    this.trackVersion = 1,
  });

  final List<GoalCredit> goals;
  final List<PlayerPerf> perfs;

  /// Positions échantillonnées (46 octets par image de 6 s).
  final List<int> track;

  /// Cartons : « minute|1 si domicile|joueur|Y ou R ».
  final List<String> cards;

  /// Occasions : « minute|1 si domicile|tireur|G/S/M/B|xG en centièmes ».
  final List<String> chances;

  /// Noms des 22 titulaires dans l'ordre de la trajectoire.
  final List<String> names;

  /// Remplacements : « minute|1 si domicile|sortant|entrant ».
  final List<String> subs;

  /// Journal du match (moteur v2) : « seconde|code|1 si domicile|a|b|x|y ».
  final List<String> log;

  /// Joueurs sortis sur blessure sérieuse (identifiants).
  final List<String> injured;

  /// 1 : 46 octets toutes les 6 s ; 2 : 54 octets chaque seconde.
  final int trackVersion;
}

enum MatchOutcome { homeWin, draw, awayWin }

class MatchResult {
  const MatchResult({
    required this.homeGoals,
    required this.awayGoals,
    required this.events,
    this.stats,
    this.detail,
  });

  final int homeGoals;
  final int awayGoals;
  final List<MatchEvent> events;

  /// Statistiques détaillées (possession, tirs, fautes...).
  final MatchStats? stats;

  /// Présent quand le match a été simulé joueur par joueur.
  final PitchDetail? detail;

  MatchOutcome get outcome {
    if (homeGoals > awayGoals) return MatchOutcome.homeWin;
    if (homeGoals < awayGoals) return MatchOutcome.awayWin;
    return MatchOutcome.draw;
  }
}


/// Trajectoire compressée pour la sauvegarde : « z: » + base64 du gzip
/// (environ deux fois plus léger que le base64 brut).
String packTrack(List<int> track) {
  if (track.isEmpty) return '';
  try {
    return 'z:${base64Encode(gzip.encode(track))}';
  } catch (_) {
    return base64Encode(track);
  }
}

/// Lit une trajectoire, compressée ou non (anciennes sauvegardes).
Uint8List? unpackTrack(String raw) {
  if (raw.isEmpty) return null;
  try {
    if (raw.startsWith('z:')) {
      return Uint8List.fromList(gzip.decode(base64Decode(raw.substring(2))));
    }
    return base64Decode(raw);
  } catch (_) {
    return null;
  }
}

/// Conditions du match, identiques pour le moteur et l'affichage : match
/// en nocturne (une journée sur deux) et pluie (environ une sur neuf).
({bool night, bool rain}) matchConditions(int season, int round) {
  return (
    night: round % 2 == 1,
    rain: (round * 31 + season * 7) % 9 == 0,
  );
}
