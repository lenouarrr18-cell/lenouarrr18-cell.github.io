import 'dart:math';

import '../../domain/entities/honours.dart';

String _handle(String name) {
  return '@${name.toLowerCase().replaceAll(' ', '_')}';
}

const List<String> _winTexts = [
  'Victoire ! Merci aux supporters pour cette ambiance incroyable.',
  'Trois points de plus, on continue sur cette lancée !',
  'Belle performance collective ce week-end. Allez le club !',
];

const List<String> _drawTexts = [
  'Un point pris, mais on veut plus la prochaine fois.',
  'Match nul accroché. On reste solides et on avance.',
];

const List<String> _lossTexts = [
  'Une défaite qui fait mal. On se relève ensemble.',
  'Pas notre jour. On travaille pour rebondir dès la prochaine journée.',
];

const List<String> _fanWin = [
  'Quelle équipe ! On y croit !',
  'Le stade était en feu aujourd\'hui !',
  'Les ultras ont chanté 90 minutes, bravo les gars.',
];

const List<String> _fanLoss = [
  'Il faut du changement, là...',
  'On mérite mieux. Réveillez-vous !',
  'Courage, on reste derrière vous quand même.',
];

const List<String> _rivalTexts = [
  'Victoire importante pour nous ce week-end.',
  'Le travail paie, on continue !',
  'Belle prestation de toute l\'équipe.',
];

String _pick(List<String> list, Random random) {
  return list[random.nextInt(list.length)];
}

/// Messages du réseau social après une journée.
/// [outcome] : 1 victoire, 0 nul, -1 défaite, `null` si pas de match.
List<SocialPost> roundPosts({
  required Random random,
  required String clubName,
  required String rivalName,
  required bool hasCommunityManager,
  required int followers,
  required int season,
  required int round,
  required int? outcome,
}) {
  final posts = <SocialPost>[];
  final base = followers < 100 ? 100 : followers;

  if (outcome != null && hasCommunityManager) {
    final text = outcome > 0
        ? _pick(_winTexts, random)
        : (outcome == 0 ? _pick(_drawTexts, random) : _pick(_lossTexts, random));
    posts.add(
      SocialPost(
        author: clubName,
        text: text,
        likes: (base * (0.03 + random.nextDouble() * 0.04)).round(),
        season: season,
        round: round,
        isUser: true,
      ),
    );
  }

  if (outcome != null) {
    final text = outcome >= 0 ? _pick(_fanWin, random) : _pick(_fanLoss, random);
    posts.add(
      SocialPost(
        author: '${_handle(clubName)}_ultras',
        text: text,
        likes: 20 + random.nextInt(180),
        season: season,
        round: round,
      ),
    );
  }

  posts.add(
    SocialPost(
      author: rivalName,
      text: _pick(_rivalTexts, random),
      likes: 30 + random.nextInt(400),
      season: season,
      round: round,
    ),
  );
  return posts;
}

/// Évolution des abonnés après une journée.
int nextFollowers({
  required int followers,
  required int target,
  required int communityLevel,
}) {
  final growth = ((target - followers) * 0.03).round() + communityLevel ~/ 10;
  final next = followers + growth;
  return next < 0 ? 0 : next;
}
