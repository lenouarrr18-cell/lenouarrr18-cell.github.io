import 'dart:math';

import '../../domain/entities/club.dart';
import '../../domain/entities/division.dart';
import '../../domain/entities/honours.dart';
import '../../domain/entities/player.dart';
import '../world/nations.dart';

/// Résultat complet d'un passage de tournois pour une saison.
class InternationalReport {
  const InternationalReport({
    required this.clubs,
    required this.results,
    required this.prestigeGain,
    required this.messages,
    required this.bonus,
  });

  final List<Club> clubs;
  final List<TournamentResult> results;

  /// Gain de prestige par identifiant de club.
  final Map<String, int> prestigeGain;
  final List<String> messages;

  /// Points de score ajoutés aux joueurs brillants (Ballon d'or).
  final Map<String, double> bonus;
}

/// Tournois organisés après la fin de la saison [season] (aucun sinon).
/// Coupe du monde : saisons 2, 6, 10... Tournois continentaux : 4, 8, 12...
List<String> tournamentsForSeason(int season) {
  if (season % 4 == 2) return const ['Coupe du monde'];
  if (season % 4 == 0) {
    return const [
      "Coupe d'Afrique des Nations",
      "Championnat d'Europe",
      'Copa América',
      "Coupe d'Asie",
    ];
  }
  return const [];
}

/// Prochaine saison (terminée) après laquelle un tournoi a lieu.
int nextTournamentSeason(int currentSeason) {
  var s = currentSeason;
  while (tournamentsForSeason(s).isEmpty) {
    s++;
  }
  return s;
}

bool _wins(Random random, int a, int b) {
  final p = 1 / (1 + exp(-(a - b) / 7));
  return random.nextDouble() < p;
}

NationInfo _knockout(List<NationInfo> teams, Random random, List<NationInfo> losers) {
  var round = teams;
  NationInfo? runner;
  while (round.length > 1) {
    final next = <NationInfo>[];
    for (var i = 0; i + 1 < round.length; i += 2) {
      final a = round[i];
      final b = round[i + 1];
      final winner = _wins(random, a.rating, b.rating) ? a : b;
      final loser = winner == a ? b : a;
      if (round.length == 2) runner = loser;
      losers.add(loser);
      next.add(winner);
    }
    round = next;
  }
  if (runner != null) losers.add(runner);
  return round.first;
}

/// Simule un tournoi à élimination après phase de groupes.
/// Renvoie [champion, finaliste].
List<NationInfo> _simulate(List<NationInfo> pool, int size, Random random) {
  final noisy = <NationInfo, int>{
    for (final n in pool) n: n.rating + random.nextInt(9) - 4,
  };
  final ranked = pool.toList()..sort((a, b) => noisy[b]!.compareTo(noisy[a]!));
  final field = ranked.take(size).toList()..shuffle(random);

  final winners = <NationInfo>[];
  final runners = <NationInfo>[];
  for (var g = 0; g + 3 < field.length; g += 4) {
    final group = field.sublist(g, g + 4);
    final points = <NationInfo, int>{for (final n in group) n: 0};
    for (var i = 0; i < 4; i++) {
      for (var j = i + 1; j < 4; j++) {
        final a = group[i];
        final b = group[j];
        if (random.nextDouble() < 0.22) {
          points[a] = points[a]! + 1;
          points[b] = points[b]! + 1;
        } else if (_wins(random, a.rating, b.rating)) {
          points[a] = points[a]! + 3;
        } else {
          points[b] = points[b]! + 3;
        }
      }
    }
    group.sort((a, b) {
      final byPoints = points[b]!.compareTo(points[a]!);
      return byPoints != 0 ? byPoints : b.rating.compareTo(a.rating);
    });
    winners.add(group[0]);
    runners.add(group[1]);
  }

  // Tableau : chaque premier de groupe affronte le second du groupe suivant.
  final bracket = <NationInfo>[];
  for (var i = 0; i < winners.length; i++) {
    bracket.add(winners[i]);
    bracket.add(runners[(i + 1) % runners.length]);
  }
  final losers = <NationInfo>[];
  final champion = _knockout(bracket, random, losers);
  final runnerUp = losers.isNotEmpty ? losers.last : champion;
  return [champion, runnerUp];
}

List<NationInfo> _pool(String name) {
  switch (name) {
    case "Coupe d'Afrique des Nations":
      return nations.where((n) => n.continent == Continent.africa).toList();
    case "Championnat d'Europe":
      return nations.where((n) => n.continent == Continent.europe).toList();
    case 'Copa América':
      return nations
          .where(
            (n) =>
                n.continent == Continent.southAmerica ||
                n.continent == Continent.northAmerica,
          )
          .toList();
    case "Coupe d'Asie":
      return nations.where((n) => n.continent == Continent.asia).toList();
    default:
      return nations.toList();
  }
}

/// Fait jouer les tournois de la saison et applique leurs effets :
/// sélections (caps) et prestige des clubs dont des joueurs participent.
InternationalReport runInternational({
  required List<Club> clubs,
  required int season,
  required int seed,
  required int division,
  Map<String, int> divisionByClub = const {},
}) {
  final names = tournamentsForSeason(season);
  if (names.isEmpty) {
    return InternationalReport(
      clubs: clubs,
      results: const [],
      prestigeGain: const {},
      messages: const [],
      bonus: const {},
    );
  }

  final random = Random(seed + season * 15731);
  final results = <TournamentResult>[];
  final messages = <String>[];
  final gain = <String, int>{};
  final bonus = <String, double>{};
  final capsById = <String, int>{};

  for (final name in names) {
    final pool = _pool(name);
    final size = name == 'Coupe du monde' ? 32 : 16;
    final outcome = _simulate(pool, size < pool.length ? size : pool.length, random);
    final champion = outcome[0];
    final runnerUp = outcome[1];

    final called = <String>[];
    for (final club in clubs) {
      final threshold = divisionBase(divisionByClub[club.id] ?? division) + 6;
      for (final p in club.squad) {
        final nation = nationByName(p.nation);
        if (nation == null || !pool.contains(nation)) continue;
        final eligible = p.skill >= threshold ||
            (p.age <= 22 && p.skill >= threshold - 6 && p.maxSkill >= 75);
        if (!eligible) continue;
        called.add(p.id);
        capsById[p.id] = (capsById[p.id] ?? 0) + 3 + random.nextInt(5);
        gain[club.id] = (gain[club.id] ?? 0) + 1;
        bonus[p.id] = (bonus[p.id] ?? 0) + 2.0;
        if (nation.name == champion.name) {
          gain[club.id] = (gain[club.id] ?? 0) + 2;
          bonus[p.id] = (bonus[p.id] ?? 0) + 12.0;
        }
        if (club.isUser) {
          messages.add(
            '${p.name} est appelé avec ${nation.name} pour : $name.',
          );
        }
      }
    }

    results.add(
      TournamentResult(
        season: season,
        name: name,
        champion: champion.name,
        runnerUp: runnerUp.name,
        userPlayers: [
          for (final club in clubs)
            if (club.isUser)
              for (final p in club.squad)
                if (called.contains(p.id)) p.name,
        ],
      ),
    );
    messages.add('$name : ${champion.name} champion, ${runnerUp.name} finaliste.');
  }

  Player credit(Player p) {
    final c = capsById[p.id];
    return c == null ? p : p.copyWith(caps: p.caps + c);
  }

  final updated = [
    for (final club in clubs)
      club.squad.any((p) => capsById.containsKey(p.id))
          ? club.copyWith(squad: [for (final p in club.squad) credit(p)])
          : club,
  ];

  return InternationalReport(
    clubs: updated,
    results: results,
    prestigeGain: gain,
    messages: messages,
    bonus: bonus,
  );
}

/// Place d'une sélection au classement mondial.
class NationRank {
  const NationRank(this.nation, this.points, this.titles, this.finals);

  final NationInfo nation;
  final int points;
  final int titles;
  final int finals;
}

/// Classement mondial : niveau de base de la sélection, plus les titres et
/// finales récents (une Coupe du monde compte davantage ; les résultats
/// perdent 20 % de leur poids chaque saison).
List<NationRank> worldRanking(List<TournamentResult> history, int season) {
  final out = <NationRank>[];
  for (final n in nations) {
    var pts = n.rating * 15.0;
    var titles = 0;
    var finals = 0;
    for (final r in history) {
      final decay = pow(0.8, max(0, season - r.season)).toDouble();
      final world = r.name == 'Coupe du monde';
      if (r.champion == n.name) {
        titles++;
        pts += (world ? 400 : 250) * decay;
      } else if (r.runnerUp == n.name) {
        finals++;
        pts += (world ? 200 : 120) * decay;
      }
    }
    out.add(NationRank(n, pts.round(), titles, finals));
  }
  out.sort((a, b) => b.points.compareTo(a.points));
  return out;
}

/// Chances d'un joueur d'être appelé au prochain tournoi.
enum CallUpOutlook { star, likely, possible, none }

String callUpLabel(CallUpOutlook o) {
  switch (o) {
    case CallUpOutlook.star:
      return 'Cadre de la sélection';
    case CallUpOutlook.likely:
      return 'Sélectionnable';
    case CallUpOutlook.possible:
      return 'Espoir surveillé';
    case CallUpOutlook.none:
      return 'Hors sélection';
  }
}

/// Même règle que le sélectionneur des tournois (niveau selon la division).
CallUpOutlook callUpOutlook(Player p, int division) {
  if (nationByName(p.nation) == null) return CallUpOutlook.none;
  final threshold = divisionBase(division) + 6;
  if (p.skill >= threshold + 8) return CallUpOutlook.star;
  if (p.skill >= threshold) return CallUpOutlook.likely;
  if (p.age <= 22 && p.skill >= threshold - 6 && p.maxSkill >= 75) {
    return CallUpOutlook.possible;
  }
  return CallUpOutlook.none;
}
