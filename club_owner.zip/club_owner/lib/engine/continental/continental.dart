import 'dart:math';

import '../../domain/entities/club.dart';
import '../../domain/entities/honours.dart';
import '../../domain/entities/owner.dart';
import '../match/match_engine.dart';
import '../season/season.dart';
import '../world/nations.dart';
import '../world/world_league.dart';

/// Résultat des compétitions de clubs continentales d'une saison.
class ContinentalReport {
  const ContinentalReport({
    required this.results,
    required this.prestigeGain,
    required this.news,
    required this.userNotes,
    this.clubScore = const {},
  });

  final List<TournamentResult> results;
  final Map<String, int> prestigeGain;
  final List<NewsItem> news;
  final List<String> userNotes;

  /// Points de parcours continental par club (identifiant) : sert au
  /// Ballon d'or et aux autres distinctions individuelles.
  final Map<String, double> clubScore;
}

/// Points d'un parcours selon le tour atteint.
double stagePoints(String? stage) {
  switch (stage) {
    case 'Vainqueur':
      return 10;
    case 'Finale':
      return 7;
    case 'Demi-finales':
      return 5;
    case 'Quarts de finale':
      return 3.5;
    case 'Huitièmes de finale':
      return 2.5;
    default:
      return 1;
  }
}

double _power(Club club) {
  final s = club.matchStrength;
  return (s.attack + s.midfield + s.defense + s.goalkeeper) / 4;
}

List<Club> _ranked(Season season) {
  return [
    for (final row in season.standings) season.clubById(row.clubId),
  ];
}

/// Prend, pays par pays (du plus fort au plus faible), les clubs
/// suivants du classement. [used] retient combien de places de chaque
/// pays sont déjà prises par une compétition plus prestigieuse.
List<Club> _gather({
  required Map<String, List<Club>> tables,
  required List<String> countries,
  required Map<String, int> used,
  required int Function(int rank) slotsOf,
  required int maxClubs,
}) {
  final picked = <Club>[];
  for (var rank = 0; rank < countries.length; rank++) {
    final country = countries[rank];
    final table = tables[country];
    if (table == null) continue;
    final start = used[country] ?? 0;
    final count = slotsOf(rank);
    for (var i = 0; i < count; i++) {
      if (start + i >= table.length || picked.length >= maxClubs) break;
      picked.add(table[start + i]);
    }
    used[country] = start + count;
  }
  return picked;
}

class _Cup {
  _Cup(this.name, this.entrants, int seed)
    : engine = MatchEngine(seed: seed),
      random = Random(seed + 17);

  final String name;
  final List<Club> entrants;
  final MatchEngine engine;
  final Random random;
  final Map<String, String> reached = {};
  Club? champion;
  Club? runnerUp;

  Club _tie(Club a, Club b) {
    final r = engine.simulate(home: a.matchStrength, away: b.matchStrength);
    if (r.homeGoals > r.awayGoals) return a;
    if (r.homeGoals < r.awayGoals) return b;
    final pa = _power(a);
    final pb = _power(b);
    return random.nextDouble() < pa / (pa + pb) ? a : b;
  }

  void run() {
    var size = 32;
    while (size > entrants.length && size > 8) {
      size ~/= 2;
    }
    final field = [...entrants.take(size)]..shuffle(random);
    for (final c in field) {
      reached[c.id] = 'Phase de groupes';
    }

    final advancing = <Club>[];
    for (var g = 0; g < field.length ~/ 4; g++) {
      final group = field.sublist(g * 4, g * 4 + 4);
      final points = {for (final c in group) c.id: 0};
      final diff = {for (final c in group) c.id: 0};
      for (var i = 0; i < 4; i++) {
        for (var j = i + 1; j < 4; j++) {
          final r = engine.simulate(
            home: group[i].matchStrength,
            away: group[j].matchStrength,
          );
          diff[group[i].id] = diff[group[i].id]! + r.homeGoals - r.awayGoals;
          diff[group[j].id] = diff[group[j].id]! + r.awayGoals - r.homeGoals;
          if (r.homeGoals > r.awayGoals) {
            points[group[i].id] = points[group[i].id]! + 3;
          } else if (r.homeGoals < r.awayGoals) {
            points[group[j].id] = points[group[j].id]! + 3;
          } else {
            points[group[i].id] = points[group[i].id]! + 1;
            points[group[j].id] = points[group[j].id]! + 1;
          }
        }
      }
      final order = [...group]
        ..sort((a, b) {
          final byPoints = points[b.id]!.compareTo(points[a.id]!);
          return byPoints != 0
              ? byPoints
              : diff[b.id]!.compareTo(diff[a.id]!);
        });
      advancing.addAll(order.take(2));
    }

    var round = advancing..shuffle(random);
    while (round.length > 1) {
      final label = round.length == 2
          ? 'Finale'
          : (round.length == 4
                ? 'Demi-finales'
                : (round.length == 8
                      ? 'Quarts de finale'
                      : 'Huitièmes de finale'));
      for (final c in round) {
        reached[c.id] = label;
      }
      final next = <Club>[];
      Club? lastLoser;
      for (var i = 0; i + 1 < round.length; i += 2) {
        final winner = _tie(round[i], round[i + 1]);
        lastLoser = winner.id == round[i].id ? round[i + 1] : round[i];
        next.add(winner);
      }
      if (next.length == 1) runnerUp = lastLoser;
      round = next;
    }
    champion = round.first;
    reached[champion!.id] = 'Vainqueur';
  }
}

/// Compétitions de clubs de la saison (Ligue des champions, Ligue Europa,
/// Ligue Europa Conférence, compétitions africaines, sud-américaines,
/// nord-américaines et asiatiques) puis Coupe du monde des clubs. Elles
/// se jouent à la fin de la saison, avec les classements finaux des
/// premières divisions.
ContinentalReport runContinentalCups({
  required List<WorldLeague> world,
  required Season userSeason,
  required int userDivision,
  required String homeCountry,
  required int seasonNumber,
  required int seed,
}) {
  final tables = <String, List<Club>>{};
  for (final league in world) {
    if (league.division == 1) tables[league.country] = _ranked(league.season);
  }
  if (userDivision == 1) tables[homeCountry] = _ranked(userSeason);

  List<String> countriesOf(Continent continent) {
    final names = [
      for (final n in nations)
        if (n.continent == continent && tables.containsKey(n.name)) n,
    ]..sort((a, b) {
        final byRating = b.rating.compareTo(a.rating);
        return byRating != 0 ? byRating : a.name.compareTo(b.name);
      });
    return [for (final n in names) n.name];
  }

  final plans = <_Plan>[];
  final europe = countriesOf(Continent.europe);
  final usedEurope = <String, int>{};
  plans.add(
    _Plan(
      'Ligue des champions',
      true,
      _gather(
        tables: tables,
        countries: europe,
        used: usedEurope,
        slotsOf: (r) => r < 4 ? 4 : (r < 6 ? 3 : (r < 10 ? 2 : 1)),
        maxClubs: 32,
      ),
    ),
  );
  plans.add(
    _Plan(
      'Ligue Europa',
      false,
      _gather(
        tables: tables,
        countries: europe,
        used: usedEurope,
        slotsOf: (r) => r < 6 ? 2 : (r < 16 ? 1 : 0),
        maxClubs: 32,
      ),
    ),
  );
  plans.add(
    _Plan(
      'Ligue Europa Conférence',
      false,
      _gather(
        tables: tables,
        countries: europe,
        used: usedEurope,
        slotsOf: (r) => r < 4 ? 2 : (r < 12 ? 1 : 0),
        maxClubs: 32,
      ),
    ),
  );

  final africa = countriesOf(Continent.africa);
  final usedAfrica = <String, int>{};
  plans.add(
    _Plan(
      'Ligue des champions africaine',
      true,
      _gather(
        tables: tables,
        countries: africa,
        used: usedAfrica,
        slotsOf: (r) => r < 8 ? 2 : 0,
        maxClubs: 16,
      ),
    ),
  );
  plans.add(
    _Plan(
      'Coupe de la Confédération',
      false,
      _gather(
        tables: tables,
        countries: africa,
        used: usedAfrica,
        slotsOf: (r) => r < 8 ? 2 : 1,
        maxClubs: 16,
      ),
    ),
  );

  final southAmerica = countriesOf(Continent.southAmerica);
  final usedSouth = <String, int>{};
  plans.add(
    _Plan(
      'Copa Libertadores',
      true,
      _gather(
        tables: tables,
        countries: southAmerica,
        used: usedSouth,
        slotsOf: (r) => 2,
        maxClubs: 16,
      ),
    ),
  );
  plans.add(
    _Plan(
      'Copa Sudamericana',
      false,
      _gather(
        tables: tables,
        countries: southAmerica,
        used: usedSouth,
        slotsOf: (r) => 2,
        maxClubs: 16,
      ),
    ),
  );

  final northAmerica = countriesOf(Continent.northAmerica);
  plans.add(
    _Plan(
      'Ligue des champions CONCACAF',
      true,
      _gather(
        tables: tables,
        countries: northAmerica,
        used: <String, int>{},
        slotsOf: (r) => 2,
        maxClubs: 16,
      ),
    ),
  );

  final asia = countriesOf(Continent.asia);
  final usedAsia = <String, int>{};
  plans.add(
    _Plan(
      "Ligue des champions d'Asie",
      true,
      _gather(
        tables: tables,
        countries: asia,
        used: usedAsia,
        slotsOf: (r) => r < 8 ? 2 : 0,
        maxClubs: 16,
      ),
    ),
  );
  plans.add(
    _Plan(
      "Coupe de l'AFC",
      false,
      _gather(
        tables: tables,
        countries: asia,
        used: usedAsia,
        slotsOf: (r) => 1,
        maxClubs: 16,
      ),
    ),
  );

  final results = <TournamentResult>[];
  final gain = <String, int>{};
  final news = <NewsItem>[];
  final userNotes = <String>[];
  final topChampions = <Club>[];
  final clubScore = <String, double>{};

  void addGain(String id, int amount) {
    gain[id] = (gain[id] ?? 0) + amount;
  }

  var index = 0;
  for (final plan in plans) {
    index++;
    if (plan.clubs.length < 8) continue;
    final cup = _Cup(plan.name, plan.clubs, seed * 31 + seasonNumber * 7 + index)
      ..run();
    final champion = cup.champion!;
    final runnerUp = cup.runnerUp ?? champion;
    for (final c in cup.entrants) {
      addGain(c.id, 1);
      final pts = stagePoints(cup.reached[c.id]) * (plan.top ? 1.5 : 1.0);
      clubScore[c.id] = (clubScore[c.id] ?? 0) + pts;
    }
    addGain(champion.id, 5);
    addGain(runnerUp.id, 2);
    if (plan.top) topChampions.add(champion);

    String userLine = '';
    final stage = cup.reached['user'];
    if (stage != null) {
      userLine = 'Votre club : $stage';
      userNotes.add('${plan.name} : $stage.');
    }
    results.add(
      TournamentResult(
        season: seasonNumber,
        name: plan.name,
        champion: champion.name,
        runnerUp: runnerUp.name,
        userPlayers: userLine.isEmpty ? const [] : [userLine],
      ),
    );
    news.add(
      NewsItem(
        headline: '${champion.name} remporte la ${plan.name}',
        body: 'Finale contre ${runnerUp.name} dans la ${plan.name} '
            '(saison $seasonNumber).',
        season: seasonNumber,
        round: 38,
        kind: NewsKind.world,
      ),
    );
  }

  if (topChampions.length >= 4) {
    final cwc = _Cup('Coupe du monde des clubs', topChampions, seed + 99);
    final field = [...topChampions]..shuffle(cwc.random);
    var round = field.take(field.length >= 8 ? 8 : 4).toList();
    Club? runner;
    while (round.length > 1) {
      final next = <Club>[];
      for (var i = 0; i + 1 < round.length; i += 2) {
        final winner = cwc._tie(round[i], round[i + 1]);
        runner = winner.id == round[i].id ? round[i + 1] : round[i];
        next.add(winner);
      }
      round = next;
    }
    final champion = round.first;
    addGain(champion.id, 4);
    clubScore[champion.id] = (clubScore[champion.id] ?? 0) + 5;
    results.add(
      TournamentResult(
        season: seasonNumber,
        name: 'Coupe du monde des clubs',
        champion: champion.name,
        runnerUp: runner?.name ?? champion.name,
        userPlayers: const [],
      ),
    );
    news.add(
      NewsItem(
        headline: '${champion.name} champion du monde des clubs',
        body: 'Le vainqueur de la Coupe du monde des clubs est '
            '${champion.name}.',
        season: seasonNumber,
        round: 38,
        kind: NewsKind.world,
      ),
    );
  }

  return ContinentalReport(
    results: results,
    prestigeGain: gain,
    news: news,
    userNotes: userNotes,
    clubScore: clubScore,
  );
}

class _Plan {
  _Plan(this.name, this.top, this.clubs);

  final String name;
  final bool top;
  final List<Club> clubs;
}
