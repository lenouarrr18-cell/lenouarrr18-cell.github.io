import '../../core/utils/format.dart';
import '../../domain/entities/club.dart';
import '../../domain/entities/lineup.dart';
import '../../domain/entities/owner.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/roles.dart';
import '../../domain/entities/transfer.dart';
import '../finance/finance.dart';
import '../transfers/moves.dart';
import 'game_state.dart';
import 'round_hooks.dart';

/// Indemnité pour libérer un joueur : la moitié des salaires restants.
int releaseCost(Player player) {
  final years = player.contractYears < 1 ? 1 : player.contractYears;
  return (annualWage(player) * years * 0.5 / 1000).round() * 1000;
}

/// Prime de prolongation : la moitié du salaire annuel par année ajoutée.
int renewalCost(Player player, int years) {
  return (annualWage(player) * years * 0.5 / 1000).round() * 1000;
}

/// Transferts, prêts, contrats et organisation des équipes du club.
extension TransferActions on GameState {
  InboxMessage _msg(String title, String body) {
    return InboxMessage(
      title: title,
      body: body,
      season: seasonNumber,
      round: season.currentRound,
    );
  }

  GameState _noted(String title, String body) {
    return copyWith(owner: owner.addMessage(_msg(title, body)));
  }

  Offer? offerById(String id) => offers.where((o) => o.id == id).firstOrNull;

  /// Les autres clubs du championnat.
  List<Club> get otherClubs => season.clubs.where((c) => !c.isUser).toList();

  SquadSlot? slotOf(String playerId) {
    final club = userClub;
    if (club.squad.any((p) => p.id == playerId)) return SquadSlot.first;
    if (club.reserve.any((p) => p.id == playerId)) return SquadSlot.reserve;
    if (club.academy.any((p) => p.id == playerId)) return SquadSlot.academy;
    return null;
  }

  Player? ownPlayer(String playerId) {
    for (final p in userClub.allPlayers) {
      if (p.id == playerId) return p;
    }
    return null;
  }

  // ---------- offres envoyées ----------

  String? validateOffer({
    required String playerId,
    required OfferKind kind,
    required int fee,
    int optionFee = 0,
  }) {
    if (!transferWindowOpen) return transferWindowMessage;
    if (sportingDirector == null) {
      return 'Engagez un directeur sportif : il mène les négociations.';
    }
    final holder = clubOfPlayer(everyClub, playerId);
    if (holder == null) {
      return "Ce joueur n'est pas sous contrat : voyez les agents libres.";
    }
    if (holder.isUser) return 'Ce joueur est déjà dans votre club.';
    final busy = offers.any(
      (o) =>
          !o.incoming &&
          o.playerId == playerId &&
          (o.status == OfferStatus.pending ||
              o.status == OfferStatus.countered),
    );
    if (busy) return 'Une offre est déjà en cours pour ce joueur.';
    if (fee <= 0) return "Le montant de l'offre doit être positif.";
    if (kind == OfferKind.loanOption && optionFee <= 0) {
      return "Indiquez le prix de l'option d'achat.";
    }
    if (finance.treasury < fee) return 'Trésorerie insuffisante.';
    final club = userClub;
    final hasRoom =
        club.squad.length < maxSquadSize ||
        (division <= 3 && club.reserve.length < 25);
    if (!hasRoom) return 'Votre effectif est complet.';
    return null;
  }

  /// Envoie une offre : le club vendeur répond tout de suite
  /// (acceptée, contre-proposition ou refus).
  GameState makeOffer({
    required String playerId,
    required OfferKind kind,
    required int fee,
    int optionFee = 0,
    int contractYears = 3,
  }) {
    if (validateOffer(
          playerId: playerId,
          kind: kind,
          fee: fee,
          optionFee: optionFee,
        ) !=
        null) {
      return this;
    }
    final player = findPlayer(everyClub, playerId)!;
    final seller = clubOfPlayer(everyClub, playerId)!;
    var n = offers.length;
    while (offers.any((o) => o.id == 'out$seasonNumber-$n')) {
      n++;
    }
    final offer = Offer(
      id: 'out$seasonNumber-$n',
      playerId: playerId,
      playerName: player.name,
      sellerClubId: seller.id,
      buyerClubId: userClub.id,
      kind: kind,
      fee: fee,
      status: OfferStatus.pending,
      incoming: false,
      season: seasonNumber,
      round: season.currentRound,
      optionFee: optionFee,
      contractYears: contractYears,
    );
    return copyWith(offers: [...offers, offer]).resolveRoundOffers();
  }

  String? validateRaise(String offerId, int newFee) {
    if (!transferWindowOpen) return transferWindowMessage;
    final offer = offerById(offerId);
    if (offer == null || offer.status != OfferStatus.countered) {
      return "Cette offre n'est plus en négociation.";
    }
    if (newFee <= offer.fee) return "Proposez plus que l'offre précédente.";
    if (finance.treasury < newFee) return 'Trésorerie insuffisante.';
    return null;
  }

  /// Relance une offre contrée avec un nouveau montant.
  GameState raiseOffer(String offerId, int newFee) {
    if (validateRaise(offerId, newFee) != null) return this;
    final offer = offerById(offerId)!;
    final updated = offer.copyWith(
      fee: newFee,
      status: OfferStatus.pending,
      counterFee: 0,
      round: season.currentRound,
    );
    return copyWith(
      offers: [for (final o in offers) o.id == offerId ? updated : o],
    ).resolveRoundOffers();
  }

  String? validateAcceptCounter(String offerId) {
    if (!transferWindowOpen) return transferWindowMessage;
    final offer = offerById(offerId);
    if (offer == null || offer.status != OfferStatus.countered) {
      return "Cette offre n'est plus en négociation.";
    }
    if (finance.treasury < offer.counterFee) return 'Trésorerie insuffisante.';
    return null;
  }

  GameState acceptCounter(String offerId) {
    if (validateAcceptCounter(offerId) != null) return this;
    final offer = offerById(offerId)!;
    final player = findPlayer(everyClub, offer.playerId);
    final seller = clubOfPlayer(everyClub, offer.playerId);
    if (player == null || seller == null || seller.id != offer.sellerClubId) {
      return withdrawOffer(offerId);
    }
    return this.completeOutgoing(offer, player, seller, offer.counterFee);
  }

  GameState withdrawOffer(String offerId) {
    return copyWith(offers: offers.where((o) => o.id != offerId).toList());
  }

  // ---------- offres reçues ----------

  String? validateAcceptIncoming(String offerId) {
    if (!transferWindowOpen) return transferWindowMessage;
    final offer = offerById(offerId);
    if (offer == null || !offer.incoming) return "Cette offre n'existe plus.";
    final player = ownPlayer(offer.playerId);
    if (player == null) return "Ce joueur n'est plus dans votre club.";
    if (userClub.squad.any((p) => p.id == player.id)) {
      final count = userClub.squad
          .where((p) => p.position == player.position)
          .length;
      final minimum = minSquadByPosition[player.position] ?? 0;
      if (count <= minimum) {
        return 'Il vous faut au moins $minimum joueurs à ce poste.';
      }
    }
    final buyerExists = season.clubs.any((c) => c.id == offer.buyerClubId);
    if (!buyerExists) return "Le club acheteur n'existe plus.";
    return null;
  }

  GameState respondIncoming(String offerId, {required bool accept}) {
    final offer = offerById(offerId);
    if (offer == null || !offer.incoming) return this;
    final others = offers.where((o) => o.id != offerId).toList();
    if (!accept) return copyWith(offers: others);
    if (validateAcceptIncoming(offerId) != null) return this;

    final player = ownPlayer(offer.playerId)!;
    final isLoan = offer.kind != OfferKind.transfer;
    final arriving = isLoan ? player : player.copyWith(contractYears: 3);
    final clubs = movePlayer(
      clubs: season.clubs,
      player: arriving,
      fromClubId: userClub.id,
      toClubId: offer.buyerClubId,
    );
    final buyerName = season.clubById(offer.buyerClubId).name;
    var next = copyWith(
      season: season.withClubs(clubs),
      finance: finance.copyWith(
        treasury: finance.treasury + offer.fee,
        transfers: finance.transfers + offer.fee,
      ),
      offers: others,
      loans: isLoan
          ? [
              ...loans,
              LoanDeal(
                playerId: player.id,
                playerName: player.name,
                ownerClubId: userClub.id,
                borrowerClubId: offer.buyerClubId,
                optionFee: offer.kind == OfferKind.loanOption
                    ? offer.optionFee
                    : 0,
              ),
            ]
          : loans,
    );
    if (!next.userClub.hasFullLineup) next = next.autoPickStarters();
    return next._noted(
      isLoan ? 'Joueur prêté' : 'Joueur vendu',
      isLoan
          ? '${player.name} part en prêt à $buyerName '
              '(${formatMoney(offer.fee)}).'
          : '${player.name} signe à $buyerName pour '
              '${formatMoney(offer.fee)}.',
    );
  }

  // ---------- contrats ----------

  String? validateRelease(String playerId) {
    final player = ownPlayer(playerId);
    if (player == null) return 'Joueur introuvable.';
    if (loans.any((l) => l.playerId == playerId)) {
      return 'Ce joueur est en prêt : impossible de le libérer.';
    }
    if (userClub.squad.any((p) => p.id == playerId)) {
      final count = userClub.squad
          .where((p) => p.position == player.position)
          .length;
      final minimum = minSquadByPosition[player.position] ?? 0;
      if (count <= minimum) {
        return 'Il vous faut au moins $minimum joueurs à ce poste.';
      }
    }
    if (finance.treasury < releaseCost(player)) {
      return "Trésorerie insuffisante pour l'indemnité.";
    }
    return null;
  }

  /// Libère un joueur contre une indemnité : il devient agent libre.
  GameState releasePlayer(String playerId) {
    if (validateRelease(playerId) != null) return this;
    final player = ownPlayer(playerId)!;
    final cost = releaseCost(player);
    final club = userClub;
    final updated = club.copyWith(
      squad: club.squad.where((p) => p.id != playerId).toList(),
      reserve: club.reserve.where((p) => p.id != playerId).toList(),
      academy: club.academy.where((p) => p.id != playerId).toList(),
      starterIds: club.starterIds.where((id) => id != playerId).toList(),
    );
    var next = copyWith(
      season: season.withClub(updated),
      finance: finance.copyWith(
        treasury: finance.treasury - cost,
        wages: finance.wages + cost,
      ),
      market: [...market, player.copyWith(contractYears: 2)],
    );
    if (!next.userClub.hasFullLineup) next = next.autoPickStarters();
    return next._noted(
      'Joueur libéré',
      '${player.name} quitte le club (indemnité ${formatMoney(cost)}).',
    );
  }

  String? validateRenew(String playerId, int years) {
    final player = ownPlayer(playerId);
    if (player == null) return 'Joueur introuvable.';
    if (player.wantsOut) {
      return '${player.name} veut partir : il refuse de prolonger.';
    }
    if (player.mood < 35) {
      return '${player.name} est trop mécontent pour prolonger.';
    }
    if (years < 1 || years > 5) return 'Durée de 1 à 5 ans.';
    if (player.contractYears + years > 5) {
      return 'Un contrat ne peut pas dépasser 5 ans.';
    }
    if (finance.treasury < renewalCost(player, years)) {
      return 'Trésorerie insuffisante.';
    }
    return null;
  }

  GameState renewContract(String playerId, int years) {
    if (validateRenew(playerId, years) != null) return this;
    final player = ownPlayer(playerId)!;
    final cost = renewalCost(player, years);
    final club = userClub;
    Player pick(Player p) {
      return p.id == playerId
          ? p.copyWith(contractYears: p.contractYears + years)
          : p;
    }

    return copyWith(
      season: season.withClub(
        club.copyWith(
          squad: [for (final p in club.squad) pick(p)],
          reserve: [for (final p in club.reserve) pick(p)],
          academy: [for (final p in club.academy) pick(p)],
        ),
      ),
      finance: finance.copyWith(
        treasury: finance.treasury - cost,
        wages: finance.wages + cost,
      ),
    );
  }

  // ---------- équipes ----------

  String? validateMoveTo(String playerId, SquadSlot target) {
    final player = ownPlayer(playerId);
    final from = slotOf(playerId);
    if (player == null || from == null) return 'Joueur introuvable.';
    if (from == target) return 'Ce joueur est déjà dans cette équipe.';
    final club = userClub;
    switch (target) {
      case SquadSlot.first:
        if (club.squad.length >= maxSquadSize) {
          return 'Équipe première complète ($maxSquadSize joueurs).';
        }
        break;
      case SquadSlot.reserve:
        if (division > 3) return "Votre division n'a pas d'équipe réserve.";
        if (club.reserve.length >= 25) return 'Équipe réserve complète.';
        break;
      case SquadSlot.academy:
        if (player.age > 21) {
          return 'Le centre de formation accueille les moins de 22 ans.';
        }
        if (club.academy.length >= 20) return 'Centre de formation complet.';
        break;
    }
    if (from == SquadSlot.first) {
      final count = club.squad
          .where((p) => p.position == player.position)
          .length;
      final minimum = minSquadByPosition[player.position] ?? 0;
      if (count <= minimum) {
        return 'Il vous faut au moins $minimum joueurs à ce poste.';
      }
    }
    return null;
  }

  /// Promeut ou rétrograde un joueur entre équipe première, réserve et
  /// centre de formation.
  GameState moveToTeam(String playerId, SquadSlot target) {
    if (validateMoveTo(playerId, target) != null) return this;
    final player = ownPlayer(playerId)!;
    final club = userClub;
    final cleaned = club.copyWith(
      squad: club.squad.where((p) => p.id != playerId).toList(),
      reserve: club.reserve.where((p) => p.id != playerId).toList(),
      academy: club.academy.where((p) => p.id != playerId).toList(),
      starterIds: club.starterIds.where((id) => id != playerId).toList(),
    );
    final Club updated;
    switch (target) {
      case SquadSlot.first:
        updated = cleaned.copyWith(squad: [...cleaned.squad, player]);
        break;
      case SquadSlot.reserve:
        updated = cleaned.copyWith(reserve: [...cleaned.reserve, player]);
        break;
      case SquadSlot.academy:
        updated = cleaned.copyWith(academy: [...cleaned.academy, player]);
        break;
    }
    var next = copyWith(season: season.withClub(updated));
    if (!next.userClub.hasFullLineup) next = next.autoPickStarters();
    return next;
  }

  // ---------- prêts reçus ----------

  String? validateExerciseOption(String playerId) {
    if (!transferWindowOpen) return transferWindowMessage;
    final loan = loans
        .where((l) => l.playerId == playerId && l.borrowerClubId == 'user')
        .firstOrNull;
    if (loan == null) return "Ce joueur n'est pas prêté à votre club.";
    if (loan.optionFee <= 0) return "Ce prêt n'a pas d'option d'achat.";
    if (finance.treasury < loan.optionFee) return 'Trésorerie insuffisante.';
    return null;
  }

  GameState exerciseOption(String playerId) {
    if (validateExerciseOption(playerId) != null) return this;
    final loan = loans.firstWhere(
      (l) => l.playerId == playerId && l.borrowerClubId == 'user',
    );
    final player = ownPlayer(playerId)!;
    final clubs = updatePlayer(
      everyClub,
      player.copyWith(contractYears: 3),
    );
    return withEveryClub(clubs).copyWith(
      finance: finance.copyWith(
        treasury: finance.treasury - loan.optionFee,
        transfers: finance.transfers - loan.optionFee,
      ),
      loans: loans.where((l) => l.playerId != playerId).toList(),
    )._noted(
      "Option d'achat levée",
      '${player.name} signe définitivement pour '
          '${formatMoney(loan.optionFee)}.',
    );
  }

  // ---------- réglages ----------

  String? validateStadiumName(String name) {
    final trimmed = name.trim();
    if (trimmed.length < 2) return 'Le nom est trop court.';
    if (trimmed.length > 32) return 'Le nom est trop long (32 lettres).';
    return null;
  }

  GameState renameStadium(String name) {
    if (validateStadiumName(name) != null) return this;
    return copyWith(owner: owner.copyWith(stadiumName: name.trim()));
  }

  GameState setSeatColor(int index) {
    return copyWith(owner: owner.copyWith(seatColor: index.clamp(0, 5).toInt()));
  }

  GameState setDifficulty(int level) {
    return copyWith(owner: owner.copyWith(difficulty: level.clamp(0, 2).toInt()));
  }

  // ---------- humeur et prêts de développement ----------

  GameState _replaceOwn(Player updated) {
    final club = userClub;
    Player pick(Player p) => p.id == updated.id ? updated : p;
    return copyWith(
      season: season.withClub(
        club.copyWith(
          squad: [for (final p in club.squad) pick(p)],
          reserve: [for (final p in club.reserve) pick(p)],
          academy: [for (final p in club.academy) pick(p)],
        ),
      ),
    );
  }

  String? validateTalk(String playerId) {
    final player = ownPlayer(playerId);
    if (player == null) return 'Joueur introuvable.';
    if (player.mood >= 70) {
      return '${player.name} va bien : inutile d\'en parler.';
    }
    return null;
  }

  /// Le président discute avec un joueur mécontent.
  GameState talkToPlayer(String playerId) {
    if (validateTalk(playerId) != null) return this;
    final player = ownPlayer(playerId)!;
    final mood = (player.mood + 10).clamp(0, 100).toInt();
    final updated = player.copyWith(
      mood: mood,
      wantsOut: player.wantsOut && mood < 45,
    );
    return _replaceOwn(updated)._noted(
      'Discussion avec ${player.name}',
      '${player.name} se sent mieux écouté (${moodLabel(mood)}).',
    );
  }

  String? validateSendOnLoan(String playerId, String clubId) {
    if (!transferWindowOpen) return transferWindowMessage;
    if (sportingDirector == null) {
      return 'Engagez un directeur sportif pour organiser un prêt.';
    }
    final player = ownPlayer(playerId);
    if (player == null) return 'Joueur introuvable.';
    final target = season.clubs
        .where((c) => c.id == clubId && !c.isUser)
        .firstOrNull;
    if (target == null) return 'Club introuvable.';
    if (loans.any((l) => l.playerId == playerId)) {
      return 'Ce joueur est déjà en prêt.';
    }
    if (loans.where((l) => l.ownerClubId == userClub.id).length >= 6) {
      return 'Vous avez déjà 6 joueurs prêtés.';
    }
    if (target.squad.length >= 26) {
      return '${target.name} a déjà un effectif complet.';
    }
    if (userClub.squad.any((p) => p.id == playerId)) {
      final count = userClub.squad
          .where((p) => p.position == player.position)
          .length;
      final minimum = minSquadByPosition[player.position] ?? 0;
      if (count <= minimum) {
        return 'Il vous faut au moins $minimum joueurs à ce poste.';
      }
    }
    return null;
  }

  /// Envoie un joueur en prêt dans un club du championnat pour qu'il
  /// progresse (les moins de 24 ans gagnent des niveaux en fin de saison).
  GameState sendOnLoan(String playerId, String clubId) {
    if (validateSendOnLoan(playerId, clubId) != null) return this;
    final player = ownPlayer(playerId)!;
    final target = season.clubById(clubId);
    final clubs = movePlayer(
      clubs: season.clubs,
      player: player,
      fromClubId: userClub.id,
      toClubId: clubId,
    );
    var next = copyWith(
      season: season.withClubs(clubs),
      loans: [
        ...loans,
        LoanDeal(
          playerId: player.id,
          playerName: player.name,
          ownerClubId: userClub.id,
          borrowerClubId: clubId,
        ),
      ],
    );
    if (!next.userClub.hasFullLineup) next = next.autoPickStarters();
    return next
        .addHeadline(
          '${player.name} prêté à ${target.name}',
          '${userClub.name} envoie son joueur gagner du temps de jeu.',
          NewsKind.transfer,
        )
        ._noted(
          'Joueur prêté',
          '${player.name} part en prêt à ${target.name} pour progresser.',
        );
  }
}
