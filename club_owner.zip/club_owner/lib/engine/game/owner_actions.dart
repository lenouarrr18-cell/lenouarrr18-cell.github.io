import '../../core/utils/format.dart';
import '../../domain/entities/owner.dart';
import '../finance/finance.dart';
import '../owner/infrastructure.dart';
import '../owner/sponsors.dart';
import 'game_state.dart';

/// Dette maximale (intérêts compris).
const int maxDebt = 500000;

/// Montants proposés par la banque.
const List<int> loanAmounts = [50000, 100000, 200000];

/// Actions du propriétaire : travaux, sponsor, banque, messagerie.
extension OwnerActions on GameState {
  InboxMessage _message(String title, String body) {
    return InboxMessage(
      title: title,
      body: body,
      season: seasonNumber,
      round: season.currentRound,
    );
  }

  // ---------- infrastructures ----------

  String? validateUpgrade(InfraKind kind) {
    final level = owner.levelOf(kind);
    if (level >= maxInfraLevel) return 'Niveau maximum atteint.';
    if (owner.works.length >= maxConcurrentWorks(owner)) {
      return maxConcurrentWorks(owner) == 1
          ? 'Des travaux sont déjà en cours (le centre des opérations '
              'permet de mener plusieurs chantiers).'
          : 'Nombre maximal de chantiers atteint.';
    }
    final blockers = infraBlockers(owner, kind);
    if (blockers.isNotEmpty) return blockers.first;
    if (finance.treasury < upgradeCost(kind, level + 1)) {
      return 'Trésorerie insuffisante.';
    }
    return null;
  }

  GameState startUpgrade(InfraKind kind) {
    if (validateUpgrade(kind) != null) return this;
    final target = owner.levelOf(kind) + 1;
    final cost = upgradeCost(kind, target);
    final rounds = effectiveRounds(owner, kind, target);
    return copyWith(
      finance: finance.copyWith(
        treasury: finance.treasury - cost,
        infrastructure: finance.infrastructure + cost,
      ),
      owner: owner
          .withWorks([
            ...owner.works,
            InfraWork(kind: kind, targetLevel: target, roundsLeft: rounds),
          ])
          .logInfra(
            'Saison $seasonNumber, journée ${season.currentRound} : '
            '${infraLabel(kind)} niveau $target lancé '
            '(${formatLevelMoney(cost)}, $rounds journées)',
          )
          .addMessage(
            _message(
              'Travaux lancés',
              '${infraLevelName(kind, target)} : fin des travaux dans '
                  '$rounds journées.',
            ),
          ),
    );
  }

  // ---------- sponsor principal ----------

  List<SponsorDeal> get sponsorOffers {
    return generateSponsorOffers(
      division: division,
      seed: season.seed,
      seasonNumber: seasonNumber,
      reputation: owner.reputation,
    );
  }

  String? validateSignSponsor(String offerId) {
    if (owner.deal != null) return 'Vous avez déjà un sponsor principal.';
    final found = sponsorOffers.where((o) => o.id == offerId).isNotEmpty;
    if (!found) return "Cette offre n'est plus disponible.";
    return null;
  }

  GameState signSponsor(String offerId) {
    if (validateSignSponsor(offerId) != null) return this;
    final offer = sponsorOffers.firstWhere((o) => o.id == offerId);
    return copyWith(
      owner: owner
          .copyWith(deal: offer)
          .addMessage(
            _message(
              'Nouveau sponsor',
              '${offer.name} devient votre sponsor principal pour '
                  '${offer.seasonsLeft} saison(s).',
            ),
          ),
    );
  }

  /// Pénalité en cas de rupture : un quart de la somme annuelle.
  int get sponsorBreakPenalty {
    final deal = owner.deal;
    return deal == null ? 0 : deal.perSeason ~/ 4;
  }

  String? validateCancelSponsor() {
    if (owner.deal == null) return "Vous n'avez pas de sponsor principal.";
    if (finance.treasury < sponsorBreakPenalty) {
      return 'Trésorerie insuffisante pour la pénalité.';
    }
    return null;
  }

  GameState cancelSponsor() {
    if (validateCancelSponsor() != null) return this;
    final deal = owner.deal!;
    final penalty = sponsorBreakPenalty;
    return copyWith(
      finance: finance.copyWith(
        treasury: finance.treasury - penalty,
        extras: finance.extras - penalty,
      ),
      owner: owner
          .copyWith(clearDeal: true)
          .addMessage(
            _message(
              'Contrat rompu',
              'Vous rompez avec ${deal.name} et payez une pénalité de '
                  '${formatMoney(penalty)}.',
            ),
          ),
    );
  }

  // ---------- banque ----------

  String? validateLoan(int amount) {
    if (amount <= 0) return 'Montant invalide.';
    final total = (amount * (1 + loanInterestRate)).round();
    if (owner.debt + total > maxDebt) {
      return 'La banque refuse : dette maximale de ${formatMoney(maxDebt)} '
          'dépassée.';
    }
    return null;
  }

  GameState takeLoan(int amount) {
    if (validateLoan(amount) != null) return this;
    final total = (amount * (1 + loanInterestRate)).round();
    final newDebt = owner.debt + total;
    final perRound = (newDebt / season.totalRounds).ceil();
    return copyWith(
      finance: finance.copyWith(treasury: finance.treasury + amount),
      owner: owner
          .copyWith(debt: newDebt, loanPerRound: perRound)
          .addMessage(
            _message(
              'Prêt accordé',
              'La banque vous prête ${formatMoney(amount)}. Dette totale : '
                  '${formatMoney(newDebt)}, '
                  'remboursée à chaque journée.',
            ),
          ),
    );
  }

  String? validateRepay() {
    if (owner.debt <= 0) return "Vous n'avez aucune dette.";
    if (finance.treasury < owner.debt) {
      return 'Trésorerie insuffisante pour tout rembourser.';
    }
    return null;
  }

  GameState repayLoan() {
    if (validateRepay() != null) return this;
    final debt = owner.debt;
    final interest = (debt * loanInterestRate / (1 + loanInterestRate)).round();
    return copyWith(
      finance: finance.copyWith(
        treasury: finance.treasury - debt,
        debtService: finance.debtService + interest,
      ),
      owner: owner
          .copyWith(debt: 0, loanPerRound: 0)
          .addMessage(_message('Dette soldée', 'Vous avez remboursé la banque.')),
    );
  }

  // ---------- messagerie ----------

  GameState markInboxRead() => copyWith(owner: owner.markAllRead());
}
