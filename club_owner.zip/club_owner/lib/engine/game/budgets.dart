import 'dart:math';

import '../finance/finance.dart';
import 'game_state.dart';

/// Budgets fixés par le président : le staff s'en sert pour renouveler
/// l'effectif (transferts, prolongations), sans jamais les dépasser.
extension Budgets on GameState {
  /// Budget transferts de la saison (automatique : 30 % de la trésorerie).
  int get transferBudgetTotal => owner.transferBudget > 0
      ? owner.transferBudget
      : max(0, (finance.treasury * 0.3).round());

  int get transferSpentThisSeason =>
      owner.spentSeason == seasonNumber ? owner.transferSpent : 0;

  /// Ce qu'il reste à dépenser cette saison.
  int get transferBudgetLeft => owner.transferBudget > 0
      ? max(0, owner.transferBudget - transferSpentThisSeason)
      : transferBudgetTotal;

  /// Masse salariale annuelle actuelle.
  int get wageBill => squadAnnualWages(userClub.allPlayers);

  /// Plafond salarial (automatique : masse actuelle + 15 %).
  int get wageBudget =>
      owner.wageBudget > 0 ? owner.wageBudget : (wageBill * 1.15).round();

  GameState setBudgets({int? transfer, int? wage}) {
    return copyWith(
      owner: owner.copyWith(
        transferBudget: transfer == null ? null : max(0, transfer),
        wageBudget: wage == null ? null : max(0, wage),
      ),
    );
  }

  /// Enregistre une dépense de transfert sur la saison en cours.
  GameState spendTransfer(int amount) {
    if (amount <= 0) return this;
    return copyWith(
      owner: owner.copyWith(
        transferSpent: transferSpentThisSeason + amount,
        spentSeason: seasonNumber,
      ),
    );
  }

  GameState toggleSellList(String playerId) {
    final list = [...owner.sellList];
    list.contains(playerId) ? list.remove(playerId) : list.add(playerId);
    return copyWith(owner: owner.copyWith(sellList: list));
  }
}
