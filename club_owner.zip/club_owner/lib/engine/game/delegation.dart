import '../../core/utils/format.dart';
import '../../domain/entities/lineup.dart';
import '../../domain/entities/owner.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/transfer.dart';
import '../finance/finance.dart';
import 'budgets.dart';
import 'game_state.dart';
import 'governance.dart';
import 'transfer_actions.dart';

/// Gestion de l'effectif par le staff : le président fixe les budgets,
/// le directeur sportif s'occupe des ventes, des jeunes, des agents
/// libres, des prêts, des libérations et des prolongations de contrat.
/// Il agit toutes les trois journées.
extension DsDelegation on GameState {
  GameState dsRoutine(int round) {
    if (sportingDirector == null) return this;
    if (round % 3 != 1) return this;

    var state = this;
    final lines = <String>[];

    // 0. Joueurs que le président veut voir partir : offre correcte acceptée.
    for (final offer in [...state.offers]) {
      if (!offer.incoming || offer.status != OfferStatus.pending) continue;
      if (!state.owner.sellList.contains(offer.playerId)) continue;
      final player = state.ownPlayer(offer.playerId);
      if (player == null) continue;
      if (offer.fee < playerValue(player) * 0.85) continue;
      if (state.validateAcceptIncoming(offer.id) != null) continue;
      state = state.respondIncoming(offer.id, accept: true);
      state = state.copyWith(
        owner: state.owner.copyWith(
          sellList: [
            for (final id in state.owner.sellList)
              if (id != player.id) id,
          ],
        ),
      );
      lines.add('${player.name} est vendu pour ${formatMoney(offer.fee)}, '
          'comme vous le souhaitiez.');
    }

    // 1. Ventes : offres reçues très au-dessus de la valeur du joueur.
    for (final offer in [...state.offers]) {
      if (!offer.incoming || offer.status != OfferStatus.pending) continue;
      final player = state.ownPlayer(offer.playerId);
      if (player == null) continue;
      if (state.userClub.starterIds.contains(player.id)) continue;
      if (offer.fee < playerValue(player) * 1.15) continue;
      if (state.validateAcceptIncoming(offer.id) != null) continue;
      state = state.proposeDecision(
        kind: 'sell',
        playerId: player.id,
        playerName: player.name,
        amount: offer.fee,
        offerId: offer.id,
        round: round,
        text: 'Je recommande de vendre ${player.name} pour '
            '${formatMoney(offer.fee)} : le montant dépasse sa valeur.',
      );
    }

    // 2. Promotion des jeunes du centre de formation.
    var promoted = 0;
    final youths = [...state.userClub.academy]
      ..sort((a, b) => b.maxSkill.compareTo(a.maxSkill));
    for (final youth in youths) {
      if (promoted >= 2) break;
      final ready = (youth.age >= 18 && youth.skill >= 45) ||
          (youth.age >= 19 && youth.maxSkill >= 65);
      if (!ready) continue;
      final target = state.division <= 3 ? SquadSlot.reserve : SquadSlot.first;
      if (state.validateMoveTo(youth.id, target) != null) continue;
      state = state.moveToTeam(youth.id, target);
      promoted++;
      lines.add(
        '${youth.name} est promu '
        '${target == SquadSlot.reserve ? 'en réserve' : 'en équipe première'}.',
      );
    }

    // 3. Agents libres : combler les postes les moins fournis.
    var signed = 0;
    for (final position in PlayerPosition.values) {
      if (signed >= 2) break;
      final minimum = minSquadByPosition[position] ?? 0;
      final have = state.userClub.squad
          .where((p) => p.position == position)
          .length;
      if (have > minimum) continue;
      final budget = state.transferBudgetLeft * 0.4;
      final options = state.market
          .where((p) => p.position == position && playerValue(p) <= budget)
          .toList()
        ..sort((a, b) => b.skill.compareTo(a.skill));
      for (final candidate in options.take(3)) {
        if (state.validateBuy(candidate.id) != null) continue;
        final before = state.finance.treasury;
        state = state.buyPlayer(candidate.id);
        state = state.spendTransfer(before - state.finance.treasury);
        signed++;
        lines.add('Signature de ${candidate.name} (agent libre).');
        break;
      }
    }

    // 4. Prêts de développement pour les jeunes non titulaires.
    var lent = 0;
    final loanedOut = state.loans
        .where((l) => l.ownerClubId == state.userClub.id)
        .length;
    if (loanedOut < 4) {
      final prospects = [
        ...state.userClub.squad,
        ...state.userClub.reserve,
      ].where(
        (p) =>
            p.age <= 22 &&
            p.maxSkill > p.skill + 3 &&
            !state.userClub.starterIds.contains(p.id),
      ).toList()
        ..sort((a, b) => b.maxSkill.compareTo(a.maxSkill));
      final hosts = state.otherClubs
        ..sort((a, b) => a.squad.length.compareTo(b.squad.length));
      for (final prospect in prospects) {
        if (lent >= 2 || hosts.isEmpty) break;
        final host = hosts.first;
        if (state.validateSendOnLoan(prospect.id, host.id) != null) continue;
        state = state.sendOnLoan(prospect.id, host.id);
        lent++;
        lines.add('${prospect.name} part en prêt à ${host.name}.');
      }
    }

    // 5. Libérer un joueur en fin de carrière devenu inutile.
    for (final p in [...state.userClub.squad]) {
      final count = state.userClub.squad
          .where((x) => x.position == p.position)
          .length;
      final minimum = minSquadByPosition[p.position] ?? 0;
      if (p.age < 34 || p.skill >= 55 || count <= minimum + 2) continue;
      if (state.finance.treasury < releaseCost(p) * 5) continue;
      if (state.validateRelease(p.id) != null) continue;
      state = state.proposeDecision(
        kind: 'release',
        playerId: p.id,
        playerName: p.name,
        round: round,
        text: 'Je propose de libérer ${p.name} (${p.age} ans) : il ne '
            'rentre plus dans nos plans sportifs.',
      );
      break;
    }

    // 6. Contrats : le staff prolonge ceux qui comptent, dans le plafond
    // salarial fixé par le président, et laisse partir les autres.
    var renewed = 0;
    final ending = [
      ...state.userClub.squad,
      ...state.userClub.reserve,
    ].where((p) => p.contractYears <= 1).toList()
      ..sort((a, b) => b.skill.compareTo(a.skill));
    for (final p in ending) {
      if (renewed >= 4) break;
      final samePos = state.userClub.squad
          .where((x) => x.position == p.position)
          .toList()
        ..sort((a, b) => b.skill.compareTo(a.skill));
      final rank = samePos.indexWhere((x) => x.id == p.id);
      final keep = state.userClub.starterIds.contains(p.id) ||
          (p.age <= 23 && p.maxSkill > p.skill + 3) ||
          (rank >= 0 && rank <= (minSquadByPosition[p.position] ?? 2));
      if (!keep || p.age >= 34) {
        if (p.contractYears == 1 && round == 1) {
          lines.add('${p.name} ne sera pas prolongé : il partira en fin de '
              'contrat.');
        }
        continue;
      }
      final years = p.age <= 26 ? 3 : (p.age <= 30 ? 2 : 1);
      final cost = renewalCost(p, years);
      final raise = (annualWage(p) * 0.1).round();
      if (state.wageBill + raise > state.wageBudget) {
        lines.add('Impossible de prolonger ${p.name} : le plafond salarial '
            'est atteint.');
        continue;
      }
      if (cost > state.finance.treasury * 0.08) continue;
      if (state.validateRenew(p.id, years) != null) continue;
      state = state.renewContract(p.id, years);
      renewed++;
      lines.add('${p.name} prolonge de $years an(s) '
          '(prime ${formatMoney(cost)}).');
    }

    if (lines.isEmpty) return state;
    return state.copyWith(
      owner: state.owner.addMessage(
        InboxMessage(
          title: 'Le directeur sportif a agi',
          body: lines.join('\n'),
          season: state.seasonNumber,
          round: round,
          sender: 'ds',
        ),
      ),
    );
  }
}
