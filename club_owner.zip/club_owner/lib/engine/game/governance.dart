import 'dart:math';

import '../../core/utils/format.dart';
import '../../domain/entities/division.dart';
import '../finance/finance.dart';
import '../../domain/entities/owner.dart';
import '../owner/advisor.dart';
import '../owner/goals.dart';
import 'game_state.dart';
import 'transfer_actions.dart';

/// Libellés des expéditeurs de la messagerie.
const Map<String, String> senderLabels = {
  'system': 'Club',
  'ds': 'Directeur sportif',
  'manager': 'Manager',
  'finance': 'Finances',
  'academy': 'Formation',
  'medical': 'Staff médical',
  'commercial': 'Service commercial',
  'supporters': 'Supporters',
  'board': 'Conseil',
};

/// Missions de bienvenue (facultatives) : identifiant -> (titre, route).
const List<List<String>> startMissions = [
  ['finance', 'Consulter les finances', '/finance'],
  ['squad', "Découvrir l'effectif", '/squad'],
  ['manager', 'Lire le rapport du manager', '/staff'],
  ['infra', 'Découvrir les installations', '/infrastructure'],
  ['calendar', 'Consulter le calendrier', '/calendar'],
  ['objectives', 'Connaître les objectifs du conseil', '/office'],
];

/// Gouvernance : les dirigeants proposent, le président peut bloquer.
extension Governance on GameState {
  GameState postMessage(String sender, String title, String body, int round) {
    return copyWith(
      owner: owner.addMessage(
        InboxMessage(
          title: title,
          body: body,
          season: seasonNumber,
          round: round,
          sender: sender,
        ),
      ),
    );
  }

  /// Prépare une décision : elle sera exécutée dans deux journées si le
  /// président ne la bloque pas.
  GameState proposeDecision({
    required String kind,
    required String playerId,
    required String playerName,
    required String text,
    required int round,
    int amount = 0,
    String offerId = '',
  }) {
    if (owner.decisions.any((d) => d.playerId == playerId)) return this;
    final decision = PendingDecision(
      id: '$kind-$playerId-$seasonNumber-$round',
      kind: kind,
      playerId: playerId,
      playerName: playerName,
      text: text,
      season: seasonNumber,
      executeRound: round + 2,
      amount: amount,
      offerId: offerId,
    );
    final next = copyWith(
      owner: owner.copyWith(decisions: [...owner.decisions, decision]),
    );
    return next.postMessage(
      'ds',
      'Décision à valider',
      '$text\nSans réponse de votre part, elle sera exécutée '
          'à la journée ${decision.executeRound}.',
      round,
    );
  }

  GameState _execute(PendingDecision d, int round, {bool manual = false}) {
    var state = copyWith(
      owner: owner.copyWith(
        decisions: owner.decisions.where((x) => x.id != d.id).toList(),
      ),
    );
    if (d.kind == 'invest' || d.kind == 'buyout') {
      if (!manual) {
        return state.postMessage(
          'board',
          'Offre retirée',
          "Faute de réponse, l'offre « ${d.playerName} » a été retirée.",
          round,
        );
      }
      final cash = state.finance.copyWith(
        treasury: state.finance.treasury + d.amount,
      );
      if (d.kind == 'invest') {
        return state
            .copyWith(
              finance: cash,
              owner: state.owner.copyWith(
                fanMood: _clamp(state.owner.fanMood - 5),
                confidence: _clamp(state.owner.confidence + 4),
              ),
            )
            .postMessage(
              'finance',
              'Investissement accepté',
              '${formatMoney(d.amount)} versés au club. Une partie des '
                  "supporters s'inquiète de l'arrivée d'un investisseur.",
              round,
            );
      }
      return state
          .copyWith(
            finance: cash,
            owner: state.owner.copyWith(soldFor: d.amount),
          )
          .postMessage(
            'board',
            'Club vendu',
            'Vous avez cédé le club pour ${formatMoney(d.amount)}. '
                'Votre carrière de président se termine : lancez une '
                'nouvelle partie quand vous voulez.',
            round,
          );
    }
    if (d.kind == 'sell') {
      if (state.validateAcceptIncoming(d.offerId) != null) {
        return state.postMessage(
          'ds',
          'Vente annulée',
          "L'offre pour ${d.playerName} n'est plus valable.",
          round,
        );
      }
      state = state.respondIncoming(d.offerId, accept: true);
      return state
          .copyWith(owner: state.owner.copyWith(dsTrust: _clamp(state.owner.dsTrust + 2)))
          .postMessage(
            'ds',
            'Vente conclue',
            '${d.playerName} est vendu pour ${formatMoney(d.amount)}.',
            round,
          );
    }
    if (state.validateRelease(d.playerId) != null) {
      return state.postMessage(
        'ds',
        'Libération impossible',
        'Le dossier de ${d.playerName} ne peut plus être exécuté.',
        round,
      );
    }
    state = state.releasePlayer(d.playerId);
    return state.postMessage(
      'ds',
      'Joueur libéré',
      '${d.playerName} quitte le club comme prévu.',
      round,
    );
  }

  /// Exécute les décisions arrivées à échéance (sans veto).
  GameState processDecisions(int round) {
    if (owner.decisions.isEmpty) return this;
    var state = this;
    for (final d in [...owner.decisions]) {
      if (d.season != seasonNumber) {
        state = state.copyWith(
          owner: state.owner.copyWith(
            decisions:
                state.owner.decisions.where((x) => x.id != d.id).toList(),
          ),
        );
      } else if (round >= d.executeRound) {
        state = state._execute(d, round);
      }
    }
    return state;
  }

  PendingDecision? _find(String id) {
    for (final d in owner.decisions) {
      if (d.id == id) return d;
    }
    return null;
  }

  /// Le président valide : exécution immédiate.
  GameState approveDecision(String id) {
    final d = _find(id);
    if (d == null) return this;
    final done = _execute(d, 0, manual: true);
    return done.copyWith(
      owner: done.owner.copyWith(dsTrust: _clamp(done.owner.dsTrust + 1)),
    );
  }

  /// Droit de veto : la décision est annulée, la direction en prend note.
  GameState blockDecision(String id) {
    final d = _find(id);
    if (d == null) return this;
    if (d.kind == 'invest' || d.kind == 'buyout') {
      return copyWith(
        owner: owner.copyWith(
          decisions: owner.decisions.where((x) => x.id != id).toList(),
          fanMood: d.kind == 'buyout'
              ? _clamp(owner.fanMood + 5)
              : owner.fanMood,
        ),
      ).postMessage('board', 'Offre refusée', 'Vous déclinez : ${d.playerName}.', 0);
    }
    final next = copyWith(
      owner: owner.copyWith(
        decisions: owner.decisions.where((x) => x.id != id).toList(),
        vetoCount: owner.vetoCount + 1,
        dsTrust: _clamp(owner.dsTrust - 4),
        tension: _clamp(owner.tension + 8),
      ),
    );
    return next.postMessage(
      'ds',
      'Veto du président',
      'Vous avez bloqué la décision concernant ${d.playerName}. '
          'Nous respectons votre choix.',
      0,
    );
  }

  /// Demande une autre solution : le directeur sportif cherche un prêt.
  GameState requestAlternative(String id) {
    final d = _find(id);
    if (d == null) return this;
    var state = copyWith(
      owner: owner.copyWith(
        decisions: owner.decisions.where((x) => x.id != id).toList(),
      ),
    );
    final hosts = [...state.otherClubs]
      ..sort((a, b) => a.squad.length.compareTo(b.squad.length));
    for (final host in hosts.take(5)) {
      if (state.validateSendOnLoan(d.playerId, host.id) != null) continue;
      state = state.sendOnLoan(d.playerId, host.id);
      return state.postMessage(
        'ds',
        'Autre solution trouvée',
        '${d.playerName} est prêté à ${host.name}.',
        0,
      );
    }
    return state.postMessage(
      'ds',
      'Aucune alternative',
      'Nous gardons ${d.playerName} pour le moment, faute de solution.',
      0,
    );
  }

  /// Relevé de trésorerie et évolution des tensions, chaque journée.
  GameState leaderTick(int round) {
    final history = [...owner.financeHistory, finance.treasury];
    final trimmed = history.length > 60
        ? history.sublist(history.length - 60)
        : history;
    var next = copyWith(
      owner: owner.copyWith(
        financeHistory: trimmed,
        tension: round % 3 == 0 ? _clamp(owner.tension - 1) : owner.tension,
      ),
    );
    next = next._trackGoals(round)._trackAdvice(round)._rollClubEvent(round);
    if (round % 6 == 0 && next.owner.tension >= 60) {
      next = next
          .copyWith(
            owner: next.owner.copyWith(
              managerTrust: _clamp(next.owner.managerTrust - 3),
            ),
          )
          .postMessage(
            'manager',
            'Climat tendu',
            'Vos interventions répétées sur les décisions sportives '
                'créent des tensions dans le vestiaire.',
            round,
          );
    }
    return next;
  }

  /// Propose parfois un investissement ou une offre de rachat du club.
  GameState _rollClubEvent(int round) {
    if (owner.soldFor > 0 || seasonNumber < 2) return this;
    if (owner.decisions.any((d) => d.kind == 'invest' || d.kind == 'buyout')) {
      return this;
    }
    final r = Random(season.seed * 29 + seasonNumber * 131 + round * 7);
    final roll = r.nextDouble();
    final factor = divisionRevenueFactor(division);
    if (roll < 0.035 && owner.reputation >= 25) {
      final amount =
          (((300000 + r.nextInt(500000)) * factor) / 10000).round() * 10000;
      return _offer(
        'invest',
        'Proposition d\'investissement',
        amount,
        'Un fonds d\'investissement propose d\'apporter '
            '${formatMoney(amount)} au club. Les supporters pourraient '
            'se méfier, mais le conseil y est favorable.',
        round,
      );
    }
    if (roll > 0.985 && owner.reputation >= 45 && seasonNumber >= 3) {
      var value = 0;
      for (final p in userClub.squad) {
        value += playerValue(p);
      }
      final infra = InfraKind.values.fold<int>(
        0,
        (sum, kind) => sum + owner.levelOf(kind),
      );
      final amount = (((value * 0.6 + infra * 100000 + owner.reputation * 80000) *
                  1.2) /
              10000)
          .round() *
          10000;
      return _offer(
        'buyout',
        'Offre de rachat du club',
        amount,
        'Un milliardaire propose de racheter le club pour '
            '${formatMoney(amount)}. Accepter met fin à votre carrière de '
            'président.',
        round,
      );
    }
    return this;
  }

  GameState _offer(
    String kind,
    String title,
    int amount,
    String text,
    int round,
  ) {
    final decision = PendingDecision(
      id: '$kind-$seasonNumber-$round',
      kind: kind,
      playerId: '',
      playerName: title,
      text: text,
      season: seasonNumber,
      executeRound: round + 6,
      amount: amount,
    );
    return copyWith(
      owner: owner.copyWith(decisions: [...owner.decisions, decision]),
    ).postMessage('board', title, '$text\nRéponse attendue avant la '
        'journée ${decision.executeRound}.', round);
  }

  GameState _trackGoals(int round) {
    var state = this;
    for (final goal in longGoals) {
      if (state.owner.goalsDone.contains(goal.id)) continue;
      if (state.seasonNumber > goal.years || state.seasonNumber < 2) continue;
      if (!goal.check(state)) continue;
      state = state.copyWith(
        owner: state.owner.copyWith(
          goalsDone: [...state.owner.goalsDone, goal.id],
          reputation: _clamp(state.owner.reputation + 2),
          confidence: _clamp(state.owner.confidence + 3),
        ),
      );
      state = state.postMessage(
        'board',
        'Objectif atteint',
        'Le conseil salue la réalisation de votre objectif à '
            '${goal.years} ans : ${goal.title}.',
        round,
      );
    }
    return state;
  }

  /// Envoie dans la messagerie les nouveaux conseils graves, une seule
  /// fois par saison et par sujet.
  GameState _trackAdvice(int round) {
    if (round % 3 != 0) return this;
    var state = this;
    for (final advice in adviseClub(state)) {
      if (advice.level.index < AdviceLevel.urgent.index) continue;
      final key = '$seasonNumber-${advice.id}';
      if (state.owner.adviceSeen.contains(key)) continue;
      final seen = [...state.owner.adviceSeen, key];
      state = state.copyWith(
        owner: state.owner.copyWith(
          adviceSeen: seen.length > 60 ? seen.sublist(seen.length - 60) : seen,
        ),
      );
      state = state.postMessage(
        'board',
        '${adviceLevelLabel(advice.level)} : ${advice.situation}',
        '${advice.explanation}\n${advice.consequence}\n'
            'Conseil : ${advice.solution}',
        round,
      );
      break;
    }
    return state;
  }

  GameState finishIntro() => copyWith(owner: owner.copyWith(introDone: true));

  GameState deleteMessage(int index) =>
      copyWith(owner: owner.removeMessageAt(index));

  GameState deleteMessages(Set<int> indices) =>
      copyWith(owner: owner.removeMessages(indices));

  GameState flagMessages(Set<int> indices, {bool? read, bool? archived}) =>
      copyWith(
        owner: owner.flagMessages(indices, read: read, archived: archived),
      );

  GameState clearReadMessages() => copyWith(
        owner: owner.copyWith(
          inbox: owner.inbox.where((m) => !m.read).toList(),
        ),
      );

  GameState completeMission(String id) {
    if (owner.missionsDone.contains(id)) return this;
    return copyWith(
      owner: owner.copyWith(missionsDone: [...owner.missionsDone, id]),
    );
  }

  GameState seeTip(String id) {
    if (owner.seenTips.contains(id)) return this;
    return copyWith(owner: owner.copyWith(seenTips: [...owner.seenTips, id]));
  }

  GameState setTipsEnabled(bool value) =>
      copyWith(owner: owner.copyWith(tipsEnabled: value));

}

int _clamp(int v) => v < 0 ? 0 : (v > 100 ? 100 : v);
