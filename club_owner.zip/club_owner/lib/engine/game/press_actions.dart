import '../../domain/entities/owner.dart';
import 'game_state.dart';

/// Réponses du président à la presse.
extension PressActions on GameState {
  /// Répond à la question de la presse avec l'option [index].
  GameState answerPress(int index) {
    final question = owner.press;
    if (question == null || index < 0 || index >= question.options.length) {
      return this;
    }
    final option = question.options[index];

    var club = userClub;
    if (option.teamMood != 0) {
      club = club.copyWith(
        squad: [
          for (final p in club.squad)
            p.copyWith(
              mood: (p.mood + option.teamMood).clamp(12, 100).toInt(),
            ),
        ],
      );
    }

    return copyWith(
      season: season.withClub(club),
      owner: owner
          .copyWith(
            fanMood: (owner.fanMood + option.fanMood).clamp(0, 100).toInt(),
            reputation: (owner.reputation + option.reputation)
                .clamp(0, 100)
                .toInt(),
            clearPress: true,
          )
          .addNews(
            NewsItem(
              headline: option.headline,
              body: '${question.context}. « ${question.question} »',
              season: seasonNumber,
              round: season.currentRound,
              kind: NewsKind.press,
            ),
          ),
    );
  }
}
