import '../../domain/data/world_data.dart';
import '../../domain/entities/club.dart';
import '../../domain/entities/honours.dart';
import '../../domain/entities/match_summary.dart';
import '../../domain/entities/owner.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/season_record.dart';
import '../../domain/entities/staff.dart';
import '../../domain/entities/tactic.dart';
import '../../domain/entities/transfer.dart';
import '../../domain/entities/team_strength.dart';
import '../calendar/fixture_generator.dart';
import '../finance/finance.dart';
import '../match/match_models.dart';
import '../season/season.dart';
import '../world/world_league.dart';
import 'world_codec.dart';
import 'game_state.dart';

const int saveVersion = 3;

/// Convertit la partie en données JSON.
///
/// Seuls les scores des matchs sont conservés ; le calendrier est
/// recalculé à partir de l'ordre des clubs.
Map<String, Object?> encodeGame(GameState state, {bool includeWorld = true}) {
  final season = state.season;
  return {
    'version': saveVersion,
    'countryId': state.country.id,
    'cityName': state.city.name,
    'division': state.division,
    'seasonNumber': state.seasonNumber,
    'seed': season.seed,
    'currentRound': season.currentRound,
    'clubs': [for (final club in season.clubs) _encodeClub(club)],
    'results': {
      for (final entry in season.results.entries)
        entry.key: [entry.value.homeGoals, entry.value.awayGoals],
    },
    'finance': state.finance.toJson(),
    'market': [for (final player in state.market) player.toJson()],
    'history': [for (final record in state.history) record.toJson()],
    'staff': [for (final member in state.staff) member.toJson()],
    'owner': state.owner.toJson(),
    'loans': [for (final loan in state.loans) loan.toJson()],
    'offers': [for (final offer in state.offers) offer.toJson()],
    'awards': [for (final award in state.awards) award.toJson()],
    'legends': [for (final legend in state.legends) legend.toJson()],
    'intl': [for (final result in state.intl) result.toJson()],
    'cups': [for (final result in state.cups) result.toJson()],
    'social': [for (final post in state.social) post.toJson()],
    'world': includeWorld
        ? [for (final league in state.world) encodeLeague(league)]
        : const <Object?>[],
    'lastMatch': state.lastMatch?.toJson(),
  };
}

/// Reconstruit la partie, ou `null` si la version est inconnue.
/// Lève une exception si les données sont corrompues.
GameState? decodeGame(Map<String, dynamic> json) {
  // Une sauvegarde plus ancienne se charge toujours : chaque ajout du jeu
  // a des valeurs par défaut. Seule une sauvegarde d'une version plus
  // récente que l'application est refusée.
  final version = json['version'];
  if (version is! int || version > saveVersion || version < 1) return null;

  final country = worldCountries.firstWhere((c) => c.id == json['countryId']);
  final city = country.cities.firstWhere((c) => c.name == json['cityName']);

  final clubs = [
    for (final raw in json['clubs'] as List<dynamic>)
      _decodeClub(raw as Map<String, dynamic>),
  ];

  final results = <String, MatchResult>{};
  (json['results'] as Map<String, dynamic>).forEach((key, value) {
    final goals = value as List<dynamic>;
    results[key] = MatchResult(
      homeGoals: goals[0] as int,
      awayGoals: goals[1] as int,
      events: const [],
    );
  });

  return GameState(
    country: country,
    city: city,
    division: json['division'] as int,
    seasonNumber: json['seasonNumber'] as int,
    season: Season(
      clubs: clubs,
      fixtures: generateRoundRobin(clubs.map((c) => c.id).toList()),
      results: results,
      currentRound: json['currentRound'] as int,
      seed: json['seed'] as int,
    ),
    finance: FinanceBook.fromJson(json['finance'] as Map<String, dynamic>),
    market: [
      for (final raw in json['market'] as List<dynamic>)
        Player.fromJson(raw as Map<String, dynamic>),
    ],
    history: [
      for (final raw in json['history'] as List<dynamic>)
        SeasonRecord.fromJson(raw as Map<String, dynamic>),
    ],
    staff: [
      for (final raw in (json['staff'] as List<dynamic>? ?? const <dynamic>[]))
        StaffMember.fromJson(raw as Map<String, dynamic>),
    ],
    owner: json['owner'] == null
        ? const OwnerState()
        : OwnerState.fromJson(json['owner'] as Map<String, dynamic>),
    loans: [
      for (final raw in _list(json, 'loans'))
        LoanDeal.fromJson(raw as Map<String, dynamic>),
    ],
    offers: [
      for (final raw in _list(json, 'offers'))
        Offer.fromJson(raw as Map<String, dynamic>),
    ],
    awards: [
      for (final raw in _list(json, 'awards'))
        AwardRecord.fromJson(raw as Map<String, dynamic>),
    ],
    legends: [
      for (final raw in _list(json, 'legends'))
        LegendEntry.fromJson(raw as Map<String, dynamic>),
    ],
    intl: [
      for (final raw in _list(json, 'intl'))
        TournamentResult.fromJson(raw as Map<String, dynamic>),
    ],
    cups: [
      for (final raw in _list(json, 'cups'))
        TournamentResult.fromJson(raw as Map<String, dynamic>),
    ],
    social: [
      for (final raw in _list(json, 'social'))
        SocialPost.fromJson(raw as Map<String, dynamic>),
    ],
    world: [
      for (final raw in _list(json, 'world'))
        decodeLeague(raw as Map<String, dynamic>),
    ],
    lastMatch: json['lastMatch'] == null
        ? null
        : MatchSummary.fromJson(json['lastMatch'] as Map<String, dynamic>),
  );
}

List<dynamic> _list(Map<String, dynamic> json, String key) {
  return json[key] as List<dynamic>? ?? const <dynamic>[];
}

Map<String, Object?> _encodeClub(Club club) {
  final strength = club.strength;
  return {
    'id': club.id,
    'name': club.name,
    'isUser': club.isUser,
    'strength': {
      'attack': strength.attack,
      'midfield': strength.midfield,
      'defense': strength.defense,
      'goalkeeper': strength.goalkeeper,
    },
    'squad': [for (final player in club.squad) player.toJson()],
    'starterIds': club.starterIds,
    'reserve': [for (final player in club.reserve) player.toJson()],
    'academy': [for (final player in club.academy) player.toJson()],
    'tactic': club.tactic.toJson(),
    'prestige': club.prestige,
  };
}

Club _decodeClub(Map<String, dynamic> json) {
  final strength = json['strength'] as Map<String, dynamic>;
  return Club(
    id: json['id'] as String,
    name: json['name'] as String,
    isUser: json['isUser'] as bool,
    strength: TeamStrength(
      attack: (strength['attack'] as num).toDouble(),
      midfield: (strength['midfield'] as num).toDouble(),
      defense: (strength['defense'] as num).toDouble(),
      goalkeeper: (strength['goalkeeper'] as num).toDouble(),
    ),
    squad: [
      for (final raw in json['squad'] as List<dynamic>)
        Player.fromJson(raw as Map<String, dynamic>),
    ],
    starterIds: [
      for (final id in json['starterIds'] as List<dynamic>) id as String,
    ],
    reserve: [
      for (final raw in _list(json, 'reserve'))
        Player.fromJson(raw as Map<String, dynamic>),
    ],
    academy: [
      for (final raw in _list(json, 'academy'))
        Player.fromJson(raw as Map<String, dynamic>),
    ],
    tactic: json['tactic'] == null
        ? const Tactic()
        : Tactic.fromJson(json['tactic'] as Map<String, dynamic>),
    prestige: json['prestige'] as int? ?? 30,
  );
}


/// Clichés du monde simulé, à part de la partie : une liste de championnats.
Map<String, Object?> encodeWorldSnapshot(GameState state) {
  return {
    'season': state.seasonNumber,
    'leagues': [for (final league in state.world) encodeLeague(league)],
  };
}

/// Décode un cliché du monde, ou `null` s'il appartient à une autre saison.
List<WorldLeague>? decodeWorldSnapshot(
  Map<String, dynamic> json, {
  required int seasonNumber,
}) {
  if ((json['season'] as int?) != seasonNumber) return null;
  return [
    for (final raw in json['leagues'] as List<dynamic>)
      decodeLeague(raw as Map<String, dynamic>),
  ];
}
