import 'dart:math';

import '../../core/utils/format.dart';
import '../../domain/entities/club.dart';
import '../../domain/entities/lineup.dart';
import '../../domain/entities/owner.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/honours.dart';
import '../../domain/entities/staff.dart';
import '../../domain/entities/transfer.dart';
import '../calendar/fixture_generator.dart';
import '../fans/fans.dart';
import '../social/social.dart';
import '../staff/staff_factory.dart';
import '../transfers/moves.dart';
import '../transfers/negotiation.dart';
import 'game_state.dart';

int _stableHash(String text) {
  var hash = 5;
  for (final unit in text.codeUnits) {
    hash = (hash * 31 + unit) & 0x3fffffff;
  }
  return hash;
}

/// Mécanismes appliqués autour de chaque journée : réponses aux offres,
/// humeur des supporters, réseau social et offres reçues.
extension RoundHooks on GameState {
  /// Les clubs répondent aux offres envoyées avant la journée.
  GameState resolveRoundOffers() {
    final pending = offers
        .where((o) => !o.incoming && o.status == OfferStatus.pending)
        .toList();
    if (pending.isEmpty) return this;
    var state = this;
    for (final offer in pending) {
      state = state._resolveOne(offer);
    }
    return state;
  }

  GameState _replaceOffer(Offer updated) {
    return copyWith(
      offers: [for (final o in offers) o.id == updated.id ? updated : o],
    );
  }

  /// Ajoute un gros titre dans la presse.
  GameState addHeadline(String headline, String body, NewsKind kind) {
    return copyWith(
      owner: owner.addNews(
        NewsItem(
          headline: headline,
          body: body,
          season: seasonNumber,
          round: season.currentRound,
          kind: kind,
        ),
      ),
    );
  }

  GameState _note(String title, String body) {
    return copyWith(
      owner: owner.addMessage(
        InboxMessage(
          title: title,
          body: body,
          season: seasonNumber,
          round: season.currentRound,
        ),
      ),
    );
  }

  GameState _resolveOne(Offer offer) {
    final everyone = everyClub;
    final player = findPlayer(everyone, offer.playerId);
    final holder = clubOfPlayer(everyone, offer.playerId);
    final sellerMatches = everyone.where((c) => c.id == offer.sellerClubId);
    if (player == null ||
        holder == null ||
        sellerMatches.isEmpty ||
        holder.id != offer.sellerClubId) {
      return _replaceOffer(
        offer.copyWith(
          status: OfferStatus.rejected,
          reason: "Le joueur n'est plus disponible.",
        ),
      );
    }
    final seller = sellerMatches.first;
    final random = Random(season.seed + _stableHash(offer.id) + offer.fee);
    final decision = decideOffer(
      offer: offer,
      player: player,
      seller: seller,
      buyerPrestige: owner.reputation,
      difficulty: owner.difficulty,
      dsLevel: directorLevel(staff),
      random: random,
    );

    switch (decision.status) {
      case OfferStatus.accepted:
        return completeOutgoing(offer, player, seller, offer.fee);
      case OfferStatus.countered:
        return _replaceOffer(
          offer.copyWith(
            status: OfferStatus.countered,
            counterFee: decision.counterFee,
            reason: decision.reason,
          ),
        )._note(
          'Contre-proposition de ${seller.name}',
          '${seller.name} demande ${formatMoney(decision.counterFee)} pour '
              '${player.name}. Votre directeur sportif étudie la contre-proposition.',
        );
      case OfferStatus.rejected:
      case OfferStatus.pending:
        return _replaceOffer(
          offer.copyWith(
            status: OfferStatus.rejected,
            reason: decision.reason,
          ),
        )._note(
          'Offre refusée pour ${player.name}',
          decision.reason,
        );
    }
  }

  /// Conclut un transfert ou un prêt envoyé par le président.
  GameState completeOutgoing(Offer offer, Player player, Club seller, int fee) {
    final me = userClub;
    if (finance.treasury < fee) {
      return _replaceOffer(
        offer.copyWith(
          status: OfferStatus.rejected,
          reason: 'Fonds insuffisants.',
        ),
      );
    }
    final SquadSlot slot;
    if (me.squad.length < maxSquadSize) {
      slot = SquadSlot.first;
    } else if (division <= 3 && me.reserve.length < 25) {
      slot = SquadSlot.reserve;
    } else {
      return _replaceOffer(
        offer.copyWith(
          status: OfferStatus.rejected,
          reason: 'Votre effectif est complet.',
        ),
      );
    }

    final isLoan = offer.kind != OfferKind.transfer;
    final arriving = isLoan
        ? player
        : player.copyWith(contractYears: offer.contractYears);
    final clubs = movePlayer(
      clubs: everyClub,
      player: arriving,
      fromClubId: seller.id,
      toClubId: me.id,
      slot: slot,
    );
    final updatedOffer = offer.copyWith(
      status: OfferStatus.accepted,
      fee: fee,
    );
    final state = withEveryClub(clubs).copyWith(
      finance: finance.copyWith(
        treasury: finance.treasury - fee,
        transfers: finance.transfers - fee,
      ),
      loans: isLoan
          ? [
              ...loans,
              LoanDeal(
                playerId: player.id,
                playerName: player.name,
                ownerClubId: seller.id,
                borrowerClubId: me.id,
                optionFee: offer.kind == OfferKind.loanOption
                    ? offer.optionFee
                    : 0,
              ),
            ]
          : loans,
    );
    return state
        .addHeadline(
          isLoan
              ? '${player.name} arrive en prêt à ${me.name}'
              : '${me.name} s\'offre ${player.name} (${seller.name})',
          isLoan
              ? 'Prêt de ${player.name}, venu de ${seller.name}.'
              : '${player.name} signe pour ${formatMoney(fee)}.',
          NewsKind.transfer,
        )
        ._replaceOffer(updatedOffer)
        ._note(
      isLoan ? 'Prêt conclu' : 'Transfert conclu',
      isLoan
          ? '${player.name} arrive en prêt de ${seller.name} '
              '(${formatMoney(fee)}).'
          : '${player.name} signe au club pour ${formatMoney(fee)}.',
    );
  }

  /// Appelé à la fin de chaque journée.
  GameState afterRound({
    required int round,
    required Fixture? fixture,
    required bool atHome,
  }) {
    var o = owner;
    final random = Random(season.seed * 37 + round * 11 + seasonNumber);
    int? outcome;
    var rival = 'Un club voisin';

    if (fixture != null) {
      final opponentId = atHome ? fixture.awayId : fixture.homeId;
      rival = season.clubById(opponentId).name;
      final result = season.resultOf(fixture);
      if (result != null) {
        final goalsFor = atHome ? result.homeGoals : result.awayGoals;
        final goalsAgainst = atHome ? result.awayGoals : result.homeGoals;
        outcome = goalsFor > goalsAgainst ? 1 : (goalsFor == goalsAgainst ? 0 : -1);
        o = o.copyWith(
          fanMood: moodAfterMatch(
            mood: o.fanMood,
            goalsFor: goalsFor,
            goalsAgainst: goalsAgainst,
            atHome: atHome,
          ),
        );
      }
    }

    final supporters = supportersCount(
      populationThousands: city.population,
      prestige: o.reputation,
    );
    final communityLevel = bestLevel(staff, StaffRole.communityManager);
    o = o.copyWith(
      followers: nextFollowers(
        followers: o.followers,
        target: (supporters * 0.6).round(),
        communityLevel: communityLevel,
      ),
    );

    final posts = roundPosts(
      random: random,
      clubName: userClub.name,
      rivalName: rival,
      hasCommunityManager: communityLevel > 0,
      followers: o.followers,
      season: seasonNumber,
      round: round,
      outcome: outcome,
    );

    // Nettoyage des anciennes offres.
    var current = <Offer>[
      for (final offer in offers)
        if (_keepOffer(offer, round)) offer,
    ];

    // Un club adverse s'intéresse peut-être à l'un de vos joueurs.
    final incomingCount = current.where((x) => x.incoming).length;
    if (transferWindowOpen && incomingCount < 3 && random.nextDouble() < 0.10) {
      final incoming = _makeIncomingOffer(random, round, current);
      if (incoming != null) {
        current = [...current, incoming];
        o = o.addMessage(
          InboxMessage(
            title: 'Offre reçue pour ${incoming.playerName}',
            body:
                '${season.clubById(incoming.buyerClubId).name} propose '
                '${formatMoney(incoming.fee)}. Répondez depuis les transferts.',
            season: seasonNumber,
            round: round,
          ),
        );
      }
    }

    return copyWith(
      owner: o,
      social: [...posts, ...social].take(60).toList(),
      offers: current,
    );
  }

  bool _keepOffer(Offer offer, int round) {
    if (offer.season != seasonNumber) return false;
    final age = round - offer.round;
    switch (offer.status) {
      case OfferStatus.accepted:
      case OfferStatus.rejected:
        return age <= 3;
      case OfferStatus.pending:
        return offer.incoming ? age <= 4 : true;
      case OfferStatus.countered:
        return age <= 8;
    }
  }

  Offer? _makeIncomingOffer(Random random, int round, List<Offer> current) {
    final loanedOut = loans.where((l) => l.ownerClubId == 'user').map((l) => l.playerId).toSet();
    final busy = current.map((o) => o.playerId).toSet();
    final candidates = [...userClub.squad, ...userClub.reserve]
        .where((p) => !loanedOut.contains(p.id) && !busy.contains(p.id))
        .toList();
    final buyers = season.clubs.where((c) => !c.isUser).toList();
    if (candidates.isEmpty || buyers.isEmpty) return null;

    candidates.sort((a, b) => b.skill.compareTo(a.skill));
    final pool = candidates.take(8).toList();
    final player = pool[random.nextInt(pool.length)];
    final buyer = buyers[random.nextInt(buyers.length)];
    final asking = askingPrice(
      player: player,
      seller: userClub,
      difficulty: owner.difficulty,
    );
    final reserveOrYoung = userClub.reserve.any((p) => p.id == player.id) ||
        player.age <= 21;
    final isLoan = reserveOrYoung && random.nextDouble() < 0.4;
    final fee = isLoan
        ? roundThousand(
            loanAskingPrice(
                  player: player,
                  seller: userClub,
                  difficulty: owner.difficulty,
                ) *
                (0.8 + random.nextDouble() * 0.4),
          )
        : roundThousand(asking * (0.7 + random.nextDouble() * 0.6));
    if (fee < 1000) return null;

    var n = offers.length + current.length;
    while (current.any((o) => o.id == 'in$seasonNumber-$n')) {
      n++;
    }
    return Offer(
      id: 'in$seasonNumber-$n',
      playerId: player.id,
      playerName: player.name,
      sellerClubId: userClub.id,
      buyerClubId: buyer.id,
      kind: isLoan ? OfferKind.loan : OfferKind.transfer,
      fee: fee,
      status: OfferStatus.pending,
      incoming: true,
      season: seasonNumber,
      round: round,
    );
  }

  /// Publication du président (nécessite un community manager).
  String? validatePost() {
    if (bestLevel(staff, StaffRole.communityManager) == 0) {
      return 'Engagez un community manager pour animer le compte du club.';
    }
    if (owner.lastPostRound == season.currentRound) {
      return 'Vous avez déjà publié pour cette journée.';
    }
    return null;
  }

  GameState publishPost(String text) {
    if (validatePost() != null) return this;
    final level = bestLevel(staff, StaffRole.communityManager);
    final followers = owner.followers;
    final post = SocialPost(
      author: userClub.name,
      text: text,
      likes: (max(followers, 100) * (0.04 + level / 1500)).round(),
      season: seasonNumber,
      round: season.currentRound,
      isUser: true,
    );
    return copyWith(
      social: [post, ...social].take(60).toList(),
      owner: owner.copyWith(
        fanMood: (owner.fanMood + 2).clamp(0, 100).toInt(),
        followers: followers + (followers * 0.01).round() + 5,
        lastPostRound: season.currentRound,
      ),
    );
  }
}
