import '../../core/utils/format.dart';
import '../../domain/entities/lineup.dart';
import '../../domain/entities/owner.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/transfer.dart';
import '../finance/finance.dart';
import '../staff/staff_factory.dart';
import '../transfers/moves.dart';
import '../transfers/negotiation.dart';
import 'budgets.dart';
import 'game_state.dart';
import 'transfer_actions.dart';

/// Avis du manager sur un joueur signalé par le président.
class CoachView {
  const CoachView(this.verdict, this.note);

  /// 0 défavorable, 1 réservé, 2 favorable.
  final int verdict;
  final String note;
}

/// Le président signale, le directeur sportif négocie, le manager donne
/// son avis : le président ne mène jamais lui-même un transfert.
extension Recruitment on GameState {
  /// Joueur visé, chez un club ou parmi les agents libres.
  Player? targetPlayer(String playerId) {
    final contracted = findPlayer(everyClub, playerId);
    if (contracted != null) return contracted;
    for (final p in market) {
      if (p.id == playerId) return p;
    }
    return null;
  }

  bool isFreeAgent(String playerId) => market.any((p) => p.id == playerId);

  /// Prix que le directeur sportif s'attend à payer.
  int expectedFee(String playerId, {bool loan = false}) {
    final player = targetPlayer(playerId);
    if (player == null) return 0;
    if (isFreeAgent(playerId)) return playerValue(player);
    final seller = clubOfPlayer(everyClub, playerId);
    if (seller == null) return playerValue(player);
    return loan
        ? loanAskingPrice(
            player: player,
            seller: seller,
            difficulty: owner.difficulty,
          )
        : askingPrice(
            player: player,
            seller: seller,
            difficulty: owner.difficulty,
          );
  }

  /// Le manager compare le joueur à ceux qu'il a déjà à ce poste.
  CoachView coachOpinion(Player player) {
    final club = userClub;
    final same = club.squad.where((p) => p.position == player.position).toList()
      ..sort((a, b) => b.skill.compareTo(a.skill));
    final need = (minSquadByPosition[player.position] ?? 2) + 1;
    final name = manager?.name ?? 'Le manager';
    if (same.length < need) {
      return CoachView(
        2,
        '$name : « Nous manquons de joueurs à ce poste, je le prends. »',
      );
    }
    final starterLevel = same.isEmpty ? 0 : same.first.skill;
    final worst = same.isEmpty ? 0 : same.last.skill;
    if (player.skill >= starterLevel - 2) {
      return CoachView(
        2,
        '$name : « Il peut être titulaire tout de suite. »',
      );
    }
    if (player.age <= 21 && player.maxSkill >= starterLevel + 5) {
      return CoachView(
        2,
        '$name : « Un vrai potentiel, je le ferai progresser. »',
      );
    }
    if (player.skill > worst) {
      return CoachView(
        1,
        '$name : « Une solution de rotation, sans plus. »',
      );
    }
    return CoachView(
      0,
      '$name : « Il n\'apporterait rien à l\'équipe, je n\'en veux pas. »',
    );
  }

  String? validateRecruit(String playerId, int maxFee) {
    if (sportingDirector == null) {
      return 'Engagez d\'abord un directeur sportif : c\'est lui qui négocie.';
    }
    final player = targetPlayer(playerId);
    if (player == null) return "Ce joueur n'est plus disponible.";
    if (userClub.allPlayers.any((p) => p.id == playerId)) {
      return 'Ce joueur est déjà au club.';
    }
    if (owner.recruits.any((r) => r.open && r.playerId == playerId)) {
      return 'Votre directeur sportif suit déjà ce dossier.';
    }
    if (owner.recruits.where((r) => r.open).length >= 6) {
      return 'Six dossiers sont déjà ouverts : laissez-le avancer.';
    }
    if (maxFee <= 0) return 'Fixez un budget maximum.';
    if (maxFee > finance.treasury) {
      return 'Ce budget dépasse votre trésorerie.';
    }
    if (maxFee > transferBudgetLeft) {
      return 'Ce montant dépasse le budget transferts restant '
          '(${formatMoney(transferBudgetLeft)}). Augmentez-le dans les '
          'finances.';
    }
    return null;
  }

  /// Le président signale un joueur au directeur sportif et au manager.
  GameState requestRecruit(String playerId, int maxFee, {bool loan = false}) {
    if (validateRecruit(playerId, maxFee) != null) return this;
    final player = targetPlayer(playerId)!;
    final view = coachOpinion(player);
    var n = owner.recruits.length;
    while (owner.recruits.any((r) => r.id == 'rec$seasonNumber-$n')) {
      n++;
    }
    final req = RecruitRequest(
      id: 'rec$seasonNumber-$n',
      playerId: playerId,
      playerName: player.name,
      maxFee: maxFee,
      season: seasonNumber,
      round: season.currentRound,
      loan: loan && !isFreeAgent(playerId),
      coachVerdict: view.verdict,
      coachNote: view.note,
      status: view.verdict == 0
          ? RecruitStatus.refusedByCoach
          : RecruitStatus.pending,
      report: view.verdict == 0
          ? 'Dossier suspendu : le manager ne veut pas de ce joueur.'
          : 'Dossier ouvert, négociation à la prochaine journée.',
    );
    final ds = sportingDirector!.name;
    return copyWith(
      owner: owner.copyWith(recruits: [req, ...owner.recruits]).addMessage(
            InboxMessage(
              title: 'Dossier ${player.name}',
              body: '$ds : « Bien reçu, Président. Budget maximum '
                  '${formatMoney(maxFee)}. »\n${view.note}',
              season: seasonNumber,
              round: season.currentRound,
              sender: 'ds',
            ),
          ),
    );
  }

  /// Le président maintient sa demande malgré l'avis du manager.
  GameState insistRecruit(String id) {
    final updated = _updateRecruit(
      id,
      (r) => r.copyWith(
        status: RecruitStatus.pending,
        force: true,
        report: 'Le président insiste : la négociation reprend.',
      ),
    );
    return updated.copyWith(
      owner: updated.owner.copyWith(
        managerTrust: (updated.owner.managerTrust - 4).clamp(0, 100).toInt(),
      ),
    );
  }

  GameState cancelRecruit(String id) {
    return _updateRecruit(
      id,
      (r) => r.copyWith(
        status: RecruitStatus.cancelled,
        report: 'Dossier abandonné par le président.',
      ),
    );
  }

  GameState _updateRecruit(
    String id,
    RecruitRequest Function(RecruitRequest) change,
  ) {
    return copyWith(
      owner: owner.copyWith(
        recruits: [
          for (final r in owner.recruits) r.id == id ? change(r) : r,
        ],
      ),
    );
  }

  /// Chaque journée, le directeur sportif avance sur les dossiers ouverts.
  GameState processRecruits(int round) {
    if (sportingDirector == null) return this;
    var state = this;
    for (final req in owner.recruits) {
      if (!req.open) continue;
      final before = state.finance.treasury;
      state = state._work(req);
      state = state.spendTransfer(before - state.finance.treasury);
    }
    // Garde les 20 dossiers les plus récents.
    if (state.owner.recruits.length > 20) {
      state = state.copyWith(
        owner: state.owner.copyWith(
          recruits: state.owner.recruits.sublist(0, 20),
        ),
      );
    }
    return state;
  }

  GameState _report(RecruitRequest req, RecruitStatus status, String text) {
    final ds = sportingDirector?.name ?? 'Le directeur sportif';
    final updated = _updateRecruit(
      req.id,
      (r) => r.copyWith(
        status: status,
        report: text,
        attempts: r.attempts + 1,
      ),
    );
    if (status == RecruitStatus.pending) return updated;
    return updated.copyWith(
      owner: updated.owner.addMessage(
        InboxMessage(
          title: status == RecruitStatus.done
              ? 'Recrue : ${req.playerName}'
              : 'Dossier ${req.playerName}',
          body: '$ds : « $text »',
          season: seasonNumber,
          round: season.currentRound,
          sender: 'ds',
        ),
      ),
    );
  }

  GameState _work(RecruitRequest req) {
    if (!transferWindowOpen) {
      if (req.report.startsWith('Mercato fermé')) return this;
      return _updateRecruit(
        req.id,
        (r) => r.copyWith(
          report: 'Mercato fermé : je relancerai le dossier à l\'ouverture.',
        ),
      );
    }
    final player = targetPlayer(req.playerId);
    if (player == null || userClub.allPlayers.any((p) => p.id == req.playerId)) {
      return _report(req, RecruitStatus.failed, 'Le joueur n\'est plus disponible.');
    }
    if (req.attempts >= 4) {
      return _report(
        req,
        RecruitStatus.failed,
        'Après plusieurs tentatives, impossible de trouver un accord.',
      );
    }

    // Agent libre : il suffit d'accepter ses conditions.
    if (isFreeAgent(req.playerId)) {
      final price = playerValue(player);
      if (price > req.maxFee) {
        return _report(
          req,
          RecruitStatus.failed,
          '${player.name} demande ${formatMoney(price)} : au-dessus de '
          'votre budget.',
        );
      }
      final err = validateBuy(req.playerId);
      if (err != null) return _report(req, RecruitStatus.failed, err);
      return buyPlayer(req.playerId)._report(
        req,
        RecruitStatus.done,
        '${player.name} a signé pour ${formatMoney(price)}.',
      );
    }

    // Joueur sous contrat : offre, contre-proposition, relance.
    final dsLevel = directorLevel(staff);
    Offer? current;
    for (final o in offers) {
      if (!o.incoming &&
          o.playerId == req.playerId &&
          (o.status == OfferStatus.pending || o.status == OfferStatus.countered)) {
        current = o;
      }
    }
    if (current != null && current.status == OfferStatus.countered) {
      if (current.counterFee <= req.maxFee) {
        if (validateAcceptCounter(current.id) != null) {
          return _report(req, RecruitStatus.failed, 'Trésorerie insuffisante.');
        }
        return acceptCounter(current.id)._report(
          req,
          RecruitStatus.done,
          'Accord trouvé : ${player.name} arrive pour '
          '${formatMoney(current.counterFee)}.',
        );
      }
      if (current.fee < req.maxFee) {
        return raiseOffer(current.id, req.maxFee)._afterOffer(req, player.name);
      }
      return withdrawOffer(current.id)._report(
        req,
        RecruitStatus.failed,
        'Le club vendeur réclame ${formatMoney(current.counterFee)}, '
        'au-dessus de votre budget de ${formatMoney(req.maxFee)}.',
      );
    }
    final ask = expectedFee(req.playerId, loan: req.loan);
    // Un bon directeur sportif ouvre plus bas.
    final opening = roundThousand(ask * (0.85 - dsLevel / 1000));
    final fee = opening.clamp(1000, req.maxFee).toInt();
    final kind = req.loan ? OfferKind.loan : OfferKind.transfer;
    final err = validateOffer(playerId: req.playerId, kind: kind, fee: fee);
    if (err != null) return _report(req, RecruitStatus.failed, err);
    return makeOffer(playerId: req.playerId, kind: kind, fee: fee)
        ._afterOffer(req, player.name);
  }

  GameState _afterOffer(RecruitRequest req, String name) {
    if (userClub.allPlayers.any((p) => p.id == req.playerId)) {
      return _report(
        req,
        RecruitStatus.done,
        'Accord conclu, $name rejoint le club.',
      );
    }
    Offer? last;
    for (final o in offers) {
      if (!o.incoming && o.playerId == req.playerId) last = o;
    }
    if (last != null && last.status == OfferStatus.countered) {
      return _report(
        req,
        RecruitStatus.pending,
        'Contre-proposition à ${formatMoney(last.counterFee)}, je négocie.',
      );
    }
    return _report(
      req,
      RecruitStatus.pending,
      'Première offre refusée, je reviens à la charge.',
    );
  }
}
