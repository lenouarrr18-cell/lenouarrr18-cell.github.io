

import '../../core/utils/format.dart';
import '../../domain/entities/club.dart';
import '../../domain/entities/country.dart';
import '../../domain/entities/division.dart';
import '../../domain/entities/honours.dart';
import '../../domain/entities/lineup.dart';
import '../../domain/entities/match_summary.dart';
import '../../domain/entities/tactic.dart';
import '../match/match_models.dart';
import '../match/pitch_sim.dart';
import '../calendar/transfer_window.dart';
import '../continental/continental.dart';
import '../../domain/entities/owner.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/season_record.dart';
import '../../domain/entities/staff.dart';
import '../../domain/entities/tactic.dart';
import '../../domain/entities/team_strength.dart';
import '../../domain/entities/transfer.dart';
import '../awards/awards.dart';
import '../fans/fans.dart';
import '../finance/finance.dart';
import '../international/international.dart';
import '../market/market_factory.dart';
import '../owner/board.dart';
import '../owner/events.dart';
import '../owner/infrastructure.dart';
import '../owner/press.dart';
import '../owner/season_goals.dart';
import '../season/league_factory.dart';
import '../season/season.dart';
import '../staff/staff_factory.dart';
import '../squad/coach.dart';
import '../squad/mood.dart';
import '../stats/match_stats.dart';
import '../transfers/ai_market.dart';
import '../transfers/loans.dart';
import '../world/world_engine.dart';
import '../world/world_factory.dart';
import '../world/world_league.dart';
import '../world/world_progression.dart';
import 'delegation.dart';
import 'recruitment.dart';
import 'governance.dart';
import 'round_hooks.dart';

/// Toute la partie en cours (Dart pur, immuable). Chaque action renvoie
/// un nouvel état ; les `validate...` renvoient un message d'erreur ou `null`.
class GameState {
  const GameState({
    required this.country,
    required this.city,
    required this.season,
    required this.division,
    required this.seasonNumber,
    required this.finance,
    required this.market,
    this.history = const [],
    this.staff = const [],
    this.owner = const OwnerState(),
    this.loans = const [],
    this.offers = const [],
    this.awards = const [],
    this.legends = const [],
    this.intl = const [],
    this.cups = const [],
    this.social = const [],
    this.world = const [],
    this.lastMatch,
  });

  factory GameState.newGame({
    required String clubName,
    required Country country,
    required City city,
    required int seed,
  }) {
    final clubs = generateLeagueClubs(
      userClubName: clubName.trim(),
      userCityWealth: city.wealth,
      seed: seed,
      homeNation: country.name,
    );
    final supporters = supportersCount(
      populationThousands: city.population,
      prestige: 20,
    );
    final game = GameState(
      country: country,
      city: city,
      season: Season.create(clubs: clubs, seed: seed),
      division: lowestDivision,
      seasonNumber: 1,
      finance: FinanceBook(treasury: startingTreasury(city.wealth)),
      market: generateMarket(
        division: lowestDivision,
        seed: seed,
        seasonNumber: 1,
        homeNation: country.name,
      ),
      world: generateWorld(
        homeCountry: country.name,
        userDivision: lowestDivision,
        seed: seed,
        generation: 1,
      ),
      owner: OwnerState(
        stadiumName: 'Stade de ${city.name}',
        followers: (supporters * 0.05).round(),
      ).addMessage(
        InboxMessage(
          title: 'Bienvenue, président !',
          body:
              'Vous prenez la tête de ${clubName.trim()}. Engagez un '
              'manager et un directeur sportif : ils recruteront votre '
              'staff et prépareront le mercato. À vous de bâtir un empire.',
          season: 1,
          round: 1,
        ),
      ),
    );
    return game.copyWith(
      owner: game.owner.copyWith(objectiveRank: game.suggestedObjective),
    );
  }

  final Country country;
  final City city;
  final Season season;
  final int division;
  final int seasonNumber;
  final FinanceBook finance;

  /// Joueurs libres (agents libres, pépites détectées).
  final List<Player> market;
  final List<SeasonRecord> history;
  final List<StaffMember> staff;
  final OwnerState owner;
  final List<LoanDeal> loans;
  final List<Offer> offers;
  final List<AwardRecord> awards;
  final List<LegendEntry> legends;
  final List<TournamentResult> intl;

  /// Résultats des compétitions de clubs (Ligue des champions...).
  final List<TournamentResult> cups;
  final List<SocialPost> social;

  /// Championnats simulés en arrière-plan (autres divisions, autres pays).
  final List<WorldLeague> world;

  /// Dernier match du président (buteurs et minutes réels).
  final MatchSummary? lastMatch;

  Club get userClub => season.userClub;

  /// Tous les clubs du monde : votre championnat et les autres.
  List<Club> get everyClub => [
    ...season.clubs,
    for (final league in world) ...league.season.clubs,
  ];

  /// Remplace les clubs (de votre championnat ou du monde) par leurs
  /// versions mises à jour.
  GameState withEveryClub(List<Club> updated) {
    final byId = {for (final c in updated) c.id: c};
    return copyWith(
      season: season.withClubs([for (final c in season.clubs) byId[c.id] ?? c]),
      world: applyToWorld(world, updated),
    );
  }

  /// Génère les championnats du monde s'ils n'existent pas encore
  /// (anciennes sauvegardes) et les met à la même journée que le vôtre.
  GameState ensureWorld() {
    if (world.isNotEmpty) return this;
    var leagues = generateWorld(
      homeCountry: country.name,
      userDivision: division,
      seed: season.seed,
      generation: seasonNumber,
    );
    for (var i = 1; i < season.currentRound; i++) {
      leagues = playWorldRound(leagues);
    }
    return copyWith(world: leagues);
  }

  bool get canPlayNextRound =>
      !season.isFinished && userClub.hasFullLineup && owner.soldFor == 0;

  GameState copyWith({
    Season? season,
    int? division,
    int? seasonNumber,
    FinanceBook? finance,
    List<Player>? market,
    List<SeasonRecord>? history,
    List<StaffMember>? staff,
    OwnerState? owner,
    List<LoanDeal>? loans,
    List<Offer>? offers,
    List<AwardRecord>? awards,
    List<LegendEntry>? legends,
    List<TournamentResult>? intl,
    List<TournamentResult>? cups,
    List<SocialPost>? social,
    List<WorldLeague>? world,
    MatchSummary? lastMatch,
  }) {
    return GameState(
      country: country,
      city: city,
      season: season ?? this.season,
      division: division ?? this.division,
      seasonNumber: seasonNumber ?? this.seasonNumber,
      finance: finance ?? this.finance,
      market: market ?? this.market,
      history: history ?? this.history,
      staff: staff ?? this.staff,
      owner: owner ?? this.owner,
      loans: loans ?? this.loans,
      offers: offers ?? this.offers,
      awards: awards ?? this.awards,
      legends: legends ?? this.legends,
      intl: intl ?? this.intl,
      cups: cups ?? this.cups,
      social: social ?? this.social,
      world: world ?? this.world,
      lastMatch: lastMatch ?? this.lastMatch,
    );
  }

  /// Le mercato est-il ouvert ? (été : jusqu'au 1er septembre ; hiver : janvier).
  bool get transferWindowOpen => isTransferWindowOpen(
    seasonNumber: seasonNumber,
    round: season.currentRound,
    finished: season.isFinished,
  );

  String get transferWindowMessage => transferWindowText(
    seasonNumber: seasonNumber,
    round: season.currentRound,
    finished: season.isFinished,
  );

  // ---------- conseil d'administration ----------

  /// Place attendue par le conseil d'après la force de votre équipe.
  int get suggestedObjective {
    double overall(TeamStrength s) =>
        (s.attack + s.midfield + s.defense + s.goalkeeper) / 4;

    final scores = [
      for (final club in season.clubs)
        MapEntry(club.id, overall(club.matchStrength)),
    ]..sort((a, b) => b.value.compareTo(a.value));
    final rank = scores.indexWhere((e) => e.key == userClub.id) + 1;
    return rank.clamp(2, 14).toInt();
  }

  /// Objectif de la saison fixé par le conseil.
  int get boardObjective =>
      owner.objectiveRank > 0 ? owner.objectiveRank : suggestedObjective;

  GameState _withClub(Club club, {FinanceBook? finance, List<Player>? market}) {
    return copyWith(
      season: season.withClub(club),
      finance: finance,
      market: market,
    );
  }

  // ---------- journées ----------

  /// Joue la journée en cours : propositions de transfert traitées,
  /// matchs, statistiques, recettes, charges, travaux et événements.
  GameState playNextRound() {
    if (!canPlayNextRound) return this;
    return this.ensureWorld().resolveRoundOffers()._playRound();
  }

  GameState _playRound() {
    final round = season.currentRound;
    final fixture = season.userFixtureOfRound(round);
    final atHome = fixture != null && fixture.homeId == userClub.id;
    final homeBoost = atHome ? 1 + (owner.fanMood - 50) / 2500 : 1.0;
    // Le coach compose l'équipe de la journée (rotation comprise).
    final coach = coachSelects(userClub);
    final prepared = season.withClub(
      coach.club.copyWith(staffBoost: managerBoost(staff) * homeBoost),
    );
    var simulated = prepared.playNextRound();
    // Le match du président est simulé joueur par joueur sur le terrain.
    if (fixture != null) {
      try {
        final pitch = PitchSim(
          seed: season.seed * 7919 + round * 131 + seasonNumber,
        );
        // Le score n'est pas écrit d'avance : il sort du terrain.
        final detailed = pitch.simulate(
          home: simulated.clubById(fixture.homeId),
          away: simulated.clubById(fixture.awayId),
          rain: matchConditions(seasonNumber, round).rain,
        );
        simulated = simulated.withResult(fixture.key, detailed);
      } catch (_) {
        // Composition incomplète : on garde la simulation par phases.
      }
    }
    final homeNotes = <_Scored>[];
    final awayNotes = <_Scored>[];
    final next = simulated.withClubs(
      applyRoundStats(
        clubs: simulated.clubs,
        fixtures: season.fixturesOfRound(round),
        results: simulated.results,
        seed: season.seed,
        round: round,
        onGoal: (f, home, scorer, assister) {
          if (fixture == null || f.key != fixture.key) return;
          (home ? homeNotes : awayNotes).add(
            _Scored(scorer.name, assister?.name ?? ''),
          );
        },
      ),
    );
    final rounds = season.totalRounds;

    final capacity = stadiumCapacity(owner.stadium);
    final attendance = atHome
        ? attendanceFor(
            populationThousands: city.population,
            rank: next.userRank,
            clubCount: season.clubs.length,
            prestige: owner.reputation,
            fanMood: owner.fanMood,
            capacity: capacity,
          )
        : 0;
    final ticketBase = atHome
        ? ticketRevenue(
            populationThousands: city.population,
            division: division,
            rank: next.userRank,
            clubCount: season.clubs.length,
            stadiumLevel: owner.stadium,
            prestige: owner.reputation,
            fanMood: owner.fanMood,
            capacity: capacity,
          )
        : 0;
    final ticket = (ticketBase * ticketMultiplier(owner)).round();
    final wages =
        (squadAnnualWages(userClub.squad) + staffAnnualWages(staff)) ~/ rounds;
    final deal = owner.deal;
    final sponsor =
        ((sponsorIncomePerSeason(wealth: city.wealth, division: division) ~/
                    rounds +
                (deal == null ? 0 : deal.perSeason ~/ rounds)) *
                sponsorMultiplier(owner))
            .round();
    final merch = atHome
        ? (merchRevenue(
                    populationThousands: city.population,
                    division: division,
                    reputation: owner.reputation,
                  ) *
                  shopFactor(owner.shop) *
                  commercialMultiplier(owner))
              .round()
        : 0;
    final matchday = (attendance *
            (fanZonePerFan(owner.fanZone) +
                parkingPerFan(owner.parking) +
                hospitalityPerFan(owner)))
        .round();
    final buildings = (atHome ? homeExtraIncome(owner, division: division) : 0) +
        mallIncomePerRound(owner, division: division);
    final extras =
        tvIncomePerSeason(division) ~/ rounds + merch + matchday + buildings;
    final upkeep = infrastructureUpkeepPerSeason(owner) ~/ rounds;
    final repayment = owner.debt < owner.loanPerRound
        ? owner.debt
        : owner.loanPerRound;
    final interest = (repayment * loanInterestRate / (1 + loanInterestRate))
        .round();
    final remainingDebt = owner.debt - repayment;

    // Les blessés récupèrent peu à peu.
    var club = applyMatchLoad(
      next.userClub,
      medicalLevel: owner.medical,
      restBonus: fitnessRestBonus(owner),
      matchSaving: fitnessMatchSaving(owner),
    );
    if (club.squad.any((p) => p.form < 1.0)) {
      club = club.copyWith(
        squad: [
          for (final p in club.squad)
            p.form < 1.0
                ? p.copyWith(
                    form: (p.form + 0.05 + rehabRecovery(owner))
                        .clamp(0.0, 1.0)
                        .toDouble(),
                  )
                : p,
        ],
      );
    }

    var nextOwner = owner.copyWith(
      debt: remainingDebt,
      loanPerRound: remainingDebt == 0 ? 0 : owner.loanPerRound,
    );
    nextOwner = _advanceWorks(nextOwner, round);

    var income = ticket + sponsor + extras;
    var expense = wages + upkeep + repayment;
    var extrasTotal = finance.extras + extras;
    var infraTotal = finance.infrastructure + upkeep;

    final event = rollOwnerEvent(
      seed: season.seed,
      seasonNumber: seasonNumber,
      round: round,
      division: division,
      starters: club.starters,
      medicalLevel: medicalProtection(owner),
    );
    if (event != null) {
      income += event.income;
      expense += event.expense;
      extrasTotal += event.income;
      infraTotal += event.expense;
      final injured = event.injuredPlayerId;
      if (injured != null) {
        club = club.copyWith(
          squad: [
            for (final p in club.squad)
              p.id == injured ? p.copyWith(form: injuredForm) : p,
          ],
        );
      }
      nextOwner = nextOwner
          .copyWith(
            reputation: (nextOwner.reputation + event.reputationDelta)
                .clamp(0, 100)
                .toInt(),
            confidence: (nextOwner.confidence + event.confidenceDelta)
                .clamp(0, 100)
                .toInt(),
          )
          .addMessage(
            InboxMessage(
              title: event.title,
              body: event.body,
              season: seasonNumber,
              round: round,
            ),
          );
    }

    // Autres championnats du monde et gros titres.
    var nextWorld = playWorldRound(world);
    final worldNews = worldRoundNews(
      world: nextWorld,
      seed: season.seed,
      seasonNumber: seasonNumber,
      round: round,
    );
    nextWorld = worldNews.world;
    for (final item in worldNews.news.reversed) {
      nextOwner = nextOwner.addNews(item);
    }

    // Résultat du match du président : humeurs, vestiaire, presse.
    var goalsFor = 0;
    var goalsAgainst = 0;
    var outcome = 0;
    var opponentName = '';
    MatchSummary? summary;
    var injuredIds = const <String>[];
    if (fixture != null) {
      final r = next.resultOf(fixture);
      if (r != null) {
        final homeMinutes = [
          for (final e in r.events)
            if (e.type == MatchEventType.goal && e.isHome) e.minute,
        ]..sort();
        final awayMinutes = [
          for (final e in r.events)
            if (e.type == MatchEventType.goal && !e.isHome) e.minute,
        ]..sort();
        final notes = <GoalNote>[];
        for (var i = 0; i < homeNotes.length; i++) {
          notes.add(
            GoalNote(
              minute: i < homeMinutes.length ? homeMinutes[i] : 45,
              home: true,
              scorer: homeNotes[i].scorer,
              assist: homeNotes[i].assist,
            ),
          );
        }
        for (var i = 0; i < awayNotes.length; i++) {
          notes.add(
            GoalNote(
              minute: i < awayMinutes.length ? awayMinutes[i] : 45,
              home: false,
              scorer: awayNotes[i].scorer,
              assist: awayNotes[i].assist,
            ),
          );
        }
        notes.sort((a, b) => a.minute.compareTo(b.minute));
        final homeClub = next.clubById(fixture.homeId);
        final awayClub = next.clubById(fixture.awayId);
        summary = MatchSummary(
          season: seasonNumber,
          round: round,
          homeId: fixture.homeId,
          awayId: fixture.awayId,
          homeName: homeClub.name,
          awayName: awayClub.name,
          homeGoals: r.homeGoals,
          awayGoals: r.awayGoals,
          goals: notes,
          homeFormation: homeClub.tactic.formation.label,
          awayFormation: awayClub.tactic.formation.label,
          stats: r.stats,
          perfs: r.detail?.perfs ?? const [],
          track: r.detail == null ? '' : packTrack(r.detail!.track),
          subs: r.detail?.subs ?? const [],
          cards: r.detail?.cards ?? const [],
          chances: r.detail?.chances ?? const [],
          names: r.detail?.names ?? const [],
          log: r.detail?.log ?? const [],
          trackVersion: r.detail?.trackVersion ?? 1,
          attendance: attendance,
          capacity: atHome ? capacity : 0,
        );
        injuredIds = r.detail?.injured ?? const <String>[];
        goalsFor = atHome ? r.homeGoals : r.awayGoals;
        goalsAgainst = atHome ? r.awayGoals : r.homeGoals;
        outcome = goalsFor > goalsAgainst ? 1 : (goalsFor < goalsAgainst ? -1 : 0);
        opponentName = next.clubById(atHome ? fixture.awayId : fixture.homeId).name;
      }
    }
    final moods = updateMoods(
      club: club,
      outcome: outcome,
      season: seasonNumber,
      round: round,
    );
    club = moods.club;
    // Blessures survenues pendant le match : le staff médical prévient.
    if (injuredIds.isNotEmpty) {
      final hurt = [
        for (final p in club.squad)
          if (injuredIds.contains(p.id)) p,
      ];
      if (hurt.isNotEmpty) {
        club = club.copyWith(
          squad: [
            for (final p in club.squad)
              injuredIds.contains(p.id)
                  ? p.copyWith(
                      form: injuredForm,
                      fitness: (p.fitness - 30).clamp(30, 100).toInt(),
                    )
                  : p,
          ],
        );
        for (final p in hurt) {
          nextOwner = nextOwner.addMessage(
            InboxMessage(
              title: 'Blessure : ${p.name}',
              body: '${p.name} est sorti sur blessure pendant le match. '
                  'Le staff médical le prend en charge : il sera diminué '
                  'pendant quelques journées.',
              season: seasonNumber,
              round: round,
              sender: 'medical',
            ),
          );
        }
      }
    }
    for (final m in moods.messages) {
      nextOwner = nextOwner.addMessage(m);
    }
    for (final n in moods.news) {
      nextOwner = nextOwner.addNews(n);
    }
    final locker = rollLockerEvent(
      seed: season.seed,
      season: seasonNumber,
      round: round,
      club: club,
      hasManager: manager != null,
    );
    if (locker != null) {
      final applied = applyLockerEvent(
        club: club,
        event: locker,
        season: seasonNumber,
        round: round,
      );
      club = applied.club;
      for (final m in applied.messages) {
        nextOwner = nextOwner.addMessage(m);
      }
      for (final n in applied.news) {
        nextOwner = nextOwner.addNews(n);
      }
    }
    if (fixture != null && opponentName.isNotEmpty) {
      final head = matchHeadline(
        clubName: club.name,
        opponent: opponentName,
        goalsFor: goalsFor,
        goalsAgainst: goalsAgainst,
        season: seasonNumber,
        round: round,
      );
      if (head != null) nextOwner = nextOwner.addNews(head);
      if (nextOwner.press != null) {
        // La presse n'a pas obtenu de réponse : les supporters le notent.
        nextOwner = nextOwner.copyWith(
          fanMood: (nextOwner.fanMood - 1).clamp(0, 100).toInt(),
        );
      }
      final question = makePressQuestion(
        seed: season.seed,
        season: seasonNumber,
        round: round,
        clubName: club.name,
        opponent: opponentName,
        goalsFor: goalsFor,
        goalsAgainst: goalsAgainst,
        rank: next.userRank,
      );
      nextOwner = nextOwner.copyWith(
        press: question,
        clearPress: question == null,
      );
    }

    final result = copyWith(
      season: next.withClub(club),
      finance: finance.copyWith(
        treasury: finance.treasury + income - expense,
        tickets: finance.tickets + ticket,
        sponsors: finance.sponsors + sponsor,
        wages: finance.wages + wages,
        extras: extrasTotal,
        infrastructure: infraTotal,
        debtService: finance.debtService + interest,
      ),
      owner: nextOwner,
      world: nextWorld,
      lastMatch: summary,
    );
    final reported = coach.notes.isEmpty
        ? result
        : result.postMessage(
            'manager',
            'Composition du coach',
            "Le coach a fait tourner l'effectif : "
                '${coach.notes.take(3).join(' ')}',
            round,
          );
    return reported
        .afterRound(round: round, fixture: fixture, atHome: atHome)
        .processDecisions(round)
        .dsRoutine(round)
        .processRecruits(round)
        .leaderTick(round);
  }

  /// Fait avancer les travaux d'une journée et livre ceux qui sont finis.
  OwnerState _advanceWorks(OwnerState current, int round) {
    final works = current.works;
    if (works.isEmpty) return current;

    var next = current;
    final remaining = <InfraWork>[];
    for (final work in works) {
      final left = work.roundsLeft - 1;
      if (left > 0) {
        remaining.add(work.copyWith(roundsLeft: left));
        continue;
      }
      next = next
          .withLevel(work.kind, work.targetLevel)
          .logInfra(
            'Saison $seasonNumber, journée $round : '
            '${infraLabel(work.kind)} niveau ${work.targetLevel} terminé',
          )
          .addMessage(
            InboxMessage(
              title: 'Travaux terminés',
              body:
                  '${infraLevelName(work.kind, work.targetLevel)} est '
                  'prêt : ${infraEffect(work.kind, work.targetLevel)}.',
              season: seasonNumber,
              round: round,
            ),
          );
    }
    return next.withWorks(remaining);
  }

  // ---------- fin de saison ----------

  SeasonOutcome get seasonOutcomeNow {
    return seasonOutcome(
      rank: season.userRank,
      division: division,
      clubCount: season.clubs.length,
    );
  }

  /// Clôt la saison : tournois, distinctions, fin des prêts, vieillissement
  /// du monde (retraites, regens), mercato des clubs, nouveau championnat.
  GameState startNextSeason(int seed) {
    if (!season.isFinished) return this;
    if (world.isEmpty) return ensureWorld().startNextSeason(seed);

    final outcome = seasonOutcomeNow;
    final newDivision = nextDivision(division, outcome);
    final newNumber = seasonNumber + 1;
    final rank = season.userRank;
    final record = SeasonRecord(
      season: seasonNumber,
      division: division,
      rank: rank,
      outcome: outcome,
    );

    final notes = <String>[];
    final headlines = <NewsItem>[...worldSeasonNews(world, seasonNumber)];
    final userLeagueIds = {for (final c in season.clubs) c.id};
    final divisionOf = <String, int>{
      for (final c in season.clubs) c.id: division,
      for (final l in world)
        for (final c in l.season.clubs) c.id: l.division,
    };
    var everything = everyClub;

    // 1. Tournois internationaux : sélections, prestige.
    final intlPool = [
      for (final c in everything)
        if (userLeagueIds.contains(c.id) || divisionOf[c.id] == 1) c,
    ];
    final report = runInternational(
      clubs: intlPool,
      season: seasonNumber,
      seed: seed,
      division: division,
      divisionByClub: {
        for (final c in intlPool) c.id: divisionOf[c.id] ?? division,
      },
    );
    everything = _mergeClubs(everything, [
      for (final c in report.clubs)
        c.isUser || !report.prestigeGain.containsKey(c.id)
            ? c
            : c.copyWith(
                prestige: (c.prestige + report.prestigeGain[c.id]!)
                    .clamp(0, 100)
                    .toInt(),
              ),
    ]);
    var userGain = report.prestigeGain['user'] ?? 0;
    notes.addAll(report.messages);

    // 2b. Compétitions de clubs : Ligue des champions, Ligue Europa,
    //     Conférence, compétitions continentales, Coupe du monde des clubs.
    final continental = runContinentalCups(
      world: world,
      userSeason: season,
      userDivision: division,
      homeCountry: country.name,
      seasonNumber: seasonNumber,
      seed: seed,
    );
    everything = _mergeClubs(everything, [
      for (final c in everything)
        if (!c.isUser && continental.prestigeGain.containsKey(c.id))
          c.copyWith(
            prestige: (c.prestige + continental.prestigeGain[c.id]!)
                .clamp(0, 100)
                .toInt(),
          ),
    ]);
    userGain += continental.prestigeGain['user'] ?? 0;
    notes.addAll(continental.userNotes);
    headlines.addAll(continental.news);

    // 2. Distinctions : seuls les joueurs des clubs de première division
    //    (dans tous les pays simulés) sont concernés.
    final awardPool = [
      for (final c in everything)
        if (divisionOf[c.id] == 1) c,
    ];
    final honours = computeSeasonAwards(
      clubs: awardPool,
      season: seasonNumber,
      bonus: report.bonus,
      clubBonus: continental.clubScore,
      champions: {
        if (division == 1 && season.standings.isNotEmpty)
          season.standings.first.clubId,
        for (final l in world)
          if (l.division == 1 && l.season.standings.isNotEmpty)
            l.season.standings.first.clubId,
      },
    );
    everything = _mergeClubs(everything, honours.clubs);
    for (final a in honours.records) {
      notes.add('${a.category} : ${a.playerName} (${a.clubName}).');
      headlines.add(
        NewsItem(
          headline: '${a.category} : ${a.playerName}',
          body: '${a.playerName} (${a.clubName}) remporte le trophée. '
              '${a.detail}',
          season: seasonNumber,
          round: 38,
          kind: NewsKind.award,
        ),
      );
    }

    // 3. Progression des joueurs prêtés puis fin des prêts.
    final devReport = applyLoanDevelopment(
      clubs: everything,
      loans: loans,
      seed: seed,
    );
    everything = devReport.clubs;
    notes.addAll(devReport.messages);
    final loanReport = endLoans(clubs: everything, loans: loans, seed: seed);
    everything = loanReport.clubs;
    notes.addAll(loanReport.messages);

    var clubs = [
      for (final c in everything)
        if (userLeagueIds.contains(c.id)) c,
    ];
    final worldAfter = applyToWorld(world, [
      for (final c in everything)
        if (!userLeagueIds.contains(c.id)) c,
    ]);

    // 4. Le monde vieillit : progression, retraites, regens, contrats.
    final retired = <Player>[];
    final released = <Player>[];
    final developedClubs = <Club>[];
    for (final c in clubs) {
      final dev = developClub(
        club: c,
        seed: seed,
        seasonNumber: newNumber,
        homeNation: country.name,
        isUser: c.isUser,
        division: newDivision,
        trainingLevel: owner.training,
        academyLevel: owner.academy,
        coachFirst: bestLevel(staff, StaffRole.coachFirst),
        coachReserve: bestLevel(staff, StaffRole.coachReserve),
        coachAcademy: bestLevel(staff, StaffRole.coachAcademy),
        trainingExtra: complexTrainingBonus(owner),
        academyExtra: youthGrowthChance(owner),
        youthQualityBonus: youthAcademyBonus(owner),
        youthExtra: youthAcademyExtra(owner),
      );
      developedClubs.add(dev.club);
      retired.addAll(dev.retired);
      released.addAll(dev.expired);
      if (c.isUser) notes.addAll(dev.notes);
    }

    // 5. Mercato des clubs adverses.
    final aiReport = simulateAiTransfers(
      clubs: developedClubs,
      seed: seed,
      seasonNumber: newNumber,
    );
    clubs = aiReport.clubs;
    final bigMoves = aiReport.news;

    var club = clubs.firstWhere((c) => c.isUser);
    if (!club.hasFullLineup) {
      club = club.copyWith(
        starterIds: pickBestStarters(club.squad, club.tactic.formation),
      );
    }

    // 5b. Le reste du monde : promotions, vieillissement, mercato des stars.
    final worldEnd = endWorldSeason(
      world: worldAfter,
      oldUserClubs: [
        for (final c in clubs)
          if (!c.isUser) c,
      ],
      userDivision: division,
      newDivision: newDivision,
      homeCountry: country.name,
      seed: seed,
      newNumber: newNumber,
    );
    final starMoves = worldTransfers(
      world: worldEnd.world,
      seed: seed,
      seasonNumber: seasonNumber,
    );
    retired.addAll(worldEnd.retired);
    notes.addAll(worldEnd.notes);
    headlines.addAll(starMoves.news);

    // 6. Bilan du conseil, de la réputation et du sponsor principal.
    final verdict = evaluateSeason(
      rank: rank,
      objective: boardObjective,
      outcome: outcome,
      confidence: owner.confidence,
      reputation: owner.reputation,
    );
    final reputation = (verdict.reputation + userGain + reputationPerSeason(owner))
        .clamp(0, 100)
        .toInt();
    final boardRep = boardReport(
      treasury: finance.treasury,
      debt: owner.debt,
      fanMood: owner.fanMood,
      infraLevels: owner.stadium +
          owner.training +
          owner.academy +
          owner.fanZone +
          owner.parking +
          owner.shop,
      tension: owner.tension,
      vetoCount: owner.vetoCount,
    );
    final finalConfidence =
        (verdict.confidence + boardRep.delta).clamp(0, 100).toInt();
    var nextOwner = owner.copyWith(
      confidence: finalConfidence,
      reputation: reputation,
      confidenceHistory: [...owner.confidenceHistory, finalConfidence],
      managerTrust: (owner.managerTrust + (verdict.objectiveReached ? 6 : -6))
          .clamp(0, 100)
          .toInt(),
      dsTrust: (owner.dsTrust + (verdict.objectiveReached ? 3 : -3))
          .clamp(0, 100)
          .toInt(),
      tension: 0,
      decisions: const [],
    );
    var bonusIncome = loanReport.income;
    // Contrat d'objectifs : prime et confiance pour chaque objectif tenu
    // (le classement est déjà compté dans le verdict du conseil).
    final contract = seasonObjectives(this);
    final kept = [
      for (final o in contract)
        if (o.id != 'rank' && o.reached) o,
    ];
    final missed = [
      for (final o in contract)
        if (o.id != 'rank' && !o.reached) o,
    ];
    if (contract.isNotEmpty) {
      final prize = objectiveReward(division) * kept.length;
      bonusIncome += prize;
      nextOwner = nextOwner.copyWith(
        confidence: (nextOwner.confidence + kept.length * 4 - missed.length * 5)
            .clamp(0, 100)
            .toInt(),
      );
      nextOwner = nextOwner.addMessage(
        InboxMessage(
          title: "Contrat d'objectifs : bilan",
          body: [
            for (final o in contract)
              '${o.reached ? '✔' : '✘'} ${o.title} — ${o.status}',
            if (prize > 0)
              'Le conseil verse une prime de ${formatMoney(prize)}.',
          ].join('\n'),
          season: newNumber,
          round: 1,
          sender: 'board',
        ),
      );
    }
    final deal = owner.deal;
    if (deal != null) {
      final reachedTarget = deal.targetRank > 0 && rank <= deal.targetRank;
      if (reachedTarget) {
        bonusIncome += deal.bonus;
        nextOwner = nextOwner.addMessage(
          InboxMessage(
            title: 'Prime de ${deal.name}',
            body:
                'Objectif sportif atteint : ${deal.name} verse une prime '
                'de ${formatMoney(deal.bonus)}.',
            season: newNumber,
            round: 1,
          ),
        );
      }
      final left = deal.seasonsLeft - 1;
      if (left <= 0) {
        nextOwner = nextOwner
            .copyWith(clearDeal: true)
            .addMessage(
              InboxMessage(
                title: 'Contrat terminé',
                body:
                    'Votre contrat avec ${deal.name} est arrivé à terme. '
                    'De nouvelles offres vous attendent.',
                season: newNumber,
                round: 1,
              ),
            );
      } else {
        nextOwner = nextOwner.copyWith(deal: deal.copyWith(seasonsLeft: left));
      }
    }
    final objectiveText = verdict.objectiveReached
        ? 'Objectif du conseil atteint.'
        : 'Objectif du conseil manqué.';
    nextOwner = nextOwner.addMessage(
      InboxMessage(
        title: 'Bilan de la saison $seasonNumber',
        body:
            '${ordinalFr(rank)} sur ${season.clubs.length}. '
            '$objectiveText ${confidenceLabel(finalConfidence)}.\n'
            '${boardRep.lines.join('\n')}',
        season: newNumber,
        round: 1,
      ),
    );
    if (notes.isNotEmpty) {
      nextOwner = nextOwner.addMessage(
        InboxMessage(
          title: 'Fin de saison : le monde du football',
          body: notes.join('\n'),
          season: newNumber,
          round: 1,
        ),
      );
    }
    if (bigMoves.isNotEmpty) {
      nextOwner = nextOwner.addMessage(
        InboxMessage(
          title: 'Mercato : les gros transferts',
          body: bigMoves.join('\n'),
          season: newNumber,
          round: 1,
        ),
      );
    }

    final userHeadline = outcome == SeasonOutcome.promoted
        ? '${club.name} accède à la division supérieure !'
        : (outcome == SeasonOutcome.relegated
              ? '${club.name} est relégué en division inférieure'
              : (rank == 1
                    ? 'Sacre pour ${club.name}, champion de sa division'
                    : '${club.name} termine ${ordinalFr(rank)} du championnat'));
    for (final h in headlines.reversed) {
      nextOwner = nextOwner.addNews(h);
    }
    nextOwner = nextOwner
        .addNews(
          NewsItem(
            headline: userHeadline,
            body: 'Bilan de la saison $seasonNumber : '
                '${ordinalFr(rank)} sur ${season.clubs.length}.',
            season: newNumber,
            round: 1,
            kind: NewsKind.club,
          ),
        )
        .copyWith(clearPress: true);

    club = club.copyWith(prestige: reputation);
    final keep = newDivision == division
        ? clubs.where((c) => !c.isUser).toList()
        : null;

    // 7. Joueurs retraités : légendes du débat du GOAT.
    final legendList = [...legends];
    for (final p in retired) {
      final entry = legendFrom(p, seasonNumber);
      if (entry != null) legendList.add(entry);
    }
    legendList.sort((a, b) => b.goatScore.compareTo(a.goatScore));

    final fresh = GameState(
      country: country,
      city: city,
      season: Season.create(
        clubs: generateNextLeague(
          userClub: club,
          division: newDivision,
          seed: seed,
          homeNation: country.name,
          generation: newNumber,
          keep: keep,
        ),
        seed: seed,
      ),
      division: newDivision,
      seasonNumber: newNumber,
      finance: finance.resetSeason().copyWith(
        treasury: finance.treasury + bonusIncome,
        extras: bonusIncome,
      ),
      market: [
        ...generateMarket(
          division: newDivision,
          seed: seed,
          seasonNumber: newNumber,
          scoutBonus: scoutBonus(staff) +
              recruitmentBonus(owner.recruitment) +
              analysisBonus(owner),
          homeNation: country.name,
        ),
        ...released.map((p) => p.copyWith(contractYears: 2)),
      ],
      history: [...history, record],
      staff: staff,
      owner: nextOwner,
      loans: const [],
      offers: const [],
      awards: [...honours.records, ...awards].take(150).toList(),
      legends: legendList.take(60).toList(),
      intl: [...report.results, ...intl].take(30).toList(),
      cups: [...continental.results, ...cups].take(60).toList(),
      social: social,
      world: starMoves.world,
    );
    return fresh.copyWith(
      owner: fresh.owner.copyWith(objectiveRank: fresh.suggestedObjective),
    );
  }

  // ---------- composition et tactique ----------

  String? validateToggleStarter(String playerId) {
    // La composition est l'affaire du coach, pas celle du président.
    return 'Le coach compose l\'équipe : ce n\'est pas votre rôle.';
  }

  String? _legacyValidateToggleStarter(String playerId) {
    final club = userClub;
    final player = club.squad.where((p) => p.id == playerId).firstOrNull;
    if (player == null) return 'Joueur introuvable.';
    if (club.starterIds.contains(playerId)) return null;

    final slots = club.tactic.formation.slots[player.position] ?? 0;
    final already = club.starters
        .where((p) => p.position == player.position)
        .length;
    if (already >= slots) {
      return "Poste complet : retirez d'abord un titulaire à ce poste.";
    }
    return null;
  }

  GameState toggleStarter(String playerId) {
    if (_legacyValidateToggleStarter(playerId) != null) return this;
    final club = userClub;
    final ids = club.starterIds.contains(playerId)
        ? club.starterIds.where((id) => id != playerId).toList()
        : [...club.starterIds, playerId];
    return _withClub(club.copyWith(starterIds: ids));
  }

  GameState autoPickStarters() {
    final club = userClub;
    return _withClub(
      club.copyWith(
        starterIds: pickBestStarters(club.squad, club.tactic.formation),
      ),
    );
  }

  /// Change la formation et recompose automatiquement l'équipe.
  GameState setFormation(Formation formation) {
    final club = userClub;
    final updated = club.copyWith(
      tactic: club.tactic.copyWith(formation: formation),
      starterIds: pickBestStarters(club.squad, formation),
    );
    return _withClub(updated);
  }

  /// Applique un plan de jeu complet. Si la formation change, le coach
  /// recompose l'équipe (le président ne choisit pas les joueurs).
  GameState setTactic(Tactic tactic) {
    final club = userClub;
    var updated = club.copyWith(tactic: tactic);
    if (tactic.formation != club.tactic.formation) {
      updated = updated.copyWith(
        starterIds: pickBestStarters(club.squad, tactic.formation),
      );
    }
    return _withClub(updated);
  }

  /// Enregistre le plan actuel dans une configuration (0 principale,
  /// 1 offensive, 2 défensive).
  GameState savePreset(int index) {
    final t = userClub.tactic;
    final list = t.presets.isEmpty ? _defaultPresets(t) : [...t.presets];
    list[index.clamp(0, 2).toInt()] = t.copyWith(presets: const []);
    return setTactic(t.copyWith(presets: list));
  }

  /// Passe à une configuration enregistrée.
  GameState loadPreset(int index) {
    final t = userClub.tactic;
    final list = t.presets.isEmpty ? _defaultPresets(t) : [...t.presets];
    final p = list[index.clamp(0, 2).toInt()];
    return setTactic(p.copyWith(presets: list));
  }

  List<Tactic> _defaultPresets(Tactic t) {
    final main = t.copyWith(presets: const []);
    return [
      main,
      main.copyWith(
        style: TacticStyle.attacking,
        pressing: Pressing.high,
        lineHeight: 3,
        width: 3,
      ),
      main.copyWith(
        style: TacticStyle.defensive,
        pressing: Pressing.low,
        lineHeight: 1,
        width: 1,
        transition: Transition.regroup,
      ),
    ];
  }

  GameState setStyle(TacticStyle style) {
    final club = userClub;
    return _withClub(club.copyWith(tactic: club.tactic.copyWith(style: style)));
  }

  GameState setPressing(Pressing pressing) {
    final club = userClub;
    return _withClub(
      club.copyWith(tactic: club.tactic.copyWith(pressing: pressing)),
    );
  }

  // ---------- mercato (agents libres) ----------

  String? validateBuy(String playerId, {SquadSlot slot = SquadSlot.first}) {
    if (!transferWindowOpen) return transferWindowMessage;
    final player = market.where((p) => p.id == playerId).firstOrNull;
    if (player == null) return "Ce joueur n'est plus disponible.";
    final club = userClub;
    switch (slot) {
      case SquadSlot.first:
        if (club.squad.length >= maxSquadSize) {
          return 'Effectif complet ($maxSquadSize joueurs maximum).';
        }
        break;
      case SquadSlot.reserve:
        if (division > 3) return "Votre division n'a pas d'équipe réserve.";
        if (club.reserve.length >= 25) return 'Équipe réserve complète.';
        break;
      case SquadSlot.academy:
        if (player.age > 21) {
          return 'Le centre de formation accueille les moins de 22 ans.';
        }
        if (club.academy.length >= 20) return 'Centre de formation complet.';
        break;
    }
    if (finance.treasury < playerValue(player)) {
      return 'Trésorerie insuffisante.';
    }
    return null;
  }

  GameState buyPlayer(String playerId, {SquadSlot slot = SquadSlot.first}) {
    if (validateBuy(playerId, slot: slot) != null) return this;
    final player = market.firstWhere((p) => p.id == playerId);
    final price = playerValue(player);
    final club = userClub;
    final Club updated;
    switch (slot) {
      case SquadSlot.first:
        updated = club.copyWith(squad: [...club.squad, player]);
        break;
      case SquadSlot.reserve:
        updated = club.copyWith(reserve: [...club.reserve, player]);
        break;
      case SquadSlot.academy:
        updated = club.copyWith(academy: [...club.academy, player]);
        break;
    }
    return _withClub(
      updated,
      finance: finance.copyWith(
        treasury: finance.treasury - price,
        transfers: finance.transfers - price,
      ),
      market: market.where((p) => p.id != playerId).toList(),
    );
  }

  String? validateSell(String playerId) {
    if (!transferWindowOpen) return transferWindowMessage;
    final club = userClub;
    final player = club.squad.where((p) => p.id == playerId).firstOrNull;
    if (player == null) return 'Joueur introuvable.';

    final count = club.squad.where((p) => p.position == player.position).length;
    final minimum = minSquadByPosition[player.position] ?? 0;
    if (count <= minimum) {
      return 'Il vous faut au moins $minimum joueurs à ce poste.';
    }
    return null;
  }

  GameState sellPlayer(String playerId) {
    if (validateSell(playerId) != null) return this;
    final club = userClub;
    final player = club.squad.firstWhere((p) => p.id == playerId);
    final price = sellPrice(player);
    return _withClub(
      club.copyWith(
        squad: club.squad.where((p) => p.id != playerId).toList(),
        starterIds: club.starterIds.where((id) => id != playerId).toList(),
      ),
      finance: finance.copyWith(
        treasury: finance.treasury + price,
        transfers: finance.transfers + price,
      ),
    );
  }

  // ---------- staff ----------

  StaffMember? staffOf(StaffRole role) =>
      staff.where((m) => m.role == role).firstOrNull;

  StaffMember? get manager => staffOf(StaffRole.manager);

  StaffMember? get sportingDirector => staffOf(StaffRole.sportingDirector);

  List<StaffMember> get scouts =>
      staff.where((m) => m.role == StaffRole.scout).toList();

  /// Candidats de la saison qui ne sont pas encore recrutés.
  List<StaffMember> get staffCandidates {
    return generateStaffCandidates(
      division: division,
      seed: season.seed,
      seasonNumber: seasonNumber,
      directorLevel: directorLevel(staff),
    ).where((c) => !staff.any((m) => m.id == c.id)).toList();
  }

  String? validateHire(String candidateId) {
    final candidate = staffCandidates
        .where((c) => c.id == candidateId)
        .firstOrNull;
    if (candidate == null) return "Ce candidat n'est plus disponible.";
    if (needsDirector(candidate.role) && sportingDirector == null) {
      return "Engagez d'abord un directeur sportif.";
    }
    final held = staff.where((m) => m.role == candidate.role).length;
    if (held >= roleLimit(candidate.role)) {
      return candidate.role == StaffRole.scout
          ? 'Vous avez déjà $maxScouts recruteurs.'
          : "Ce poste est déjà pourvu : licenciez d'abord son titulaire.";
    }
    if (finance.treasury < hiringFee(candidate)) {
      return 'Trésorerie insuffisante.';
    }
    return null;
  }

  GameState hireStaff(String candidateId) {
    if (validateHire(candidateId) != null) return this;
    final candidate = staffCandidates.firstWhere((c) => c.id == candidateId);
    final fee = hiringFee(candidate);
    return copyWith(
      staff: [...staff, candidate],
      finance: finance.copyWith(
        treasury: finance.treasury - fee,
        wages: finance.wages + fee,
      ),
    );
  }

  String? validateFire(String staffId) {
    final member = staff.where((m) => m.id == staffId).firstOrNull;
    if (member == null) return 'Membre du staff introuvable.';
    if (finance.treasury < severancePay(member)) {
      return "Trésorerie insuffisante pour l'indemnité.";
    }
    return null;
  }

  GameState fireStaff(String staffId) {
    if (validateFire(staffId) != null) return this;
    final member = staff.firstWhere((m) => m.id == staffId);
    final pay = severancePay(member);
    return copyWith(
      staff: staff.where((m) => m.id != staffId).toList(),
      finance: finance.copyWith(
        treasury: finance.treasury - pay,
        wages: finance.wages + pay,
      ),
    );
  }

  // ---------- prospection mondiale ----------

  String? validateProspecting() {
    if (scouts.isEmpty) {
      return 'Embauchez un recruteur pour lancer une prospection.';
    }
    if (market.length >= maxMarketSize) {
      return 'Le mercato est déjà bien rempli.';
    }
    if (finance.treasury < prospectingCost) {
      return 'Trésorerie insuffisante.';
    }
    return null;
  }

  /// Envoie les recruteurs sur une région ([nationPool] vide = monde).
  GameState prospect({List<String> nationPool = const []}) {
    if (validateProspecting() != null) return this;
    final found = generateProspects(
      division: division,
      seed: season.seed + market.length * 31 + finance.treasury % 9973,
      seasonNumber: seasonNumber,
      scoutBonus: scoutBonus(staff) +
          recruitmentBonus(owner.recruitment) +
          analysisBonus(owner),
      existing: [...market, ...userClub.allPlayers],
      count: prospectsPerRun,
      nationPool: nationPool,
      homeNation: country.name,
    );
    return copyWith(
      market: [...market, ...found],
      finance: finance.copyWith(
        treasury: finance.treasury - prospectingCost,
        wages: finance.wages + prospectingCost,
      ),
    );
  }
}

List<Club> _mergeClubs(List<Club> base, List<Club> updated) {
  final byId = {for (final c in updated) c.id: c};
  return [for (final c in base) byId[c.id] ?? c];
}

class _Scored {
  const _Scored(this.scorer, this.assist);

  final String scorer;
  final String assist;
}
