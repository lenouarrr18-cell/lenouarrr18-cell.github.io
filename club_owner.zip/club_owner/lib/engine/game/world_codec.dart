import '../../domain/entities/club.dart';
import '../../domain/entities/lineup.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/tactic.dart';
import '../../domain/entities/team_strength.dart';
import '../calendar/fixture_generator.dart';
import '../match/match_models.dart';
import '../season/season.dart';
import '../world/nations.dart';
import '../world/world_league.dart';

/// Sauvegarde compacte des championnats du monde : les joueurs sont
/// écrits sous forme de listes de valeurs, et les résultats sous forme
/// de scores dans l'ordre du calendrier.
List<Object?> _encodePlayer(Player p, String clubId, int index) {
  final nationIndex = nations.indexWhere((n) => n.name == p.nation);
  return [
    p.id == '$clubId-p$index' ? '' : p.id,
    p.name,
    PlayerPosition.values.indexOf(p.position),
    p.skill,
    p.age,
    p.potential,
    nationIndex >= 0 ? nationIndex : p.nation,
    p.contractYears,
    p.matches,
    p.goals,
    p.assists,
    p.cleanSheets,
    p.careerMatches,
    p.careerGoals,
    p.careerAssists,
    p.caps,
    p.awards,
    p.mood,
    p.wantsOut ? 1 : 0,
    (p.form * 100).round(),
  ];
}

Player _decodePlayer(List<dynamic> a, String clubId, int index) {
  final id = a[0] as String;
  final nation = a[6];
  return Player(
    id: id.isEmpty ? '$clubId-p$index' : id,
    name: a[1] as String,
    position: PlayerPosition.values[a[2] as int],
    skill: a[3] as int,
    age: a[4] as int,
    potential: a[5] as int,
    nation: nation is int ? nations[nation].name : nation as String,
    contractYears: a[7] as int,
    matches: a[8] as int,
    goals: a[9] as int,
    assists: a[10] as int,
    cleanSheets: a[11] as int,
    careerMatches: a[12] as int,
    careerGoals: a[13] as int,
    careerAssists: a[14] as int,
    caps: a[15] as int,
    awards: a[16] as int,
    mood: a[17] as int,
    wantsOut: (a[18] as int) == 1,
    form: (a[19] as int) / 100,
  );
}

List<Object?> _encodeClub(Club club) {
  return [
    club.id,
    club.name,
    club.prestige,
    Formation.values.indexOf(club.tactic.formation),
    TacticStyle.values.indexOf(club.tactic.style),
    Pressing.values.indexOf(club.tactic.pressing),
    [
      for (var i = 0; i < club.squad.length; i++)
        _encodePlayer(club.squad[i], club.id, i),
    ],
  ];
}

Club _decodeClub(List<dynamic> a) {
  final id = a[0] as String;
  final players = a[6] as List<dynamic>;
  final squad = [
    for (var i = 0; i < players.length; i++)
      _decodePlayer(players[i] as List<dynamic>, id, i),
  ];
  final tactic = Tactic(
    formation: Formation.values[a[3] as int],
    style: TacticStyle.values[a[4] as int],
    pressing: Pressing.values[a[5] as int],
  );
  final starterIds = pickBestStarters(squad, tactic.formation);
  return Club(
    id: id,
    name: a[1] as String,
    strength: TeamStrength.fromPlayers(
      squad.where((p) => starterIds.contains(p.id)),
    ),
    squad: squad,
    starterIds: starterIds,
    tactic: tactic,
    prestige: a[2] as int,
  );
}

Map<String, Object?> encodeLeague(WorldLeague league) {
  final season = league.season;
  final scores = <int>[];
  for (final fixture in season.fixtures) {
    final result = season.results[fixture.key];
    if (result == null) break;
    scores.add(result.homeGoals * 100 + result.awayGoals);
  }
  return {
    'id': league.id,
    'country': league.country,
    'division': league.division,
    'seed': season.seed,
    'round': season.currentRound,
    'scores': scores,
    'clubs': [for (final club in season.clubs) _encodeClub(club)],
  };
}

WorldLeague decodeLeague(Map<String, dynamic> json) {
  final clubs = [
    for (final raw in json['clubs'] as List<dynamic>)
      _decodeClub(raw as List<dynamic>),
  ];
  final fixtures = generateRoundRobin(clubs.map((c) => c.id).toList());
  final scores = json['scores'] as List<dynamic>;
  final results = <String, MatchResult>{};
  for (var i = 0; i < scores.length && i < fixtures.length; i++) {
    final score = scores[i] as int;
    results[fixtures[i].key] = MatchResult(
      homeGoals: score ~/ 100,
      awayGoals: score % 100,
      events: const [],
    );
  }
  return WorldLeague(
    id: json['id'] as String,
    country: json['country'] as String,
    division: json['division'] as int,
    season: Season(
      clubs: clubs,
      fixtures: fixtures,
      results: results,
      currentRound: json['round'] as int,
      seed: json['seed'] as int,
    ),
  );
}
