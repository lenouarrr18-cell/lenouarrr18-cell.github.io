/// Nombre de supporters du club.
int supportersCount({
  required int populationThousands,
  required int prestige,
}) {
  return (populationThousands * 1000 * 0.012 * (0.5 + prestige / 50)).round();
}

/// Ultras : le noyau dur des supporters.
int ultrasCount(int supporters) => supporters ~/ 40;

String fanMoodLabel(int mood) {
  if (mood >= 80) return 'Euphorie dans les tribunes';
  if (mood >= 60) return 'Les supporters sont contents';
  if (mood >= 40) return 'Les supporters sont partagés';
  if (mood >= 20) return 'Les supporters grondent';
  return 'Colère des supporters';
}

/// Évolution de l'humeur des supporters après un match.
int moodAfterMatch({
  required int mood,
  required int goalsFor,
  required int goalsAgainst,
  required bool atHome,
}) {
  int delta;
  if (goalsFor > goalsAgainst) {
    delta = atHome ? 3 : 4;
  } else if (goalsFor == goalsAgainst) {
    delta = atHome ? -1 : 1;
  } else {
    delta = atHome ? -5 : -3;
  }
  return (mood + delta).clamp(0, 100).toInt();
}
