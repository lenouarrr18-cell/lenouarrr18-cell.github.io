import '../../domain/entities/club.dart';
import '../../domain/entities/lineup.dart';
import '../../domain/entities/player.dart';

/// Résultat du choix du coach pour la prochaine journée.
class CoachSelection {
  const CoachSelection(this.club, this.notes);

  final Club club;

  /// Décisions notables (joueurs ménagés, retours...).
  final List<String> notes;
}

/// Le coach compose l'équipe : le président ne titularise personne.
///
/// Il choisit le meilleur onze pour la formation retenue, en tenant compte
/// du poste naturel, de la forme et de la condition physique. Un joueur
/// fatigué est ménagé quand un remplaçant du même niveau est disponible.
CoachSelection coachSelects(Club club) {
  if (club.squad.length < 11) return CoachSelection(club, const []);
  final formation = club.tactic.formation;
  final chosen = pickBestStarters(club.squad, formation);
  if (chosen.length != 11) return CoachSelection(club, const []);

  // Onze « idéal » si tout le monde était frais : sert à repérer la rotation.
  final fresh = [for (final p in club.squad) p.copyWith(fitness: 100)];
  final ideal = pickBestStarters(fresh, formation).toSet();
  final notes = <String>[];
  for (final p in club.squad) {
    if (ideal.contains(p.id) && !chosen.contains(p.id)) {
      notes.add('${p.name} est ménagé (condition ${p.fitness} %).');
    }
  }
  return CoachSelection(club.copyWith(starterIds: chosen), notes);
}

/// Fatigue après un match : les titulaires se fatiguent (davantage avec
/// l'âge), les autres récupèrent. Le staff médical accélère la récupération.
Club applyMatchLoad(
  Club club, {
  int medicalLevel = 0,
  int restBonus = 0,
  int matchSaving = 0,
}) {
  final starters = club.starterIds.toSet();
  return club.copyWith(
    squad: [
      for (final p in club.squad)
        if (starters.contains(p.id))
          p.copyWith(
            fitness: (p.fitness -
                    (9 - matchSaving) -
                    (p.age > 29 ? p.age - 29 : 0))
                .clamp(30, 100)
                .toInt(),
          )
        else
          p.copyWith(
            fitness: (p.fitness + 14 + medicalLevel * 2 + restBonus)
                .clamp(0, 100)
                .toInt(),
          ),
    ],
  );
}

/// Joueurs à ménager à court terme (pour l'affichage).
List<Player> tiredPlayers(Club club) =>
    [for (final p in club.squad) if (p.fitness < 60) p];
