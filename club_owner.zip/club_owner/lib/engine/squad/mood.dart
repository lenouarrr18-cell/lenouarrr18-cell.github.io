import 'dart:math';

import '../../domain/entities/club.dart';
import '../../domain/entities/owner.dart';
import '../../domain/entities/player.dart';

/// Résultat d'une mise à jour des humeurs du vestiaire.
class MoodReport {
  const MoodReport({
    required this.club,
    this.messages = const [],
    this.news = const [],
  });

  final Club club;
  final List<InboxMessage> messages;
  final List<NewsItem> news;
}

int _clampMood(int value) => value.clamp(12, 100).toInt();

/// Met à jour l'humeur des joueurs de l'équipe première après un match.
/// [outcome] vaut 1 (victoire), 0 (nul) ou -1 (défaite).
MoodReport updateMoods({
  required Club club,
  required int outcome,
  required int season,
  required int round,
}) {
  final starters = club.starterIds.toSet();
  final worstStarter = <PlayerPosition, int>{};
  for (final p in club.squad) {
    if (!starters.contains(p.id)) continue;
    final current = worstStarter[p.position];
    if (current == null || p.skill < current) worstStarter[p.position] = p.skill;
  }

  final messages = <InboxMessage>[];
  final news = <NewsItem>[];

  final updated = <Player>[];
  for (final p in club.squad) {
    var delta = 0;
    final isStarter = starters.contains(p.id);
    if (isStarter) {
      delta += outcome == 1 ? 2 : (outcome == 0 ? 1 : 0);
    } else {
      final threshold = (worstStarter[p.position] ?? 99) - 2;
      if (p.skill >= threshold) delta -= 3;
    }
    delta += (65 - p.mood) ~/ 15;
    final mood = _clampMood(p.mood + delta);

    var wantsOut = p.wantsOut;
    if (!wantsOut && p.mood >= 35 && mood < 35 && !isStarter) {
      messages.add(
        InboxMessage(
          title: '${p.name} se plaint',
          body:
              '${p.name} estime ne pas jouer assez. Faites-le jouer, '
              'discutez avec lui ou préparez son départ.',
          season: season,
          round: round,
        ),
      );
    }
    if (!wantsOut && mood <= 24) {
      wantsOut = true;
      messages.add(
        InboxMessage(
          title: '${p.name} réclame son départ',
          body:
              '${p.name} veut partir. Son prix de vente baissera, mais '
              'vous pouvez encore le convaincre de rester.',
          season: season,
          round: round,
        ),
      );
      news.add(
        NewsItem(
          headline: '${p.name} réclame son départ',
          body:
              'Peu utilisé, ${p.name} (${club.name}) aurait demandé à '
              'être transféré.',
          season: season,
          round: round,
          kind: NewsKind.locker,
        ),
      );
    } else if (wantsOut && mood >= 45) {
      wantsOut = false;
    }
    updated.add(p.copyWith(mood: mood, wantsOut: wantsOut));
  }

  return MoodReport(
    club: club.copyWith(squad: updated),
    messages: messages,
    news: news,
  );
}

/// Incident du vestiaire.
class LockerEvent {
  const LockerEvent({
    required this.title,
    required this.body,
    required this.headline,
    required this.moodChanges,
  });

  final String title;
  final String body;
  final String headline;

  /// Variation d'humeur par identifiant de joueur.
  final Map<String, int> moodChanges;
}

/// Tire éventuellement un incident (environ une journée sur vingt).
LockerEvent? rollLockerEvent({
  required int seed,
  required int season,
  required int round,
  required Club club,
  required bool hasManager,
}) {
  final random = Random(seed * 17 + season * 1009 + round * 313);
  if (random.nextDouble() >= 0.05) return null;
  final pool = club.squad;
  if (pool.length < 2) return null;

  final kind = hasManager ? random.nextInt(2) : 0;
  if (kind == 0) {
    final a = pool[random.nextInt(pool.length)];
    var b = pool[random.nextInt(pool.length)];
    var guard = 0;
    while (b.id == a.id && guard < 10) {
      b = pool[random.nextInt(pool.length)];
      guard++;
    }
    if (b.id == a.id) return null;
    return LockerEvent(
      title: 'Altercation au vestiaire',
      body: '${a.name} et ${b.name} en sont venus aux mains à '
          "l'entraînement. L'ambiance est tendue.",
      headline: 'Altercation entre ${a.name} et ${b.name} à ${club.name}',
      moodChanges: {a.id: -14, b.id: -14},
    );
  }
  final p = pool[random.nextInt(pool.length)];
  return LockerEvent(
    title: 'Clash avec le manager',
    body: '${p.name} s\'est vivement disputé avec le manager devant tout '
        'le groupe.',
    headline: '${p.name} clashe avec son entraîneur à ${club.name}',
    moodChanges: {p.id: -26},
  );
}

/// Applique un incident : humeurs et demandes de départ.
MoodReport applyLockerEvent({
  required Club club,
  required LockerEvent event,
  required int season,
  required int round,
}) {
  final messages = <InboxMessage>[
    InboxMessage(
      title: event.title,
      body: event.body,
      season: season,
      round: round,
    ),
  ];
  final news = <NewsItem>[
    NewsItem(
      headline: event.headline,
      body: event.body,
      season: season,
      round: round,
      kind: NewsKind.locker,
    ),
  ];
  final updated = <Player>[];
  for (final p in club.squad) {
    final change = event.moodChanges[p.id];
    if (change == null) {
      updated.add(p);
      continue;
    }
    final mood = _clampMood(p.mood + change);
    var wantsOut = p.wantsOut;
    if (!wantsOut && mood <= 24) {
      wantsOut = true;
      messages.add(
        InboxMessage(
          title: '${p.name} réclame son départ',
          body: 'Après l\'incident, ${p.name} veut quitter le club.',
          season: season,
          round: round,
        ),
      );
      news.add(
        NewsItem(
          headline: '${p.name} veut quitter ${club.name}',
          body: 'Fâché, ${p.name} réclame son transfert.',
          season: season,
          round: round,
          kind: NewsKind.locker,
        ),
      );
    }
    updated.add(p.copyWith(mood: mood, wantsOut: wantsOut));
  }
  return MoodReport(
    club: club.copyWith(squad: updated),
    messages: messages,
    news: news,
  );
}
