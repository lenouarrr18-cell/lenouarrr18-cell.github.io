import 'dart:math';

import '../../domain/entities/lineup.dart';
import '../../domain/entities/player.dart';
import '../owner/infrastructure.dart';
import 'squad_factory.dart';

const int retirementAge = 36;

const List<PlayerPosition> _youthPositions = [
  PlayerPosition.goalkeeper,
  PlayerPosition.defender,
  PlayerPosition.defender,
  PlayerPosition.midfielder,
  PlayerPosition.midfielder,
  PlayerPosition.forward,
];

int _skillDelta(int age, Random random) {
  if (age <= 22) return 1 + random.nextInt(4);
  if (age <= 27) return random.nextInt(4) - 1;
  if (age <= 31) return random.nextInt(4) - 2;
  return random.nextInt(5) - 4;
}

/// Vieillit l'effectif d'un an : les jeunes progressent, les anciens
/// déclinent, les joueurs de 36 ans prennent leur retraite et deux jeunes
/// rejoignent le groupe.
List<Player> developSquad({
  required List<Player> squad,
  required int seed,
  required int seasonNumber,
  int trainingLevel = 1,
  int academyLevel = 1,
}) {
  final random = Random(seed + seasonNumber * 7919);
  final next = <Player>[];

  for (final player in squad) {
    final age = player.age + 1;
    if (age >= retirementAge) continue;
    var delta = _skillDelta(age, random);
    if (trainingLevel > 1 &&
        age <= 29 &&
        random.nextDouble() < trainingChance(trainingLevel)) {
      delta += 1;
    }
    final skill = (player.skill + delta).clamp(25, 95).toInt();
    next.add(
      Player(
        id: player.id,
        name: player.name,
        position: player.position,
        skill: skill,
        age: age,
      ),
    );
  }

  final usedNames = next.map((p) => p.name).toSet();
  for (var i = 0; i < youthCount(academyLevel); i++) {
    if (next.length >= maxSquadSize) break;
    next.add(
      Player(
        id: 'y$seasonNumber-$i',
        name: randomPlayerName(random, usedNames),
        position: _youthPositions[random.nextInt(_youthPositions.length)],
        skill: (42 + youthBonus(academyLevel) + random.nextDouble() * 10 - 5)
            .round()
            .clamp(25, 85)
            .toInt(),
        age: 17 + random.nextInt(2),
      ),
    );
  }

  return next;
}
