import 'dart:math';

import '../../domain/entities/player.dart';
import '../../domain/data/names_data.dart';

const List<String> _firstNames = [
  'Kouadio',
  'Yao',
  'Ibrahim',
  'Moussa',
  'Samuel',
  'Thomas',
  'Lucas',
  'Karim',
  'Ousmane',
  'Daniel',
  'Jordan',
  'Matteo',
  'Idrissa',
  'Cédric',
  'Aboubacar',
  'Jean',
  'Paul',
  'Nicolas',
  'Adama',
  'Eric',
  'Mamadou',
  'Seydou',
  'Hugo',
  'Rayan',
  'Brice',
  'Franck',
  'Wilfried',
  'Serge',
  'Amadou',
  'Yannick',
];

const List<String> _lastNames = [
  'Konan',
  'Diallo',
  'Traoré',
  'Martin',
  'Bamba',
  'Mensah',
  'Ndiaye',
  'Dupont',
  'Okafor',
  'Silva',
  'Camara',
  'Fofana',
  'Bernard',
  'Touré',
  'Koffi',
  'Sow',
  'Benali',
  'Moreau',
  'Kamara',
  'Lambert',
  'Coulibaly',
  'Sanogo',
  'Gueye',
  'Barry',
  'Nguessan',
  'Ouattara',
  'Kouassi',
  'Zogbo',
  'Dembélé',
  'Cissé',
];

const Map<PlayerPosition, int> _squadComposition = {
  PlayerPosition.goalkeeper: 3,
  PlayerPosition.defender: 7,
  PlayerPosition.midfielder: 7,
  PlayerPosition.forward: 5,
};

/// Nom crédible pour la nationalité [nation] (prénom et nom de sa culture),
/// unique parmi [used]. Nationalité inconnue : liste générale.
String randomPlayerNameFor(String nation, Random random, Set<String> used) {
  var group = nameGroupsByNation[nation];
  if (group == null) return randomPlayerName(random, used);
  // Binationaux : une part des joueurs porte un nom d'une autre culture.
  final heritage = heritageByNation[nation];
  if (heritage != null && random.nextDouble() < heritage.$1) {
    group = heritage.$2[random.nextInt(heritage.$2.length)];
  }
  final g = group;
  String make() {
    final first = g.first[random.nextInt(g.first.length)];
    final last = g.last[random.nextInt(g.last.length)];
    return g.familyFirst ? '$last $first' : '$first $last';
  }

  for (var attempt = 0; attempt < 40; attempt++) {
    final name = make();
    if (used.add(name)) return name;
  }
  final base = make();
  var n = 2;
  while (!used.add('$base $n')) {
    n++;
  }
  return '$base $n';
}

/// Tire un nom unique parmi [used] (le nom tiré y est ajouté).
String randomPlayerName(Random random, Set<String> used) {
  for (var attempt = 0; attempt < 30; attempt++) {
    final first = _firstNames[random.nextInt(_firstNames.length)];
    final last = _lastNames[random.nextInt(_lastNames.length)];
    final name = '$first $last';
    if (used.add(name)) return name;
  }
  // Presque tous les noms sont pris : on ajoute une initiale, puis un
  // numéro. Cette recherche se termine toujours.
  const letters = 'ABCDEFGHIJKLMNOPRSTV';
  final first = _firstNames[random.nextInt(_firstNames.length)];
  final last = _lastNames[random.nextInt(_lastNames.length)];
  final initial = letters[random.nextInt(letters.length)];
  final base = '$first $initial. $last';
  if (used.add(base)) return base;
  var n = 2;
  while (!used.add('$base $n')) {
    n++;
  }
  return '$base $n';
}

/// Génère un effectif de 22 joueurs autour d'un niveau moyen.
List<Player> generateSquad({required double level, required int seed}) {
  final random = Random(seed);
  final usedNames = <String>{};
  final players = <Player>[];
  var index = 0;

  _squadComposition.forEach((position, count) {
    for (var i = 0; i < count; i++) {
      final name = randomPlayerName(random, usedNames);
      final skill = (level + random.nextDouble() * 12 - 6)
          .round()
          .clamp(25, 85)
          .toInt();
      players.add(
        Player(
          id: 'p$index',
          name: name,
          position: position,
          skill: skill,
          age: 17 + random.nextInt(18),
        ),
      );
      index++;
    }
  });

  return players;
}
