import '../../domain/entities/division.dart';
import '../../domain/entities/owner.dart';
import '../game/game_state.dart';

/// Un succès du président, calculé à partir de la partie (rien à
/// sauvegarder : il reste acquis tant que l'exploit figure dans l'historique).
class Achievement {
  const Achievement(this.id, this.title, this.description, this.tier, this.test);

  final String id;
  final String title;
  final String description;

  /// 1 bronze, 2 argent, 3 or.
  final int tier;
  final bool Function(GameState g) test;
}

int _wins(GameState g) {
  for (final s in g.season.standings) {
    if (s.clubId == g.userClub.id) return s.won;
  }
  return 0;
}

int _built(OwnerState o) =>
    InfraKind.values.where((k) => o.levelOf(k) > 0).length;

final List<Achievement> achievements = [
  Achievement('first_win', 'Premier frisson', 'Gagner un match officiel.', 1,
      (g) => _wins(g) >= 1 || g.history.isNotEmpty),
  Achievement('ten_wins', 'Machine à gagner',
      'Gagner 10 matchs en une saison.', 2, (g) => _wins(g) >= 10),
  Achievement('promotion', 'Ascension', 'Monter en division supérieure.', 2,
      (g) => g.history.any((r) => r.outcome == SeasonOutcome.promoted)),
  Achievement('champion', 'Champion !', 'Terminer une saison à la 1re place.',
      3, (g) => g.history.any((r) => r.rank == 1)),
  Achievement('elite', 'L\'élite', 'Jouer en première division.', 3,
      (g) => g.division == 1 || g.history.any((r) => r.division == 1)),
  Achievement('stadium2', 'Stade régional', 'Agrandir le stade au niveau 2.',
      1, (g) => g.owner.stadium >= 2),
  Achievement('stadium4', 'Arène moderne', 'Stade au niveau 4.', 3,
      (g) => g.owner.stadium >= 4),
  Achievement('builder', 'Bâtisseur', 'Posséder 10 bâtiments différents.', 2,
      (g) => _built(g.owner) >= 10),
  Achievement('million', 'Premier million', 'Atteindre 1 M€ de trésorerie.',
      1, (g) => g.finance.treasury >= 1000000),
  Achievement('empire', 'Empire financier',
      'Atteindre 10 M€ de trésorerie.', 3, (g) => g.finance.treasury >= 10000000),
  Achievement('staff', 'Organigramme', 'Engager un manager et un directeur '
      'sportif.', 1, (g) => g.manager != null && g.sportingDirector != null),
  Achievement('sponsor', 'Partenaire principal',
      'Signer un sponsor principal.', 1, (g) => g.owner.deal != null),
  Achievement('fans', 'Ville conquise', 'Atteindre 10 000 abonnés.', 2,
      (g) => g.owner.followers >= 10000),
  Achievement('europe', 'Nuit continentale',
      'Disputer une coupe continentale.', 3,
      (g) => g.cups.any((c) => c.userPlayers.isNotEmpty)),
  Achievement('continental', 'Roi du continent',
      'Remporter une coupe continentale.', 3,
      (g) => g.cups.any((c) => c.champion == g.userClub.name)),
  Achievement('ballon', 'Ballon d\'or maison',
      'Un de vos joueurs remporte le Ballon d\'or.', 3,
      (g) => g.awards.any(
            (a) => a.clubName == g.userClub.name && a.category.contains('Ballon'),
          )),
  Achievement('loyal', 'Président fidèle', 'Diriger le club 5 saisons.', 2,
      (g) => g.history.length >= 5),
];

Set<String> unlockedAchievements(GameState g) => {
      for (final a in achievements)
        if (a.test(g)) a.id,
    };
