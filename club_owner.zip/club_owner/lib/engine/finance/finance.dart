import 'dart:math';

import '../../domain/entities/division.dart';
import '../../domain/entities/player.dart';

const int ticketPrice = 5;

/// Intérêt appliqué à un prêt bancaire.
const double loanInterestRate = 0.08;

/// Salaire annuel d'un joueur.
int annualWage(Player player) => player.skill * 450;

int squadAnnualWages(Iterable<Player> squad) {
  return squad.fold<int>(0, (sum, p) => sum + annualWage(p));
}

/// Valeur de transfert : croît vite avec le niveau, tient compte du
/// potentiel des jeunes, de l'âge et de l'expérience (matchs joués).
int playerValue(Player player) {
  final double ageFactor;
  if (player.age <= 21) {
    ageFactor = 1.4;
  } else if (player.age <= 26) {
    ageFactor = 1.1;
  } else if (player.age <= 30) {
    ageFactor = 0.9;
  } else {
    ageFactor = 0.55;
  }
  final gap = player.maxSkill - player.skill;
  final potentialWeight = player.age <= 21 ? 0.5 : (player.age <= 24 ? 0.3 : 0.0);
  final effective = player.skill + gap * potentialWeight;
  final experience = 1 + (player.totalMatches > 300 ? 300 : player.totalMatches) / 1500;
  final raw = 12000 * pow(1.15, effective - 45) * ageFactor * experience;
  return (raw / 1000).round() * 1000;
}

/// Prix de revente : 80 % de la valeur.
int sellPrice(Player player) {
  return (playerValue(player) * 0.8 / 1000).round() * 1000;
}

int startingTreasury(int wealth) => 250000 + wealth * 50000;

/// Nombre de spectateurs d'un match à domicile.
int attendanceFor({
  required int populationThousands,
  required int rank,
  int clubCount = 20,
  int prestige = 20,
  int fanMood = 60,
  int capacity = 1000000,
}) {
  final demand = 700 + 11 * sqrt(populationThousands);
  final fanFactor = 1.3 - 0.5 * (rank - 1) / (clubCount - 1);
  final prestigeFactor = 0.8 + prestige / 100;
  final moodFactor = 0.7 + fanMood / 200;
  final wanted = (demand * fanFactor * prestigeFactor * moodFactor).round();
  return wanted > capacity ? capacity : wanted;
}

/// Recette de billetterie d'un match à domicile.
int ticketRevenue({
  required int populationThousands,
  required int division,
  required int rank,
  int clubCount = 20,
  int stadiumLevel = 1,
  int prestige = 20,
  int fanMood = 60,
  int capacity = 1000000,
}) {
  final stadiumFactor = 1 + 0.2 * (stadiumLevel - 1);
  final attendance = attendanceFor(
    populationThousands: populationThousands,
    rank: rank,
    clubCount: clubCount,
    prestige: prestige,
    fanMood: fanMood,
    capacity: capacity,
  );
  return (attendance *
          ticketPrice *
          divisionRevenueFactor(division) *
          stadiumFactor)
      .round();
}

/// Droits TV versés sur une saison.
int tvIncomePerSeason(int division) {
  switch (division) {
    case 1:
      return 600000;
    case 2:
      return 250000;
    case 3:
      return 100000;
    default:
      return 40000;
  }
}

/// Recette de merchandising d'un match à domicile.
int merchRevenue({
  required int populationThousands,
  required int division,
  required int reputation,
}) {
  final base = 150 + 6 * sqrt(populationThousands);
  return (base * (0.6 + reputation / 100) * divisionRevenueFactor(division) * 4)
      .round();
}

/// Revenus de sponsoring sur une saison.
int sponsorIncomePerSeason({required int wealth, required int division}) {
  return ((150000 + wealth * 40000) * divisionRevenueFactor(division)).round();
}

/// Comptes du club : trésorerie et bilan de la saison en cours.
class FinanceBook {
  const FinanceBook({
    required this.treasury,
    this.tickets = 0,
    this.sponsors = 0,
    this.wages = 0,
    this.transfers = 0,
    this.extras = 0,
    this.infrastructure = 0,
    this.debtService = 0,
  });

  factory FinanceBook.fromJson(Map<String, dynamic> json) {
    return FinanceBook(
      treasury: json['treasury'] as int,
      tickets: json['tickets'] as int,
      sponsors: json['sponsors'] as int,
      wages: json['wages'] as int,
      transfers: json['transfers'] as int,
      extras: json['extras'] as int? ?? 0,
      infrastructure: json['infrastructure'] as int? ?? 0,
      debtService: json['debtService'] as int? ?? 0,
    );
  }

  final int treasury;
  final int tickets;
  final int sponsors;
  final int wages;

  /// Solde net des transferts de la saison (positif = ventes).
  final int transfers;

  /// Autres revenus : droits TV, merchandising, primes, événements.
  final int extras;

  /// Travaux et entretien des infrastructures.
  final int infrastructure;

  /// Intérêts payés sur les prêts.
  final int debtService;

  int get seasonResult =>
      tickets + sponsors + extras - wages - infrastructure - debtService +
      transfers;

  FinanceBook copyWith({
    int? treasury,
    int? tickets,
    int? sponsors,
    int? wages,
    int? transfers,
    int? extras,
    int? infrastructure,
    int? debtService,
  }) {
    return FinanceBook(
      treasury: treasury ?? this.treasury,
      tickets: tickets ?? this.tickets,
      sponsors: sponsors ?? this.sponsors,
      wages: wages ?? this.wages,
      transfers: transfers ?? this.transfers,
      extras: extras ?? this.extras,
      infrastructure: infrastructure ?? this.infrastructure,
      debtService: debtService ?? this.debtService,
    );
  }

  /// Remet à zéro le bilan de saison en gardant la trésorerie.
  FinanceBook resetSeason() => FinanceBook(treasury: treasury);

  Map<String, Object?> toJson() {
    return {
      'treasury': treasury,
      'tickets': tickets,
      'sponsors': sponsors,
      'wages': wages,
      'transfers': transfers,
      'extras': extras,
      'infrastructure': infrastructure,
      'debtService': debtService,
    };
  }
}
