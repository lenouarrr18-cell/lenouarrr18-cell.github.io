import 'dart:math';

import '../../domain/entities/division.dart';
import '../../domain/entities/staff.dart';
import '../squad/squad_factory.dart';

/// Nombre maximum de recruteurs en même temps.
const int maxScouts = 3;

/// Coût d'une campagne de prospection.
const int prospectingCost = 20000;

/// Nombre de joueurs ramenés par une prospection.
const int prospectsPerRun = 4;

/// Taille maximale du mercato.
const int maxMarketSize = 60;

int _rate(StaffRole role) {
  switch (role) {
    case StaffRole.manager:
      return 700;
    case StaffRole.sportingDirector:
      return 600;
    case StaffRole.scout:
      return 400;
    case StaffRole.coachFirst:
    case StaffRole.coachReserve:
    case StaffRole.coachAcademy:
      return 450;
    case StaffRole.communityManager:
      return 300;
  }
}

/// Salaire annuel d'un membre du staff.
int staffAnnualWage(StaffMember member) => member.level * _rate(member.role);

int staffAnnualWages(Iterable<StaffMember> staff) {
  return staff.fold<int>(0, (sum, m) => sum + staffAnnualWage(m));
}

/// Prime d'embauche : la moitié du salaire annuel.
int hiringFee(StaffMember member) => staffAnnualWage(member) ~/ 2;

/// Indemnité de licenciement : la moitié du salaire annuel.
int severancePay(StaffMember member) => staffAnnualWage(member) ~/ 2;

/// Les recruteurs et les coachs sont engagés par le directeur sportif.
bool needsDirector(StaffRole role) {
  return role == StaffRole.scout ||
      role == StaffRole.coachFirst ||
      role == StaffRole.coachReserve ||
      role == StaffRole.coachAcademy;
}

/// Nombre maximum de membres pour un poste.
int roleLimit(StaffRole role) => role == StaffRole.scout ? maxScouts : 1;

/// Multiplicateur de force d'équipe apporté par un manager de ce niveau.
double managerBoostFor(int level) => 1 + level / 2000;

int bestLevel(Iterable<StaffMember> staff, StaffRole role) {
  var best = 0;
  for (final member in staff) {
    if (member.role == role && member.level > best) best = member.level;
  }
  return best;
}

/// Multiplicateur de force d'équipe selon le staff (1.0 sans manager).
double managerBoost(Iterable<StaffMember> staff) {
  final best = bestLevel(staff, StaffRole.manager);
  return best == 0 ? 1.0 : managerBoostFor(best);
}

/// Points de niveau ajoutés aux joueurs trouvés par les recruteurs.
double scoutBonus(Iterable<StaffMember> staff) {
  return bestLevel(staff, StaffRole.scout) / 20;
}

/// Niveau du directeur sportif (0 s'il n'y en a pas).
int directorLevel(Iterable<StaffMember> staff) {
  return bestLevel(staff, StaffRole.sportingDirector);
}

String _prefix(StaffRole role) {
  switch (role) {
    case StaffRole.manager:
      return 'mgr';
    case StaffRole.sportingDirector:
      return 'dir';
    case StaffRole.scout:
      return 'sct';
    case StaffRole.coachFirst:
      return 'cf';
    case StaffRole.coachReserve:
      return 'cr';
    case StaffRole.coachAcademy:
      return 'ca';
    case StaffRole.communityManager:
      return 'cm';
  }
}

/// Candidats disponibles cette saison (reproductibles grâce à la graine).
/// Sans directeur sportif, seuls le manager, le directeur et le
/// community manager sont proposés.
List<StaffMember> generateStaffCandidates({
  required int division,
  required int seed,
  required int seasonNumber,
  int directorLevel = 0,
}) {
  final random = Random(seed + seasonNumber * 15485863);
  final base = divisionBase(division);
  final usedNames = <String>{};
  final candidates = <StaffMember>[];

  void add(StaffRole role, int count, double bonus) {
    for (var i = 0; i < count; i++) {
      candidates.add(
        StaffMember(
          id: '${_prefix(role)}$seasonNumber-$i',
          name: randomPlayerName(random, usedNames),
          role: role,
          level: (base + bonus - 8 + random.nextDouble() * 22)
              .round()
              .clamp(25, 90)
              .toInt(),
        ),
      );
    }
  }

  add(StaffRole.manager, 4, 0);
  add(StaffRole.sportingDirector, 3, 0);
  add(StaffRole.communityManager, 3, 0);

  if (directorLevel > 0) {
    final bonus = directorLevel / 10;
    add(StaffRole.scout, 2 + directorLevel ~/ 30, bonus);
    add(StaffRole.coachFirst, 3, bonus);
    if (division <= 3) add(StaffRole.coachReserve, 3, bonus);
    add(StaffRole.coachAcademy, 3, bonus);
  }
  return candidates;
}
