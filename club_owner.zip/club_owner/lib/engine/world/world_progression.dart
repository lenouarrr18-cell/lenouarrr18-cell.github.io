import 'dart:math';

import '../../domain/entities/club.dart';
import '../../domain/entities/lineup.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/team_strength.dart';
import '../owner/infrastructure.dart';
import '../squad/squad_factory.dart';
import 'club_factory.dart';
import 'profile.dart';

/// Résultat du passage d'une saison pour un club.
class ClubDevelopment {
  const ClubDevelopment({
    required this.club,
    required this.retired,
    required this.expired,
    required this.notes,
  });

  final Club club;

  /// Joueurs partis à la retraite (avec leurs statistiques de carrière).
  final List<Player> retired;

  /// Joueurs du club du président dont le contrat n'a pas été prolongé.
  final List<Player> expired;

  /// Messages destinés au président (retraites, promotions, regens).
  final List<String> notes;
}

int _stable(String text) {
  var hash = 7;
  for (final unit in text.codeUnits) {
    hash = (hash * 31 + unit) & 0x3fffffff;
  }
  return hash;
}

Player _develop(Player closed, Random random, double extraChance) {
  final age = closed.age + 1;
  int delta;
  if (age <= 21) {
    delta = 1 + random.nextInt(4);
  } else if (age <= 25) {
    delta = random.nextInt(4);
  } else if (age <= 29) {
    delta = random.nextInt(3) - 1;
  } else if (age <= 32) {
    delta = -random.nextInt(4);
  } else {
    delta = -1 - random.nextInt(4);
  }
  if (delta > 0) {
    final room = closed.maxSkill - closed.skill;
    if (delta > room) delta = room;
    if (room > delta && random.nextDouble() < extraChance) delta += 1;
  }
  final skill = (closed.skill + delta).clamp(25, 95).toInt();
  return closed.copyWith(
    skill: skill,
    age: age,
    form: 1.0,
    contractYears: closed.contractYears - 1,
    potential: closed.maxSkill < skill ? skill : closed.potential,
    mood: (closed.mood + 70) ~/ 2,
    wantsOut: false,
  );
}

bool _retires(Player player, Random random) {
  var age = player.age;
  if (player.skill >= 80) age -= 2;
  if (player.position == PlayerPosition.goalkeeper) age -= 2;
  final double chance;
  if (age <= 32) {
    chance = 0;
  } else if (age == 33) {
    chance = 0.05;
  } else if (age == 34) {
    chance = 0.12;
  } else if (age == 35) {
    chance = 0.22;
  } else if (age == 36) {
    chance = 0.38;
  } else if (age == 37) {
    chance = 0.55;
  } else if (age == 38) {
    chance = 0.75;
  } else {
    chance = 1.0;
  }
  return random.nextDouble() < chance;
}

double _worth(Player p) => p.skill + p.maxSkill * 0.3 - p.age * 0.5;

/// Fait vieillir un club d'une saison : progression, retraites, contrats,
/// regens du centre de formation et promotions des jeunes.
ClubDevelopment developClub({
  required Club club,
  required int seed,
  required int seasonNumber,
  required String homeNation,
  required bool isUser,
  required int division,
  int trainingLevel = 1,
  int academyLevel = 1,
  int coachFirst = 0,
  int coachReserve = 0,
  int coachAcademy = 0,
  double trainingExtra = 0,
  double academyExtra = 0,
  int youthQualityBonus = 0,
  int youthExtra = 0,
  bool light = false,
  Map<PlayerPosition, int>? needsOverride,
}) {
  final random = Random(seed + _stable(club.id) * 31 + seasonNumber * 977);
  final retired = <Player>[];
  final expired = <Player>[];
  final notes = <String>[];

  final aiChance = club.prestige / 300;
  final firstChance = isUser
      ? trainingChance(trainingLevel) + coachFirst / 400 + trainingExtra
      : aiChance;
  final reserveChance = isUser
      ? trainingChance(trainingLevel) * 0.6 +
            coachReserve / 400 +
            trainingExtra * 0.6
      : aiChance;
  final academyChance = isUser
      ? 0.1 + academyLevel * 0.05 + coachAcademy / 300 + academyExtra
      : 0.1 + club.prestige / 400;

  List<Player> advance(List<Player> list, double extraChance) {
    final kept = <Player>[];
    for (final raw in list) {
      final aged = _develop(raw.closeSeason(), random, extraChance);
      if (_retires(aged, random)) {
        retired.add(aged);
        if (isUser) {
          notes.add('${aged.name} prend sa retraite à ${aged.age} ans.');
        }
        continue;
      }
      kept.add(aged);
    }
    return kept;
  }

  List<Player> handleContracts(List<Player> list) {
    final result = <Player>[];
    for (final p in list) {
      if (p.contractYears > 0) {
        result.add(p);
      } else if (!isUser || list.length <= 14) {
        result.add(p.copyWith(contractYears: 1 + random.nextInt(3)));
      } else {
        expired.add(p);
        notes.add('${p.name} quitte le club : contrat arrivé à terme.');
      }
    }
    return result;
  }

  var squad = handleContracts(advance(club.squad, firstChance));
  var reserve = handleContracts(advance(club.reserve, reserveChance));
  var academy = advance(club.academy, academyChance);

  // Nouveaux jeunes (regens) dans le centre de formation.
  final youthCount = light
      ? 0
      : 2 +
          (isUser
              ? (academyLevel - 1) ~/ 2 + youthExtra
              : club.prestige ~/ 40);
  final quality = isUser
      ? 20 + (academyLevel - 1) * 15 + coachAcademy ~/ 4 + youthQualityBonus
      : club.prestige;
  final fresh = generateYouths(
    prefix: '${club.id}-y$seasonNumber',
    count: youthCount,
    seed: seed + _stable(club.id) + seasonNumber,
    quality: quality.clamp(0, 100).toInt(),
    homeNation: homeNation,
  );
  academy = [...academy, ...fresh];
  if (isUser) {
    notes.add('${fresh.length} nouveaux jeunes arrivent au centre de formation.');
  }

  // Les jeunes en âge passent chez les pros.
  final graduateAge = isUser ? 21 : 18;
  final graduates = academy.where((p) => p.age >= graduateAge).toList()
    ..sort((a, b) => b.maxSkill.compareTo(a.maxSkill));
  academy = academy.where((p) => p.age < graduateAge).toList();
  final hasReserve = division <= 3;
  for (final g in graduates) {
    final pro = g.copyWith(contractYears: 3);
    if (hasReserve) {
      reserve = [...reserve, pro];
      if (isUser) notes.add('${pro.name} rejoint l\'équipe réserve.');
    } else if (squad.length < (isUser ? maxSquadSize : 24)) {
      squad = [...squad, pro];
      if (isUser) notes.add('${pro.name} rejoint l\'équipe première.');
    } else if (isUser) {
      notes.add('${pro.name} quitte la formation faute de place.');
    }
  }

  if (!isUser) {
    // Les réservistes confirmés montent, les autres partent.
    final stay = <Player>[];
    for (final p in reserve) {
      if (p.age >= 23 && squad.length < 24) {
        squad = [...squad, p];
      } else if (p.age >= 25) {
        continue;
      } else {
        stay.add(p);
      }
    }
    reserve = stay;
    if (reserve.length > 14) {
      reserve = (reserve.toList()..sort((a, b) => _worth(b).compareTo(_worth(a))))
          .take(14)
          .toList();
    }

    // Effectif IA : ni trop grand, ni incomplet.
    if (squad.length > 26) {
      final sorted = squad.toList()..sort((a, b) => _worth(b).compareTo(_worth(a)));
      squad = sorted.take(26).toList();
    }
    final needs = needsOverride ?? (light
        ? const {
            PlayerPosition.goalkeeper: 2,
            PlayerPosition.defender: 5,
            PlayerPosition.midfielder: 5,
            PlayerPosition.forward: 3,
          }
        : const {
            PlayerPosition.goalkeeper: 2,
            PlayerPosition.defender: 6,
            PlayerPosition.midfielder: 6,
            PlayerPosition.forward: 3,
          });
    var counter = 0;
    needs.forEach((position, minimum) {
      final have = squad.where((p) => p.position == position).length;
      for (var i = have; i < minimum; i++) {
        final skill = (35 + club.prestige * 0.3 + random.nextInt(10))
            .round()
            .clamp(25, 70)
            .toInt();
        final base = Player(
          id: '${club.id}-f$seasonNumber-$counter',
          name: randomPlayerName(random, <String>{}),
          position: position,
          skill: skill,
          age: 20 + random.nextInt(12),
        );
        squad = [
          ...squad,
          withProfile(base, random, homeNation,
              used: {for (final p in squad) p.name}),
        ];
        counter++;
      }
    });
  }

  final squadIds = squad.map((p) => p.id).toSet();
  final starterIds = isUser
      ? club.starterIds.where(squadIds.contains).toList()
      : pickBestStarters(squad, club.tactic.formation);

  final updated = club.copyWith(
    squad: squad,
    reserve: reserve,
    academy: academy,
    starterIds: starterIds,
    strength: TeamStrength.fromPlayers(
      squad.where((p) => starterIds.contains(p.id)),
    ),
  );
  return ClubDevelopment(
    club: updated,
    retired: retired,
    expired: expired,
    notes: notes,
  );
}
