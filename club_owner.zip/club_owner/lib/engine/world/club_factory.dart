import 'dart:math';

import '../../domain/entities/club.dart';
import '../../domain/entities/division.dart';
import '../../domain/entities/lineup.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/tactic.dart';
import '../../domain/entities/team_strength.dart';
import '../squad/squad_factory.dart';
import 'profile.dart';

const Map<PlayerPosition, int> _composition = {
  PlayerPosition.goalkeeper: 3,
  PlayerPosition.defender: 7,
  PlayerPosition.midfielder: 7,
  PlayerPosition.forward: 5,
};

const List<PlayerPosition> _youthPositions = [
  PlayerPosition.goalkeeper,
  PlayerPosition.defender,
  PlayerPosition.defender,
  PlayerPosition.midfielder,
  PlayerPosition.midfielder,
  PlayerPosition.forward,
  PlayerPosition.forward,
];

/// Effectif de 22 joueurs d'un club adverse.
List<Player> generateAiSquad({
  required String clubId,
  required double level,
  required int seed,
  required String homeNation,
}) {
  final random = Random(seed);
  final profileRandom = Random(seed + 11);
  final used = <String>{};
  final players = <Player>[];
  var index = 0;

  _composition.forEach((position, count) {
    for (var i = 0; i < count; i++) {
      final name = randomPlayerName(random, used);
      final skill = (level + random.nextDouble() * 12 - 6)
          .round()
          .clamp(25, 88)
          .toInt();
      final base = Player(
        id: '$clubId-p$index',
        name: name,
        position: position,
        skill: skill,
        age: 17 + random.nextInt(18),
      );
      players.add(withProfile(base, profileRandom, homeNation, used: used));
      index++;
    }
  });
  return players;
}

/// Jeunes du centre de formation. [quality] va de 0 à 100.
List<Player> generateYouths({
  required String prefix,
  required int count,
  required int seed,
  required int quality,
  required String homeNation,
  int minAge = 15,
}) {
  final random = Random(seed);
  final used = <String>{};
  final youths = <Player>[];
  for (var i = 0; i < count; i++) {
    final skill = (26 + quality * 0.12 + random.nextDouble() * 10)
        .round()
        .clamp(20, 70)
        .toInt();
    final potential = (skill + 12 + random.nextInt(30) + quality ~/ 8)
        .clamp(skill, 94)
        .toInt();
    final youthNation = pickNation(random, homeNation);
    youths.add(
      Player(
        id: '$prefix-$i',
        name: randomPlayerNameFor(youthNation, random, used),
        position: _youthPositions[random.nextInt(_youthPositions.length)],
        skill: skill,
        age: minAge + random.nextInt(4),
        potential: potential,
        nation: youthNation,
        contractYears: 3,
      ),
    );
  }
  return youths;
}

/// Équipe réserve : de jeunes adultes un peu moins forts que l'équipe A.
List<Player> generateReserve({
  required String clubId,
  required double level,
  required int seed,
  required String homeNation,
  int size = 9,
}) {
  final random = Random(seed);
  final profileRandom = Random(seed + 5);
  final used = <String>{};
  final players = <Player>[];
  for (var i = 0; i < size; i++) {
    final position = _youthPositions[random.nextInt(_youthPositions.length)];
    final skill = (level - 8 + random.nextDouble() * 10)
        .round()
        .clamp(22, 80)
        .toInt();
    final base = Player(
      id: '$clubId-r$i',
      name: randomPlayerName(random, used),
      position: position,
      skill: skill,
      age: 18 + random.nextInt(6),
    );
    players.add(withProfile(base, profileRandom, homeNation, used: used));
  }
  return players;
}

/// Un club adverse complet : équipe première, réserve et formation.
Club generateAiClub({
  required String id,
  required String name,
  required int division,
  required int seed,
  required String homeNation,
}) {
  final random = Random(seed);
  final level = divisionBase(division) - 10 + random.nextDouble() * 20;
  final squad = generateAiSquad(
    clubId: id,
    level: level,
    seed: seed + 1,
    homeNation: homeNation,
  );
  final formation = Formation.values[random.nextInt(Formation.values.length)];
  final starterIds = pickBestStarters(squad, formation);
  final prestige = (20 + (lowestDivision - division) * 12 + random.nextInt(20))
      .clamp(5, 95)
      .toInt();
  final academy = generateYouths(
    prefix: '$id-a0',
    count: 4 + random.nextInt(3),
    seed: seed + 2,
    quality: prestige,
    homeNation: homeNation,
  );
  final reserve = division <= 3
      ? generateReserve(
          clubId: id,
          level: level,
          seed: seed + 3,
          homeNation: homeNation,
        )
      : const <Player>[];

  return Club(
    id: id,
    name: name,
    strength: TeamStrength.fromPlayers(
      squad.where((p) => starterIds.contains(p.id)),
    ),
    squad: squad,
    starterIds: starterIds,
    reserve: reserve,
    academy: academy,
    tactic: Tactic(formation: formation),
    prestige: prestige,
  );
}
