import 'dart:math';

import '../../core/utils/format.dart';
import '../../domain/entities/club.dart';
import '../../domain/entities/division.dart';
import '../../domain/entities/owner.dart';
import '../../domain/entities/player.dart';
import '../finance/finance.dart';
import '../season/season.dart';
import '../squad/squad_factory.dart';
import '../stats/match_stats.dart';
import '../transfers/moves.dart';
import '../transfers/negotiation.dart';
import 'world_factory.dart';
import 'world_league.dart';
import 'world_progression.dart';

/// Tous les clubs du monde simulé (hors championnat du président).
List<Club> worldClubs(List<WorldLeague> world) {
  return [for (final l in world) ...l.season.clubs];
}

/// Fait jouer la prochaine journée de chaque championnat du monde.
List<WorldLeague> playWorldRound(List<WorldLeague> world) {
  return [for (final league in world) _playLeagueRound(league)];
}

WorldLeague _playLeagueRound(WorldLeague league) {
  final season = league.season;
  if (season.isFinished) return league;
  final round = season.currentRound;
  final simulated = season.playNextRound();
  final clubs = applyRoundStats(
    clubs: simulated.clubs,
    fixtures: season.fixturesOfRound(round),
    results: simulated.results,
    seed: season.seed,
    round: round,
  );
  return league.copyWith(season: simulated.withClubs(clubs));
}

/// Remplace les clubs du monde par leurs versions mises à jour.
List<WorldLeague> applyToWorld(List<WorldLeague> world, List<Club> updated) {
  final byId = {for (final c in updated) c.id: c};
  return [
    for (final l in world)
      l.copyWith(
        season: l.season.withClubs([
          for (final c in l.season.clubs) byId[c.id] ?? c,
        ]),
      ),
  ];
}

class WorldNews {
  const WorldNews({required this.world, required this.news});

  final List<WorldLeague> world;
  final List<NewsItem> news;
}

/// Gros titres de la journée dans le monde du football (limogeage,
/// demande de départ d'une star, altercation).
WorldNews worldRoundNews({
  required List<WorldLeague> world,
  required int seed,
  required int seasonNumber,
  required int round,
}) {
  final random = Random(seed * 23 + seasonNumber * 719 + round * 61);
  if (world.isEmpty || random.nextDouble() >= 0.3) {
    return WorldNews(world: world, news: const []);
  }
  final top = world.where((l) => l.division == 1).toList();
  final pool = top.isEmpty ? world : top;
  final league = pool[random.nextInt(pool.length)];
  final clubs = league.season.clubs;
  final club = clubs[random.nextInt(clubs.length)];
  final kind = random.nextInt(3);

  NewsItem item(String headline, String body, NewsKind newsKind) {
    return NewsItem(
      headline: headline,
      body: body,
      season: seasonNumber,
      round: round,
      kind: newsKind,
    );
  }

  if (kind == 0) {
    return WorldNews(
      world: world,
      news: [
        item(
          '${club.name} limoge son entraîneur',
          'Après une série de mauvais résultats, ${club.name} '
              '(${league.country}) se sépare de son entraîneur.',
          NewsKind.world,
        ),
      ],
    );
  }

  final starters = club.starters;
  if (starters.isEmpty) return WorldNews(world: world, news: const []);
  final player = starters[random.nextInt(starters.length)];

  if (kind == 1) {
    if (player.wantsOut) return WorldNews(world: world, news: const []);
    final updatedClub = club.copyWith(
      squad: [
        for (final p in club.squad)
          p.id == player.id ? p.copyWith(wantsOut: true, mood: 20) : p,
      ],
    );
    final updatedWorld = [
      for (final l in world)
        l.id == league.id ? l.copyWith(season: l.season.withClub(updatedClub)) : l,
    ];
    return WorldNews(
      world: updatedWorld,
      news: [
        item(
          '${player.name} réclame son départ',
          '${player.name} (${club.name}, ${league.country}) veut quitter '
              'son club : le prix de son transfert pourrait baisser.',
          NewsKind.transfer,
        ),
      ],
    );
  }

  final others = starters.where((p) => p.id != player.id).toList();
  if (others.isEmpty) return WorldNews(world: world, news: const []);
  final other = others[random.nextInt(others.length)];
  return WorldNews(
    world: world,
    news: [
      item(
        'Altercation entre ${player.name} et ${other.name} à ${club.name}',
        'Une dispute a éclaté dans le vestiaire de ${club.name}.',
        NewsKind.locker,
      ),
    ],
  );
}

/// Champions et meilleurs buteurs des championnats du monde (avant la
/// remise à zéro des statistiques).
List<NewsItem> worldSeasonNews(List<WorldLeague> world, int seasonNumber) {
  final news = <NewsItem>[];
  for (final league in world) {
    if (league.division != 1) continue;
    final standings = league.season.standings;
    if (standings.isEmpty) continue;
    final champion = league.season.clubById(standings.first.clubId);
    news.add(
      NewsItem(
        headline: '${champion.name} champion de ${league.country}',
        body: '${champion.name} remporte le championnat de première '
            'division (${league.country}).',
        season: seasonNumber,
        round: 38,
        kind: NewsKind.world,
      ),
    );
    Player? best;
    for (final c in league.season.clubs) {
      for (final p in c.squad) {
        if (best == null || p.goals > best.goals) best = p;
      }
    }
    if (best != null && best.goals > 0) {
      news.add(
        NewsItem(
          headline: '${best.name} meilleur buteur en ${league.country}',
          body: '${best.name} termine avec ${best.goals} buts.',
          season: seasonNumber,
          round: 38,
          kind: NewsKind.award,
        ),
      );
    }
  }
  return news;
}

class WorldTransferReport {
  const WorldTransferReport({required this.world, required this.news});

  final List<WorldLeague> world;
  final List<NewsItem> news;
}

/// Mercato des stars dans les premières divisions du monde.
WorldTransferReport worldTransfers({
  required List<WorldLeague> world,
  required int seed,
  required int seasonNumber,
}) {
  final random = Random(seed + seasonNumber * 7331);
  final topLeagues = world.where((l) => l.division == 1).toList();
  if (topLeagues.length < 2) {
    return WorldTransferReport(world: world, news: const []);
  }

  final byId = {
    for (final l in topLeagues)
      for (final c in l.season.clubs) c.id: c,
  };
  final stars = <_Star>[];
  for (final club in byId.values) {
    for (final p in club.squad) {
      if (p.skill >= 72 && p.age <= 31) stars.add(_Star(p, club.id));
    }
  }
  stars.sort((a, b) => b.player.skill.compareTo(a.player.skill));

  final news = <NewsItem>[];
  var counter = 0;
  for (final star in stars.take(6)) {
    final from = byId[star.clubId]!;
    final candidates = byId.values
        .where((c) => c.id != from.id && c.prestige > from.prestige + 5)
        .toList();
    if (candidates.isEmpty) continue;
    final to = candidates[random.nextInt(candidates.length)];
    final holder = byId[from.id]!;
    if (!holder.squad.any((p) => p.id == star.player.id)) continue;
    final fee = roundThousand(playerValue(star.player) * (1.05 + random.nextDouble() * 0.25));

    // Le club vendeur recrute un remplaçant plus jeune et moins fort.
    final replacementNation =
        holder.squad.isEmpty ? '' : holder.squad.first.nation;
    final replacement = Player(
      id: 'wt$seasonNumber-$counter',
      name: randomPlayerNameFor(replacementNation, random, {
        for (final p in holder.squad) p.name,
      }),
      position: star.player.position,
      skill: (star.player.skill - 12).clamp(30, 85).toInt(),
      age: 19 + random.nextInt(5),
      potential: star.player.skill,
      nation: replacementNation,
      contractYears: 3,
    );
    counter++;

    final arriving = star.player.copyWith(
      contractYears: 3,
      mood: 70,
      wantsOut: false,
    );
    final buyerSquad = [...to.squad];
    final sameRole = buyerSquad
        .where((p) => p.position == star.player.position)
        .toList()
      ..sort((a, b) => a.skill.compareTo(b.skill));
    if (buyerSquad.length >= lightMinSquad && sameRole.isNotEmpty) {
      buyerSquad.removeWhere((p) => p.id == sameRole.first.id);
    }
    buyerSquad.add(arriving);

    byId[from.id] = refreshAiClub(
      holder.copyWith(
        squad: [
          for (final p in holder.squad)
            if (p.id != star.player.id) p,
          replacement,
        ],
      ),
    );
    byId[to.id] = refreshAiClub(to.copyWith(squad: buyerSquad));

    news.add(
      NewsItem(
        headline: 'Transfert : ${star.player.name} signe à ${to.name}',
        body: '${star.player.name} (${star.player.skill}) quitte '
            '${from.name} pour ${to.name} : ${formatMoney(fee)}.',
        season: seasonNumber + 1,
        round: 1,
        kind: NewsKind.transfer,
      ),
    );
  }

  return WorldTransferReport(
    world: applyToWorld(world, byId.values.toList()),
    news: news,
  );
}

class _Star {
  const _Star(this.player, this.clubId);

  final Player player;
  final String clubId;
}

class WorldEndReport {
  const WorldEndReport({
    required this.world,
    required this.retired,
    required this.notes,
  });

  final List<WorldLeague> world;
  final List<Player> retired;
  final List<String> notes;
}

/// Fin de saison des championnats du monde : promotions et relégations
/// dans votre pays, vieillissement des joueurs, nouvelles saisons.
/// [oldUserClubs] sont les adversaires de votre ancien championnat, qui
/// deviennent un championnat simulé si vous changez de division.
WorldEndReport endWorldSeason({
  required List<WorldLeague> world,
  required List<Club> oldUserClubs,
  required int userDivision,
  required int newDivision,
  required String homeCountry,
  required int seed,
  required int newNumber,
}) {
  final members = {
    for (final l in world) l.id: [...l.season.clubs],
  };
  final meta = {for (final l in world) l.id: l};
  final notes = <String>[];

  // Promotions et relégations entre championnats simulés de votre pays.
  for (var d = 1; d < lowestDivision; d++) {
    final upperId = worldLeagueId(homeCountry, d);
    final lowerId = worldLeagueId(homeCountry, d + 1);
    final upper = meta[upperId];
    final lower = meta[lowerId];
    if (upper == null || lower == null) continue;
    final upRank = upper.season.standings.map((s) => s.clubId).toList();
    final lowRank = lower.season.standings.map((s) => s.clubId).toList();
    if (upRank.length < 4 || lowRank.length < 4) continue;
    final down = upRank.sublist(upRank.length - 2).toSet();
    final up = lowRank.take(2).toSet();

    final upperClubs = members[upperId]!;
    final lowerClubs = members[lowerId]!;
    Club shift(Club c, int delta) {
      return c.copyWith(prestige: (c.prestige + delta).clamp(5, 95).toInt());
    }

    members[upperId] = [
      for (final c in upperClubs)
        if (!down.contains(c.id)) c,
      for (final c in lowerClubs)
        if (up.contains(c.id)) shift(c, 6),
    ];
    members[lowerId] = [
      for (final c in lowerClubs)
        if (!up.contains(c.id)) c,
      for (final c in upperClubs)
        if (down.contains(c.id)) shift(c, -6),
    ];
  }

  // Vieillissement : progression, retraites, contrats.
  final retired = <Player>[];
  final developed = <String, List<Club>>{};
  for (final league in world) {
    developed[league.id] = [
      for (final c in members[league.id]!)
        () {
          final dev = developClub(
            club: c,
            seed: seed,
            seasonNumber: newNumber,
            homeNation: league.country,
            isUser: false,
            division: league.division,
            light: true,
            needsOverride: compositionFor(league.division),
          );
          if (league.division == 1) retired.addAll(dev.retired);
          return dev.club;
        }(),
    ];
  }

  var leagues = [
    for (final l in world)
      l.copyWith(
        season: Season.create(
          clubs: developed[l.id]!,
          seed: seed + newNumber * 31 + l.division * 17,
        ),
      ),
  ];

  // Si vous changez de division, votre ancien championnat devient un
  // championnat simulé et celui de votre nouvelle division disparaît.
  if (newDivision != userDivision) {
    leagues = [
      for (final l in leagues)
        if (!(l.country == homeCountry && l.division == newDivision)) l,
    ];
    final random = Random(seed + newNumber * 53);
    final converted = [
      for (final c in oldUserClubs) trimToLight(c, userDivision),
    ];
    if (converted.length < 20) {
      converted.add(
        generateLightClub(
          id: 'w$newNumber-x$userDivision',
          name: randomClubName(random),
          division: userDivision,
          nation: homeCountry,
          seed: random.nextInt(1 << 30),
        ),
      );
    }
    leagues = [
      ...leagues,
      WorldLeague(
        id: worldLeagueId(homeCountry, userDivision),
        country: homeCountry,
        division: userDivision,
        season: Season.create(clubs: converted, seed: seed + newNumber * 29),
      ),
    ];
    notes.add(
      'Votre ancien championnat (${divisionName(userDivision)}) '
      'continue sans vous.',
    );
  }

  return WorldEndReport(world: leagues, retired: retired, notes: notes);
}
