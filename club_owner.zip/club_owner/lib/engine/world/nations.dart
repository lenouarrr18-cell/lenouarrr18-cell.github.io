enum Continent { africa, europe, southAmerica, northAmerica, asia }

/// Une sélection nationale (valeurs de jeu, pas des classements officiels).
class NationInfo {
  const NationInfo(this.name, this.continent, this.rating);

  final String name;
  final Continent continent;
  final int rating;
}

const List<NationInfo> nations = [
  NationInfo("Côte d'Ivoire", Continent.africa, 74),
  NationInfo('Sénégal', Continent.africa, 77),
  NationInfo('Maroc', Continent.africa, 79),
  NationInfo('Cameroun', Continent.africa, 73),
  NationInfo('Nigeria', Continent.africa, 75),
  NationInfo('Ghana', Continent.africa, 71),
  NationInfo('Égypte', Continent.africa, 72),
  NationInfo('Algérie', Continent.africa, 73),
  NationInfo('Tunisie', Continent.africa, 70),
  NationInfo('Mali', Continent.africa, 69),
  NationInfo('Burkina Faso', Continent.africa, 66),
  NationInfo('RD Congo', Continent.africa, 67),
  NationInfo('Afrique du Sud', Continent.africa, 64),
  NationInfo('Guinée', Continent.africa, 64),
  NationInfo('Gabon', Continent.africa, 62),
  NationInfo('Cap-Vert', Continent.africa, 63),
  NationInfo('Angola', Continent.africa, 60),
  NationInfo('Zambie', Continent.africa, 60),
  NationInfo('Bénin', Continent.africa, 58),
  NationInfo('Togo', Continent.africa, 57),
  NationInfo('France', Continent.europe, 86),
  NationInfo('Angleterre', Continent.europe, 85),
  NationInfo('Espagne', Continent.europe, 87),
  NationInfo('Allemagne', Continent.europe, 84),
  NationInfo('Portugal', Continent.europe, 83),
  NationInfo('Italie', Continent.europe, 82),
  NationInfo('Pays-Bas', Continent.europe, 82),
  NationInfo('Belgique', Continent.europe, 80),
  NationInfo('Croatie', Continent.europe, 79),
  NationInfo('Danemark', Continent.europe, 76),
  NationInfo('Suisse', Continent.europe, 75),
  NationInfo('Pologne', Continent.europe, 73),
  NationInfo('Serbie', Continent.europe, 74),
  NationInfo('Turquie', Continent.europe, 74),
  NationInfo('Écosse', Continent.europe, 70),
  NationInfo('Suède', Continent.europe, 72),
  NationInfo('Brésil', Continent.southAmerica, 88),
  NationInfo('Argentine', Continent.southAmerica, 89),
  NationInfo('Uruguay', Continent.southAmerica, 80),
  NationInfo('Colombie', Continent.southAmerica, 79),
  NationInfo('Équateur', Continent.southAmerica, 72),
  NationInfo('Chili', Continent.southAmerica, 72),
  NationInfo('Paraguay', Continent.southAmerica, 68),
  NationInfo('Pérou', Continent.southAmerica, 66),
  NationInfo('États-Unis', Continent.northAmerica, 74),
  NationInfo('Mexique', Continent.northAmerica, 76),
  NationInfo('Canada', Continent.northAmerica, 70),
  NationInfo('Costa Rica', Continent.northAmerica, 66),
  NationInfo('Panama', Continent.northAmerica, 62),
  NationInfo('Jamaïque', Continent.northAmerica, 63),
  NationInfo('Honduras', Continent.northAmerica, 60),
  NationInfo('Cuba', Continent.northAmerica, 55),
  NationInfo('Japon', Continent.asia, 77),
  NationInfo('Corée du Sud', Continent.asia, 76),
  NationInfo('Iran', Continent.asia, 72),
  NationInfo('Australie', Continent.asia, 71),
  NationInfo('Arabie saoudite', Continent.asia, 66),
  NationInfo('Qatar', Continent.asia, 65),
  NationInfo('Ouzbékistan', Continent.asia, 62),
  NationInfo('Irak', Continent.asia, 63),
  NationInfo('Jordanie', Continent.asia, 60),
  NationInfo('Chine', Continent.asia, 58),
  NationInfo('Émirats arabes unis', Continent.asia, 60),
  NationInfo('Bahreïn', Continent.asia, 57),
  NationInfo('Oman', Continent.asia, 57),
  NationInfo('Thaïlande', Continent.asia, 55),
  NationInfo('Inde', Continent.asia, 54),
  NationInfo('Vietnam', Continent.asia, 54),
];

NationInfo? nationByName(String name) {
  for (final nation in nations) {
    if (nation.name == name) return nation;
  }
  return null;
}

String continentLabel(Continent continent) {
  switch (continent) {
    case Continent.africa:
      return 'Afrique';
    case Continent.europe:
      return 'Europe';
    case Continent.southAmerica:
      return 'Amérique du Sud';
    case Continent.northAmerica:
      return 'Amérique du Nord et centrale';
    case Continent.asia:
      return 'Asie et Océanie';
  }
}

/// Noms des nations d'un continent (liste vide = monde entier).
List<String> nationNamesOf(Continent? continent) {
  if (continent == null) return const [];
  return [
    for (final n in nations)
      if (n.continent == continent) n.name,
  ];
}

const Map<String, String> _isoCodes = {
  "Côte d'Ivoire": 'CI',
  'Sénégal': 'SN',
  'Maroc': 'MA',
  'Cameroun': 'CM',
  'Nigeria': 'NG',
  'Ghana': 'GH',
  'Égypte': 'EG',
  'Algérie': 'DZ',
  'Tunisie': 'TN',
  'Mali': 'ML',
  'Burkina Faso': 'BF',
  'RD Congo': 'CD',
  'Afrique du Sud': 'ZA',
  'Guinée': 'GN',
  'Gabon': 'GA',
  'Cap-Vert': 'CV',
  'Angola': 'AO',
  'Zambie': 'ZM',
  'Bénin': 'BJ',
  'Togo': 'TG',
  'France': 'FR',
  'Angleterre': 'GB',
  'Espagne': 'ES',
  'Allemagne': 'DE',
  'Portugal': 'PT',
  'Italie': 'IT',
  'Pays-Bas': 'NL',
  'Belgique': 'BE',
  'Croatie': 'HR',
  'Danemark': 'DK',
  'Suisse': 'CH',
  'Pologne': 'PL',
  'Serbie': 'RS',
  'Turquie': 'TR',
  'Écosse': 'GB',
  'Suède': 'SE',
  'Brésil': 'BR',
  'Argentine': 'AR',
  'Uruguay': 'UY',
  'Colombie': 'CO',
  'Équateur': 'EC',
  'Chili': 'CL',
  'Paraguay': 'PY',
  'Pérou': 'PE',
  'États-Unis': 'US',
  'Mexique': 'MX',
  'Canada': 'CA',
  'Costa Rica': 'CR',
  'Panama': 'PA',
  'Jamaïque': 'JM',
  'Honduras': 'HN',
  'Cuba': 'CU',
  'Japon': 'JP',
  'Corée du Sud': 'KR',
  'Iran': 'IR',
  'Australie': 'AU',
  'Arabie saoudite': 'SA',
  'Qatar': 'QA',
  'Ouzbékistan': 'UZ',
  'Irak': 'IQ',
  'Jordanie': 'JO',
  'Chine': 'CN',
  'Émirats arabes unis': 'AE',
  'Bahreïn': 'BH',
  'Oman': 'OM',
  'Thaïlande': 'TH',
  'Inde': 'IN',
  'Vietnam': 'VN',
};

/// Drapeau (emoji) d'une nation, ou un drapeau blanc si elle est inconnue.
String flagOf(String nation) {
  final code = _isoCodes[nation];
  if (code == null) return '\u{1F3F3}';
  return String.fromCharCodes([
    for (final unit in code.codeUnits) 0x1F1E6 + unit - 65,
  ]);
}
