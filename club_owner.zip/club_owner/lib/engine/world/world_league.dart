import '../season/season.dart';

/// Un championnat simulé en arrière-plan (clubs « légers » : seulement
/// l'équipe première, sans réserve ni formation).
class WorldLeague {
  const WorldLeague({
    required this.id,
    required this.country,
    required this.division,
    required this.season,
  });

  final String id;
  final String country;
  final int division;
  final Season season;

  WorldLeague copyWith({Season? season, int? division}) {
    return WorldLeague(
      id: id,
      country: country,
      division: division ?? this.division,
      season: season ?? this.season,
    );
  }
}
