import 'dart:math';

import '../../domain/entities/club.dart';
import '../../domain/entities/division.dart';
import '../../domain/entities/lineup.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/tactic.dart';
import '../../domain/entities/team_strength.dart';
import '../season/season.dart';
import '../squad/squad_factory.dart';
import 'nations.dart';
import 'profile.dart';
import 'world_league.dart';

/// Nombre de nations avec un championnat de première division simulé.
const int worldD1Count = 60;

/// Nations avec une deuxième puis une troisième division simulées.
const int worldD2Count = 20;
const int worldD3Count = 8;

const List<String> _prefixes = [
  'FC',
  'AS',
  'US',
  'Racing',
  'Union',
  'Sporting',
  'Athletic',
  'Olympique',
  'Real',
  'Stade',
  'Dynamo',
  'Étoile',
];

const List<String> _words = [
  'Aurore',
  'Bastion',
  'Cèdre',
  'Dauphin',
  'Éclair',
  'Falaise',
  'Granit',
  'Horizon',
  'Îlot',
  'Jaguar',
  'Kilimandjaro',
  'Lagune',
  'Marée',
  'Nordique',
  'Orchidée',
  'Phénix',
  'Quartz',
  'Rivière',
  'Savane',
  'Tempête',
  'Union',
  'Volcan',
  'Zénith',
  'Ardent',
  'Boréal',
  'Corail',
  'Dorado',
  'Émeraude',
  'Forge',
  'Glacier',
  'Havre',
  'Ivoire',
  'Jade',
  'Lotus',
  'Mistral',
  'Nacre',
  'Opale',
  'Piton',
  'Rubis',
  'Sirocco',
];

/// Effectif cible selon la division : plus de joueurs dans les divisions
/// supérieures.
Map<PlayerPosition, int> compositionFor(int division) {
  if (division <= 1) {
    return const {
      PlayerPosition.goalkeeper: 3,
      PlayerPosition.defender: 7,
      PlayerPosition.midfielder: 7,
      PlayerPosition.forward: 5,
    };
  }
  if (division == 2) {
    return const {
      PlayerPosition.goalkeeper: 2,
      PlayerPosition.defender: 6,
      PlayerPosition.midfielder: 7,
      PlayerPosition.forward: 5,
    };
  }
  return const {
    PlayerPosition.goalkeeper: 2,
    PlayerPosition.defender: 6,
    PlayerPosition.midfielder: 6,
    PlayerPosition.forward: 4,
  };
}

int squadSizeFor(int division) =>
    compositionFor(division).values.fold(0, (a, b) => a + b);

/// Seuil sous lequel un club « léger » garde son effectif lors d'un
/// transfert (il ne se sépare pas d'un joueur de plus).
const int lightMinSquad = 18;

/// Un club simulé en arrière-plan.
Club generateLightClub({
  required String id,
  required String name,
  required int division,
  required String nation,
  required int seed,
  double levelBonus = 0,
}) {
  final random = Random(seed);
  final profileRandom = Random(seed + 13);
  final used = <String>{};
  final level = divisionBase(division) - 8 + random.nextDouble() * 16 + levelBonus;

  final squad = <Player>[];
  var index = 0;
  compositionFor(division).forEach((position, count) {
    for (var i = 0; i < count; i++) {
      final skill = (level + random.nextDouble() * 12 - 6)
          .round()
          .clamp(25, 90)
          .toInt();
      final base = Player(
        id: '$id-p$index',
        name: randomPlayerName(random, used),
        position: position,
        skill: skill,
        age: 17 + random.nextInt(18),
      );
      squad.add(withProfile(base, profileRandom, nation, used: used));
      index++;
    }
  });

  final formation = Formation.values[random.nextInt(Formation.values.length)];
  final starterIds = pickBestStarters(squad, formation);
  final prestige = (20 + (lowestDivision - division) * 14 + random.nextInt(25))
      .clamp(5, 95)
      .toInt();

  return Club(
    id: id,
    name: name,
    strength: TeamStrength.fromPlayers(
      squad.where((p) => starterIds.contains(p.id)),
    ),
    squad: squad,
    starterIds: starterIds,
    tactic: Tactic(formation: formation),
    prestige: prestige,
  );
}

String _countryCode(String country) {
  final index = nations.indexWhere((n) => n.name == country);
  if (index >= 0) return '$index';
  var sum = 0;
  for (final unit in country.codeUnits) {
    sum = (sum * 31 + unit) % 9973;
  }
  return 'x$sum';
}

/// Identifiant stable d'un championnat simulé.
String worldLeagueId(String country, int division) {
  return 'w-${_countryCode(country)}-d$division';
}

/// Un nom de club tiré au hasard (pour compléter un championnat).
String randomClubName(Random random) {
  return '${_prefixes[random.nextInt(_prefixes.length)]} '
      '${_words[random.nextInt(_words.length)]}';
}

List<String> _clubNames(Random random, int count) {
  final used = <String>{};
  final names = <String>[];
  var guard = 0;
  while (names.length < count && guard < 2000) {
    guard++;
    final name =
        '${_prefixes[random.nextInt(_prefixes.length)]} '
        '${_words[random.nextInt(_words.length)]}';
    if (used.add(name)) names.add(name);
  }
  var n = 2;
  while (names.length < count) {
    names.add('${_words[random.nextInt(_words.length)]} $n');
    n++;
  }
  return names;
}

/// Un championnat complet de [size] clubs légers.
WorldLeague generateLightLeague({
  required String country,
  required int division,
  required int seed,
  required int generation,
  int size = 20,
}) {
  final random = Random(seed);
  final rating = nationByName(country)?.rating ?? 75;
  final bonus = (rating - 75) * 0.3;
  final id = worldLeagueId(country, division);
  final names = _clubNames(random, size);
  final clubs = [
    for (var i = 0; i < size; i++)
      generateLightClub(
        id: 'w$generation-${_countryCode(country)}-d$division-c$i',
        name: names[i],
        division: division,
        nation: country,
        seed: random.nextInt(1 << 30),
        levelBonus: division == 1 ? bonus : 0,
      ),
  ];
  return WorldLeague(
    id: id,
    country: country,
    division: division,
    season: Season.create(clubs: clubs, seed: seed),
  );
}

/// Un championnat prévu dans le monde simulé.
class LeaguePlan {
  const LeaguePlan(this.country, this.division);

  final String country;
  final int division;
}

/// Liste des championnats simulés : toutes les divisions de votre pays
/// (sauf la vôtre) et les divisions des nations les plus fortes.
List<LeaguePlan> worldPlan({
  required String homeCountry,
  required int userDivision,
}) {
  final plans = <LeaguePlan>[
    for (var d = 1; d <= lowestDivision; d++)
      if (d != userDivision) LeaguePlan(homeCountry, d),
  ];
  final ranked = [...nations]
    ..sort((a, b) {
      final byRating = b.rating.compareTo(a.rating);
      return byRating != 0 ? byRating : a.name.compareTo(b.name);
    });
  final foreign = [
    for (final n in ranked)
      if (n.name != homeCountry) n.name,
  ];
  for (var i = 0; i < foreign.length; i++) {
    if (i < worldD1Count) plans.add(LeaguePlan(foreign[i], 1));
    if (i < worldD2Count) plans.add(LeaguePlan(foreign[i], 2));
    if (i < worldD3Count) plans.add(LeaguePlan(foreign[i], 3));
  }
  return plans;
}

List<WorldLeague> generateWorld({
  required String homeCountry,
  required int userDivision,
  required int seed,
  required int generation,
}) {
  final plans = worldPlan(homeCountry: homeCountry, userDivision: userDivision);
  return [
    for (var i = 0; i < plans.length; i++)
      generateLightLeague(
        country: plans[i].country,
        division: plans[i].division,
        seed: seed + 101 * (i + 1),
        generation: generation,
      ),
  ];
}

/// Réduit un club complet à un effectif « léger » de la taille de sa
/// division (pour un championnat simulé en arrière-plan).
Club trimToLight(Club club, int division) {
  final composition = compositionFor(division);
  final kept = <Player>[];
  final rest = <Player>[];
  for (final position in PlayerPosition.values) {
    final ofPosition = club.squad.where((p) => p.position == position).toList()
      ..sort((a, b) => b.skill.compareTo(a.skill));
    final count = composition[position] ?? 0;
    kept.addAll(ofPosition.take(count));
    rest.addAll(ofPosition.skip(count));
  }
  rest.sort((a, b) => b.skill.compareTo(a.skill));
  final target = squadSizeFor(division);
  if (kept.length < target) kept.addAll(rest.take(target - kept.length));
  final starterIds = pickBestStarters(kept, club.tactic.formation);
  return Club(
    id: club.id,
    name: club.name,
    strength: TeamStrength.fromPlayers(
      kept.where((p) => starterIds.contains(p.id)),
    ),
    squad: kept,
    starterIds: starterIds,
    tactic: club.tactic,
    prestige: club.prestige,
  );
}
