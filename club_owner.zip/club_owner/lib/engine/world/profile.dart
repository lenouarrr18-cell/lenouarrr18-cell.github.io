import 'dart:math';

import '../../domain/entities/player.dart';
import '../squad/squad_factory.dart';
import 'nations.dart';

int _potentialFor(Player player, Random random) {
  final age = player.age;
  final int bonus;
  if (age <= 18) {
    bonus = 10 + random.nextInt(30);
  } else if (age <= 21) {
    bonus = 6 + random.nextInt(22);
  } else if (age <= 24) {
    bonus = 3 + random.nextInt(12);
  } else if (age <= 27) {
    bonus = random.nextInt(5);
  } else {
    bonus = 0;
  }
  final cap = player.skill > 95 ? player.skill : 95;
  return (player.skill + bonus).clamp(player.skill, cap).toInt();
}

/// Nationalité d'un joueur : le plus souvent celle du pays du club.
String pickNation(Random random, String homeNation) {
  if (homeNation.isNotEmpty && random.nextDouble() < 0.72) return homeNation;
  return nations[random.nextInt(nations.length)].name;
}

/// Ajoute potentiel, nationalité et contrat à un joueur généré. Le nom est
/// tiré dans la culture de sa nationalité (unique parmi [used]).
Player withProfile(
  Player player,
  Random random,
  String homeNation, {
  Set<String>? used,
  String? nation,
}) {
  final n = nation ?? pickNation(random, homeNation);
  final names = used ?? <String>{};
  names.remove(player.name);
  return player.copyWith(
    name: randomPlayerNameFor(n, random, names),
    potential: _potentialFor(player, random),
    nation: n,
    contractYears: 1 + random.nextInt(4),
  );
}
