import '../../domain/entities/club.dart';
import '../../domain/entities/owner.dart';
import '../fans/fans.dart';
import '../owner/infrastructure.dart';

const List<String> _stadiumPatterns = [
  'Stade %',
  '% Arena',
  'Parc %',
  'Stade du %',
  '% Park',
  'Stade Olympique %',
];

/// Installations d'un club adverse, déduites de son prestige : plus un
/// club est prestigieux (division supérieure, titres), plus son stade,
/// sa fan zone, son parking et sa boutique sont développés.
class ClubFacilities {
  const ClubFacilities({
    required this.stadium,
    required this.fanZone,
    required this.parking,
    required this.shop,
    required this.stadiumName,
    required this.capacity,
    required this.supporters,
  });

  final int stadium;
  final int fanZone;
  final int parking;
  final int shop;
  final String stadiumName;
  final int capacity;
  final int supporters;

  /// État équivalent pour dessiner le stade avec la même vue que le vôtre.
  OwnerState toOwnerState() {
    return OwnerState(
      stadium: stadium,
      fanZone: fanZone,
      parking: parking,
      shop: shop,
      stadiumName: stadiumName,
    );
  }
}

int _stable(String text) {
  var h = 7;
  for (final unit in text.codeUnits) {
    h = (h * 31 + unit) & 0x3fffffff;
  }
  return h;
}

/// Nom de stade propre à chaque club (stable).
String stadiumNameFor(String clubName) {
  final words = clubName.split(' ').where((w) => w.isNotEmpty).toList();
  final word = words.isEmpty ? clubName : words.last;
  final pattern = _stadiumPatterns[_stable(clubName) % _stadiumPatterns.length];
  return pattern.replaceFirst('%', word);
}

ClubFacilities facilitiesOf(Club club, {int populationThousands = 1500}) {
  final level = (1 + club.prestige ~/ 22).clamp(1, 5).toInt();
  return ClubFacilities(
    stadium: level,
    fanZone: (level - 1).clamp(0, 5).toInt(),
    parking: (level - 1).clamp(0, 5).toInt(),
    shop: (level - 1).clamp(0, 5).toInt(),
    stadiumName: stadiumNameFor(club.name),
    capacity: stadiumCapacity(level),
    supporters: supportersCount(
      populationThousands: populationThousands,
      prestige: club.prestige,
    ),
  );
}
