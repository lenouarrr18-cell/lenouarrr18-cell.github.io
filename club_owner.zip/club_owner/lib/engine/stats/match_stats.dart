import 'dart:math';

import '../../domain/entities/club.dart';
import '../../domain/entities/player.dart';
import '../calendar/fixture_generator.dart';
import '../match/match_models.dart';

class _Inc {
  int matches = 0;
  int goals = 0;
  int assists = 0;
  int cleanSheets = 0;
}

double _scoreWeight(Player p) {
  final double base;
  switch (p.position) {
    case PlayerPosition.forward:
      base = 6.0;
      break;
    case PlayerPosition.midfielder:
      base = 2.5;
      break;
    case PlayerPosition.defender:
      base = 0.8;
      break;
    case PlayerPosition.goalkeeper:
      base = 0.02;
      break;
  }
  return base * (p.skill / 60);
}

double _assistWeight(Player p) {
  final double base;
  switch (p.position) {
    case PlayerPosition.forward:
      base = 3.0;
      break;
    case PlayerPosition.midfielder:
      base = 4.0;
      break;
    case PlayerPosition.defender:
      base = 1.5;
      break;
    case PlayerPosition.goalkeeper:
      base = 0.05;
      break;
  }
  return base * (p.skill / 60);
}

Player? _pick(
  List<Player> players,
  Random random,
  double Function(Player) weight,
) {
  if (players.isEmpty) return null;
  var total = 0.0;
  for (final p in players) {
    total += weight(p);
  }
  var roll = random.nextDouble() * total;
  for (final p in players) {
    roll -= weight(p);
    if (roll <= 0) return p;
  }
  return players.last;
}

/// Attribue matchs, buts, passes décisives et clean sheets aux joueurs
/// pour les rencontres d'une journée. Reproductible avec la graine.
List<Club> applyRoundStats({
  required List<Club> clubs,
  required List<Fixture> fixtures,
  required Map<String, MatchResult> results,
  required int seed,
  required int round,
  void Function(Fixture fixture, bool home, Player scorer, Player? assister)?
      onGoal,
}) {
  final byId = {for (final c in clubs) c.id: c};
  final inc = <String, _Inc>{};

  _Inc of(String id) => inc.putIfAbsent(id, () => _Inc());

  var index = 0;
  for (final fixture in fixtures) {
    final result = results[fixture.key];
    final random = Random(seed * 7919 + round * 131 + index);
    index++;
    if (result == null) continue;

    for (final home in [true, false]) {
      final club = byId[home ? fixture.homeId : fixture.awayId];
      if (club == null) continue;
      final scored = home ? result.homeGoals : result.awayGoals;
      final conceded = home ? result.awayGoals : result.homeGoals;
      final starters = club.starters;

      for (final p in starters) {
        of(p.id).matches += 1;
        if (conceded == 0 && p.position == PlayerPosition.goalkeeper) {
          of(p.id).cleanSheets += 1;
        }
      }

      final detail = result.detail;
      if (detail != null) {
        // Match simulé sur le terrain : les buteurs sont connus.
        Player? find(String id) {
          for (final p in club.squad) {
            if (p.id == id) return p;
          }
          return null;
        }

        for (final credit in detail.goals) {
          if (credit.home != home) continue;
          final scorer = find(credit.scorerId);
          if (scorer == null) continue;
          of(scorer.id).goals += 1;
          final assistId = credit.assistId;
          Player? assister;
          if (assistId != null) {
            assister = find(assistId);
            if (assister != null) of(assister.id).assists += 1;
          }
          if (onGoal != null) onGoal(fixture, home, scorer, assister);
        }
        continue;
      }

      for (var g = 0; g < scored; g++) {
        final scorer = _pick(starters, random, _scoreWeight);
        if (scorer == null) continue;
        of(scorer.id).goals += 1;
        Player? assister;
        if (random.nextDouble() < 0.7) {
          final others = starters.where((p) => p.id != scorer.id).toList();
          assister = _pick(others, random, _assistWeight);
          if (assister != null) of(assister.id).assists += 1;
        }
        if (onGoal != null) onGoal(fixture, home, scorer, assister);
      }
    }
  }

  if (inc.isEmpty) return clubs;

  Player apply(Player p) {
    final i = inc[p.id];
    if (i == null) return p;
    return p.copyWith(
      matches: p.matches + i.matches,
      goals: p.goals + i.goals,
      assists: p.assists + i.assists,
      cleanSheets: p.cleanSheets + i.cleanSheets,
    );
  }

  return [
    for (final club in clubs)
      club.squad.any((p) => inc.containsKey(p.id))
          ? club.copyWith(squad: [for (final p in club.squad) apply(p)])
          : club,
  ];
}
