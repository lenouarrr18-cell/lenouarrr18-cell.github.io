import '../../domain/entities/club.dart';
import '../../domain/entities/honours.dart';
import '../../domain/entities/player.dart';

class SeasonAwards {
  const SeasonAwards({required this.clubs, required this.records});

  final List<Club> clubs;
  final List<AwardRecord> records;
}

class _Entry {
  const _Entry(this.player, this.club);

  final Player player;
  final Club club;
}

double playerScore(Player p) {
  return p.goals * 3.0 +
      p.assists * 2.0 +
      p.matches * 0.2 +
      (p.skill - 60) * 0.5 +
      p.cleanSheets * 0.5;
}

/// Fiche d'une distinction : critère et conditions d'éligibilité.
class AwardInfo {
  const AwardInfo(this.name, this.criterion, this.eligibility, {this.elite = true});

  final String name;
  final String criterion;
  final String eligibility;

  /// Réservée aux joueurs de première division engagés en compétition
  /// continentale ou internationaux.
  final bool elite;
}

const String eliteRule =
    'Première division, et club engagé en compétition continentale ou '
    'joueur appelé en sélection.';

const List<AwardInfo> awardCatalog = [
  AwardInfo(
    "Ballon d'or",
    'Le meilleur joueur du monde : statistiques, parcours continental du '
        'club, titre de champion, tournoi avec sa sélection.',
    eliteRule,
  ),
  AwardInfo(
    'Golden Boy',
    'Le meilleur espoir de 21 ans ou moins : performances et potentiel.',
    '21 ans ou moins. $eliteRule',
  ),
  AwardInfo(
    'Trophée Kopa',
    'Le meilleur joueur de 21 ans ou moins sur la saison.',
    '21 ans ou moins. $eliteRule',
  ),
  AwardInfo(
    'Trophée Yachine',
    'Le meilleur gardien : matchs sans but encaissé et parcours du club.',
    'Gardien. $eliteRule',
  ),
  AwardInfo(
    "Soulier d'or",
    'Le meilleur buteur de toutes les premières divisions.',
    'Première division.',
    elite: false,
  ),
  AwardInfo(
    'Meilleur passeur',
    'Le plus de passes décisives en première division.',
    'Première division.',
    elite: false,
  ),
];

/// Distinctions de la saison, calculées avant que les statistiques
/// ne soient remises à zéro. Les vainqueurs reçoivent +1 distinction.
///
/// [clubs] ne contient que des clubs de première division. Comme dans la
/// réalité, les grandes distinctions individuelles (Ballon d'or, Golden
/// Boy, Kopa, Yachine) ne concernent que les joueurs qui disputent, en
/// plus du championnat, une compétition continentale avec leur club
/// ([clubBonus], par identifiant de club) ou un tournoi avec leur
/// sélection ([bonus], par identifiant de joueur). [champions] donne les
/// clubs champions de leur pays.
SeasonAwards computeSeasonAwards({
  required List<Club> clubs,
  required int season,
  Map<String, double> bonus = const {},
  Map<String, double> clubBonus = const {},
  Set<String> champions = const {},
}) {
  final entries = <_Entry>[
    for (final club in clubs)
      for (final p in club.squad) _Entry(p, club),
  ];
  var elite = [
    for (final e in entries)
      if (clubBonus.containsKey(e.club.id) || bonus.containsKey(e.player.id)) e,
  ];
  // Aucune compétition cette saison (monde réduit) : tout le monde concourt.
  if (elite.isEmpty) elite = entries;

  final records = <AwardRecord>[];
  final winners = <String>[];

  double prestige(_Entry e) =>
      (bonus[e.player.id] ?? 0) +
      (clubBonus[e.club.id] ?? 0) * 2.2 +
      (champions.contains(e.club.id) ? 8 : 0);

  double scoreOf(_Entry e) => playerScore(e.player) + prestige(e);

  List<_Entry> ranked(List<_Entry> list, double Function(_Entry) score) {
    final out = [...list]..sort((a, b) => score(b).compareTo(score(a)));
    return out;
  }

  void add(String category, List<_Entry> order, String Function(_Entry) detail,
      {bool podium = false}) {
    if (order.isEmpty) return;
    final entry = order.first;
    var text = detail(entry);
    if (podium && order.length >= 3) {
      text = '$text · 2e ${order[1].player.name} (${order[1].club.name}), '
          '3e ${order[2].player.name} (${order[2].club.name})';
    }
    records.add(
      AwardRecord(
        season: season,
        category: category,
        playerName: entry.player.name,
        clubName: entry.club.name,
        detail: text,
      ),
    );
    winners.add(entry.player.id);
  }

  String path(_Entry e) {
    final parts = <String>[];
    if (champions.contains(e.club.id)) parts.add('champion');
    if (clubBonus.containsKey(e.club.id)) parts.add('coupe continentale');
    if (bonus.containsKey(e.player.id)) parts.add('sélection');
    return parts.isEmpty ? '' : ' · ${parts.join(', ')}';
  }

  add(
    "Ballon d'or",
    ranked(elite, scoreOf),
    (e) => '${e.player.goals} buts, ${e.player.assists} passes${path(e)}',
    podium: true,
  );

  final young = elite.where((e) => e.player.age <= 21).toList();
  add(
    'Golden Boy',
    ranked(
      young,
      (e) => scoreOf(e) + (e.player.maxSkill - 60) * 0.6,
    ),
    (e) => '${e.player.age} ans, ${e.player.goals} buts, '
        'potentiel ${e.player.maxSkill}',
  );

  add(
    'Trophée Kopa',
    ranked(young, scoreOf),
    (e) => '${e.player.age} ans, ${e.player.goals} buts, '
        '${e.player.assists} passes',
  );

  add(
    'Trophée Yachine',
    ranked(
      elite.where((e) => e.player.position == PlayerPosition.goalkeeper).toList(),
      (e) => e.player.cleanSheets * 2.0 + e.player.skill * 0.3 + prestige(e) * 0.5,
    ),
    (e) => '${e.player.cleanSheets} matchs sans but${path(e)}',
  );

  add(
    "Soulier d'or",
    ranked(entries, (e) => e.player.goals * 100.0 + e.player.assists),
    (e) => '${e.player.goals} buts',
  );

  add(
    'Meilleur passeur',
    ranked(entries, (e) => e.player.assists * 100.0 + e.player.goals),
    (e) => '${e.player.assists} passes décisives',
  );

  if (winners.isEmpty) return SeasonAwards(clubs: clubs, records: records);

  final winnerSet = winners.toSet();
  final counted = <String, int>{};
  for (final id in winners) {
    counted[id] = (counted[id] ?? 0) + 1;
  }
  Player credit(Player p) {
    final n = counted[p.id];
    return n == null ? p : p.copyWith(awards: p.awards + n);
  }

  final updated = [
    for (final club in clubs)
      club.squad.any((p) => winnerSet.contains(p.id))
          ? club.copyWith(squad: [for (final p in club.squad) credit(p)])
          : club,
  ];
  return SeasonAwards(clubs: updated, records: records);
}

/// Trace d'un joueur retraité pour le débat du GOAT.
LegendEntry? legendFrom(Player p, int season) {
  final matches = p.careerMatches;
  if (matches < 40 && p.awards == 0 && p.caps == 0) return null;
  return LegendEntry(
    name: p.name,
    nation: p.nation,
    matches: matches,
    goals: p.careerGoals,
    assists: p.careerAssists,
    caps: p.caps,
    awards: p.awards,
    peakSkill: p.maxSkill > p.skill ? p.skill : p.skill,
    retiredSeason: season,
  );
}

/// Classement des plus grands joueurs (retraités et en activité).
List<LegendEntry> goatRanking(List<LegendEntry> retired, List<Club> clubs) {
  final all = <LegendEntry>[...retired];
  for (final club in clubs) {
    for (final p in club.allPlayers) {
      if (p.totalMatches < 10 && p.awards == 0 && p.caps == 0) continue;
      all.add(
        LegendEntry(
          name: '${p.name} (en activité)',
          nation: p.nation,
          matches: p.totalMatches,
          goals: p.totalGoals,
          assists: p.totalAssists,
          caps: p.caps,
          awards: p.awards,
          peakSkill: p.skill,
          retiredSeason: 0,
        ),
      );
    }
  }
  all.sort((a, b) => b.goatScore.compareTo(a.goatScore));
  return all.take(30).toList();
}
