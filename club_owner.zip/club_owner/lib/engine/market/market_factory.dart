import 'dart:math';

import '../../domain/entities/division.dart';
import '../../domain/entities/player.dart';
import '../squad/squad_factory.dart';
import '../world/profile.dart';

const List<PlayerPosition> _marketPositions = [
  PlayerPosition.goalkeeper,
  PlayerPosition.defender,
  PlayerPosition.defender,
  PlayerPosition.defender,
  PlayerPosition.midfielder,
  PlayerPosition.midfielder,
  PlayerPosition.midfielder,
  PlayerPosition.forward,
  PlayerPosition.forward,
];

/// Joueurs disponibles au mercato, adaptés au niveau de la division.
List<Player> generateMarket({
  required int division,
  required int seed,
  required int seasonNumber,
  int size = 30,
  double scoutBonus = 0.0,
  String homeNation = '',
}) {
  final random = Random(seed + seasonNumber * 104729);
  final profileRandom = Random(seed + seasonNumber * 7 + 3);
  final base = divisionBase(division);
  final usedNames = <String>{};

  return [
    for (var i = 0; i < size; i++)
      withProfile(
        Player(
          id: 'm$seasonNumber-$i',
          name: randomPlayerName(random, usedNames),
          position: _marketPositions[i % _marketPositions.length],
          skill: (base - 6 + random.nextDouble() * 18 + scoutBonus)
              .round()
              .clamp(25, 90)
              .toInt(),
          age: 18 + random.nextInt(17),
        ),
        profileRandom,
        homeNation,
        used: usedNames,
      ),
  ];
}

/// Joueurs ramenés par une prospection : meilleurs quand le recruteur
/// est bon. La moitié sont des jeunes pépites. [nationPool] limite les
/// nationalités à une région du monde (vide = monde entier).
List<Player> generateProspects({
  required int division,
  required int seed,
  required int seasonNumber,
  required double scoutBonus,
  required List<Player> existing,
  int count = 4,
  List<String> nationPool = const [],
  String homeNation = '',
}) {
  final random = Random(seed);
  final base = divisionBase(division);
  final usedNames = existing.map((p) => p.name).toSet();
  final usedIds = existing.map((p) => p.id).toSet();
  final prospects = <Player>[];
  var counter = 0;

  String nation() {
    if (nationPool.isEmpty) return pickNation(random, homeNation);
    return nationPool[random.nextInt(nationPool.length)];
  }

  for (var i = 0; i < count; i++) {
    final youth = i < count ~/ 2;
    final prefix = youth ? 'sy' : 'sc';
    while (usedIds.contains('$prefix$seasonNumber-$counter')) {
      counter++;
    }
    final id = '$prefix$seasonNumber-$counter';
    usedIds.add(id);

    if (youth) {
      final skill = (28 + scoutBonus * 2 + random.nextDouble() * 12)
          .round()
          .clamp(20, 75)
          .toInt();
      final potential = (skill + 15 + random.nextInt(30) + scoutBonus * 2)
          .round()
          .clamp(skill, 95)
          .toInt();
      final youngNation = nation();
      prospects.add(
        Player(
          id: id,
          name: randomPlayerNameFor(youngNation, random, usedNames),
          position: _marketPositions[random.nextInt(_marketPositions.length)],
          skill: skill,
          age: 16 + random.nextInt(4),
          potential: potential,
          nation: youngNation,
          contractYears: 3,
        ),
      );
    } else {
      final adult = Player(
        id: id,
        name: randomPlayerName(random, usedNames),
        position: _marketPositions[random.nextInt(_marketPositions.length)],
        skill: (base - 2 + random.nextDouble() * 14 + scoutBonus)
            .round()
            .clamp(25, 90)
            .toInt(),
        age: 20 + random.nextInt(12),
      );
      prospects.add(
        withProfile(adult, random, homeNation,
            used: usedNames, nation: nation()),
      );
    }
  }
  return prospects;
}
