import 'dart:math';

import '../../domain/entities/division.dart';
import '../../domain/entities/owner.dart';

const List<String> _brands = [
  'Banque Baobab',
  'Télécom Savane',
  'Brasserie Lagune',
  'Assurances Horizon',
  'Énergie Soleil',
  'Mobile Kora',
  'Transports Rapide',
  'Cacao Prestige',
  'Construction Équateur',
  'Eaux de Source Ébène',
];

int _round1000(double value) => (value / 1000).round() * 1000;

/// Trois offres de sponsor principal, reproductibles pour la saison :
/// une sûre, une équilibrée et une ambitieuse avec prime.
List<SponsorDeal> generateSponsorOffers({
  required int division,
  required int seed,
  required int seasonNumber,
  required int reputation,
}) {
  final random = Random(seed + seasonNumber * 32452843);
  final scale = divisionRevenueFactor(division) * (0.8 + reputation / 200);
  final base = 120000 * scale;
  final names = List<String>.of(_brands)..shuffle(random);

  double jitter() => 0.9 + random.nextDouble() * 0.2;

  return [
    SponsorDeal(
      id: 'sp$seasonNumber-0',
      name: names[0],
      perSeason: _round1000(base * 0.8 * jitter()),
      seasonsLeft: 3,
      bonus: 0,
      targetRank: 0,
    ),
    SponsorDeal(
      id: 'sp$seasonNumber-1',
      name: names[1],
      perSeason: _round1000(base * 1.0 * jitter()),
      seasonsLeft: 2,
      bonus: _round1000(base * 0.4),
      targetRank: 8,
    ),
    SponsorDeal(
      id: 'sp$seasonNumber-2',
      name: names[2],
      perSeason: _round1000(base * 1.3 * jitter()),
      seasonsLeft: 1,
      bonus: _round1000(base * 0.8),
      targetRank: 3,
    ),
  ];
}
