import 'dart:math';

import '../../domain/entities/owner.dart';

/// Génère éventuellement une question de la presse après un match.
PressQuestion? makePressQuestion({
  required int seed,
  required int season,
  required int round,
  required String clubName,
  required String opponent,
  required int goalsFor,
  required int goalsAgainst,
  required int rank,
}) {
  final random = Random(seed * 41 + season * 811 + round * 97);
  final diff = goalsFor - goalsAgainst;
  final decisive = diff.abs() >= 3 || (goalsFor == 0 && goalsAgainst == 0);
  final chance = decisive ? 0.75 : 0.4;
  if (random.nextDouble() >= chance) return null;

  final score = '$goalsFor-$goalsAgainst';
  final context = '$clubName $score $opponent, ${rank}e au classement';

  if (diff > 0) {
    final questions = [
      'Belle victoire contre $opponent ($score) ! Visez-vous désormais '
          'le titre ?',
      'Qu\'est-ce qui a fait la différence aujourd\'hui, président ?',
      'Vos joueurs étaient en grande forme : une récompense pour le '
          'staff ?',
    ];
    return PressQuestion(
      question: questions[random.nextInt(questions.length)],
      context: context,
      season: season,
      round: round,
      options: [
        PressOption(
          label: 'Rester humble et saluer l\'adversaire',
          fanMood: 1,
          reputation: 0,
          teamMood: 1,
          headline: '$clubName : le président garde la tête froide',
        ),
        PressOption(
          label: 'Afficher de grandes ambitions',
          fanMood: 3,
          reputation: 1,
          teamMood: 0,
          headline: '« Nous visons plus haut » : le président de $clubName '
              'fixe le cap',
        ),
        PressOption(
          label: 'Rappeler que rien n\'est joué',
          fanMood: 0,
          reputation: 0,
          teamMood: 2,
          headline: '$clubName : « Rien n\'est gagné », prévient son '
              'président',
        ),
      ],
    );
  }

  if (diff == 0) {
    final questions = [
      'Un match nul contre $opponent ($score) : une occasion manquée ?',
      'Le public attendait mieux. Que lui répondez-vous ?',
    ];
    return PressQuestion(
      question: questions[random.nextInt(questions.length)],
      context: context,
      season: season,
      round: round,
      options: [
        PressOption(
          label: 'Positiver : un point qui peut compter',
          fanMood: 0,
          reputation: 0,
          teamMood: 1,
          headline: '$clubName garde le sourire malgré le nul',
        ),
        PressOption(
          label: 'Exiger plus d\'envie',
          fanMood: 2,
          reputation: 0,
          teamMood: -2,
          headline: 'Le président de $clubName réclame plus d\'envie',
        ),
        PressOption(
          label: 'Défendre le groupe',
          fanMood: -1,
          reputation: 0,
          teamMood: 3,
          headline: '$clubName : le président défend son groupe',
        ),
      ],
    );
  }

  final questions = [
    'Défaite contre $opponent ($score) : le coach est-il en danger ?',
    'Les supporters sont déçus. Que leur dites-vous ?',
    'Faut-il s\'inquiéter pour la suite de la saison ?',
  ];
  return PressQuestion(
    question: questions[random.nextInt(questions.length)],
    context: context,
    season: season,
    round: round,
    options: [
      PressOption(
        label: 'Assumer et défendre le groupe',
        fanMood: -1,
        reputation: 0,
        teamMood: 3,
        headline: 'Après la défaite, le président de $clubName fait bloc',
      ),
      PressOption(
        label: 'Promettre une réaction immédiate',
        fanMood: 2,
        reputation: 0,
        teamMood: 0,
        headline: '$clubName : « Il y aura une réaction », promet le président',
      ),
      PressOption(
        label: 'Critiquer publiquement les joueurs',
        fanMood: 1,
        reputation: -1,
        teamMood: -5,
        headline: 'Coup de gueule du président de $clubName contre ses '
            'joueurs',
      ),
    ],
  );
}

/// Titre de presse pour un résultat marquant, ou `null`.
NewsItem? matchHeadline({
  required String clubName,
  required String opponent,
  required int goalsFor,
  required int goalsAgainst,
  required int season,
  required int round,
}) {
  final diff = goalsFor - goalsAgainst;
  if (diff >= 3) {
    return NewsItem(
      headline: 'Festival : $clubName écrase $opponent ($goalsFor-$goalsAgainst)',
      body: 'Une démonstration de $clubName devant son public.',
      season: season,
      round: round,
      kind: NewsKind.match,
    );
  }
  if (diff <= -3) {
    return NewsItem(
      headline: 'Naufrage de $clubName contre $opponent '
          '($goalsFor-$goalsAgainst)',
      body: 'Une soirée à oublier pour $clubName.',
      season: season,
      round: round,
      kind: NewsKind.match,
    );
  }
  if (goalsFor + goalsAgainst >= 7) {
    return NewsItem(
      headline: 'Match fou : $clubName et $opponent se quittent sur '
          '$goalsFor-$goalsAgainst',
      body: 'Un festival de buts pour les spectateurs.',
      season: season,
      round: round,
      kind: NewsKind.match,
    );
  }
  return null;
}
