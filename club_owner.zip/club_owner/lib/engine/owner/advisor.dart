import '../../domain/entities/lineup.dart';
import '../../domain/entities/player.dart';
import '../game/game_state.dart';
import '../staff/staff_factory.dart';
import '../finance/finance.dart';

/// Niveaux d'urgence, du moins au plus grave.
enum AdviceLevel { info, recommendation, warning, urgent, critical }

String adviceLevelLabel(AdviceLevel level) {
  switch (level) {
    case AdviceLevel.info:
      return 'Information';
    case AdviceLevel.recommendation:
      return 'Recommandation';
    case AdviceLevel.warning:
      return 'Attention';
    case AdviceLevel.urgent:
      return 'Urgent';
    case AdviceLevel.critical:
      return 'Critique';
  }
}

/// Recommandation du conseiller, calculée sur les vraies données du club.
class Advice {
  const Advice({
    required this.id,
    required this.level,
    required this.situation,
    required this.explanation,
    required this.consequence,
    required this.solution,
    this.route,
    this.actionLabel = '',
  });

  final String id;
  final AdviceLevel level;
  final String situation;
  final String explanation;
  final String consequence;
  final String solution;

  /// Page à ouvrir pour agir ('/finance', '/squad'... ).
  final String? route;
  final String actionLabel;
}

/// Analyse le club et renvoie les recommandations, les plus graves d'abord.
List<Advice> adviseClub(GameState game) {
  final out = <Advice>[];
  final owner = game.owner;
  final club = game.userClub;
  final treasury = game.finance.treasury;
  final rounds = game.season.totalRounds;
  final wagesPerRound =
      (squadAnnualWages(club.squad) + staffAnnualWages(game.staff)) ~/ rounds;

  if (treasury < 0) {
    out.add(const Advice(
      id: 'cash_negative',
      level: AdviceLevel.critical,
      situation: 'Trésorerie négative',
      explanation: 'Le club dépense plus qu\'il ne gagne.',
      consequence: 'Les achats sont bloqués et le conseil perd confiance.',
      solution: 'Vendre un joueur, emprunter à la banque ou réduire les dépenses.',
      route: '/business',
      actionLabel: 'Ouvrir la banque',
    ));
  } else if (wagesPerRound > 0 && treasury < wagesPerRound * 4) {
    out.add(const Advice(
      id: 'cash_low',
      level: AdviceLevel.urgent,
      situation: 'Trésorerie fragile',
      explanation: 'Moins de quatre journées de salaires en caisse.',
      consequence: 'Une mauvaise série ou une blessure peut vous mettre dans le rouge.',
      solution: 'Évitez les gros investissements et cherchez un sponsor.',
      route: '/finance',
      actionLabel: 'Voir les finances',
    ));
  }

  if (owner.debt > 0 && treasury > owner.debt) {
    out.add(const Advice(
      id: 'debt_repay',
      level: AdviceLevel.recommendation,
      situation: 'Dette remboursable',
      explanation: 'Votre trésorerie couvre la dette du club.',
      consequence: 'Les intérêts continuent de coûter chaque journée.',
      solution: 'Rembourser la banque.',
      route: '/business',
      actionLabel: 'Ouvrir la banque',
    ));
  }

  if (owner.deal == null) {
    out.add(const Advice(
      id: 'no_sponsor',
      level: AdviceLevel.recommendation,
      situation: 'Aucun sponsor principal',
      explanation: 'Le club se prive d\'un revenu régulier.',
      consequence: 'Moins de budget pour le recrutement et les travaux.',
      solution: 'Choisir une offre de sponsor.',
      route: '/business',
      actionLabel: 'Voir les offres',
    ));
  }

  for (final position in PlayerPosition.values) {
    final minimum = minSquadByPosition[position] ?? 0;
    final have = club.squad.where((p) => p.position == position).length;
    if (have < minimum) {
      out.add(Advice(
        id: 'thin_${position.name}',
        level: AdviceLevel.urgent,
        situation: 'Effectif trop court au poste ${position.name}',
        explanation: '$have joueur(s) pour $minimum nécessaires.',
        consequence: 'Compositions faibles et risque de forfait tactique.',
        solution: 'Recruter un joueur à ce poste.',
        route: '/transfers',
        actionLabel: 'Aller aux transferts',
      ));
    }
  }

  final expiring = club.starters.where((p) => p.contractYears <= 1).toList();
  if (expiring.isNotEmpty) {
    out.add(Advice(
      id: 'contracts_${expiring.length}',
      level: AdviceLevel.warning,
      situation: '${expiring.length} titulaire(s) en fin de contrat',
      explanation: expiring.take(3).map((p) => p.name).join(', '),
      consequence: 'Ils partiront libres et affaibliront l\'équipe.',
      solution: 'Prolonger leurs contrats ou préparer des remplaçants.',
      route: '/squad',
      actionLabel: "Ouvrir l'effectif",
    ));
  }

  final hurt = club.starters.where((p) => p.form < 0.9).toList();
  if (hurt.isNotEmpty) {
    out.add(Advice(
      id: 'injuries',
      level: AdviceLevel.warning,
      situation: '${hurt.length} titulaire(s) diminué(s)',
      explanation: hurt.take(3).map((p) => p.name).join(', '),
      consequence: 'Équipe moins performante tant qu\'ils ne sont pas rétablis.',
      solution: owner.medical < 2
          ? 'Construire ou améliorer le centre médical.'
          : 'Faire tourner l\'effectif.',
      route: '/infrastructure',
      actionLabel: 'Voir les installations',
    ));
  }

  if (game.owner.fanMood < 40) {
    out.add(const Advice(
      id: 'fans_angry',
      level: AdviceLevel.urgent,
      situation: 'Supporters mécontents',
      explanation: 'L\'humeur des tribunes est basse.',
      consequence: 'Billetterie en baisse et pression sur le conseil.',
      solution: 'Répondre à la presse, améliorer la fan zone, gagner des matchs.',
      route: '/social',
      actionLabel: 'Parler aux supporters',
    ));
  }

  if (owner.confidence < 40) {
    out.add(Advice(
      id: 'board_${owner.confidence < 20 ? 'critical' : 'low'}',
      level: owner.confidence < 20 ? AdviceLevel.critical : AdviceLevel.urgent,
      situation: 'Confiance du conseil faible (${owner.confidence}/100)',
      explanation: 'Les résultats ou les finances déçoivent.',
      consequence: 'Risque de limogeage à la fin de la saison.',
      solution: 'Redresser les résultats et assainir les comptes.',
      route: '/office',
      actionLabel: 'Bureau du président',
    ));
  }

  if (owner.decisions.isNotEmpty) {
    out.add(Advice(
      id: 'decisions_${owner.decisions.length}',
      level: AdviceLevel.info,
      situation: '${owner.decisions.length} décision(s) de la direction',
      explanation: 'Votre direction attend éventuellement votre veto.',
      consequence: 'Sans réponse, elles seront exécutées.',
      solution: 'Valider ou bloquer depuis le bureau.',
      route: '/office',
      actionLabel: 'Bureau du président',
    ));
  }

  if (owner.press != null) {
    out.add(const Advice(
      id: 'press_waiting',
      level: AdviceLevel.info,
      situation: 'Une question de la presse vous attend',
      explanation: 'Votre réponse influence les supporters et le vestiaire.',
      consequence: 'Sans réponse, la question disparaîtra.',
      solution: 'Répondre en conférence de presse.',
      route: '/press',
      actionLabel: 'Répondre',
    ));
  }

  if (owner.work == null && treasury > 400000 && owner.academy < 3) {
    out.add(const Advice(
      id: 'invest_academy',
      level: AdviceLevel.recommendation,
      situation: 'Argent disponible, formation limitée',
      explanation: 'La trésorerie permet un investissement durable.',
      consequence: 'Sans académie, les jeunes talents seront moins nombreux.',
      solution: 'Améliorer le centre de formation.',
      route: '/infrastructure',
      actionLabel: 'Voir les installations',
    ));
  }

  if (game.userClub.squad.length < 14) {
    out.add(const Advice(
      id: 'squad_size',
      level: AdviceLevel.warning,
      situation: 'Effectif réduit',
      explanation: 'Moins de 14 joueurs dans l\'équipe première.',
      consequence: 'Fatigue et blessures peuvent vider le banc.',
      solution: 'Recruter ou promouvoir des jeunes.',
      route: '/transfers',
      actionLabel: 'Aller aux transferts',
    ));
  }

  out.sort((a, b) => b.level.index.compareTo(a.level.index));
  return out;
}
