import 'dart:math';

import '../../core/utils/format.dart';
import '../../domain/entities/division.dart';
import '../../domain/entities/player.dart';

/// Un événement qui frappe le club pendant une journée.
class OwnerEvent {
  const OwnerEvent({
    required this.title,
    required this.body,
    this.income = 0,
    this.expense = 0,
    this.reputationDelta = 0,
    this.confidenceDelta = 0,
    this.injuredPlayerId,
  });

  final String title;
  final String body;
  final int income;
  final int expense;
  final int reputationDelta;
  final int confidenceDelta;
  final String? injuredPlayerId;
}

/// Forme d'un joueur blessé.
const double injuredForm = 0.85;

int _scaledAmount(Random random, int base, int spread, double factor) {
  return (((base + random.nextInt(spread)) * factor) / 1000).round() * 1000;
}

/// Tire éventuellement un événement (environ une journée sur huit).
OwnerEvent? rollOwnerEvent({
  required int seed,
  required int seasonNumber,
  required int round,
  required int division,
  required List<Player> starters,
  int medicalLevel = 0,
}) {
  final random = Random(seed * 31 + seasonNumber * 977 + round * 7919);
  if (random.nextDouble() >= 0.12) return null;

  final factor = divisionRevenueFactor(division);
  switch (random.nextInt(5)) {
    case 0:
      final donation = _scaledAmount(random, 10000, 30000, factor);
      return OwnerEvent(
        title: 'Don d\'un supporter',
        body: 'Un supporter fortuné offre ${formatMoney(donation)} au club.',
        income: donation,
      );
    case 1:
      final cost = _scaledAmount(random, 8000, 22000, factor);
      return OwnerEvent(
        title: 'Dégâts au stade',
        body: 'Une tempête abîme les tribunes. Réparations : '
            '${formatMoney(cost)}.',
        expense: cost,
      );
    case 2:
      if (starters.isEmpty) return null;
      final player = starters[random.nextInt(starters.length)];
      if (random.nextDouble() < medicalLevel * 0.12) {
        return OwnerEvent(
          title: 'Blessure évitée',
          body: 'Grâce à votre centre médical, ${player.name} a été '
              'soigné à temps et reste disponible.',
        );
      }
      return OwnerEvent(
        title: 'Blessure',
        body: '${player.name} se blesse à l\'entraînement. Il sera '
            'diminué quelques journées.',
        injuredPlayerId: player.id,
      );
    case 3:
      final flash = _scaledAmount(random, 15000, 35000, factor);
      return OwnerEvent(
        title: 'Offre éclair',
        body: 'Une entreprise locale verse ${formatMoney(flash)} pour '
            'afficher son logo pendant un mois.',
        income: flash,
      );
    default:
      return const OwnerEvent(
        title: 'Le club fait le buzz',
        body: 'Votre club est partout sur les réseaux sociaux. '
            'Votre réputation grimpe.',
        reputationDelta: 3,
      );
  }
}
