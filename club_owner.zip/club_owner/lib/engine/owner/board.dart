import '../../domain/entities/division.dart';

/// Conséquences d'une saison sur le conseil et la réputation.
class SeasonVerdict {
  const SeasonVerdict({
    required this.confidence,
    required this.reputation,
    required this.objectiveReached,
  });

  final int confidence;
  final int reputation;
  final bool objectiveReached;
}

int _clampPercent(int value) => value.clamp(0, 100).toInt();

SeasonVerdict evaluateSeason({
  required int rank,
  required int objective,
  required SeasonOutcome outcome,
  required int confidence,
  required int reputation,
}) {
  final reached = rank <= objective;
  var confidenceDelta = reached ? 10 : -15;
  var reputationDelta = rank <= 3 ? 5 : (rank <= 10 ? 2 : -2);

  if (outcome == SeasonOutcome.promoted) {
    confidenceDelta += 10;
    reputationDelta += 6;
  } else if (outcome == SeasonOutcome.relegated) {
    confidenceDelta -= 15;
    reputationDelta -= 6;
  }

  return SeasonVerdict(
    confidence: _clampPercent(confidence + confidenceDelta),
    reputation: _clampPercent(reputation + reputationDelta),
    objectiveReached: reached,
  );
}

String confidenceLabel(int confidence) {
  if (confidence >= 75) return 'Le conseil vous fait confiance';
  if (confidence >= 40) return 'Le conseil reste prudent';
  if (confidence >= 20) return 'Le conseil est inquiet';
  return 'Le conseil est à bout de patience';
}

/// Rapport multicritères de fin de saison : finances, infrastructures,
/// supporters et climat interne s'ajoutent au verdict sportif.
class BoardReport {
  const BoardReport({required this.delta, required this.lines});

  final int delta;
  final List<String> lines;
}

BoardReport boardReport({
  required int treasury,
  required int debt,
  required int fanMood,
  required int infraLevels,
  required int tension,
  required int vetoCount,
}) {
  var delta = 0;
  final lines = <String>[];

  if (treasury < 0) {
    delta -= 8;
    lines.add('Finances : trésorerie négative, le conseil est furieux.');
  } else if (debt > treasury * 2 && debt > 0) {
    delta -= 4;
    lines.add("Finances : l'endettement inquiète les investisseurs.");
  } else if (treasury > 0) {
    delta += 3;
    lines.add('Finances : comptes sains, les investisseurs sont rassurés.');
  }

  if (fanMood >= 70) {
    delta += 4;
    lines.add('Supporters : très attachés à leur président.');
  } else if (fanMood < 35) {
    delta -= 5;
    lines.add('Supporters : protestations et banderoles dans les tribunes.');
  }

  if (infraLevels >= 9) {
    delta += 3;
    lines.add('Infrastructures : le complexe se modernise.');
  } else if (infraLevels <= 4) {
    delta -= 2;
    lines.add('Infrastructures : trop peu investi dans le club.');
  }

  if (tension >= 60 || vetoCount >= 6) {
    delta -= 3;
    lines.add('Personnel : vos interventions répétées crispent la direction.');
  }

  return BoardReport(delta: delta, lines: lines);
}
