import '../../domain/entities/division.dart';
import '../../domain/entities/owner.dart';

const int maxInfraLevel = 5;

/// Familles de bâtiments du complexe.
enum InfraCategory { sport, stadium, commercial, admin }

String infraCategoryLabel(InfraCategory c) {
  switch (c) {
    case InfraCategory.sport:
      return 'Sportif';
    case InfraCategory.stadium:
      return 'Stade';
    case InfraCategory.commercial:
      return 'Commercial';
    case InfraCategory.admin:
      return 'Administratif';
  }
}

/// Condition de déblocage : un autre bâtiment doit avoir ce niveau.
class InfraReq {
  const InfraReq(this.kind, this.level);

  final InfraKind kind;
  final int level;
}

/// Fiche complète d'un bâtiment (coûts, durée, personnel, déblocage).
class InfraSpec {
  const InfraSpec({
    required this.label,
    required this.category,
    required this.costs,
    required this.rounds,
    required this.maintenance,
    required this.staffPerLevel,
    required this.names,
    this.requires = const [],
    this.minReputation = 0,
    this.cap,
    this.capOffset = 0,
  });

  final String label;
  final InfraCategory category;

  /// Coût pour atteindre le niveau i (index 0 inutilisé).
  final List<int> costs;

  /// Journées de travaux pour atteindre le niveau i.
  final List<int> rounds;

  /// Entretien annuel par niveau.
  final int maintenance;

  /// Employés nécessaires par niveau.
  final int staffPerLevel;

  /// Nom du bâtiment à chaque niveau (index 0 = non construit).
  final List<String> names;

  /// Bâtiments à posséder avant la première construction.
  final List<InfraReq> requires;

  /// Réputation minimale pour la première construction.
  final int minReputation;

  /// Le niveau ne peut dépasser celui de ce bâtiment (+ [capOffset]).
  final InfraKind? cap;
  final int capOffset;
}

List<int> _ladder(int base) => [
      0,
      base,
      base * 5 ~/ 2,
      base * 11 ~/ 2,
      base * 11,
      base * 22,
    ];

List<int> _time(int first) => [0, first, first + 2, first + 5, first + 9, first + 13];

/// Le catalogue de tous les bâtiments du club.
final Map<InfraKind, InfraSpec> infraCatalog = {
  // ---------- Sportif ----------
  InfraKind.training: const InfraSpec(
    label: "Terrains d'entraînement",
    category: InfraCategory.sport,
    costs: [0, 0, 80000, 200000, 450000, 1000000],
    rounds: [0, 0, 4, 8, 12, 16],
    maintenance: 5000,
    staffPerLevel: 3,
    names: [
      '',
      "Terrain d'entraînement",
      'Centre régional',
      'Centre moderne',
      "Centre d'élite",
      'Complexe de pointe',
    ],
  ),
  InfraKind.academy: const InfraSpec(
    label: 'Centre de formation',
    category: InfraCategory.sport,
    costs: [0, 0, 70000, 180000, 400000, 900000],
    rounds: [0, 0, 4, 8, 12, 16],
    maintenance: 4000,
    staffPerLevel: 3,
    names: [
      '',
      'École de foot',
      'Centre de formation',
      'Centre agréé',
      "Pôle d'excellence",
      'Académie de renom',
    ],
  ),
  InfraKind.youth: InfraSpec(
    label: 'Académie des jeunes',
    category: InfraCategory.sport,
    costs: _ladder(60000),
    rounds: _time(3),
    maintenance: 4000,
    staffPerLevel: 3,
    requires: const [InfraReq(InfraKind.academy, 2)],
    cap: InfraKind.academy,
    capOffset: 1,
    names: const [
      'Non construite',
      'Équipe U15',
      'Académie U17',
      'Académie U19',
      'Académie élite',
      'Académie internationale',
    ],
  ),
  InfraKind.medical: const InfraSpec(
    label: 'Centre médical',
    category: InfraCategory.sport,
    costs: [0, 60000, 150000, 320000, 650000, 1200000],
    rounds: [0, 4, 6, 9, 12, 16],
    maintenance: 4000,
    staffPerLevel: 3,
    names: [
      'Non construit',
      'Salle de soins',
      'Cabinet médical',
      'Centre médical',
      'Clinique du sport',
      'Pôle médical de pointe',
    ],
  ),
  InfraKind.rehab: InfraSpec(
    label: 'Centre de rééducation',
    category: InfraCategory.sport,
    costs: _ladder(70000),
    rounds: _time(3),
    maintenance: 3500,
    staffPerLevel: 2,
    requires: const [InfraReq(InfraKind.medical, 2)],
    cap: InfraKind.medical,
    capOffset: 1,
    names: const [
      'Non construit',
      'Salle de kiné',
      'Bassin de rééducation',
      'Centre de rééducation',
      'Clinique de récupération',
      'Institut de pointe',
    ],
  ),
  InfraKind.fitness: InfraSpec(
    label: 'Préparation physique',
    category: InfraCategory.sport,
    costs: _ladder(60000),
    rounds: _time(3),
    maintenance: 3000,
    staffPerLevel: 2,
    requires: const [InfraReq(InfraKind.training, 2)],
    cap: InfraKind.training,
    capOffset: 1,
    names: const [
      'Non construit',
      'Salle de musculation',
      'Salle de préparation',
      'Centre de performance',
      'Laboratoire sportif',
      'Institut de performance',
    ],
  ),
  InfraKind.recruitment: const InfraSpec(
    label: 'Recrutement et scouting',
    category: InfraCategory.sport,
    costs: [0, 50000, 130000, 300000, 600000, 1100000],
    rounds: [0, 4, 6, 9, 12, 16],
    maintenance: 3500,
    staffPerLevel: 2,
    names: [
      'Non construit',
      'Bureau de recrutement',
      'Cellule de détection',
      'Centre de scouting',
      'Réseau de recruteurs',
      'Réseau mondial',
    ],
  ),
  InfraKind.analysis: InfraSpec(
    label: "Centre d'analyse vidéo",
    category: InfraCategory.sport,
    costs: _ladder(50000),
    rounds: _time(3),
    maintenance: 3000,
    staffPerLevel: 2,
    requires: const [InfraReq(InfraKind.recruitment, 1)],
    cap: InfraKind.recruitment,
    capOffset: 1,
    names: const [
      'Non construit',
      'Salle vidéo',
      "Cellule d'analyse",
      "Centre d'analyse",
      'Pôle données',
      'Centre de données avancé',
    ],
  ),
  InfraKind.complex: InfraSpec(
    label: 'Complexe sportif',
    category: InfraCategory.sport,
    costs: _ladder(150000),
    rounds: _time(5),
    maintenance: 5000,
    staffPerLevel: 4,
    requires: const [
      InfraReq(InfraKind.training, 3),
      InfraReq(InfraKind.stadium, 2),
    ],
    minReputation: 15,
    names: const [
      'Non construit',
      'Terrains annexes',
      'Complexe local',
      'Complexe régional',
      'Grand complexe',
      'Campus sportif',
    ],
  ),

  // ---------- Stade ----------
  InfraKind.stadium: const InfraSpec(
    label: 'Stade (tribunes)',
    category: InfraCategory.stadium,
    costs: [0, 0, 120000, 300000, 700000, 1500000],
    rounds: [0, 0, 6, 10, 14, 18],
    maintenance: 6000,
    staffPerLevel: 4,
    names: [
      '',
      'Petit stade local',
      'Stade régional',
      'Stade professionnel',
      'Grand stade moderne',
      'Stade de prestige international',
    ],
  ),
  InfraKind.pitch: InfraSpec(
    label: 'Pelouse',
    category: InfraCategory.stadium,
    costs: _ladder(40000),
    rounds: _time(2),
    maintenance: 2500,
    staffPerLevel: 1,
    cap: InfraKind.stadium,
    capOffset: 1,
    names: const [
      'Pelouse basique',
      'Pelouse entretenue',
      'Drainage amélioré',
      'Pelouse hybride',
      'Pelouse premium',
      'Pelouse de prestige',
    ],
  ),
  InfraKind.lighting: InfraSpec(
    label: 'Éclairage',
    category: InfraCategory.stadium,
    costs: _ladder(50000),
    rounds: _time(2),
    maintenance: 2000,
    staffPerLevel: 1,
    requires: const [InfraReq(InfraKind.stadium, 2)],
    cap: InfraKind.stadium,
    capOffset: 1,
    names: const [
      'Aucun éclairage',
      'Projecteurs',
      "Mâts d'éclairage",
      'Éclairage LED',
      'LED dynamique',
      'Éclairage spectacle',
    ],
  ),
  InfraKind.screens: InfraSpec(
    label: 'Écrans et tableau',
    category: InfraCategory.stadium,
    costs: _ladder(60000),
    rounds: _time(2),
    maintenance: 2500,
    staffPerLevel: 1,
    requires: const [InfraReq(InfraKind.stadium, 3)],
    cap: InfraKind.stadium,
    capOffset: 1,
    names: const [
      'Aucun écran',
      "Tableau d'affichage",
      'Écran vidéo',
      'Écran géant',
      'Double écran géant',
      'Écrans circulaires',
    ],
  ),
  InfraKind.roof: InfraSpec(
    label: 'Toiture',
    category: InfraCategory.stadium,
    costs: _ladder(90000),
    rounds: _time(3),
    maintenance: 3000,
    staffPerLevel: 1,
    requires: const [InfraReq(InfraKind.stadium, 3)],
    cap: InfraKind.stadium,
    capOffset: 1,
    names: const [
      'Tribunes à ciel ouvert',
      'Auvent',
      'Toiture partielle',
      'Toiture complète',
      'Toit moderne',
      'Toit rétractable',
    ],
  ),

  // ---------- Commercial ----------
  InfraKind.shop: const InfraSpec(
    label: 'Boutique officielle',
    category: InfraCategory.commercial,
    costs: [0, 50000, 120000, 280000, 550000, 1100000],
    rounds: [0, 3, 6, 9, 12, 16],
    maintenance: 3000,
    staffPerLevel: 2,
    names: [
      'Non construite',
      'Kiosque',
      'Boutique du club',
      'Boutique officielle',
      'Mégastore',
      'Flagship store',
    ],
  ),
  InfraKind.restaurant: InfraSpec(
    label: 'Restaurant du club',
    category: InfraCategory.commercial,
    costs: _ladder(45000),
    rounds: _time(3),
    maintenance: 2500,
    staffPerLevel: 3,
    requires: const [InfraReq(InfraKind.stadium, 2)],
    names: const [
      'Non construit',
      'Snack',
      'Restaurant du club',
      'Brasserie',
      'Restaurant gastronomique',
      'Table de prestige',
    ],
  ),
  InfraKind.vip: const InfraSpec(
    label: 'Installations VIP',
    category: InfraCategory.commercial,
    costs: [0, 90000, 220000, 450000, 900000, 1800000],
    rounds: [0, 5, 8, 11, 14, 18],
    maintenance: 6000,
    staffPerLevel: 3,
    names: [
      'Non construites',
      'Loges de base',
      'Salon VIP',
      'Espace VIP',
      'Espace premium',
      'Club des partenaires',
    ],
  ),
  InfraKind.boxes: InfraSpec(
    label: 'Loges privées',
    category: InfraCategory.commercial,
    costs: _ladder(100000),
    rounds: _time(4),
    maintenance: 3000,
    staffPerLevel: 2,
    requires: const [
      InfraReq(InfraKind.vip, 2),
      InfraReq(InfraKind.stadium, 3),
    ],
    cap: InfraKind.vip,
    capOffset: 1,
    names: const [
      'Non construites',
      'Quelques loges',
      'Loges privées',
      'Loges premium',
      'Étage de loges',
      'Suites de prestige',
    ],
  ),
  InfraKind.ads: InfraSpec(
    label: 'Espaces publicitaires',
    category: InfraCategory.commercial,
    costs: _ladder(35000),
    rounds: _time(2),
    maintenance: 1500,
    staffPerLevel: 1,
    requires: const [InfraReq(InfraKind.stadium, 2)],
    names: const [
      'Aucun',
      'Panneaux fixes',
      'Bandeaux LED',
      'Ceinture LED',
      'Publicité interactive',
      'Régie premium',
    ],
  ),
  InfraKind.museum: InfraSpec(
    label: 'Musée du club',
    category: InfraCategory.commercial,
    costs: _ladder(80000),
    rounds: _time(4),
    maintenance: 2000,
    staffPerLevel: 2,
    requires: const [InfraReq(InfraKind.stadium, 3)],
    minReputation: 25,
    names: const [
      'Non construit',
      'Vitrine de trophées',
      'Petit musée',
      'Musée du club',
      'Musée interactif',
      'Musée de légende',
    ],
  ),
  InfraKind.mall: InfraSpec(
    label: 'Centre commercial',
    category: InfraCategory.commercial,
    costs: _ladder(200000),
    rounds: _time(6),
    maintenance: 4000,
    staffPerLevel: 3,
    requires: const [
      InfraReq(InfraKind.stadium, 4),
      InfraReq(InfraKind.parking, 2),
    ],
    minReputation: 40,
    names: const [
      'Non construit',
      'Galerie marchande',
      'Petit centre',
      'Centre commercial',
      'Grand centre',
      'Centre de destination',
    ],
  ),
  InfraKind.partners: InfraSpec(
    label: 'Espaces partenaires',
    category: InfraCategory.commercial,
    costs: _ladder(70000),
    rounds: _time(3),
    maintenance: 2500,
    staffPerLevel: 2,
    requires: const [InfraReq(InfraKind.vip, 3)],
    minReputation: 30,
    names: const [
      'Non construit',
      'Salon partenaires',
      'Espace partenaires',
      'Club des marques',
      'Pavillon des marques',
      'Village des marques',
    ],
  ),
  InfraKind.fanZone: const InfraSpec(
    label: 'Fan zone',
    category: InfraCategory.commercial,
    costs: [0, 40000, 100000, 250000, 500000, 1000000],
    rounds: [0, 3, 5, 8, 12, 16],
    maintenance: 3000,
    staffPerLevel: 2,
    names: [
      'Non construite',
      'Buvette',
      'Fan zone',
      'Fan village',
      'Grande fan zone',
      'Parc des supporters',
    ],
  ),
  InfraKind.parking: const InfraSpec(
    label: 'Parking',
    category: InfraCategory.commercial,
    costs: [0, 30000, 80000, 200000, 420000, 900000],
    rounds: [0, 3, 5, 8, 12, 16],
    maintenance: 2000,
    staffPerLevel: 1,
    names: [
      'Non construit',
      'Parking de terre',
      'Parking aménagé',
      'Parking sécurisé',
      'Grand parking',
      'Parking premium',
    ],
  ),

  // ---------- Administratif ----------
  InfraKind.hq: InfraSpec(
    label: 'Siège administratif',
    category: InfraCategory.admin,
    costs: _ladder(50000),
    rounds: _time(3),
    maintenance: 2500,
    staffPerLevel: 1,
    names: const [
      'Non construit',
      'Bureaux',
      'Siège administratif',
      'Siège moderne',
      'Siège de direction',
      'Tour du club',
    ],
  ),
  InfraKind.hrCenter: InfraSpec(
    label: 'Recrutement du personnel',
    category: InfraCategory.admin,
    costs: _ladder(45000),
    rounds: _time(3),
    maintenance: 2000,
    staffPerLevel: 1,
    requires: const [InfraReq(InfraKind.hq, 1)],
    cap: InfraKind.hq,
    capOffset: 2,
    names: const [
      'Non construit',
      'Service RH',
      'Pôle recrutement',
      'Centre RH',
      'Académie du personnel',
      'Direction des talents',
    ],
  ),
  InfraKind.operations: InfraSpec(
    label: 'Centre des opérations',
    category: InfraCategory.admin,
    costs: _ladder(70000),
    rounds: _time(4),
    maintenance: 2500,
    staffPerLevel: 2,
    requires: const [InfraReq(InfraKind.hq, 2)],
    cap: InfraKind.hq,
    capOffset: 1,
    names: const [
      'Non construit',
      'Salle de contrôle',
      'Centre des opérations',
      'Centre logistique',
      'Centre de pilotage',
      'Centre de commandement',
    ],
  ),
  InfraKind.conference: InfraSpec(
    label: 'Centre de conférences',
    category: InfraCategory.admin,
    costs: _ladder(60000),
    rounds: _time(3),
    maintenance: 2000,
    staffPerLevel: 1,
    requires: const [InfraReq(InfraKind.hq, 2)],
    minReputation: 20,
    cap: InfraKind.hq,
    capOffset: 1,
    names: const [
      'Non construit',
      'Salle de réunion',
      'Salle de presse',
      'Centre de conférences',
      'Auditorium',
      'Centre de congrès',
    ],
  ),
  InfraKind.commercial: InfraSpec(
    label: 'Bureaux commerciaux',
    category: InfraCategory.admin,
    costs: _ladder(50000),
    rounds: _time(3),
    maintenance: 2000,
    staffPerLevel: 2,
    requires: const [
      InfraReq(InfraKind.hq, 2),
      InfraReq(InfraKind.shop, 1),
    ],
    cap: InfraKind.hq,
    capOffset: 1,
    names: const [
      'Non construits',
      'Bureau commercial',
      'Pôle commercial',
      'Direction commerciale',
      'Agence intégrée',
      'Régie internationale',
    ],
  ),
};

/// Les bâtiments d'une famille, dans l'ordre d'affichage.
List<InfraKind> infraOfCategory(InfraCategory category) => [
      for (final e in infraCatalog.entries)
        if (e.value.category == category) e.key,
    ];

String infraLabel(InfraKind kind) => infraCatalog[kind]!.label;

/// Coût pour passer au niveau [toLevel].
int upgradeCost(InfraKind kind, int toLevel) => infraCatalog[kind]!.costs[toLevel];

/// Nombre de journées de travaux de base pour atteindre [toLevel].
int upgradeRounds(InfraKind kind, int toLevel) =>
    infraCatalog[kind]!.rounds[toLevel];

String infraLevelName(InfraKind kind, int level) =>
    infraCatalog[kind]!.names[level];

// ---------- Personnel, entretien, chantiers ----------

/// Employés nécessaires à un bâtiment de ce niveau.
int infraStaffOf(InfraKind kind, int level) =>
    infraCatalog[kind]!.staffPerLevel * level;

/// Nombre total d'employés du complexe.
int infraEmployees(OwnerState owner) {
  var total = 0;
  for (final kind in InfraKind.values) {
    total += infraStaffOf(kind, owner.levelOf(kind));
  }
  return total;
}

/// Effectif maximal que l'administration peut gérer.
int staffCapacity(OwnerState owner) =>
    60 + 20 * owner.levelOf(InfraKind.hq) + 30 * owner.levelOf(InfraKind.hrCenter);

/// Salaire annuel moyen d'un employé du complexe.
const int employeeWage = 800;

double _discount(OwnerState owner) {
  final d = 0.02 * owner.levelOf(InfraKind.hq) +
      0.02 * owner.levelOf(InfraKind.operations);
  return d > 0.25 ? 0.25 : d;
}

double _staffDiscount(OwnerState owner) {
  final d = 0.06 * owner.levelOf(InfraKind.hrCenter);
  return d > 0.3 ? 0.3 : d;
}

/// Entretien annuel du seul bâtiment [kind] à ce niveau.
int infraMaintenanceOf(InfraKind kind, int level) =>
    infraCatalog[kind]!.maintenance * level;

/// Masse salariale annuelle du personnel des bâtiments.
int infraStaffCost(OwnerState owner) {
  return (infraEmployees(owner) * employeeWage * (1 - _staffDiscount(owner)))
      .round();
}

/// Entretien annuel de toutes les infrastructures, personnel compris.
int infrastructureUpkeepPerSeason(OwnerState owner) {
  var maintenance = 0;
  for (final kind in InfraKind.values) {
    maintenance += infraMaintenanceOf(kind, owner.levelOf(kind));
  }
  return ((maintenance + infraStaffCost(owner)) * (1 - _discount(owner))).round();
}

/// Nombre de chantiers possibles en même temps.
int maxConcurrentWorks(OwnerState owner) {
  final ops = owner.levelOf(InfraKind.operations);
  return 1 + (ops >= 2 ? 1 : 0) + (ops >= 4 ? 1 : 0);
}

/// Durée réelle des travaux (le centre des opérations les accélère).
int effectiveRounds(OwnerState owner, InfraKind kind, int toLevel) {
  final base = upgradeRounds(kind, toLevel);
  final factor = 1 - 0.06 * owner.levelOf(InfraKind.operations);
  final value = (base * factor).round();
  return value < 1 ? 1 : value;
}

/// Raisons qui empêchent de construire le niveau suivant (liste vide = OK).
List<String> infraBlockers(OwnerState owner, InfraKind kind) {
  final spec = infraCatalog[kind]!;
  final level = owner.levelOf(kind);
  final out = <String>[];
  if (level >= maxInfraLevel) {
    out.add('Niveau maximum atteint.');
    return out;
  }
  final target = level + 1;
  if (level == 0) {
    for (final req in spec.requires) {
      if (owner.levelOf(req.kind) < req.level) {
        out.add('${infraLabel(req.kind)} niveau ${req.level} requis.');
      }
    }
    if (owner.reputation < spec.minReputation) {
      out.add('Réputation ${spec.minReputation} requise.');
    }
  }
  if (target == 4 && owner.reputation < 35) {
    out.add('Réputation 35 requise pour le niveau 4.');
  }
  if (target == 5 && owner.reputation < 55) {
    out.add('Réputation 55 requise pour le niveau 5.');
  }
  final cap = spec.cap;
  if (cap != null && target > owner.levelOf(cap) + spec.capOffset) {
    out.add(
      '${infraLabel(cap)} niveau '
      '${target - spec.capOffset} requis.',
    );
  }
  if (infraEmployees(owner) + spec.staffPerLevel > staffCapacity(owner)) {
    out.add(
      'Personnel insuffisant : développez le siège '
      'ou le recrutement du personnel.',
    );
  }
  if (owner.works.any((w) => w.kind == kind)) {
    out.add('Travaux déjà en cours sur ce bâtiment.');
  }
  return out;
}

// ---------- Effets chiffrés ----------

/// Chance, par joueur de moins de 30 ans, de gagner un niveau de plus.
double trainingChance(int level) => (level - 1) * 0.2;

/// Bonus d'entraînement venant du complexe sportif.
double complexTrainingBonus(OwnerState o) => 0.04 * o.levelOf(InfraKind.complex);

/// Nombre de jeunes issus du centre de formation chaque saison.
int youthCount(int level) => 2 + (level - 1) ~/ 2;

/// Niveau de départ supplémentaire des jeunes.
int youthBonus(int level) => (level - 1) * 3;

/// Bonus de niveau des jeunes dû à l'académie des jeunes.
int youthAcademyBonus(OwnerState o) => 2 * o.levelOf(InfraKind.youth);

/// Jeunes supplémentaires grâce à l'académie des jeunes.
int youthAcademyExtra(OwnerState o) => o.levelOf(InfraKind.youth) >= 3 ? 1 : 0;

/// Chance de progression supplémentaire des moins de 22 ans.
double youthGrowthChance(OwnerState o) => 0.08 * o.levelOf(InfraKind.youth);

/// Chance d'éviter une blessure à l'entraînement (centre médical).
double injuryAvoidChance(int level) => level * 0.12;

/// Niveau de protection médicale : centre médical, pelouse et rééducation.
int medicalProtection(OwnerState o) {
  final extra = (o.levelOf(InfraKind.pitch) + o.levelOf(InfraKind.rehab)) / 2;
  final value = o.medical + extra.round();
  return value > 6 ? 6 : value;
}

/// Récupération des blessés supplémentaire à chaque journée.
double rehabRecovery(OwnerState o) => 0.02 * o.levelOf(InfraKind.rehab);

/// Points de fraîcheur gagnés en plus par les joueurs au repos.
int fitnessRestBonus(OwnerState o) => 2 * o.levelOf(InfraKind.fitness);

/// Points de fraîcheur épargnés aux titulaires après un match.
int fitnessMatchSaving(OwnerState o) =>
    (0.8 * o.levelOf(InfraKind.fitness)).round();

/// Bonus de détection des talents (recrutement + analyse vidéo).
int recruitmentBonus(int level) => level * 2;

int analysisBonus(OwnerState o) => o.levelOf(InfraKind.analysis);

/// Recette par spectateur de la fan zone (€ par match à domicile).
double fanZonePerFan(int level) => 0.8 * level;

/// Recette par spectateur du parking.
double parkingPerFan(int level) => 0.25 * level;

/// Recette par spectateur du restaurant et des écrans.
double hospitalityPerFan(OwnerState o) =>
    0.6 * o.levelOf(InfraKind.restaurant) + 0.15 * o.levelOf(InfraKind.screens);

/// Multiplicateur des ventes de la boutique (merchandising, maillots).
double shopFactor(int level) => 1 + 0.3 * level;

/// Multiplicateur de la billetterie grâce aux installations VIP.
double vipFactor(int level) => 1 + 0.07 * level;

/// Billetterie : VIP, éclairage et toiture.
double ticketMultiplier(OwnerState o) =>
    vipFactor(o.vip) +
    0.03 * o.levelOf(InfraKind.lighting) +
    0.02 * o.levelOf(InfraKind.roof);

/// Bonus des bureaux commerciaux sur les revenus commerciaux.
double commercialMultiplier(OwnerState o) =>
    1 + 0.05 * o.levelOf(InfraKind.commercial);

/// Bonus des espaces partenaires sur les sponsors.
double sponsorMultiplier(OwnerState o) =>
    1 + 0.06 * o.levelOf(InfraKind.partners);

/// Revenus d'un match à domicile : loges, publicité, musée.
int homeExtraIncome(OwnerState o, {required int division}) {
  final f = divisionRevenueFactor(division);
  final rep = 0.5 + o.reputation / 100;
  final boxes = 2500.0 * o.levelOf(InfraKind.boxes);
  final ads = 800.0 * o.levelOf(InfraKind.ads) * rep;
  final museum = 600.0 * o.levelOf(InfraKind.museum) * rep;
  return ((boxes + ads + museum) * f * commercialMultiplier(o)).round();
}

/// Loyers du centre commercial à chaque journée.
int mallIncomePerRound(OwnerState o, {required int division}) {
  return (1500.0 *
          o.levelOf(InfraKind.mall) *
          divisionRevenueFactor(division) *
          commercialMultiplier(o))
      .round();
}

/// Réputation gagnée en fin de saison (musée, conférences).
int reputationPerSeason(OwnerState o) {
  var gain = 0;
  if (o.levelOf(InfraKind.museum) >= 3) gain += 1;
  final conf = o.levelOf(InfraKind.conference);
  if (conf >= 3) gain += 1;
  if (conf >= 5) gain += 1;
  return gain;
}

/// Revenus annuels estimés d'un bâtiment (pour l'écran des comptes).
int infraAnnualIncome(
  InfraKind kind,
  OwnerState o, {
  required int division,
  required int homeMatches,
  required int rounds,
  int averageAttendance = 0,
}) {
  final level = o.levelOf(kind);
  if (level == 0) return 0;
  final f = divisionRevenueFactor(division);
  final rep = 0.5 + o.reputation / 100;
  final cm = commercialMultiplier(o);
  switch (kind) {
    case InfraKind.fanZone:
      return (fanZonePerFan(level) * averageAttendance * homeMatches).round();
    case InfraKind.parking:
      return (parkingPerFan(level) * averageAttendance * homeMatches).round();
    case InfraKind.restaurant:
      return (0.6 * level * averageAttendance * homeMatches).round();
    case InfraKind.screens:
      return (0.15 * level * averageAttendance * homeMatches).round();
    case InfraKind.boxes:
      return (2500.0 * level * f * cm * homeMatches).round();
    case InfraKind.ads:
      return (800.0 * level * rep * f * cm * homeMatches).round();
    case InfraKind.museum:
      return (600.0 * level * rep * f * cm * homeMatches).round();
    case InfraKind.mall:
      return (1500.0 * level * f * cm * rounds).round();
    default:
      return 0;
  }
}

/// Texte décrivant l'effet d'un niveau.
String infraEffect(InfraKind kind, int level) {
  String pct(double v) => '${(v * 100).round()} %';
  switch (kind) {
    case InfraKind.stadium:
      return '${stadiumCapacity(level)} places, '
          'billetterie +${(level - 1) * 20} %';
    case InfraKind.training:
      return 'Progression : ${((level - 1) * 20)} % de chances de '
          'gagner un niveau de plus par saison';
    case InfraKind.academy:
      return '${youthCount(level)} jeunes par saison, '
          'niveau de départ +${youthBonus(level)}';
    case InfraKind.fanZone:
      return level == 0
          ? 'Animations et restauration avant les matchs'
          : '${fanZonePerFan(level).toStringAsFixed(1)} € par spectateur, '
              'supporters plus heureux';
    case InfraKind.parking:
      return level == 0
          ? 'Accueille les supporters venus en voiture'
          : '${parkingPerFan(level).toStringAsFixed(2)} € par spectateur';
    case InfraKind.shop:
      return level == 0
          ? 'Vente de maillots et de produits dérivés'
          : 'Ventes du merchandising x${shopFactor(level).toStringAsFixed(1)}';
    case InfraKind.medical:
      return level == 0
          ? 'Réduit les blessures'
          : '${(injuryAvoidChance(level) * 100).round()} % de blessures '
              "évitées à l'entraînement";
    case InfraKind.recruitment:
      return level == 0
          ? 'Améliore la détection des talents'
          : 'Talents détectés : niveau +${recruitmentBonus(level)}';
    case InfraKind.vip:
      return level == 0
          ? 'Loges et salons pour les entreprises'
          : 'Billetterie x${vipFactor(level).toStringAsFixed(2)}';
    case InfraKind.youth:
      return level == 0
          ? 'Les jeunes progressent plus vite'
          : 'Jeunes : niveau de départ +${2 * level}, '
              'progression +${pct(0.08 * level)}'
              '${level >= 3 ? ', un jeune de plus par saison' : ''}';
    case InfraKind.rehab:
      return level == 0
          ? 'Les blessés reviennent plus vite'
          : 'Retour des blessés : +${(0.02 * level * 100).round()} points '
              'de forme par journée';
    case InfraKind.fitness:
      return level == 0
          ? 'Moins de fatigue, meilleure récupération'
          : 'Repos : +${2 * level} de fraîcheur, '
              'titulaires : ${(0.8 * level).round()} de fatigue en moins';
    case InfraKind.analysis:
      return level == 0
          ? 'Rapports de recrutement plus précis'
          : 'Rapports plus précis : talents détectés +$level';
    case InfraKind.complex:
      return level == 0
          ? "Terrains supplémentaires pour l'entraînement"
          : 'Progression : +${pct(0.04 * level)} de chances par saison';
    case InfraKind.pitch:
      return level == 0
          ? 'Pelouse de base'
          : 'Moins de blessures (protection médicale +${(level / 2).round()})';
    case InfraKind.lighting:
      return level == 0
          ? 'Matchs de nuit impossibles'
          : 'Billetterie +${pct(0.03 * level)}, ambiance nocturne';
    case InfraKind.screens:
      return level == 0
          ? 'Animations et replays'
          : '+${(0.15 * level).toStringAsFixed(2)} € par spectateur';
    case InfraKind.roof:
      return level == 0
          ? 'Tribunes exposées à la météo'
          : 'Confort des spectateurs : billetterie +${pct(0.02 * level)}';
    case InfraKind.restaurant:
      return level == 0
          ? 'Restauration des jours de match'
          : '+${(0.6 * level).toStringAsFixed(1)} € par spectateur';
    case InfraKind.boxes:
      return level == 0
          ? 'Loges louées aux entreprises'
          : '${formatLevelMoney(2500 * level)} par match à domicile';
    case InfraKind.ads:
      return level == 0
          ? 'Panneaux publicitaires autour du terrain'
          : '${formatLevelMoney(800 * level)} par match (selon la réputation)';
    case InfraKind.museum:
      return level == 0
          ? 'Visites et boutique du musée'
          : '${formatLevelMoney(600 * level)} par match'
              '${level >= 3 ? ', réputation +1 par saison' : ''}';
    case InfraKind.mall:
      return level == 0
          ? 'Loyers de commerces autour du stade'
          : '${formatLevelMoney(1500 * level)} de loyers par journée';
    case InfraKind.partners:
      return level == 0
          ? 'Accueil des marques partenaires'
          : 'Revenus de sponsoring +${pct(0.06 * level)}';
    case InfraKind.hq:
      return level == 0
          ? 'Gestion du club'
          : 'Personnel géré : ${60 + 20 * level}+, '
              'frais généraux -${pct(0.02 * level)}';
    case InfraKind.conference:
      return level == 0
          ? 'Conférences et événements'
          : level >= 3
              ? 'Réputation +${level >= 5 ? 2 : 1} par saison'
              : 'Salle pour la presse et les événements';
    case InfraKind.hrCenter:
      return level == 0
          ? 'Recrutement des employés'
          : 'Personnel géré +${30 * level}, '
              'salaires -${pct(0.06 * level)}';
    case InfraKind.operations:
      return level == 0
          ? 'Pilotage des chantiers'
          : 'Travaux -${pct(0.06 * level)}, '
              '${1 + (level >= 2 ? 1 : 0) + (level >= 4 ? 1 : 0)} '
              'chantier(s) en parallèle';
    case InfraKind.commercial:
      return level == 0
          ? 'Équipe commerciale du club'
          : 'Revenus commerciaux +${pct(0.05 * level)}';
  }
}

/// Montant en euros, version courte pour les descriptions.
String formatLevelMoney(int value) {
  final s = value.toString();
  final buf = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) buf.write(' ');
    buf.write(s[i]);
  }
  return '$buf €';
}

const List<int> _capacities = [0, 3000, 5000, 9000, 16000, 30000];

int stadiumCapacity(int level) => _capacities[level];
