import '../game/game_state.dart';

/// Objectif présidentiel à long terme.
class LongGoal {
  const LongGoal(this.id, this.years, this.title, this.check);

  final String id;

  /// Horizon en saisons.
  final int years;
  final String title;
  final bool Function(GameState game) check;
}

final List<LongGoal> longGoals = [
  LongGoal('g3_stadium', 3, 'Moderniser le stade (niveau 3)',
      (g) => g.owner.stadium >= 3),
  LongGoal('g3_cash', 3, 'Garder une trésorerie positive sans dette',
      (g) => g.finance.treasury > 0 && g.owner.debt == 0),
  LongGoal('g3_promo', 3, 'Atteindre la division 3 ou mieux',
      (g) => g.division <= 3),
  LongGoal('g5_div1', 5, 'Atteindre la première division', (g) => g.division <= 1),
  LongGoal('g5_academy', 5, 'Développer une académie (niveau 4)',
      (g) => g.owner.academy >= 4),
  LongGoal('g5_medical', 5, 'Construire un centre médical (niveau 3)',
      (g) => g.owner.medical >= 3),
  LongGoal('g10_rep', 10, 'Atteindre 85 de réputation',
      (g) => g.owner.reputation >= 85),
  LongGoal('g10_stadium', 10, 'Stade mythique (niveau 5)',
      (g) => g.owner.stadium >= 5),
  LongGoal('g10_empire', 10, 'Bâtir un empire : toutes les installations niveau 3',
      (g) {
    final o = g.owner;
    return o.stadium >= 3 &&
        o.training >= 3 &&
        o.academy >= 3 &&
        o.fanZone >= 3 &&
        o.parking >= 3 &&
        o.shop >= 3 &&
        o.medical >= 3 &&
        o.recruitment >= 3 &&
        o.vip >= 3;
  }),
];

enum GoalStatus { done, open, failed }

GoalStatus goalStatus(GameState game, LongGoal goal) {
  if (game.owner.goalsDone.contains(goal.id)) return GoalStatus.done;
  if (game.seasonNumber > goal.years) return GoalStatus.failed;
  return GoalStatus.open;
}
