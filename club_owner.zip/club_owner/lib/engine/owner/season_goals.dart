import '../game/game_state.dart';

/// Contrat d'objectifs de la saison fixé par le conseil : classement,
/// finances et supporters. Chaque objectif tenu rapporte une prime du
/// conseil et de la confiance ; chacun manqué en coûte.
class SeasonObjective {
  const SeasonObjective({
    required this.id,
    required this.title,
    required this.status,
    required this.reached,
    required this.progress,
  });

  final String id;
  final String title;

  /// Où on en est (« 4e pour un objectif de 6e »...).
  final String status;
  final bool reached;

  /// De 0 à 1, pour la jauge.
  final double progress;
}

/// Prime versée par le conseil pour chaque objectif tenu.
int objectiveReward(int division) {
  switch (division) {
    case 1:
      return 1500000;
    case 2:
      return 600000;
    case 3:
      return 250000;
    case 4:
      return 120000;
    default:
      return 60000;
  }
}

/// Supporters à satisfaire : plus exigeants en haut de la pyramide.
int fanTarget(int division) => division <= 2 ? 65 : 55;

List<SeasonObjective> seasonObjectives(GameState g) {
  final rank = g.season.userRank;
  final target = g.boardObjective;
  final clubs = g.season.clubs.length;
  final treasury = g.finance.treasury;
  final fans = g.owner.fanMood;
  final fansGoal = fanTarget(g.division);
  final rankProgress = rank <= target
      ? 1.0
      : (1 - (rank - target) / clubs).clamp(0.0, 1.0).toDouble();
  return [
    SeasonObjective(
      id: 'rank',
      title: 'Finir ${target == 1 ? '1er' : '$targetᵉ'} ou mieux',
      status: rank <= target
          ? 'Actuellement ${rank == 1 ? '1er' : '$rankᵉ'} : objectif tenu'
          : 'Actuellement $rankᵉ : il manque ${rank - target} place(s)',
      reached: rank <= target,
      progress: rankProgress,
    ),
    SeasonObjective(
      id: 'cash',
      title: 'Finir la saison sans trésorerie négative ni dette',
      status: treasury >= 0 && g.owner.debt == 0
          ? 'Comptes sains'
          : (treasury < 0 ? 'Trésorerie dans le rouge' : 'Dette en cours'),
      reached: treasury >= 0 && g.owner.debt == 0,
      progress: treasury >= 0 && g.owner.debt == 0 ? 1.0 : 0.3,
    ),
    SeasonObjective(
      id: 'fans',
      title: 'Garder des supporters satisfaits ($fansGoal/100)',
      status: 'Humeur des supporters : $fans/100',
      reached: fans >= fansGoal,
      progress: (fans / fansGoal).clamp(0.0, 1.0).toDouble(),
    ),
  ];
}
