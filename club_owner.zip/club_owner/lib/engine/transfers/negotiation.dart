import 'dart:math';

import '../../domain/entities/club.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/transfer.dart';
import '../finance/finance.dart';

int roundThousand(num value) => (value / 1000).round() * 1000;

/// Prix demandé par un club pour l'un de ses joueurs.
/// [difficulty] : 0 facile, 1 normal, 2 difficile.
int askingPrice({
  required Player player,
  required Club seller,
  required int difficulty,
}) {
  var price = playerValue(player).toDouble();
  if (seller.starterIds.contains(player.id)) price *= 1.12;
  price *= 1.0 + (seller.prestige - 30) / 400;
  if (difficulty == 0) {
    price *= 0.92;
  } else if (difficulty >= 2) {
    price *= 1.1;
  }
  if (player.contractYears <= 1) price *= 0.8;
  // Un joueur qui réclame son départ se négocie à prix réduit.
  if (player.wantsOut) price *= 0.7;
  final rounded = roundThousand(price);
  return rounded < 3000 ? 3000 : rounded;
}

/// Indemnité de prêt demandée (environ 15 % de la valeur du joueur).
int loanAskingPrice({
  required Player player,
  required Club seller,
  required int difficulty,
}) {
  final value = askingPrice(player: player, seller: seller, difficulty: difficulty);
  final fee = roundThousand(value * 0.15);
  return fee < 1000 ? 1000 : fee;
}

class OfferDecision {
  const OfferDecision({
    required this.status,
    this.counterFee = 0,
    this.reason = '',
  });

  final OfferStatus status;
  final int counterFee;
  final String reason;
}

/// Raison pour laquelle le joueur refuse de rejoindre le club, ou `null`.
String? playerRefusal({
  required Player player,
  required Club seller,
  required int buyerPrestige,
  required Random random,
}) {
  // Un joueur qui veut partir accepte presque toutes les destinations.
  if (player.wantsOut) return null;
  final gap = seller.prestige - buyerPrestige;
  if (player.mood >= 85 && random.nextDouble() < 0.2) {
    return '${player.name} est épanoui ici et préfère rester.';
  }
  if (player.skill >= 66 && gap > 18) {
    return '${player.name} préfère rester dans un club plus prestigieux.';
  }
  if (random.nextDouble() < 0.08) {
    return '${player.name} refuse pour des raisons personnelles.';
  }
  return null;
}

/// Décision d'un club adverse face à une offre du président.
/// [dsLevel] améliore la négociation (directeur sportif).
OfferDecision decideOffer({
  required Offer offer,
  required Player player,
  required Club seller,
  required int buyerPrestige,
  required int difficulty,
  required int dsLevel,
  required Random random,
}) {
  final refusal = playerRefusal(
    player: player,
    seller: seller,
    buyerPrestige: buyerPrestige,
    random: random,
  );
  if (refusal != null) {
    return OfferDecision(status: OfferStatus.rejected, reason: refusal);
  }

  final isTransfer = offer.kind == OfferKind.transfer;
  final target = isTransfer
      ? askingPrice(player: player, seller: seller, difficulty: difficulty)
      : loanAskingPrice(player: player, seller: seller, difficulty: difficulty);
  final ratio = offer.fee * (1 + dsLevel / 1000) / target;

  var optionOk = true;
  var optionTarget = 0;
  if (offer.kind == OfferKind.loanOption) {
    optionTarget = roundThousand(
      askingPrice(player: player, seller: seller, difficulty: difficulty) * 1.05,
    );
    optionOk = offer.optionFee >= optionTarget;
  }

  if (ratio >= 1.0 && optionOk) {
    return const OfferDecision(status: OfferStatus.accepted);
  }
  if (ratio >= 0.8) {
    final counter = roundThousand(target * (0.98 + random.nextDouble() * 0.07));
    return OfferDecision(
      status: OfferStatus.countered,
      counterFee: counter < offer.fee ? offer.fee : counter,
      reason: optionOk
          ? 'Le club demande une hausse de l\'offre.'
          : 'Le club demande une option d\'achat plus élevée '
              '(environ $optionTarget €).',
    );
  }
  return const OfferDecision(
    status: OfferStatus.rejected,
    reason: 'Offre jugée insuffisante par le club.',
  );
}
