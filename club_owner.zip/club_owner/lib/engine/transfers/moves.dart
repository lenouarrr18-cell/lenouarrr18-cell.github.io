import '../../domain/entities/club.dart';
import '../../domain/entities/lineup.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/team_strength.dart';
import '../../domain/entities/transfer.dart';

/// Cherche un joueur dans tous les clubs : renvoie `null` s'il est libre.
Club? clubOfPlayer(List<Club> clubs, String playerId) {
  for (final club in clubs) {
    if (club.allPlayers.any((p) => p.id == playerId)) return club;
  }
  return null;
}

Player? findPlayer(List<Club> clubs, String playerId) {
  for (final club in clubs) {
    for (final p in club.allPlayers) {
      if (p.id == playerId) return p;
    }
  }
  return null;
}

/// Recalcule composition et force d'un club adverse après un mouvement.
Club refreshAiClub(Club club) {
  if (club.isUser) return club;
  final starterIds = pickBestStarters(club.squad, club.tactic.formation);
  return club.copyWith(
    starterIds: starterIds,
    strength: TeamStrength.fromPlayers(
      club.squad.where((p) => starterIds.contains(p.id)),
    ),
  );
}

Club _without(Club club, String playerId) {
  return club.copyWith(
    squad: club.squad.where((p) => p.id != playerId).toList(),
    reserve: club.reserve.where((p) => p.id != playerId).toList(),
    academy: club.academy.where((p) => p.id != playerId).toList(),
    starterIds: club.starterIds.where((id) => id != playerId).toList(),
  );
}

Club _with(Club club, Player player, SquadSlot slot) {
  switch (slot) {
    case SquadSlot.first:
      return club.copyWith(squad: [...club.squad, player]);
    case SquadSlot.reserve:
      return club.copyWith(reserve: [...club.reserve, player]);
    case SquadSlot.academy:
      return club.copyWith(academy: [...club.academy, player]);
  }
}

/// Déplace un joueur d'un club à un autre (ou le place dans un club s'il
/// était libre, [fromClubId] vide). Renvoie les clubs mis à jour.
List<Club> movePlayer({
  required List<Club> clubs,
  required Player player,
  required String fromClubId,
  required String toClubId,
  SquadSlot slot = SquadSlot.first,
}) {
  return [
    for (final club in clubs)
      if (club.id == fromClubId)
        refreshAiClub(_without(club, player.id))
      else if (club.id == toClubId)
        refreshAiClub(_with(club, player, slot))
      else
        club,
  ];
}

/// Retire un joueur de son club (libération, retraite).
List<Club> removePlayer(List<Club> clubs, String playerId) {
  return [
    for (final club in clubs)
      club.allPlayers.any((p) => p.id == playerId)
          ? refreshAiClub(_without(club, playerId))
          : club,
  ];
}

/// Met à jour un joueur là où il se trouve.
List<Club> updatePlayer(List<Club> clubs, Player updated) {
  Player pick(Player p) => p.id == updated.id ? updated : p;
  return [
    for (final club in clubs)
      club.allPlayers.any((p) => p.id == updated.id)
          ? club.copyWith(
              squad: [for (final p in club.squad) pick(p)],
              reserve: [for (final p in club.reserve) pick(p)],
              academy: [for (final p in club.academy) pick(p)],
            )
          : club,
  ];
}
