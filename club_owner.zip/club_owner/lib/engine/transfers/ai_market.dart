import 'dart:math';

import '../../domain/entities/club.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/lineup.dart';
import 'moves.dart';

class AiTransferReport {
  const AiTransferReport({required this.clubs, required this.news});

  final List<Club> clubs;
  final List<String> news;
}

/// Les clubs adverses échangent des joueurs entre eux pendant le mercato.
/// Les plus prestigieux achètent aux moins prestigieux.
AiTransferReport simulateAiTransfers({
  required List<Club> clubs,
  required int seed,
  required int seasonNumber,
  int maxMoves = 10,
}) {
  final random = Random(seed + seasonNumber * 4099);
  var current = clubs;
  final moves = <MapEntry<int, String>>[];

  final buyers = clubs.where((c) => !c.isUser).toList()
    ..sort((a, b) => b.prestige.compareTo(a.prestige));

  var count = 0;
  for (final buyerRef in buyers) {
    if (count >= maxMoves) break;
    if (random.nextDouble() > 0.55) continue;

    final buyer = current.firstWhere((c) => c.id == buyerRef.id);
    if (buyer.squad.length >= 26) continue;

    final position = PlayerPosition.values[random.nextInt(4)];
    final buyerSkills = buyer.squad
        .where((p) => p.position == position)
        .map((p) => p.skill)
        .toList()
      ..sort();
    final threshold = buyerSkills.isEmpty ? 0 : buyerSkills.first;

    final sellers = current
        .where((c) => !c.isUser && c.id != buyer.id && c.prestige < buyer.prestige)
        .toList();
    if (sellers.isEmpty) continue;
    final seller = sellers[random.nextInt(sellers.length)];

    final candidates = seller.squad
        .where((p) => p.position == position && p.skill > threshold)
        .toList()
      ..sort((a, b) => b.skill.compareTo(a.skill));
    if (candidates.isEmpty) continue;

    final minimum = minSquadByPosition[position] ?? 0;
    final sameCount = seller.squad.where((p) => p.position == position).length;
    if (sameCount <= minimum + 1) continue;

    final player = candidates.first;
    current = movePlayer(
      clubs: current,
      player: player.copyWith(contractYears: 3),
      fromClubId: seller.id,
      toClubId: buyer.id,
    );
    count++;
    moves.add(
      MapEntry(
        player.skill,
        '${player.name} (${player.skill}) quitte ${seller.name} pour ${buyer.name}.',
      ),
    );
  }

  moves.sort((a, b) => b.key.compareTo(a.key));
  return AiTransferReport(
    clubs: current,
    news: [for (final m in moves.take(5)) m.value],
  );
}
