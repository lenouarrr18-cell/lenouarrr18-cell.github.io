import 'dart:math';

import '../../core/utils/format.dart';
import '../../domain/entities/club.dart';
import '../../domain/entities/lineup.dart';
import '../../domain/entities/transfer.dart';
import 'moves.dart';

class LoanEndReport {
  const LoanEndReport({
    required this.clubs,
    required this.income,
    required this.messages,
  });

  final List<Club> clubs;

  /// Options d'achat levées par des clubs adverses (revenu du président).
  final int income;
  final List<String> messages;
}

/// Fin de saison : les joueurs prêtés rentrent dans leur club. Un club
/// adverse peut lever l'option d'achat d'un joueur du président.
LoanEndReport endLoans({
  required List<Club> clubs,
  required List<LoanDeal> loans,
  required int seed,
}) {
  final random = Random(seed + 991);
  var current = clubs;
  var income = 0;
  final messages = <String>[];

  for (final loan in loans) {
    final player = findPlayer(current, loan.playerId);
    if (player == null) continue;
    final holder = clubOfPlayer(current, loan.playerId);
    if (holder == null) continue;

    final userOwns = loan.ownerClubId == 'user';
    if (userOwns && loan.optionFee > 0 && random.nextDouble() < 0.4) {
      // Le club adverse lève l'option : le joueur reste chez lui.
      current = updatePlayer(current, player.copyWith(contractYears: 3));
      income += loan.optionFee;
      messages.add(
        '${player.name} est acheté définitivement : '
        '${formatMoney(loan.optionFee)} pour le club.',
      );
      continue;
    }

    final owner = current.where((c) => c.id == loan.ownerClubId);
    if (owner.isEmpty) continue;
    final slot = (userOwns && owner.first.squad.length >= maxSquadSize)
        ? SquadSlot.reserve
        : SquadSlot.first;
    current = movePlayer(
      clubs: current,
      player: player,
      fromClubId: holder.id,
      toClubId: loan.ownerClubId,
      slot: slot,
    );
    messages.add('${player.name} termine son prêt et rentre à '
        '${owner.first.name}.');
  }
  return LoanEndReport(clubs: current, income: income, messages: messages);
}

class LoanDevReport {
  const LoanDevReport({required this.clubs, required this.messages});

  final List<Club> clubs;
  final List<String> messages;
}

/// Les jeunes du président prêtés gagnent des niveaux grâce au temps de
/// jeu (moins de 24 ans, dans la limite de leur potentiel).
LoanDevReport applyLoanDevelopment({
  required List<Club> clubs,
  required List<LoanDeal> loans,
  required int seed,
}) {
  final random = Random(seed + 1303);
  var current = clubs;
  final messages = <String>[];
  for (final loan in loans) {
    if (loan.ownerClubId != 'user') continue;
    final player = findPlayer(current, loan.playerId);
    if (player == null || player.age > 23) continue;
    final room = player.maxSkill - player.skill;
    if (room <= 0) continue;
    var gain = 1 + random.nextInt(3);
    if (player.matches >= 12) gain += 1;
    if (gain > room) gain = room;
    final updated = player.copyWith(
      skill: player.skill + gain,
      mood: (player.mood + 8).clamp(0, 100).toInt(),
    );
    current = updatePlayer(current, updated);
    messages.add('${player.name} progresse de +$gain grâce à son prêt.');
  }
  return LoanDevReport(clubs: current, messages: messages);
}
