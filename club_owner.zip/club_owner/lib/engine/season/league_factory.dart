import 'dart:math';

import '../../domain/entities/club.dart';
import '../../domain/entities/division.dart';
import '../../domain/entities/lineup.dart';
import '../../domain/entities/team_strength.dart';
import '../squad/squad_factory.dart';
import '../world/club_factory.dart';
import '../world/profile.dart';

/// Noms fictifs pour les clubs adverses (aucune marque réelle).
const List<String> _clubNamePool = [
  'FC Horizon',
  'AS Vallée',
  'Racing Delta',
  'US Rivage',
  'Union Lagune',
  'Étoile Dorée',
  'Sporting Baobab',
  'AS Palmeraie',
  'FC Soleil',
  'Athletic Savane',
  'Jeunesse Océane',
  'AS Cascade',
  'FC Kora',
  'Racing Mangrove',
  'US Falaise',
  'Olympic Marché',
  'AS Colline',
  'FC Harmattan',
  'Stade Ébène',
  'Union Mosaïque',
  'AS Cacao',
  'FC Rizière',
  'Sporting Rapides',
  'AS Alizé',
  'FC Lagon',
  'Racing Ananas',
  'US Tamarin',
  'AS Pirogue',
  'FC Karité',
  'Athletic Citadelle',
];

/// Crée le championnat amateur d'une nouvelle partie : le club du joueur
/// (avec son effectif) et 19 adversaires complets. La richesse de la ville
/// donne un avantage de départ au joueur.
List<Club> generateLeagueClubs({
  required String userClubName,
  required int userCityWealth,
  required int seed,
  int size = 20,
  String homeNation = '',
}) {
  final random = Random(seed);
  final profileRandom = Random(seed + 21);
  final userNames = <String>{};
  final userSquad = [
    for (final p in generateSquad(
      level: startingSquadLevel(userCityWealth),
      seed: seed + 1,
    ))
      withProfile(p, profileRandom, homeNation, used: userNames),
  ];
  final starterIds = pickBestStarters(userSquad);
  final user = Club(
    id: 'user',
    name: userClubName,
    strength: TeamStrength.fromPlayers(
      userSquad.where((p) => starterIds.contains(p.id)),
    ),
    isUser: true,
    squad: userSquad,
    starterIds: starterIds,
    academy: generateYouths(
      prefix: 'user-a0',
      count: 4,
      seed: seed + 31,
      quality: 20,
      homeNation: homeNation,
    ),
    prestige: 20,
  );
  return _assemble(
    user: user,
    division: lowestDivision,
    size: size,
    random: random,
    homeNation: homeNation,
    generation: 1,
  );
}

/// Niveau moyen de l'effectif de départ selon la richesse de la ville.
double startingSquadLevel(int wealth) => 51.0 + wealth * 0.8;

/// Crée le championnat d'une division pour une nouvelle saison. Si
/// [keep] contient les 19 adversaires de la saison précédente (même
/// division), ils sont conservés avec leurs effectifs.
List<Club> generateNextLeague({
  required Club userClub,
  required int division,
  required int seed,
  int size = 20,
  String homeNation = '',
  int generation = 2,
  List<Club>? keep,
}) {
  if (keep != null && keep.length == size - 1) {
    final clubs = <Club>[userClub, ...keep];
    clubs.shuffle(Random(seed));
    return clubs;
  }
  return _assemble(
    user: userClub,
    division: division,
    size: size,
    random: Random(seed),
    homeNation: homeNation,
    generation: generation,
  );
}

List<Club> _assemble({
  required Club user,
  required int division,
  required int size,
  required Random random,
  required String homeNation,
  required int generation,
}) {
  assert(size >= 2 && size - 1 <= _clubNamePool.length);
  final names = [..._clubNamePool]..shuffle(random);

  final clubs = <Club>[user];
  for (var i = 0; i < size - 1; i++) {
    clubs.add(
      generateAiClub(
        id: 'g$generation-c$i',
        name: names[i],
        division: division,
        seed: random.nextInt(1 << 30),
        homeNation: homeNation,
      ),
    );
  }

  clubs.shuffle(random);
  return clubs;
}

