import '../../domain/entities/club.dart';
import '../../domain/entities/standing.dart';
import '../calendar/fixture_generator.dart';
import '../match/match_engine.dart';
import '../match/match_models.dart';

/// Une saison de championnat (Dart pur, immuable).
///
/// Jouer une journée renvoie une nouvelle saison. Les résultats sont
/// reproductibles à partir de la graine de la saison.
class Season {
  const Season({
    required this.clubs,
    required this.fixtures,
    required this.results,
    required this.currentRound,
    required this.seed,
  });

  factory Season.create({required List<Club> clubs, required int seed}) {
    return Season(
      clubs: clubs,
      fixtures: generateRoundRobin(clubs.map((c) => c.id).toList()),
      results: const {},
      currentRound: 1,
      seed: seed,
    );
  }

  final List<Club> clubs;
  final List<Fixture> fixtures;

  /// Résultats indexés par [Fixture.key].
  final Map<String, MatchResult> results;
  final int currentRound;
  final int seed;

  int get totalRounds =>
      fixtures.fold<int>(0, (max, f) => f.round > max ? f.round : max);

  bool get isFinished => currentRound > totalRounds;

  Club clubById(String id) => clubs.firstWhere((c) => c.id == id);

  Club get userClub => clubs.firstWhere((c) => c.isUser);

  /// Rang actuel du club du joueur au classement (1 = premier).
  int get userRank => standings.indexWhere((s) => s.clubId == userClub.id) + 1;

  List<Fixture> fixturesOfRound(int round) =>
      fixtures.where((f) => f.round == round).toList();

  MatchResult? resultOf(Fixture fixture) => results[fixture.key];

  Fixture? userFixtureOfRound(int round) {
    final userId = userClub.id;
    for (final fixture in fixturesOfRound(round)) {
      if (fixture.homeId == userId || fixture.awayId == userId) {
        return fixture;
      }
    }
    return null;
  }

  Fixture? get nextUserFixture =>
      isFinished ? null : userFixtureOfRound(currentRound);

  Season playNextRound() {
    if (isFinished) return this;

    final newResults = Map<String, MatchResult>.from(results);
    for (final fixture in fixturesOfRound(currentRound)) {
      final index = fixtures.indexOf(fixture);
      final engine = MatchEngine(seed: seed * 100003 + index);
      final homeClub = clubById(fixture.homeId);
      var homeStrength = homeClub.matchStrength;
      // Les grands clubs (stade plein, supporters nombreux) reçoivent mieux.
      if (!homeClub.isUser) {
        homeStrength = homeStrength.scaled(1 + (homeClub.prestige - 50) / 4000);
      }
      newResults[fixture.key] = engine.simulate(
        home: homeStrength,
        away: clubById(fixture.awayId).matchStrength,
      );
    }

    return Season(
      clubs: clubs,
      fixtures: fixtures,
      results: newResults,
      currentRound: currentRound + 1,
      seed: seed,
    );
  }

  /// Renvoie une saison où le résultat d'une rencontre est remplacé.
  Season withResult(String key, MatchResult result) {
    return Season(
      clubs: clubs,
      fixtures: fixtures,
      results: {...results, key: result},
      currentRound: currentRound,
      seed: seed,
    );
  }

  /// Renvoie une saison avec une nouvelle liste de clubs (même ordre).
  Season withClubs(List<Club> updated) {
    return Season(
      clubs: updated,
      fixtures: fixtures,
      results: results,
      currentRound: currentRound,
      seed: seed,
    );
  }

  /// Renvoie une saison où le club de même identifiant est remplacé.
  Season withClub(Club updated) {
    return Season(
      clubs: [for (final c in clubs) c.id == updated.id ? updated : c],
      fixtures: fixtures,
      results: results,
      currentRound: currentRound,
      seed: seed,
    );
  }

  /// Classement : points, différence de buts, buts marqués, puis nom.
  List<Standing> get standings {
    final tallies = {for (final c in clubs) c.id: _Tally()};

    for (final fixture in fixtures) {
      final result = results[fixture.key];
      if (result == null) continue;
      tallies[fixture.homeId]!.add(result.homeGoals, result.awayGoals);
      tallies[fixture.awayId]!.add(result.awayGoals, result.homeGoals);
    }

    final rows = [for (final c in clubs) tallies[c.id]!.toStanding(c.id)];

    rows.sort((a, b) {
      final byPoints = b.points.compareTo(a.points);
      if (byPoints != 0) return byPoints;
      final byDiff = b.goalDifference.compareTo(a.goalDifference);
      if (byDiff != 0) return byDiff;
      final byGoals = b.goalsFor.compareTo(a.goalsFor);
      if (byGoals != 0) return byGoals;
      return clubById(a.clubId).name.compareTo(clubById(b.clubId).name);
    });

    return rows;
  }
}

class _Tally {
  int played = 0;
  int won = 0;
  int drawn = 0;
  int lost = 0;
  int goalsFor = 0;
  int goalsAgainst = 0;

  void add(int scored, int conceded) {
    played++;
    goalsFor += scored;
    goalsAgainst += conceded;
    if (scored > conceded) {
      won++;
    } else if (scored == conceded) {
      drawn++;
    } else {
      lost++;
    }
  }

  Standing toStanding(String clubId) {
    return Standing(
      clubId: clubId,
      played: played,
      won: won,
      drawn: drawn,
      lost: lost,
      goalsFor: goalsFor,
      goalsAgainst: goalsAgainst,
    );
  }
}
