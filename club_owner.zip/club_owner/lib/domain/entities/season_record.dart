import 'division.dart';

/// Résultat d'une saison terminée, conservé dans le palmarès.
class SeasonRecord {
  const SeasonRecord({
    required this.season,
    required this.division,
    required this.rank,
    required this.outcome,
  });

  factory SeasonRecord.fromJson(Map<String, dynamic> json) {
    return SeasonRecord(
      season: json['season'] as int,
      division: json['division'] as int,
      rank: json['rank'] as int,
      outcome: SeasonOutcome.values.byName(json['outcome'] as String),
    );
  }

  final int season;
  final int division;
  final int rank;
  final SeasonOutcome outcome;

  Map<String, Object?> toJson() {
    return {
      'season': season,
      'division': division,
      'rank': rank,
      'outcome': outcome.name,
    };
  }
}
