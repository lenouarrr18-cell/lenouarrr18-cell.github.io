/// Un but du dernier match du président, tiré de la vraie simulation.
class GoalNote {
  const GoalNote({
    required this.minute,
    required this.home,
    required this.scorer,
    this.assist = '',
  });

  factory GoalNote.fromJson(Map<String, dynamic> json) {
    return GoalNote(
      minute: json['minute'] as int,
      home: json['home'] as bool,
      scorer: json['scorer'] as String,
      assist: json['assist'] as String? ?? '',
    );
  }

  final int minute;
  final bool home;
  final String scorer;
  final String assist;

  Map<String, Object?> toJson() {
    return {
      'minute': minute,
      'home': home,
      'scorer': scorer,
      if (assist.isNotEmpty) 'assist': assist,
    };
  }
}

/// Statistiques détaillées d'un match (domicile / extérieur).
class MatchStats {
  const MatchStats({
    required this.homePossession,
    required this.homeShots,
    required this.awayShots,
    required this.homeOnTarget,
    required this.awayOnTarget,
    required this.homeCorners,
    required this.awayCorners,
    required this.homeFouls,
    required this.awayFouls,
    required this.homeYellow,
    required this.awayYellow,
    required this.homeRed,
    required this.awayRed,
    required this.homeOffsides,
    required this.awayOffsides,
    required this.homePasses,
    required this.awayPasses,
    required this.homePassAcc,
    required this.awayPassAcc,
    this.homeThrowIns = 0,
    this.awayThrowIns = 0,
    this.homeXg = 0,
    this.awayXg = 0,
  });

  factory MatchStats.fromJson(Map<String, dynamic> json) {
    int v(String k) => json[k] as int? ?? 0;
    return MatchStats(
      homePossession: v('hp'),
      homeShots: v('hs'),
      awayShots: v('as'),
      homeOnTarget: v('ht'),
      awayOnTarget: v('at'),
      homeCorners: v('hc'),
      awayCorners: v('ac'),
      homeFouls: v('hf'),
      awayFouls: v('af'),
      homeYellow: v('hy'),
      awayYellow: v('ay'),
      homeRed: v('hr'),
      awayRed: v('ar'),
      homeOffsides: v('ho'),
      awayOffsides: v('ao'),
      homePasses: v('hpa'),
      awayPasses: v('apa'),
      homePassAcc: v('hpc'),
      awayPassAcc: v('apc'),
      homeThrowIns: v('hti'),
      awayThrowIns: v('ati'),
      homeXg: v('hxg'),
      awayXg: v('axg'),
    );
  }

  final int homePossession;
  final int homeShots;
  final int awayShots;
  final int homeOnTarget;
  final int awayOnTarget;
  final int homeCorners;
  final int awayCorners;
  final int homeFouls;
  final int awayFouls;
  final int homeYellow;
  final int awayYellow;
  final int homeRed;
  final int awayRed;
  final int homeOffsides;
  final int awayOffsides;
  final int homePasses;
  final int awayPasses;
  final int homePassAcc;
  final int awayPassAcc;
  final int homeThrowIns;
  final int awayThrowIns;

  /// Buts attendus (xG), en centièmes.
  final int homeXg;
  final int awayXg;

  Map<String, Object?> toJson() {
    return {
      'hp': homePossession,
      'hs': homeShots,
      'as': awayShots,
      'ht': homeOnTarget,
      'at': awayOnTarget,
      'hti': homeThrowIns,
      'hxg': homeXg,
      'axg': awayXg,
      'ati': awayThrowIns,
      'hc': homeCorners,
      'ac': awayCorners,
      'hf': homeFouls,
      'af': awayFouls,
      'hy': homeYellow,
      'ay': awayYellow,
      'hr': homeRed,
      'ar': awayRed,
      'ho': homeOffsides,
      'ao': awayOffsides,
      'hpa': homePasses,
      'apa': awayPasses,
      'hpc': homePassAcc,
      'apc': awayPassAcc,
    };
  }
}

/// Prestation individuelle d'un joueur dans un match (issue de la
/// simulation sur le terrain).
class PlayerPerf {
  const PlayerPerf({
    required this.name,
    required this.pos,
    required this.home,
    required this.ratingTenths,
    required this.distanceHm,
    this.goals = 0,
    this.assists = 0,
    this.shots = 0,
    this.passes = 0,
    this.passesOk = 0,
    this.tackles = 0,
    this.saves = 0,
  });

  factory PlayerPerf.fromJson(Map<String, dynamic> json) {
    return PlayerPerf(
      name: json['n'] as String,
      pos: json['p'] as String,
      home: json['h'] as bool,
      ratingTenths: json['r'] as int,
      distanceHm: json['d'] as int,
      goals: json['g'] as int? ?? 0,
      assists: json['a'] as int? ?? 0,
      shots: json['s'] as int? ?? 0,
      passes: json['ps'] as int? ?? 0,
      passesOk: json['po'] as int? ?? 0,
      tackles: json['t'] as int? ?? 0,
      saves: json['sv'] as int? ?? 0,
    );
  }

  final String name;
  final String pos;
  final bool home;

  /// Note sur 10, en dixièmes (68 = 6,8).
  final int ratingTenths;

  /// Distance parcourue en hectomètres (105 = 10,5 km).
  final int distanceHm;
  final int goals;
  final int assists;
  final int shots;
  final int passes;
  final int passesOk;
  final int tackles;
  final int saves;

  double get rating => ratingTenths / 10;
  double get distanceKm => distanceHm / 10;

  Map<String, Object?> toJson() {
    return {
      'n': name,
      'p': pos,
      'h': home,
      'r': ratingTenths,
      'd': distanceHm,
      'g': goals,
      'a': assists,
      's': shots,
      'ps': passes,
      'po': passesOk,
      't': tackles,
      'sv': saves,
    };
  }
}

/// Résumé du dernier match joué par le club du président.
class MatchSummary {
  const MatchSummary({
    required this.season,
    required this.round,
    required this.homeId,
    required this.awayId,
    required this.homeName,
    required this.awayName,
    required this.homeGoals,
    required this.awayGoals,
    required this.goals,
    this.homeFormation = '4-4-2',
    this.awayFormation = '4-4-2',
    this.stats,
    this.perfs = const [],
    this.track = '',
    this.subs = const [],
    this.cards = const [],
    this.chances = const [],
    this.names = const [],
    this.log = const [],
    this.trackVersion = 1,
    this.attendance = 0,
    this.capacity = 0,
  });

  factory MatchSummary.fromJson(Map<String, dynamic> json) {
    return MatchSummary(
      season: json['season'] as int,
      round: json['round'] as int,
      homeId: json['homeId'] as String,
      awayId: json['awayId'] as String,
      homeName: json['homeName'] as String,
      awayName: json['awayName'] as String,
      homeGoals: json['homeGoals'] as int,
      awayGoals: json['awayGoals'] as int,
      goals: [
        for (final raw in json['goals'] as List<dynamic>)
          GoalNote.fromJson(raw as Map<String, dynamic>),
      ],
      homeFormation: json['homeFormation'] as String? ?? '4-4-2',
      awayFormation: json['awayFormation'] as String? ?? '4-4-2',
      stats: json['stats'] == null
          ? null
          : MatchStats.fromJson(json['stats'] as Map<String, dynamic>),
      track: json['track'] as String? ?? '',
      cards: [
        for (final x in (json['cards'] as List<dynamic>? ?? const []))
          x as String,
      ],
      chances: [
        for (final x in (json['chances'] as List<dynamic>? ?? const []))
          x as String,
      ],
      names: [
        for (final x in (json['names'] as List<dynamic>? ?? const []))
          x as String,
      ],
      subs: [
        for (final x in (json['subs'] as List<dynamic>? ?? const []))
          x as String,
      ],
      log: [
        for (final x in (json['log'] as List<dynamic>? ?? const []))
          x as String,
      ],
      trackVersion: json['tv'] as int? ?? 1,
      attendance: json['att'] as int? ?? 0,
      capacity: json['cap'] as int? ?? 0,
      perfs: [
        for (final raw
            in (json['perfs'] as List<dynamic>? ?? const <dynamic>[]))
          PlayerPerf.fromJson(raw as Map<String, dynamic>),
      ],
    );
  }

  final int season;
  final int round;
  final String homeId;
  final String awayId;
  final String homeName;
  final String awayName;
  final int homeGoals;
  final int awayGoals;
  final List<GoalNote> goals;
  final String homeFormation;
  final String awayFormation;
  final MatchStats? stats;

  /// Notes et distances des joueurs (vide pour les anciens matchs).
  final List<PlayerPerf> perfs;

  /// Trajectoires des 22 joueurs et du ballon (base64), pour le rejeu.
  final String track;

  /// Remplacements : « minute|1 si domicile|sortant|entrant ».
  final List<String> subs;

  /// Cartons : « minute|1 si domicile|joueur|Y ou R ».
  final List<String> cards;

  /// Occasions : « minute|1 si domicile|tireur|G/S/M/B|xG ».
  final List<String> chances;

  /// Noms des 22 titulaires, dans l'ordre des trajectoires.
  final List<String> names;

  /// Journal du match (moteur v2) : « seconde|code|1 si domicile|a|b|x|y ».
  final List<String> log;

  /// Format de la trajectoire : 1 (ancien) ou 2 (une image par seconde,
  /// arbitres et hauteur du ballon).
  final int trackVersion;

  /// Affluence et capacité du stade (0 pour un match à l'extérieur).
  final int attendance;
  final int capacity;

  Map<String, Object?> toJson() {
    return {
      'season': season,
      'round': round,
      'homeId': homeId,
      'awayId': awayId,
      'homeName': homeName,
      'awayName': awayName,
      'homeGoals': homeGoals,
      'awayGoals': awayGoals,
      'goals': [for (final g in goals) g.toJson()],
      'homeFormation': homeFormation,
      'awayFormation': awayFormation,
      if (stats != null) 'stats': stats!.toJson(),
      if (track.isNotEmpty) 'track': track,
      if (subs.isNotEmpty) 'subs': subs,
      if (cards.isNotEmpty) 'cards': cards,
      if (chances.isNotEmpty) 'chances': chances,
      if (names.isNotEmpty) 'names': names,
      if (log.isNotEmpty) 'log': log,
      if (trackVersion != 1) 'tv': trackVersion,
      if (attendance > 0) 'att': attendance,
      if (capacity > 0) 'cap': capacity,
      if (perfs.isNotEmpty) 'perfs': [for (final p in perfs) p.toJson()],
    };
  }
}
