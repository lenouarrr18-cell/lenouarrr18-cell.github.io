import 'lineup.dart';
import 'player.dart';
import 'tactic.dart';
import 'team_strength.dart';

class Club {
  const Club({
    required this.id,
    required this.name,
    required this.strength,
    this.isUser = false,
    this.squad = const [],
    this.starterIds = const [],
    this.staffBoost = 1.0,
    this.reserve = const [],
    this.academy = const [],
    this.tactic = const Tactic(),
    this.prestige = 30,
  });

  final String id;
  final String name;

  /// Force fixe, utilisée quand le club n'a pas d'effectif détaillé.
  final TeamStrength strength;
  final bool isUser;

  /// Équipe première.
  final List<Player> squad;
  final List<String> starterIds;

  /// Multiplicateur de force apporté par le manager (1.0 = aucun effet).
  final double staffBoost;

  /// Équipe réserve (à partir de la division 3).
  final List<Player> reserve;

  /// Centre de formation.
  final List<Player> academy;
  final Tactic tactic;

  /// Prestige du club de 0 à 100 (pour le club du joueur, c'est la
  /// réputation du propriétaire).
  final int prestige;

  List<Player> get starters =>
      squad.where((p) => starterIds.contains(p.id)).toList();

  /// Tous les joueurs sous contrat du club.
  List<Player> get allPlayers => [...squad, ...reserve, ...academy];

  /// Force utilisée en match : la composition réelle quand l'effectif
  /// existe, sinon la force fixe du club.
  TeamStrength get matchStrength {
    if (squad.isEmpty) return strength;
    final xi = starters;
    final raw = xi.length == startingXiSize
        ? lineupStrength(xi, tactic)
        : TeamStrength.fromPlayers(xi);
    final base = tactic.applyTo(raw);
    return staffBoost == 1.0 ? base : base.scaled(staffBoost);
  }

  bool get hasFullLineup => squad.isEmpty || starters.length == startingXiSize;

  Club copyWith({
    List<Player>? squad,
    List<String>? starterIds,
    double? staffBoost,
    List<Player>? reserve,
    List<Player>? academy,
    Tactic? tactic,
    int? prestige,
    TeamStrength? strength,
  }) {
    return Club(
      id: id,
      name: name,
      strength: strength ?? this.strength,
      isUser: isUser,
      squad: squad ?? this.squad,
      starterIds: starterIds ?? this.starterIds,
      staffBoost: staffBoost ?? this.staffBoost,
      reserve: reserve ?? this.reserve,
      academy: academy ?? this.academy,
      tactic: tactic ?? this.tactic,
      prestige: prestige ?? this.prestige,
    );
  }
}
