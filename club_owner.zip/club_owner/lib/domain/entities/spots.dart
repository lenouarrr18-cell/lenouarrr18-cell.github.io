import 'player.dart';
import 'tactic.dart';

/// Postes précis d'un terrain de football.
enum Spot {
  gb,
  dg,
  dd,
  dc,
  pg,
  pd,
  mdc,
  mc,
  mcg,
  mcd,
  moc,
  mg,
  md,
  ag,
  ad,
  bu,
  ac,
  bt,
}

extension SpotInfo on Spot {
  String get label {
    switch (this) {
      case Spot.gb:
        return 'GB';
      case Spot.dg:
        return 'DG';
      case Spot.dd:
        return 'DD';
      case Spot.dc:
        return 'DC';
      case Spot.pg:
        return 'PG';
      case Spot.pd:
        return 'PD';
      case Spot.mdc:
        return 'MDC';
      case Spot.mc:
        return 'MC';
      case Spot.mcg:
        return 'MCG';
      case Spot.mcd:
        return 'MCD';
      case Spot.moc:
        return 'MOC';
      case Spot.mg:
        return 'MG';
      case Spot.md:
        return 'MD';
      case Spot.ag:
        return 'AG';
      case Spot.ad:
        return 'AD';
      case Spot.bu:
        return 'BU';
      case Spot.ac:
        return 'AC';
      case Spot.bt:
        return 'BT';
    }
  }

  String get fullName {
    switch (this) {
      case Spot.gb:
        return 'Gardien de but';
      case Spot.dg:
        return 'Défenseur gauche';
      case Spot.dd:
        return 'Défenseur droit';
      case Spot.dc:
        return 'Défenseur central';
      case Spot.pg:
        return 'Piston gauche';
      case Spot.pd:
        return 'Piston droit';
      case Spot.mdc:
        return 'Milieu défensif central';
      case Spot.mc:
        return 'Milieu central';
      case Spot.mcg:
        return 'Milieu central gauche';
      case Spot.mcd:
        return 'Milieu central droit';
      case Spot.moc:
        return 'Milieu offensif central';
      case Spot.mg:
        return 'Milieu gauche';
      case Spot.md:
        return 'Milieu droit';
      case Spot.ag:
        return 'Ailier gauche';
      case Spot.ad:
        return 'Ailier droit';
      case Spot.bu:
        return 'Avant-centre';
      case Spot.ac:
        return 'Attaquant de soutien';
      case Spot.bt:
        return 'Deuxième attaquant';
    }
  }

  /// Ligne du terrain à laquelle appartient le poste.
  PlayerPosition get line {
    switch (this) {
      case Spot.gb:
        return PlayerPosition.goalkeeper;
      case Spot.dg:
      case Spot.dd:
      case Spot.dc:
      case Spot.pg:
      case Spot.pd:
        return PlayerPosition.defender;
      case Spot.mdc:
      case Spot.mc:
      case Spot.mcg:
      case Spot.mcd:
      case Spot.moc:
      case Spot.mg:
      case Spot.md:
        return PlayerPosition.midfielder;
      case Spot.ag:
      case Spot.ad:
      case Spot.bu:
      case Spot.ac:
      case Spot.bt:
        return PlayerPosition.forward;
    }
  }

  /// -1 = côté gauche, 0 = axe, 1 = côté droit.
  int get side {
    switch (this) {
      case Spot.dg:
      case Spot.pg:
      case Spot.mg:
      case Spot.ag:
      case Spot.mcg:
        return -1;
      case Spot.dd:
      case Spot.pd:
      case Spot.md:
      case Spot.ad:
      case Spot.mcd:
        return 1;
      default:
        return 0;
    }
  }

  bool get isWide => this == Spot.pg || this == Spot.pd || this == Spot.mg ||
      this == Spot.md || this == Spot.ag || this == Spot.ad ||
      this == Spot.dg || this == Spot.dd;

  /// Les postes de gauche et de droite sont des variantes d'un même poste
  /// pour le calcul d'adéquation.
  Spot get family {
    switch (this) {
      case Spot.mcg:
      case Spot.mcd:
        return Spot.mc;
      case Spot.pg:
        return Spot.dg;
      case Spot.pd:
        return Spot.dd;
      default:
        return this;
    }
  }
}

int _hash(String id) {
  var h = 7;
  for (final c in id.codeUnits) {
    h = (h * 31 + c) & 0x7fffffff;
  }
  return h;
}

/// Poste naturel du joueur. Déterministe (calculé depuis l'identifiant et
/// la ligne), donc aucune sauvegarde existante n'a besoin de changer.
Spot naturalSpot(Player p) {
  final h = _hash(p.id) % 60;
  switch (p.position) {
    case PlayerPosition.goalkeeper:
      return Spot.gb;
    case PlayerPosition.defender:
      if (h < 12) return Spot.dg;
      if (h < 24) return Spot.dd;
      return Spot.dc;
    case PlayerPosition.midfielder:
      if (h < 15) return Spot.mdc;
      if (h < 33) return Spot.mc;
      if (h < 43) return Spot.moc;
      if (h < 51) return Spot.mg;
      return Spot.md;
    case PlayerPosition.forward:
      if (h < 14) return Spot.ag;
      if (h < 28) return Spot.ad;
      if (h < 46) return Spot.bu;
      if (h < 53) return Spot.ac;
      return Spot.bt;
  }
}

/// Un joueur polyvalent s'adapte mieux aux postes voisins.
bool isVersatile(Player p) => _hash(p.id) % 7 == 0;

/// Adéquation (0..1) d'un joueur à un poste.
double spotFit(Player p, Spot target) {
  final natural = naturalSpot(p);
  final nf = natural.family;
  final tf = target.family;
  if (nf == tf) return 1.0;
  final gkMismatch = (natural == Spot.gb) != (target == Spot.gb);
  if (gkMismatch) return 0.3;
  final bonus = isVersatile(p) ? 0.05 : 0.0;
  double near(Spot a, Spot b) {
    final pair = {a, b};
    bool has(Spot x, Spot y) => pair.contains(x) && pair.contains(y);
    if (has(Spot.dg, Spot.dd)) return 0.92;
    if (has(Spot.dc, Spot.mdc)) return 0.92;
    if (has(Spot.mc, Spot.mdc)) return 0.97;
    if (has(Spot.mc, Spot.moc)) return 0.97;
    if (has(Spot.mg, Spot.md)) return 0.92;
    if (has(Spot.mg, Spot.ag)) return 0.96;
    if (has(Spot.md, Spot.ad)) return 0.96;
    if (has(Spot.ag, Spot.ad)) return 0.9;
    if (has(Spot.bu, Spot.ac)) return 0.97;
    if (has(Spot.bu, Spot.bt)) return 0.98;
    if (has(Spot.bt, Spot.ac)) return 1.0;
    if (has(Spot.moc, Spot.ac)) return 0.95;
    if (has(Spot.moc, Spot.bt)) return 0.95;
    if (has(Spot.dg, Spot.mg)) return 0.9;
    if (has(Spot.dd, Spot.md)) return 0.9;
    return 0;
  }

  final n = near(nf, tf);
  if (n > 0) return (n + bonus).clamp(0.0, 1.0).toDouble();
  final gap = (natural.line.index - target.line.index).abs();
  final base = gap == 0 ? 0.84 : (gap == 1 ? 0.7 : (gap == 2 ? 0.55 : 0.4));
  return (base + bonus).clamp(0.0, 1.0).toDouble();
}

/// Un poste du plan de jeu : coordonnées normalisées (indépendantes de la
/// taille de l'écran). x : 0 = son but, 1 = but adverse ; y : 0 = gauche,
/// 1 = droite (vu de derrière son propre but).
class SpotSlot {
  const SpotSlot(this.spot, this.x, this.y);

  final Spot spot;
  final double x;
  final double y;
}

/// Disposition footballistique propre à chaque formation.
List<SpotSlot> layoutOf(Formation f) {
  const gb = SpotSlot(Spot.gb, 0.06, 0.5);
  switch (f) {
    case Formation.f442:
      return const [
        gb,
        SpotSlot(Spot.dg, 0.24, 0.1),
        SpotSlot(Spot.dc, 0.2, 0.37),
        SpotSlot(Spot.dc, 0.2, 0.63),
        SpotSlot(Spot.dd, 0.24, 0.9),
        SpotSlot(Spot.mg, 0.5, 0.1),
        SpotSlot(Spot.mc, 0.46, 0.37),
        SpotSlot(Spot.mc, 0.46, 0.63),
        SpotSlot(Spot.md, 0.5, 0.9),
        SpotSlot(Spot.bu, 0.78, 0.38),
        SpotSlot(Spot.bu, 0.78, 0.62),
      ];
    case Formation.f433:
      return const [
        gb,
        SpotSlot(Spot.dg, 0.24, 0.1),
        SpotSlot(Spot.dc, 0.2, 0.37),
        SpotSlot(Spot.dc, 0.2, 0.63),
        SpotSlot(Spot.dd, 0.24, 0.9),
        SpotSlot(Spot.mdc, 0.38, 0.5),
        SpotSlot(Spot.mcg, 0.52, 0.3),
        SpotSlot(Spot.mcd, 0.52, 0.7),
        SpotSlot(Spot.ag, 0.76, 0.12),
        SpotSlot(Spot.bu, 0.82, 0.5),
        SpotSlot(Spot.ad, 0.76, 0.88),
      ];
    case Formation.f352:
      return const [
        gb,
        SpotSlot(Spot.dc, 0.2, 0.25),
        SpotSlot(Spot.dc, 0.18, 0.5),
        SpotSlot(Spot.dc, 0.2, 0.75),
        SpotSlot(Spot.mg, 0.5, 0.08),
        SpotSlot(Spot.mcg, 0.5, 0.32),
        SpotSlot(Spot.mdc, 0.4, 0.5),
        SpotSlot(Spot.mcd, 0.5, 0.68),
        SpotSlot(Spot.md, 0.5, 0.92),
        SpotSlot(Spot.bu, 0.78, 0.38),
        SpotSlot(Spot.bu, 0.78, 0.62),
      ];
    case Formation.f532:
      return const [
        gb,
        SpotSlot(Spot.pg, 0.32, 0.07),
        SpotSlot(Spot.dc, 0.2, 0.27),
        SpotSlot(Spot.dc, 0.18, 0.5),
        SpotSlot(Spot.dc, 0.2, 0.73),
        SpotSlot(Spot.pd, 0.32, 0.93),
        SpotSlot(Spot.mcg, 0.48, 0.3),
        SpotSlot(Spot.mdc, 0.42, 0.5),
        SpotSlot(Spot.mcd, 0.48, 0.7),
        SpotSlot(Spot.bu, 0.78, 0.38),
        SpotSlot(Spot.bu, 0.78, 0.62),
      ];
    case Formation.f451:
      return const [
        gb,
        SpotSlot(Spot.dg, 0.24, 0.1),
        SpotSlot(Spot.dc, 0.2, 0.37),
        SpotSlot(Spot.dc, 0.2, 0.63),
        SpotSlot(Spot.dd, 0.24, 0.9),
        SpotSlot(Spot.mg, 0.52, 0.08),
        SpotSlot(Spot.mcg, 0.5, 0.3),
        SpotSlot(Spot.mdc, 0.4, 0.5),
        SpotSlot(Spot.mcd, 0.5, 0.7),
        SpotSlot(Spot.md, 0.52, 0.92),
        SpotSlot(Spot.bu, 0.82, 0.5),
      ];
    case Formation.f343:
      return const [
        gb,
        SpotSlot(Spot.dc, 0.2, 0.25),
        SpotSlot(Spot.dc, 0.18, 0.5),
        SpotSlot(Spot.dc, 0.2, 0.75),
        SpotSlot(Spot.mg, 0.5, 0.1),
        SpotSlot(Spot.mc, 0.46, 0.38),
        SpotSlot(Spot.mc, 0.46, 0.62),
        SpotSlot(Spot.md, 0.5, 0.9),
        SpotSlot(Spot.ag, 0.76, 0.12),
        SpotSlot(Spot.bu, 0.82, 0.5),
        SpotSlot(Spot.ad, 0.76, 0.88),
      ];
  }
}

// ---------- rôles et consignes ----------

/// Rôle tactique d'un joueur à son poste. Chaque rôle change vraiment son
/// comportement dans le moteur de match.
enum Role {
  standard,
  sentinelle,
  recuperateur,
  regulateur,
  boxToBox,
  organisateur,
  relayeur,
  milieuRecup,
  meneurAvance,
  secondAttaquant,
  createur,
  ailierClassique,
  ailierInterieur,
  attaquantInterieur,
  lateralDefensif,
  lateralOffensif,
  lateralInverse,
  renard,
  attaquantComplet,
  pivot,
  profondeur,
}

extension RoleInfo on Role {
  String get label {
    switch (this) {
      case Role.standard:
        return 'Standard';
      case Role.sentinelle:
        return 'Sentinelle';
      case Role.recuperateur:
        return 'Récupérateur';
      case Role.regulateur:
        return 'Meneur en retrait';
      case Role.boxToBox:
        return 'Box-to-box';
      case Role.organisateur:
        return 'Organisateur';
      case Role.relayeur:
        return 'Relayeur';
      case Role.milieuRecup:
        return 'Milieu récupérateur';
      case Role.meneurAvance:
        return 'Meneur de jeu avancé';
      case Role.secondAttaquant:
        return 'Second attaquant';
      case Role.createur:
        return 'Créateur';
      case Role.ailierClassique:
        return 'Ailier classique';
      case Role.ailierInterieur:
        return 'Ailier intérieur';
      case Role.attaquantInterieur:
        return 'Attaquant intérieur';
      case Role.lateralDefensif:
        return 'Latéral défensif';
      case Role.lateralOffensif:
        return 'Latéral offensif';
      case Role.lateralInverse:
        return 'Latéral inversé';
      case Role.renard:
        return 'Renard des surfaces';
      case Role.attaquantComplet:
        return 'Attaquant complet';
      case Role.pivot:
        return 'Pivot';
      case Role.profondeur:
        return 'Attaquant en profondeur';
    }
  }

  /// Avancée (en mètres) par rapport au poste de base.
  double get advance {
    switch (this) {
      case Role.sentinelle:
        return -4;
      case Role.recuperateur:
        return -2;
      case Role.regulateur:
        return -3;
      case Role.boxToBox:
        return 4;
      case Role.relayeur:
        return 2;
      case Role.meneurAvance:
        return 4;
      case Role.secondAttaquant:
        return -6;
      case Role.createur:
        return 2;
      case Role.lateralDefensif:
        return -4;
      case Role.lateralOffensif:
        return 7;
      case Role.lateralInverse:
        return -1;
      case Role.renard:
        return 4;
      case Role.pivot:
        return -4;
      case Role.profondeur:
        return 6;
      case Role.ailierInterieur:
        return 1;
      case Role.attaquantInterieur:
        return 3;
      default:
        return 0;
    }
  }

  /// Multiplicateur de l'écart latéral (1 = largeur du poste).
  double get wide {
    switch (this) {
      case Role.ailierClassique:
        return 1.12;
      case Role.lateralOffensif:
        return 1.1;
      case Role.ailierInterieur:
        return 0.55;
      case Role.attaquantInterieur:
        return 0.45;
      case Role.lateralInverse:
        return 0.5;
      case Role.relayeur:
        return 1.15;
      default:
        return 1.0;
    }
  }

  /// Travail défensif (0..1) : replis et couverture.
  double get defWork {
    switch (this) {
      case Role.sentinelle:
      case Role.recuperateur:
      case Role.milieuRecup:
      case Role.lateralDefensif:
        return 0.9;
      case Role.boxToBox:
      case Role.relayeur:
      case Role.lateralInverse:
        return 0.6;
      case Role.regulateur:
      case Role.organisateur:
        return 0.45;
      case Role.createur:
      case Role.meneurAvance:
      case Role.renard:
      case Role.profondeur:
        return 0.1;
      default:
        return 0.35;
    }
  }

  /// Créativité : qualité des passes décisives.
  double get playmaking {
    switch (this) {
      case Role.regulateur:
      case Role.organisateur:
      case Role.meneurAvance:
      case Role.createur:
        return 1.3;
      case Role.pivot:
      case Role.attaquantComplet:
        return 1.1;
      default:
        return 1.0;
    }
  }

  /// Appétit de tir : probabilité d'être choisi pour conclure.
  double get finishing {
    switch (this) {
      case Role.renard:
        return 1.5;
      case Role.profondeur:
      case Role.attaquantInterieur:
        return 1.25;
      case Role.secondAttaquant:
      case Role.boxToBox:
        return 1.1;
      case Role.pivot:
      case Role.sentinelle:
      case Role.recuperateur:
      case Role.lateralDefensif:
        return 0.7;
      default:
        return 1.0;
    }
  }
}

/// Rôles proposés pour chaque poste.
List<Role> rolesFor(Spot spot) {
  switch (spot) {
    case Spot.gb:
      return const [Role.standard];
    case Spot.dc:
      return const [Role.standard, Role.regulateur];
    case Spot.dg:
    case Spot.dd:
    case Spot.pg:
    case Spot.pd:
      return const [
        Role.standard,
        Role.lateralDefensif,
        Role.lateralOffensif,
        Role.lateralInverse,
      ];
    case Spot.mdc:
      return const [Role.standard, Role.sentinelle, Role.recuperateur, Role.regulateur];
    case Spot.mc:
    case Spot.mcg:
    case Spot.mcd:
      return const [
        Role.standard,
        Role.boxToBox,
        Role.organisateur,
        Role.relayeur,
        Role.milieuRecup,
      ];
    case Spot.moc:
      return const [
        Role.standard,
        Role.meneurAvance,
        Role.secondAttaquant,
        Role.createur,
      ];
    case Spot.mg:
    case Spot.md:
    case Spot.ag:
    case Spot.ad:
      return const [
        Role.standard,
        Role.ailierClassique,
        Role.ailierInterieur,
        Role.attaquantInterieur,
      ];
    case Spot.bu:
    case Spot.ac:
    case Spot.bt:
      return const [
        Role.standard,
        Role.renard,
        Role.attaquantComplet,
        Role.pivot,
        Role.profondeur,
      ];
  }
}

/// Consignes individuelles.
enum Instruction {
  none,
  stayBack,
  occasionalForward,
  joinAttack,
  holdPosition,
  getForward,
  coverSpace,
  stayWide,
  cutInside,
  overlap,
  trackBack,
  dropDeep,
  runBehind,
  holdUp,
  pressDefenders,
}

extension InstructionInfo on Instruction {
  String get label {
    switch (this) {
      case Instruction.none:
        return 'Aucune';
      case Instruction.stayBack:
        return 'Rester derrière';
      case Instruction.occasionalForward:
        return 'Monter occasionnellement';
      case Instruction.joinAttack:
        return 'Participer aux attaques';
      case Instruction.holdPosition:
        return 'Rester en position';
      case Instruction.getForward:
        return 'Se projeter';
      case Instruction.coverSpace:
        return 'Couvrir les espaces';
      case Instruction.stayWide:
        return 'Rester sur le côté';
      case Instruction.cutInside:
        return "Revenir dans l'axe";
      case Instruction.overlap:
        return 'Déborder';
      case Instruction.trackBack:
        return 'Revenir défendre';
      case Instruction.dropDeep:
        return 'Décrocher';
      case Instruction.runBehind:
        return 'Prendre la profondeur';
      case Instruction.holdUp:
        return 'Jouer en pivot';
      case Instruction.pressDefenders:
        return 'Presser les défenseurs';
    }
  }

  double get advance {
    switch (this) {
      case Instruction.stayBack:
        return -5;
      case Instruction.occasionalForward:
        return 2;
      case Instruction.joinAttack:
        return 7;
      case Instruction.getForward:
        return 5;
      case Instruction.coverSpace:
        return -3;
      case Instruction.overlap:
        return 4;
      case Instruction.dropDeep:
        return -8;
      case Instruction.runBehind:
        return 7;
      case Instruction.holdUp:
        return -3;
      default:
        return 0;
    }
  }

  double get wide {
    switch (this) {
      case Instruction.stayWide:
      case Instruction.overlap:
        return 1.15;
      case Instruction.cutInside:
        return 0.55;
      default:
        return 1.0;
    }
  }

  double get defWork {
    switch (this) {
      case Instruction.stayBack:
      case Instruction.coverSpace:
      case Instruction.trackBack:
        return 0.35;
      case Instruction.pressDefenders:
        return 0.2;
      case Instruction.joinAttack:
      case Instruction.getForward:
      case Instruction.runBehind:
        return -0.3;
      default:
        return 0;
    }
  }
}

List<Instruction> instructionsFor(Spot spot) {
  switch (spot) {
    case Spot.dg:
    case Spot.dd:
    case Spot.pg:
    case Spot.pd:
      return const [
        Instruction.none,
        Instruction.stayBack,
        Instruction.occasionalForward,
        Instruction.joinAttack,
      ];
    case Spot.mdc:
    case Spot.mc:
    case Spot.mcg:
    case Spot.mcd:
    case Spot.moc:
      return const [
        Instruction.none,
        Instruction.holdPosition,
        Instruction.getForward,
        Instruction.coverSpace,
      ];
    case Spot.mg:
    case Spot.md:
    case Spot.ag:
    case Spot.ad:
      return const [
        Instruction.none,
        Instruction.stayWide,
        Instruction.cutInside,
        Instruction.overlap,
        Instruction.trackBack,
      ];
    case Spot.bu:
    case Spot.ac:
    case Spot.bt:
      return const [
        Instruction.none,
        Instruction.dropDeep,
        Instruction.runBehind,
        Instruction.holdUp,
        Instruction.pressDefenders,
      ];
    default:
      return const [Instruction.none];
  }
}
