const int topDivision = 1;
const int lowestDivision = 4;
const int promotionSpots = 2;
const int relegationSpots = 3;

String divisionName(int division) {
  switch (division) {
    case 1:
      return 'Première division';
    case 2:
      return 'Division 2';
    case 3:
      return 'Division 3';
    default:
      return 'Championnat amateur';
  }
}

/// Niveau moyen des clubs adverses d'une division.
double divisionBase(int division) => 50.0 + (lowestDivision - division) * 4.0;

/// Multiplicateur des revenus (affluence, sponsors) selon la division.
double divisionRevenueFactor(int division) {
  switch (division) {
    case 1:
      return 2.6;
    case 2:
      return 1.9;
    case 3:
      return 1.4;
    default:
      return 1.0;
  }
}

enum SeasonOutcome { promoted, relegated, stayed }

SeasonOutcome seasonOutcome({
  required int rank,
  required int division,
  int clubCount = 20,
}) {
  if (rank <= promotionSpots && division > topDivision) {
    return SeasonOutcome.promoted;
  }
  if (rank > clubCount - relegationSpots && division < lowestDivision) {
    return SeasonOutcome.relegated;
  }
  return SeasonOutcome.stayed;
}

int nextDivision(int division, SeasonOutcome outcome) {
  switch (outcome) {
    case SeasonOutcome.promoted:
      return division - 1;
    case SeasonOutcome.relegated:
      return division + 1;
    case SeasonOutcome.stayed:
      return division;
  }
}
