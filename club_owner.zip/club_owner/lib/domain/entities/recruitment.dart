/// Demande du président au directeur sportif : « ce joueur m'intéresse ».
/// Le président fixe un budget maximum ; le directeur sportif négocie, le
/// manager donne son avis sportif. Le président ne négocie jamais lui-même.
enum RecruitStatus { pending, done, failed, refusedByCoach, cancelled }

class RecruitRequest {
  const RecruitRequest({
    required this.id,
    required this.playerId,
    required this.playerName,
    required this.maxFee,
    required this.season,
    required this.round,
    this.loan = false,
    this.status = RecruitStatus.pending,
    this.attempts = 0,
    this.coachVerdict = 1,
    this.coachNote = '',
    this.report = '',
    this.force = false,
  });

  factory RecruitRequest.fromJson(Map<String, dynamic> j) {
    final st = j['st'] as String?;
    return RecruitRequest(
      id: j['id'] as String,
      playerId: j['p'] as String,
      playerName: j['n'] as String? ?? '',
      maxFee: (j['max'] as num?)?.toInt() ?? 0,
      season: (j['s'] as num?)?.toInt() ?? 1,
      round: (j['r'] as num?)?.toInt() ?? 1,
      loan: j['loan'] as bool? ?? false,
      status: RecruitStatus.values.firstWhere(
        (s) => s.name == st,
        orElse: () => RecruitStatus.pending,
      ),
      attempts: (j['a'] as num?)?.toInt() ?? 0,
      coachVerdict: (j['cv'] as num?)?.toInt() ?? 1,
      coachNote: j['cn'] as String? ?? '',
      report: j['rep'] as String? ?? '',
      force: j['f'] as bool? ?? false,
    );
  }

  final String id;
  final String playerId;
  final String playerName;
  final int maxFee;
  final int season;
  final int round;
  final bool loan;
  final RecruitStatus status;
  final int attempts;

  /// 0 défavorable, 1 réservé, 2 favorable.
  final int coachVerdict;
  final String coachNote;

  /// Dernier compte rendu du directeur sportif.
  final String report;

  /// Le président maintient sa demande malgré l'avis du manager.
  final bool force;

  bool get open => status == RecruitStatus.pending;

  RecruitRequest copyWith({
    int? maxFee,
    RecruitStatus? status,
    int? attempts,
    String? report,
    bool? force,
  }) {
    return RecruitRequest(
      id: id,
      playerId: playerId,
      playerName: playerName,
      maxFee: maxFee ?? this.maxFee,
      season: season,
      round: round,
      loan: loan,
      status: status ?? this.status,
      attempts: attempts ?? this.attempts,
      coachVerdict: coachVerdict,
      coachNote: coachNote,
      report: report ?? this.report,
      force: force ?? this.force,
    );
  }

  Map<String, Object?> toJson() => {
        'id': id,
        'p': playerId,
        'n': playerName,
        'max': maxFee,
        's': season,
        'r': round,
        if (loan) 'loan': true,
        'st': status.name,
        'a': attempts,
        'cv': coachVerdict,
        if (coachNote.isNotEmpty) 'cn': coachNote,
        if (report.isNotEmpty) 'rep': report,
        if (force) 'f': true,
      };
}
