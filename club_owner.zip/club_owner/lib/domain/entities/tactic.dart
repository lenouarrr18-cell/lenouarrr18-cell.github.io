import 'player.dart';
import 'spots.dart';
import 'team_strength.dart';

enum Formation { f442, f433, f352, f532, f451, f343 }

extension FormationInfo on Formation {
  String get label {
    switch (this) {
      case Formation.f442:
        return '4-4-2';
      case Formation.f433:
        return '4-3-3';
      case Formation.f352:
        return '3-5-2';
      case Formation.f532:
        return '5-3-2';
      case Formation.f451:
        return '4-5-1';
      case Formation.f343:
        return '3-4-3';
    }
  }

  /// Nombre de titulaires par ligne, déduit de la disposition réelle.
  Map<PlayerPosition, int> get slots {
    final out = {for (final p in PlayerPosition.values) p: 0};
    for (final slot in layoutOf(this)) {
      out[slot.spot.line] = out[slot.spot.line]! + 1;
    }
    return out;
  }

  double get attackMod {
    switch (this) {
      case Formation.f433:
        return 1.02;
      case Formation.f343:
        return 1.03;
      case Formation.f532:
        return 0.98;
      case Formation.f451:
        return 0.98;
      default:
        return 1.0;
    }
  }

  double get midfieldMod {
    switch (this) {
      case Formation.f352:
        return 1.02;
      case Formation.f451:
        return 1.02;
      case Formation.f343:
        return 0.98;
      default:
        return 1.0;
    }
  }

  double get defenseMod {
    switch (this) {
      case Formation.f532:
        return 1.03;
      case Formation.f451:
        return 1.01;
      case Formation.f343:
        return 0.97;
      case Formation.f433:
        return 0.99;
      default:
        return 1.0;
    }
  }

  String get description {
    switch (this) {
      case Formation.f442:
        return 'Équilibrée, deux attaquants.';
      case Formation.f433:
        return 'Offensive, trois attaquants, défense un peu exposée.';
      case Formation.f352:
        return 'Milieu fort, trois défenseurs.';
      case Formation.f532:
        return 'Très solide derrière, moins offensive.';
      case Formation.f451:
        return 'Contrôle du milieu, un seul attaquant.';
      case Formation.f343:
        return 'Très offensive, défense fragile.';
    }
  }
}

/// Mentalité de l'équipe (les deux dernières valeurs sont ajoutées en fin
/// pour rester compatibles avec les anciennes sauvegardes).
enum TacticStyle { defensive, balanced, attacking, veryDefensive, veryAttacking }

enum Pressing { low, medium, high, veryHigh }

enum PlayStyle {
  balanced,
  possession,
  direct,
  counter,
  intensePress,
  wings,
  central,
  fastTransition,
}

enum Transition { keepBall, counter, regroup, counterPress }

extension TacticStyleInfo on TacticStyle {
  String get label {
    switch (this) {
      case TacticStyle.veryDefensive:
        return 'Très défensive';
      case TacticStyle.defensive:
        return 'Défensive';
      case TacticStyle.balanced:
        return 'Équilibrée';
      case TacticStyle.attacking:
        return 'Offensive';
      case TacticStyle.veryAttacking:
        return 'Très offensive';
    }
  }

  /// Valeur de -2 (très défensive) à 2 (très offensive).
  int get level {
    switch (this) {
      case TacticStyle.veryDefensive:
        return -2;
      case TacticStyle.defensive:
        return -1;
      case TacticStyle.balanced:
        return 0;
      case TacticStyle.attacking:
        return 1;
      case TacticStyle.veryAttacking:
        return 2;
    }
  }

  static const List<TacticStyle> ordered = [
    TacticStyle.veryDefensive,
    TacticStyle.defensive,
    TacticStyle.balanced,
    TacticStyle.attacking,
    TacticStyle.veryAttacking,
  ];
}

extension PressingInfo on Pressing {
  String get label {
    switch (this) {
      case Pressing.low:
        return 'Bloc bas';
      case Pressing.medium:
        return 'Pressing médian';
      case Pressing.high:
        return 'Pressing haut';
      case Pressing.veryHigh:
        return 'Pressing très intense';
    }
  }

  static const List<Pressing> ordered = [
    Pressing.low,
    Pressing.medium,
    Pressing.high,
    Pressing.veryHigh,
  ];
}

extension PlayStyleInfo on PlayStyle {
  String get label {
    switch (this) {
      case PlayStyle.balanced:
        return 'Standard';
      case PlayStyle.possession:
        return 'Possession';
      case PlayStyle.direct:
        return 'Jeu direct';
      case PlayStyle.counter:
        return 'Contre-attaque';
      case PlayStyle.intensePress:
        return 'Pressing intense';
      case PlayStyle.wings:
        return 'Jeu sur les ailes';
      case PlayStyle.central:
        return 'Jeu axial';
      case PlayStyle.fastTransition:
        return 'Transitions rapides';
    }
  }
}

extension TransitionInfo on Transition {
  String get label {
    switch (this) {
      case Transition.keepBall:
        return 'Conserver le ballon';
      case Transition.counter:
        return 'Contre-attaquer';
      case Transition.regroup:
        return 'Se replacer';
      case Transition.counterPress:
        return 'Contre-presser';
    }
  }
}

const List<String> lineHeightLabels = [
  'Très basse',
  'Basse',
  'Standard',
  'Haute',
  'Très haute',
];

const List<String> widthLabels = [
  'Très étroite',
  'Étroite',
  'Équilibrée',
  'Large',
  'Très large',
];

/// Plan de jeu du club : formation, mentalité, style, pressing, ligne
/// défensive, largeur, transitions, rôles et consignes individuelles.
class Tactic {
  const Tactic({
    this.formation = Formation.f442,
    this.style = TacticStyle.balanced,
    this.pressing = Pressing.medium,
    this.playStyle = PlayStyle.balanced,
    this.lineHeight = 2,
    this.width = 2,
    this.transition = Transition.keepBall,
    this.roles = const {},
    this.instructions = const {},
    this.presets = const [],
  });

  factory Tactic.fromJson(Map<String, dynamic> json) {
    T pick<T extends Enum>(List<T> values, String key, T fallback) {
      final name = json[key] as String?;
      if (name == null) return fallback;
      for (final v in values) {
        if (v.name == name) return v;
      }
      return fallback;
    }

    Map<String, String> strMap(String key) {
      final raw = json[key] as Map<String, dynamic>?;
      if (raw == null) return const {};
      return {for (final e in raw.entries) e.key: e.value as String};
    }

    return Tactic(
      formation: pick(Formation.values, 'formation', Formation.f442),
      style: pick(TacticStyle.values, 'style', TacticStyle.balanced),
      pressing: pick(Pressing.values, 'pressing', Pressing.medium),
      playStyle: pick(PlayStyle.values, 'playStyle', PlayStyle.balanced),
      lineHeight: (json['lineHeight'] as int? ?? 2).clamp(0, 4).toInt(),
      width: (json['width'] as int? ?? 2).clamp(0, 4).toInt(),
      transition: pick(Transition.values, 'transition', Transition.keepBall),
      roles: strMap('roles'),
      instructions: strMap('instructions'),
      presets: [
        for (final raw in (json['presets'] as List<dynamic>? ?? const []))
          Tactic.fromJson(raw as Map<String, dynamic>),
      ],
    );
  }

  final Formation formation;
  final TacticStyle style;
  final Pressing pressing;
  final PlayStyle playStyle;

  /// Hauteur de la ligne défensive et largeur : de 0 à 4 (2 = standard).
  final int lineHeight;
  final int width;
  final Transition transition;

  /// Rôle et consigne par numéro de poste dans la disposition (« 5 » ->
  /// nom du rôle). Les réglages sont liés au poste, pas au joueur : le
  /// coach peut faire tourner l'effectif sans les perdre.
  final Map<String, String> roles;
  final Map<String, String> instructions;

  /// Trois configurations enregistrées : principale, offensive, défensive.
  final List<Tactic> presets;

  Role roleAt(int slot) {
    final name = roles['$slot'];
    if (name == null) return Role.standard;
    for (final r in Role.values) {
      if (r.name == name) return r;
    }
    return Role.standard;
  }

  Instruction instructionAt(int slot) {
    final name = instructions['$slot'];
    if (name == null) return Instruction.none;
    for (final r in Instruction.values) {
      if (r.name == name) return r;
    }
    return Instruction.none;
  }

  Tactic withRole(int slot, Role role) {
    final next = {...roles};
    if (role == Role.standard) {
      next.remove('$slot');
    } else {
      next['$slot'] = role.name;
    }
    return copyWith(roles: next);
  }

  Tactic withInstruction(int slot, Instruction instruction) {
    final next = {...instructions};
    if (instruction == Instruction.none) {
      next.remove('$slot');
    } else {
      next['$slot'] = instruction.name;
    }
    return copyWith(instructions: next);
  }

  Tactic copyWith({
    Formation? formation,
    TacticStyle? style,
    Pressing? pressing,
    PlayStyle? playStyle,
    int? lineHeight,
    int? width,
    Transition? transition,
    Map<String, String>? roles,
    Map<String, String>? instructions,
    List<Tactic>? presets,
  }) {
    final changedFormation = formation != null && formation != this.formation;
    return Tactic(
      formation: formation ?? this.formation,
      style: style ?? this.style,
      pressing: pressing ?? this.pressing,
      playStyle: playStyle ?? this.playStyle,
      lineHeight: lineHeight ?? this.lineHeight,
      width: width ?? this.width,
      transition: transition ?? this.transition,
      // Une autre formation = d'autres postes : les rôles sont remis à zéro.
      roles: roles ?? (changedFormation ? const {} : this.roles),
      instructions:
          instructions ?? (changedFormation ? const {} : this.instructions),
      presets: presets ?? this.presets,
    );
  }

  /// Applique le plan de jeu à la force brute de l'équipe.
  TeamStrength applyTo(TeamStrength base) {
    var attack = formation.attackMod;
    var midfield = formation.midfieldMod;
    var defense = formation.defenseMod;

    final m = style.level;
    attack *= 1 + 0.025 * m;
    defense *= 1 - 0.02 * m;

    switch (pressing) {
      case Pressing.low:
        defense *= 1.02;
        attack *= 0.99;
        break;
      case Pressing.high:
        midfield *= 1.03;
        defense *= 0.99;
        break;
      case Pressing.veryHigh:
        midfield *= 1.05;
        defense *= 0.98;
        break;
      case Pressing.medium:
        break;
    }

    switch (playStyle) {
      case PlayStyle.possession:
        midfield *= 1.03;
        break;
      case PlayStyle.direct:
        attack *= 1.02;
        midfield *= 0.99;
        break;
      case PlayStyle.counter:
        attack *= 1.01;
        defense *= 1.01;
        break;
      case PlayStyle.intensePress:
        midfield *= 1.02;
        break;
      case PlayStyle.wings:
      case PlayStyle.central:
      case PlayStyle.fastTransition:
      case PlayStyle.balanced:
        break;
    }

    // Ligne haute : plus de contrôle mais plus exposée ; basse : l'inverse.
    final h = lineHeight - 2;
    midfield *= 1 + 0.01 * h;
    defense *= 1 - 0.012 * h;

    return TeamStrength(
      attack: base.attack * attack,
      midfield: base.midfield * midfield,
      defense: base.defense * defense,
      goalkeeper: base.goalkeeper,
    );
  }

  Map<String, Object?> toJson() {
    return {
      'formation': formation.name,
      'style': style.name,
      'pressing': pressing.name,
      if (playStyle != PlayStyle.balanced) 'playStyle': playStyle.name,
      if (lineHeight != 2) 'lineHeight': lineHeight,
      if (width != 2) 'width': width,
      if (transition != Transition.keepBall) 'transition': transition.name,
      if (roles.isNotEmpty) 'roles': roles,
      if (instructions.isNotEmpty) 'instructions': instructions,
      if (presets.isNotEmpty) 'presets': [for (final p in presets) p.toJson()],
    };
  }
}
