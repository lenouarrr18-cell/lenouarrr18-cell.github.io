import 'recruitment.dart';

export 'recruitment.dart';

enum InfraKind {
  stadium,
  training,
  academy,
  fanZone,
  parking,
  shop,
  medical,
  recruitment,
  vip,
  // Ajoutés ensuite : leur niveau est stocké dans OwnerState.levels.
  youth,
  rehab,
  fitness,
  analysis,
  complex,
  pitch,
  lighting,
  screens,
  roof,
  restaurant,
  boxes,
  ads,
  museum,
  mall,
  partners,
  hq,
  conference,
  hrCenter,
  operations,
  commercial,
}

/// Nombre maximum de messages gardés dans la messagerie.
const int maxInboxMessages = 60;

/// Travaux en cours sur une infrastructure.
class InfraWork {
  const InfraWork({
    required this.kind,
    required this.targetLevel,
    required this.roundsLeft,
  });

  factory InfraWork.fromJson(Map<String, dynamic> json) {
    return InfraWork(
      kind: InfraKind.values.byName(json['kind'] as String),
      targetLevel: json['targetLevel'] as int,
      roundsLeft: json['roundsLeft'] as int,
    );
  }

  final InfraKind kind;
  final int targetLevel;
  final int roundsLeft;

  InfraWork copyWith({int? roundsLeft}) {
    return InfraWork(
      kind: kind,
      targetLevel: targetLevel,
      roundsLeft: roundsLeft ?? this.roundsLeft,
    );
  }

  Map<String, Object?> toJson() {
    return {
      'kind': kind.name,
      'targetLevel': targetLevel,
      'roundsLeft': roundsLeft,
    };
  }
}

/// Contrat de sponsor principal (ou offre de contrat).
class SponsorDeal {
  const SponsorDeal({
    required this.id,
    required this.name,
    required this.perSeason,
    required this.seasonsLeft,
    required this.bonus,
    required this.targetRank,
  });

  factory SponsorDeal.fromJson(Map<String, dynamic> json) {
    return SponsorDeal(
      id: json['id'] as String,
      name: json['name'] as String,
      perSeason: json['perSeason'] as int,
      seasonsLeft: json['seasonsLeft'] as int,
      bonus: json['bonus'] as int,
      targetRank: json['targetRank'] as int,
    );
  }

  final String id;
  final String name;

  /// Somme versée par saison.
  final int perSeason;
  final int seasonsLeft;

  /// Prime versée si le club termine au moins [targetRank] (0 = aucune).
  final int bonus;
  final int targetRank;

  SponsorDeal copyWith({int? seasonsLeft}) {
    return SponsorDeal(
      id: id,
      name: name,
      perSeason: perSeason,
      seasonsLeft: seasonsLeft ?? this.seasonsLeft,
      bonus: bonus,
      targetRank: targetRank,
    );
  }

  Map<String, Object?> toJson() {
    return {
      'id': id,
      'name': name,
      'perSeason': perSeason,
      'seasonsLeft': seasonsLeft,
      'bonus': bonus,
      'targetRank': targetRank,
    };
  }
}

/// Un message reçu par le président du club.
class InboxMessage {
  const InboxMessage({
    required this.title,
    required this.body,
    required this.season,
    required this.round,
    this.read = false,
    this.sender = 'system',
    this.archived = false,
  });

  factory InboxMessage.fromJson(Map<String, dynamic> json) {
    return InboxMessage(
      title: json['title'] as String,
      body: json['body'] as String,
      season: json['season'] as int,
      round: json['round'] as int,
      read: json['read'] as bool? ?? false,
      sender: json['sender'] as String? ?? 'system',
      archived: json['arch'] as bool? ?? false,
    );
  }

  final String title;
  final String body;
  final int season;
  final int round;
  final bool read;

  /// Expéditeur : system, ds, manager, finance, academy, medical,
  /// commercial, supporters, board.
  final String sender;

  /// Rangé dans les archives (conservé, hors de la boîte de réception).
  final bool archived;

  InboxMessage asRead() => withFlags(read: true);

  InboxMessage withFlags({bool? read, bool? archived}) {
    return InboxMessage(
      title: title,
      body: body,
      season: season,
      round: round,
      read: read ?? this.read,
      sender: sender,
      archived: archived ?? this.archived,
    );
  }

  Map<String, Object?> toJson() {
    return {
      'title': title,
      'body': body,
      'season': season,
      'round': round,
      'read': read,
      'sender': sender,
      if (archived) 'arch': true,
    };
  }
}

/// Décision préparée par la direction sportive, que le président peut
/// bloquer avant son exécution (droit de veto).
class PendingDecision {
  const PendingDecision({
    required this.id,
    required this.kind,
    required this.playerId,
    required this.playerName,
    required this.text,
    required this.season,
    required this.executeRound,
    this.amount = 0,
    this.offerId = '',
  });

  factory PendingDecision.fromJson(Map<String, dynamic> json) {
    return PendingDecision(
      id: json['id'] as String,
      kind: json['kind'] as String,
      playerId: json['playerId'] as String,
      playerName: json['playerName'] as String,
      text: json['text'] as String,
      season: json['season'] as int,
      executeRound: json['executeRound'] as int,
      amount: json['amount'] as int? ?? 0,
      offerId: json['offerId'] as String? ?? '',
    );
  }

  final String id;

  /// 'release' (libération) ou 'sell' (vente).
  final String kind;
  final String playerId;
  final String playerName;
  final String text;
  final int season;
  final int executeRound;
  final int amount;
  final String offerId;

  Map<String, Object?> toJson() {
    return {
      'id': id,
      'kind': kind,
      'playerId': playerId,
      'playerName': playerName,
      'text': text,
      'season': season,
      'executeRound': executeRound,
      'amount': amount,
      'offerId': offerId,
    };
  }
}

/// Nombre maximal de titres de journaux gardés.
const int maxNewsItems = 80;

/// Catégories de gros titres.
enum NewsKind { match, transfer, press, locker, club, world, award }

/// Un gros titre de la presse sportive.
class NewsItem {
  const NewsItem({
    required this.headline,
    required this.body,
    required this.season,
    required this.round,
    this.kind = NewsKind.club,
  });

  factory NewsItem.fromJson(Map<String, dynamic> json) {
    final kindName = json['kind'] as String?;
    return NewsItem(
      headline: json['headline'] as String,
      body: json['body'] as String? ?? '',
      season: json['season'] as int,
      round: json['round'] as int,
      kind: kindName == null
          ? NewsKind.club
          : NewsKind.values.byName(kindName),
    );
  }

  final String headline;
  final String body;
  final int season;
  final int round;
  final NewsKind kind;

  Map<String, Object?> toJson() {
    return {
      'headline': headline,
      'body': body,
      'season': season,
      'round': round,
      'kind': kind.name,
    };
  }
}

/// Réponse possible à une question de la presse.
class PressOption {
  const PressOption({
    required this.label,
    required this.fanMood,
    required this.reputation,
    required this.teamMood,
    required this.headline,
  });

  factory PressOption.fromJson(Map<String, dynamic> json) {
    return PressOption(
      label: json['label'] as String,
      fanMood: json['fanMood'] as int,
      reputation: json['reputation'] as int,
      teamMood: json['teamMood'] as int,
      headline: json['headline'] as String,
    );
  }

  final String label;
  final int fanMood;
  final int reputation;
  final int teamMood;
  final String headline;

  Map<String, Object?> toJson() {
    return {
      'label': label,
      'fanMood': fanMood,
      'reputation': reputation,
      'teamMood': teamMood,
      'headline': headline,
    };
  }
}

/// Question posée au président après un match.
class PressQuestion {
  const PressQuestion({
    required this.question,
    required this.context,
    required this.options,
    required this.season,
    required this.round,
  });

  factory PressQuestion.fromJson(Map<String, dynamic> json) {
    return PressQuestion(
      question: json['question'] as String,
      context: json['context'] as String,
      options: [
        for (final raw in json['options'] as List<dynamic>)
          PressOption.fromJson(raw as Map<String, dynamic>),
      ],
      season: json['season'] as int,
      round: json['round'] as int,
    );
  }

  final String question;
  final String context;
  final List<PressOption> options;
  final int season;
  final int round;

  Map<String, Object?> toJson() {
    return {
      'question': question,
      'context': context,
      'options': [for (final o in options) o.toJson()],
      'season': season,
      'round': round,
    };
  }
}

/// Tout ce qui fait de vous un propriétaire : infrastructures, sponsor,
/// dette, réputation, confiance du conseil et messagerie.
class OwnerState {
  const OwnerState({
    this.stadium = 1,
    this.training = 1,
    this.academy = 1,
    this.work,
    this.deal,
    this.debt = 0,
    this.loanPerRound = 0,
    this.reputation = 20,
    this.confidence = 60,
    this.objectiveRank = 0,
    this.inbox = const [],
    this.fanZone = 0,
    this.parking = 0,
    this.shop = 0,
    this.stadiumName = '',
    this.fanMood = 60,
    this.difficulty = 1,
    this.followers = 0,
    this.lastPostRound = 0,
    this.news = const [],
    this.press,
    this.delegate = true,
    this.decisions = const [],
    this.dsTrust = 60,
    this.managerTrust = 60,
    this.tension = 0,
    this.vetoCount = 0,
    this.tipsEnabled = true,
    this.seenTips = const [],
    this.missionsDone = const [],
    this.financeHistory = const [],
    this.confidenceHistory = const [],
    this.medical = 0,
    this.recruitment = 0,
    this.vip = 0,
    this.introDone = false,
    this.goalsDone = const [],
    this.adviceSeen = const [],
    this.soldFor = 0,
    this.levels = const {},
    this.extraWorks = const [],
    this.infraLog = const [],
    this.seatColor = 0,
    this.recruits = const [],
    this.transferBudget = 0,
    this.wageBudget = 0,
    this.transferSpent = 0,
    this.spentSeason = 0,
    this.sellList = const [],
  });

  factory OwnerState.fromJson(Map<String, dynamic> json) {
    final work = json['work'];
    final deal = json['deal'];
    return OwnerState(
      stadium: json['stadium'] as int? ?? 1,
      training: json['training'] as int? ?? 1,
      academy: json['academy'] as int? ?? 1,
      work: work == null
          ? null
          : InfraWork.fromJson(work as Map<String, dynamic>),
      deal: deal == null
          ? null
          : SponsorDeal.fromJson(deal as Map<String, dynamic>),
      debt: json['debt'] as int? ?? 0,
      loanPerRound: json['loanPerRound'] as int? ?? 0,
      reputation: json['reputation'] as int? ?? 20,
      confidence: json['confidence'] as int? ?? 60,
      objectiveRank: json['objectiveRank'] as int? ?? 0,
      inbox: [
        for (final raw in (json['inbox'] as List<dynamic>? ?? const <dynamic>[]))
          InboxMessage.fromJson(raw as Map<String, dynamic>),
      ],
      fanZone: json['fanZone'] as int? ?? 0,
      parking: json['parking'] as int? ?? 0,
      shop: json['shop'] as int? ?? 0,
      stadiumName: json['stadiumName'] as String? ?? '',
      fanMood: json['fanMood'] as int? ?? 60,
      difficulty: json['difficulty'] as int? ?? 1,
      followers: json['followers'] as int? ?? 0,
      lastPostRound: json['lastPostRound'] as int? ?? 0,
      news: [
        for (final raw in (json['news'] as List<dynamic>? ?? const <dynamic>[]))
          NewsItem.fromJson(raw as Map<String, dynamic>),
      ],
      press: json['press'] == null
          ? null
          : PressQuestion.fromJson(json['press'] as Map<String, dynamic>),
      delegate: json['delegate'] as bool? ?? true,
      decisions: [
        for (final raw
            in (json['decisions'] as List<dynamic>? ?? const <dynamic>[]))
          PendingDecision.fromJson(raw as Map<String, dynamic>),
      ],
      dsTrust: json['dsTrust'] as int? ?? 60,
      managerTrust: json['managerTrust'] as int? ?? 60,
      tension: json['tension'] as int? ?? 0,
      vetoCount: json['vetoCount'] as int? ?? 0,
      tipsEnabled: json['tipsEnabled'] as bool? ?? true,
      seenTips: [
        for (final raw
            in (json['seenTips'] as List<dynamic>? ?? const <dynamic>[]))
          raw as String,
      ],
      missionsDone: [
        for (final raw
            in (json['missionsDone'] as List<dynamic>? ?? const <dynamic>[]))
          raw as String,
      ],
      financeHistory: [
        for (final raw
            in (json['financeHistory'] as List<dynamic>? ?? const <dynamic>[]))
          (raw as num).toInt(),
      ],
      medical: json['medical'] as int? ?? 0,
      recruitment: json['recruitment'] as int? ?? 0,
      vip: json['vip'] as int? ?? 0,
      introDone: json['introDone'] as bool? ?? false,
      soldFor: json['soldFor'] as int? ?? 0,
      seatColor: json['seatColor'] as int? ?? 0,
      transferBudget: (json['tBudget'] as num?)?.toInt() ?? 0,
      wageBudget: (json['wBudget'] as num?)?.toInt() ?? 0,
      transferSpent: (json['tSpent'] as num?)?.toInt() ?? 0,
      spentSeason: (json['tSpentS'] as num?)?.toInt() ?? 0,
      sellList: [
        for (final x in (json['sellList'] as List<dynamic>? ?? const []))
          x as String,
      ],
      recruits: [
        for (final raw
            in (json['recruits'] as List<dynamic>? ?? const <dynamic>[]))
          RecruitRequest.fromJson(raw as Map<String, dynamic>),
      ],
      levels: {
        for (final e in ((json['levels'] as Map<String, dynamic>?) ??
                const <String, dynamic>{})
            .entries)
          e.key: (e.value as num).toInt(),
      },
      extraWorks: [
        for (final raw
            in (json['extraWorks'] as List<dynamic>? ?? const <dynamic>[]))
          InfraWork.fromJson(raw as Map<String, dynamic>),
      ],
      infraLog: [
        for (final raw
            in (json['infraLog'] as List<dynamic>? ?? const <dynamic>[]))
          raw as String,
      ],
      goalsDone: [
        for (final raw
            in (json['goalsDone'] as List<dynamic>? ?? const <dynamic>[]))
          raw as String,
      ],
      adviceSeen: [
        for (final raw
            in (json['adviceSeen'] as List<dynamic>? ?? const <dynamic>[]))
          raw as String,
      ],
      confidenceHistory: [
        for (final raw
            in (json['confidenceHistory'] as List<dynamic>? ??
                const <dynamic>[]))
          (raw as num).toInt(),
      ],
    );
  }

  final int stadium;
  final int training;
  final int academy;
  final InfraWork? work;
  final SponsorDeal? deal;

  /// Dette restante (intérêts compris).
  final int debt;
  final int loanPerRound;

  /// De 0 à 100.
  final int reputation;

  /// Confiance du conseil, de 0 à 100.
  final int confidence;

  /// Place minimale attendue par le conseil (0 = à calculer).
  final int objectiveRank;

  /// Messages, du plus récent au plus ancien.
  final List<InboxMessage> inbox;

  final int fanZone;
  final int parking;
  final int shop;
  final String stadiumName;

  /// Humeur des supporters, de 0 à 100.
  final int fanMood;

  /// 0 facile, 1 normal, 2 difficile.
  final int difficulty;

  /// Abonnés du compte du club sur le réseau social.
  final int followers;

  /// Dernière journée où le président a publié un message.
  final int lastPostRound;

  /// Gros titres de la presse, du plus récent au plus ancien.
  final List<NewsItem> news;

  /// Question de la presse en attente de réponse.
  final PressQuestion? press;

  /// Le directeur sportif gère seul les affaires courantes.
  final bool delegate;

  /// Décisions de la direction en attente (veto possible).
  final List<PendingDecision> decisions;

  /// Confiance du directeur sportif et du manager envers le président.
  final int dsTrust;
  final int managerTrust;

  /// Tensions internes (0 à 100), augmentées par les vetos répétés.
  final int tension;
  final int vetoCount;

  /// Conseils contextuels et missions du tutoriel.
  final bool tipsEnabled;
  final List<String> seenTips;
  final List<String> missionsDone;

  /// Trésorerie relevée à chaque journée (pour les graphiques).
  final List<int> financeHistory;

  /// Confiance du conseil relevée à la fin de chaque saison.
  final List<int> confidenceHistory;

  /// Centre médical, centre de recrutement et installations VIP (0 = absent).
  final int medical;
  final int recruitment;
  final int vip;

  /// Introduction narrative déjà vue.
  final bool introDone;

  /// Montant de la vente du club (0 = vous êtes toujours propriétaire).
  final int soldFor;

  /// Objectifs présidentiels à long terme atteints.
  final List<String> goalsDone;

  /// Historique des conseils déjà donnés (identifiants).
  final List<String> adviceSeen;

  /// Niveaux des bâtiments ajoutés après la première version (nom -> niveau).
  final Map<String, int> levels;

  /// Chantiers supplémentaires menés en parallèle du premier ([work]).
  final List<InfraWork> extraWorks;

  /// Historique des constructions (le plus récent en premier).
  final List<String> infraLog;

  /// Couleur des sièges du stade (indice de palette).
  final int seatColor;

  /// Joueurs signalés par le président au directeur sportif.
  final List<RecruitRequest> recruits;

  /// Budget transferts de la saison fixé par le président (0 = automatique).
  final int transferBudget;

  /// Plafond de la masse salariale annuelle (0 = automatique).
  final int wageBudget;

  /// Dépenses de transferts de la saison [spentSeason].
  final int transferSpent;
  final int spentSeason;

  /// Joueurs que le président souhaite voir vendus par le staff.
  final List<String> sellList;

  /// Tous les chantiers en cours.
  List<InfraWork> get works => [if (work != null) work!, ...extraWorks];

  /// Remplace la liste des chantiers.
  OwnerState withWorks(List<InfraWork> list) {
    return copyWith(
      work: list.isEmpty ? null : list.first,
      clearWork: list.isEmpty,
      extraWorks: list.length > 1 ? list.sublist(1) : const <InfraWork>[],
    );
  }

  OwnerState logInfra(String line) {
    final all = [line, ...infraLog];
    return copyWith(infraLog: all.length > 40 ? all.sublist(0, 40) : all);
  }

  int levelOf(InfraKind kind) {
    switch (kind) {
      case InfraKind.stadium:
        return stadium;
      case InfraKind.training:
        return training;
      case InfraKind.academy:
        return academy;
      case InfraKind.fanZone:
        return fanZone;
      case InfraKind.parking:
        return parking;
      case InfraKind.shop:
        return shop;
      case InfraKind.medical:
        return medical;
      case InfraKind.recruitment:
        return recruitment;
      case InfraKind.vip:
        return vip;
      default:
        return levels[kind.name] ?? 0;
    }
  }

  int get unreadCount => inbox.where((m) => !m.read && !m.archived).length;

  OwnerState copyWith({
    int? stadium,
    int? training,
    int? academy,
    InfraWork? work,
    bool clearWork = false,
    SponsorDeal? deal,
    bool clearDeal = false,
    int? debt,
    int? loanPerRound,
    int? reputation,
    int? confidence,
    int? objectiveRank,
    List<InboxMessage>? inbox,
    int? fanZone,
    int? parking,
    int? shop,
    String? stadiumName,
    int? fanMood,
    int? difficulty,
    int? followers,
    int? lastPostRound,
    List<NewsItem>? news,
    PressQuestion? press,
    bool clearPress = false,
    bool? delegate,
    List<PendingDecision>? decisions,
    int? dsTrust,
    int? managerTrust,
    int? tension,
    int? vetoCount,
    bool? tipsEnabled,
    List<String>? seenTips,
    List<String>? missionsDone,
    List<int>? financeHistory,
    List<int>? confidenceHistory,
    int? medical,
    int? recruitment,
    int? vip,
    bool? introDone,
    List<String>? goalsDone,
    List<String>? adviceSeen,
    int? soldFor,
    Map<String, int>? levels,
    List<InfraWork>? extraWorks,
    List<String>? infraLog,
    int? seatColor,
    List<RecruitRequest>? recruits,
    int? transferBudget,
    int? wageBudget,
    int? transferSpent,
    int? spentSeason,
    List<String>? sellList,
  }) {
    return OwnerState(
      stadium: stadium ?? this.stadium,
      training: training ?? this.training,
      academy: academy ?? this.academy,
      work: clearWork ? null : (work ?? this.work),
      deal: clearDeal ? null : (deal ?? this.deal),
      debt: debt ?? this.debt,
      loanPerRound: loanPerRound ?? this.loanPerRound,
      reputation: reputation ?? this.reputation,
      confidence: confidence ?? this.confidence,
      objectiveRank: objectiveRank ?? this.objectiveRank,
      inbox: inbox ?? this.inbox,
      fanZone: fanZone ?? this.fanZone,
      parking: parking ?? this.parking,
      shop: shop ?? this.shop,
      stadiumName: stadiumName ?? this.stadiumName,
      fanMood: fanMood ?? this.fanMood,
      difficulty: difficulty ?? this.difficulty,
      followers: followers ?? this.followers,
      lastPostRound: lastPostRound ?? this.lastPostRound,
      news: news ?? this.news,
      press: clearPress ? null : (press ?? this.press),
      delegate: delegate ?? this.delegate,
      decisions: decisions ?? this.decisions,
      dsTrust: dsTrust ?? this.dsTrust,
      managerTrust: managerTrust ?? this.managerTrust,
      tension: tension ?? this.tension,
      vetoCount: vetoCount ?? this.vetoCount,
      tipsEnabled: tipsEnabled ?? this.tipsEnabled,
      seenTips: seenTips ?? this.seenTips,
      missionsDone: missionsDone ?? this.missionsDone,
      financeHistory: financeHistory ?? this.financeHistory,
      confidenceHistory: confidenceHistory ?? this.confidenceHistory,
      medical: medical ?? this.medical,
      recruitment: recruitment ?? this.recruitment,
      vip: vip ?? this.vip,
      introDone: introDone ?? this.introDone,
      goalsDone: goalsDone ?? this.goalsDone,
      adviceSeen: adviceSeen ?? this.adviceSeen,
      soldFor: soldFor ?? this.soldFor,
      levels: levels ?? this.levels,
      extraWorks: extraWorks ?? this.extraWorks,
      infraLog: infraLog ?? this.infraLog,
      seatColor: seatColor ?? this.seatColor,
      recruits: recruits ?? this.recruits,
      transferBudget: transferBudget ?? this.transferBudget,
      wageBudget: wageBudget ?? this.wageBudget,
      transferSpent: transferSpent ?? this.transferSpent,
      spentSeason: spentSeason ?? this.spentSeason,
      sellList: sellList ?? this.sellList,
    );
  }

  OwnerState withLevel(InfraKind kind, int level) {
    switch (kind) {
      case InfraKind.stadium:
        return copyWith(stadium: level);
      case InfraKind.training:
        return copyWith(training: level);
      case InfraKind.academy:
        return copyWith(academy: level);
      case InfraKind.fanZone:
        return copyWith(fanZone: level);
      case InfraKind.parking:
        return copyWith(parking: level);
      case InfraKind.shop:
        return copyWith(shop: level);
      case InfraKind.medical:
        return copyWith(medical: level);
      case InfraKind.recruitment:
        return copyWith(recruitment: level);
      case InfraKind.vip:
        return copyWith(vip: level);
      default:
        return copyWith(levels: {...levels, kind.name: level});
    }
  }

  OwnerState addMessage(InboxMessage message) {
    final all = [message, ...inbox];
    // Les archives sont gardées : on retire d'abord les plus vieux messages
    // de la boîte de réception.
    while (all.length > maxInboxMessages) {
      final i = all.lastIndexWhere((m) => !m.archived);
      if (i <= 0) {
        all.removeLast();
      } else {
        all.removeAt(i);
      }
    }
    return copyWith(inbox: all);
  }

  /// Change l'état lu ou archivé des messages aux positions [indices].
  OwnerState flagMessages(Set<int> indices, {bool? read, bool? archived}) {
    return copyWith(
      inbox: [
        for (var i = 0; i < inbox.length; i++)
          indices.contains(i)
              ? inbox[i].withFlags(read: read, archived: archived)
              : inbox[i],
      ],
    );
  }

  OwnerState removeMessages(Set<int> indices) {
    return copyWith(
      inbox: [
        for (var i = 0; i < inbox.length; i++)
          if (!indices.contains(i)) inbox[i],
      ],
    );
  }

  OwnerState addNews(NewsItem item) {
    final all = [item, ...news];
    return copyWith(
      news: all.length > maxNewsItems ? all.sublist(0, maxNewsItems) : all,
    );
  }

  OwnerState removeMessageAt(int index) {
    if (index < 0 || index >= inbox.length) return this;
    final all = [...inbox]..removeAt(index);
    return copyWith(inbox: all);
  }

  OwnerState markAllRead() {
    return copyWith(inbox: [for (final m in inbox) m.read ? m : m.asRead()]);
  }

  Map<String, Object?> toJson() {
    return {
      'stadium': stadium,
      'training': training,
      'academy': academy,
      'work': work?.toJson(),
      'deal': deal?.toJson(),
      'debt': debt,
      'loanPerRound': loanPerRound,
      'reputation': reputation,
      'confidence': confidence,
      'objectiveRank': objectiveRank,
      'inbox': [for (final m in inbox) m.toJson()],
      'fanZone': fanZone,
      'parking': parking,
      'shop': shop,
      'stadiumName': stadiumName,
      'fanMood': fanMood,
      'difficulty': difficulty,
      'followers': followers,
      'lastPostRound': lastPostRound,
      'news': [for (final n in news) n.toJson()],
      'press': press?.toJson(),
      'delegate': delegate,
      'decisions': [for (final d in decisions) d.toJson()],
      'dsTrust': dsTrust,
      'managerTrust': managerTrust,
      'tension': tension,
      'vetoCount': vetoCount,
      'tipsEnabled': tipsEnabled,
      'seenTips': seenTips,
      'missionsDone': missionsDone,
      'financeHistory': financeHistory,
      'confidenceHistory': confidenceHistory,
      'medical': medical,
      'recruitment': recruitment,
      'vip': vip,
      'introDone': introDone,
      'goalsDone': goalsDone,
      'adviceSeen': adviceSeen,
      'soldFor': soldFor,
      'levels': levels,
      'extraWorks': [for (final w in extraWorks) w.toJson()],
      'infraLog': infraLog,
      'seatColor': seatColor,
      'recruits': [for (final r in recruits) r.toJson()],
      'tBudget': transferBudget,
      'wBudget': wageBudget,
      'tSpent': transferSpent,
      'tSpentS': spentSeason,
      'sellList': sellList,
    };
  }
}
