/// Une distinction individuelle attribuée en fin de saison.
class AwardRecord {
  const AwardRecord({
    required this.season,
    required this.category,
    required this.playerName,
    required this.clubName,
    required this.detail,
  });

  factory AwardRecord.fromJson(Map<String, dynamic> json) {
    return AwardRecord(
      season: json['season'] as int,
      category: json['category'] as String,
      playerName: json['playerName'] as String,
      clubName: json['clubName'] as String,
      detail: json['detail'] as String,
    );
  }

  final int season;
  final String category;
  final String playerName;
  final String clubName;
  final String detail;

  Map<String, Object?> toJson() {
    return {
      'season': season,
      'category': category,
      'playerName': playerName,
      'clubName': clubName,
      'detail': detail,
    };
  }
}

/// Un joueur retraité conservé dans le débat du GOAT.
class LegendEntry {
  const LegendEntry({
    required this.name,
    required this.nation,
    required this.matches,
    required this.goals,
    required this.assists,
    required this.caps,
    required this.awards,
    required this.peakSkill,
    required this.retiredSeason,
  });

  factory LegendEntry.fromJson(Map<String, dynamic> json) {
    return LegendEntry(
      name: json['name'] as String,
      nation: json['nation'] as String,
      matches: json['matches'] as int,
      goals: json['goals'] as int,
      assists: json['assists'] as int,
      caps: json['caps'] as int,
      awards: json['awards'] as int,
      peakSkill: json['peakSkill'] as int,
      retiredSeason: json['retiredSeason'] as int,
    );
  }

  final String name;
  final String nation;
  final int matches;
  final int goals;
  final int assists;
  final int caps;
  final int awards;
  final int peakSkill;
  final int retiredSeason;

  /// Score utilisé pour classer les plus grands joueurs.
  double get goatScore =>
      goals * 1.0 + assists * 0.7 + caps * 0.5 + awards * 40 + peakSkill * 0.5;

  Map<String, Object?> toJson() {
    return {
      'name': name,
      'nation': nation,
      'matches': matches,
      'goals': goals,
      'assists': assists,
      'caps': caps,
      'awards': awards,
      'peakSkill': peakSkill,
      'retiredSeason': retiredSeason,
    };
  }
}

/// Résultat d'un tournoi de sélections nationales.
class TournamentResult {
  const TournamentResult({
    required this.season,
    required this.name,
    required this.champion,
    required this.runnerUp,
    required this.userPlayers,
  });

  factory TournamentResult.fromJson(Map<String, dynamic> json) {
    return TournamentResult(
      season: json['season'] as int,
      name: json['name'] as String,
      champion: json['champion'] as String,
      runnerUp: json['runnerUp'] as String,
      userPlayers: [
        for (final raw in json['userPlayers'] as List<dynamic>) raw as String,
      ],
    );
  }

  final int season;
  final String name;
  final String champion;
  final String runnerUp;

  /// Joueurs du club du président appelés en sélection.
  final List<String> userPlayers;

  Map<String, Object?> toJson() {
    return {
      'season': season,
      'name': name,
      'champion': champion,
      'runnerUp': runnerUp,
      'userPlayers': userPlayers,
    };
  }
}

/// Un message du réseau social du jeu.
class SocialPost {
  const SocialPost({
    required this.author,
    required this.text,
    required this.likes,
    required this.season,
    required this.round,
    this.isUser = false,
  });

  factory SocialPost.fromJson(Map<String, dynamic> json) {
    return SocialPost(
      author: json['author'] as String,
      text: json['text'] as String,
      likes: json['likes'] as int,
      season: json['season'] as int,
      round: json['round'] as int,
      isUser: json['isUser'] as bool? ?? false,
    );
  }

  final String author;
  final String text;
  final int likes;
  final int season;
  final int round;
  final bool isUser;

  Map<String, Object?> toJson() {
    return {
      'author': author,
      'text': text,
      'likes': likes,
      'season': season,
      'round': round,
      'isUser': isUser,
    };
  }
}
