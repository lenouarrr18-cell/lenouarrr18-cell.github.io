enum StaffRole {
  manager,
  sportingDirector,
  scout,
  coachFirst,
  coachReserve,
  coachAcademy,
  communityManager,
}

/// Un membre du staff recruté par le propriétaire.
class StaffMember {
  const StaffMember({
    required this.id,
    required this.name,
    required this.role,
    required this.level,
  });

  factory StaffMember.fromJson(Map<String, dynamic> json) {
    return StaffMember(
      id: json['id'] as String,
      name: json['name'] as String,
      role: StaffRole.values.byName(json['role'] as String),
      level: json['level'] as int,
    );
  }

  final String id;
  final String name;
  final StaffRole role;

  /// Compétence de 1 à 99.
  final int level;

  Map<String, Object?> toJson() {
    return {'id': id, 'name': name, 'role': role.name, 'level': level};
  }
}
