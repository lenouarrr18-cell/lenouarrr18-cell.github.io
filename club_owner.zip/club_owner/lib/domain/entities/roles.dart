import 'player.dart';

/// Poste détaillé d'un joueur (DC, ArG, MO, AD...). Il est déduit de
/// façon stable de l'identifiant : un même joueur garde toujours le même
/// rôle, sans rien stocker dans la sauvegarde.
enum PlayerRole {
  goalkeeper,
  centreBack,
  leftBack,
  rightBack,
  defensiveMid,
  centralMid,
  attackingMid,
  leftWinger,
  rightWinger,
  striker,
}

int _stableHash(String text) {
  var hash = 5;
  for (final unit in text.codeUnits) {
    hash = (hash * 33 + unit) & 0x3fffffff;
  }
  return hash;
}

PlayerRole roleOf(Player player) {
  final h = _stableHash(player.id) % 10;
  switch (player.position) {
    case PlayerPosition.goalkeeper:
      return PlayerRole.goalkeeper;
    case PlayerPosition.defender:
      if (h < 5) return PlayerRole.centreBack;
      if (h < 8) return PlayerRole.leftBack;
      return PlayerRole.rightBack;
    case PlayerPosition.midfielder:
      if (h < 3) return PlayerRole.defensiveMid;
      if (h < 7) return PlayerRole.centralMid;
      return PlayerRole.attackingMid;
    case PlayerPosition.forward:
      if (h < 5) return PlayerRole.striker;
      if (h < 8) return PlayerRole.leftWinger;
      return PlayerRole.rightWinger;
  }
}

String roleShort(PlayerRole role) {
  switch (role) {
    case PlayerRole.goalkeeper:
      return 'GB';
    case PlayerRole.centreBack:
      return 'DC';
    case PlayerRole.leftBack:
      return 'ArG';
    case PlayerRole.rightBack:
      return 'ArD';
    case PlayerRole.defensiveMid:
      return 'MDC';
    case PlayerRole.centralMid:
      return 'MC';
    case PlayerRole.attackingMid:
      return 'MO';
    case PlayerRole.leftWinger:
      return 'AG';
    case PlayerRole.rightWinger:
      return 'AD';
    case PlayerRole.striker:
      return 'BU';
  }
}

String roleLabel(PlayerRole role) {
  switch (role) {
    case PlayerRole.goalkeeper:
      return 'Gardien';
    case PlayerRole.centreBack:
      return 'Défenseur central';
    case PlayerRole.leftBack:
      return 'Arrière gauche';
    case PlayerRole.rightBack:
      return 'Arrière droit';
    case PlayerRole.defensiveMid:
      return 'Milieu défensif';
    case PlayerRole.centralMid:
      return 'Milieu central';
    case PlayerRole.attackingMid:
      return 'Milieu offensif';
    case PlayerRole.leftWinger:
      return 'Ailier gauche';
    case PlayerRole.rightWinger:
      return 'Ailier droit';
    case PlayerRole.striker:
      return 'Buteur';
  }
}

/// Ordre de gauche à droite sur le terrain.
int roleSide(PlayerRole role) {
  switch (role) {
    case PlayerRole.leftBack:
    case PlayerRole.leftWinger:
      return 0;
    case PlayerRole.rightBack:
    case PlayerRole.rightWinger:
      return 2;
    default:
      return 1;
  }
}

/// Humeur : étiquette et émoji.
String moodLabel(int mood) {
  if (mood >= 80) return 'Épanoui';
  if (mood >= 60) return 'Content';
  if (mood >= 40) return 'Mitigé';
  if (mood >= 25) return 'Frustré';
  return 'Furieux';
}

String moodEmoji(int mood) {
  if (mood >= 80) return '\u{1F604}';
  if (mood >= 60) return '\u{1F642}';
  if (mood >= 40) return '\u{1F610}';
  if (mood >= 25) return '\u{1F61E}';
  return '\u{1F620}';
}
