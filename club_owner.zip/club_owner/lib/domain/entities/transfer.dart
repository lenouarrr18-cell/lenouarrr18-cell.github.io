enum OfferKind { transfer, loan, loanOption }

enum OfferStatus { pending, accepted, countered, rejected }

/// Offre de transfert ou de prêt, envoyée (ou reçue) par le club du joueur.
class Offer {
  const Offer({
    required this.id,
    required this.playerId,
    required this.playerName,
    required this.sellerClubId,
    required this.buyerClubId,
    required this.kind,
    required this.fee,
    required this.status,
    required this.incoming,
    required this.season,
    required this.round,
    this.optionFee = 0,
    this.counterFee = 0,
    this.reason = '',
    this.contractYears = 3,
  });

  factory Offer.fromJson(Map<String, dynamic> json) {
    return Offer(
      id: json['id'] as String,
      playerId: json['playerId'] as String,
      playerName: json['playerName'] as String,
      sellerClubId: json['sellerClubId'] as String,
      buyerClubId: json['buyerClubId'] as String,
      kind: OfferKind.values.byName(json['kind'] as String),
      fee: json['fee'] as int,
      status: OfferStatus.values.byName(json['status'] as String),
      incoming: json['incoming'] as bool,
      season: json['season'] as int,
      round: json['round'] as int,
      optionFee: json['optionFee'] as int? ?? 0,
      counterFee: json['counterFee'] as int? ?? 0,
      reason: json['reason'] as String? ?? '',
      contractYears: json['contractYears'] as int? ?? 3,
    );
  }

  final String id;
  final String playerId;
  final String playerName;
  final String sellerClubId;
  final String buyerClubId;
  final OfferKind kind;

  /// Montant du transfert, ou indemnité de prêt.
  final int fee;
  final OfferStatus status;

  /// `true` si un autre club fait une offre pour un joueur du club du joueur.
  final bool incoming;
  final int season;
  final int round;

  /// Prix d'achat définitif pour un prêt avec option.
  final int optionFee;

  /// Montant demandé par le club vendeur quand il contre-propose.
  final int counterFee;
  final String reason;
  final int contractYears;

  Offer copyWith({
    int? fee,
    OfferStatus? status,
    int? counterFee,
    String? reason,
    int? optionFee,
    int? round,
    int? season,
  }) {
    return Offer(
      id: id,
      playerId: playerId,
      playerName: playerName,
      sellerClubId: sellerClubId,
      buyerClubId: buyerClubId,
      kind: kind,
      fee: fee ?? this.fee,
      status: status ?? this.status,
      incoming: incoming,
      season: season ?? this.season,
      round: round ?? this.round,
      optionFee: optionFee ?? this.optionFee,
      counterFee: counterFee ?? this.counterFee,
      reason: reason ?? this.reason,
      contractYears: contractYears,
    );
  }

  Map<String, Object?> toJson() {
    return {
      'id': id,
      'playerId': playerId,
      'playerName': playerName,
      'sellerClubId': sellerClubId,
      'buyerClubId': buyerClubId,
      'kind': kind.name,
      'fee': fee,
      'status': status.name,
      'incoming': incoming,
      'season': season,
      'round': round,
      'optionFee': optionFee,
      'counterFee': counterFee,
      'reason': reason,
      'contractYears': contractYears,
    };
  }
}

/// Un joueur prêté d'un club à un autre pour la saison.
class LoanDeal {
  const LoanDeal({
    required this.playerId,
    required this.playerName,
    required this.ownerClubId,
    required this.borrowerClubId,
    this.optionFee = 0,
  });

  factory LoanDeal.fromJson(Map<String, dynamic> json) {
    return LoanDeal(
      playerId: json['playerId'] as String,
      playerName: json['playerName'] as String,
      ownerClubId: json['ownerClubId'] as String,
      borrowerClubId: json['borrowerClubId'] as String,
      optionFee: json['optionFee'] as int? ?? 0,
    );
  }

  final String playerId;
  final String playerName;
  final String ownerClubId;
  final String borrowerClubId;

  /// Prix de l'option d'achat (0 = aucune option).
  final int optionFee;

  Map<String, Object?> toJson() {
    return {
      'playerId': playerId,
      'playerName': playerName,
      'ownerClubId': ownerClubId,
      'borrowerClubId': borrowerClubId,
      'optionFee': optionFee,
    };
  }
}

/// Où placer un joueur dans le club.
enum SquadSlot { first, reserve, academy }
