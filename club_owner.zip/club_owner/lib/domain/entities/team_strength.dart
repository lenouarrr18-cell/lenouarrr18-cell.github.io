import 'player.dart';

/// Force d'une équipe par ligne, utilisée par le moteur de match.
class TeamStrength {
  const TeamStrength({
    required this.attack,
    required this.midfield,
    required this.defense,
    required this.goalkeeper,
  });

  /// Calcule la force à partir d'une composition (moyenne par ligne).
  factory TeamStrength.fromPlayers(Iterable<Player> lineup) {
    double lineAverage(PlayerPosition position) {
      final skills = lineup
          .where((p) => p.position == position)
          .map((p) => p.effectiveSkill)
          .toList();
      if (skills.isEmpty) return fallback;
      return skills.reduce((a, b) => a + b) / skills.length;
    }

    return TeamStrength(
      attack: lineAverage(PlayerPosition.forward),
      midfield: lineAverage(PlayerPosition.midfielder),
      defense: lineAverage(PlayerPosition.defender),
      goalkeeper: lineAverage(PlayerPosition.goalkeeper),
    );
  }

  /// Renvoie la force multipliée par [factor] sur toutes les lignes.
  TeamStrength scaled(double factor) {
    return TeamStrength(
      attack: attack * factor,
      midfield: midfield * factor,
      defense: defense * factor,
      goalkeeper: goalkeeper * factor,
    );
  }

  /// Valeur utilisée quand une ligne est vide.
  static const double fallback = 30;

  final double attack;
  final double midfield;
  final double defense;
  final double goalkeeper;
}
