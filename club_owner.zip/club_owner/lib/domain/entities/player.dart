enum PlayerPosition { goalkeeper, defender, midfielder, forward }

class Player {
  const Player({
    required this.id,
    required this.name,
    required this.position,
    required this.skill,
    this.age = 25,
    this.form = 1.0,
    this.potential = 0,
    this.nation = '',
    this.contractYears = 3,
    this.matches = 0,
    this.goals = 0,
    this.assists = 0,
    this.cleanSheets = 0,
    this.careerMatches = 0,
    this.careerGoals = 0,
    this.careerAssists = 0,
    this.caps = 0,
    this.awards = 0,
    this.mood = 70,
    this.wantsOut = false,
    this.fitness = 100,
  }) : assert(skill >= 1 && skill <= 99, 'skill doit être entre 1 et 99');

  factory Player.fromJson(Map<String, dynamic> json) {
    return Player(
      id: json['id'] as String,
      name: json['name'] as String,
      position: PlayerPosition.values.byName(json['position'] as String),
      skill: json['skill'] as int,
      age: json['age'] as int,
      form: (json['form'] as num?)?.toDouble() ?? 1.0,
      potential: json['potential'] as int? ?? 0,
      nation: json['nation'] as String? ?? '',
      contractYears: json['contractYears'] as int? ?? 3,
      matches: json['matches'] as int? ?? 0,
      goals: json['goals'] as int? ?? 0,
      assists: json['assists'] as int? ?? 0,
      cleanSheets: json['cleanSheets'] as int? ?? 0,
      careerMatches: json['careerMatches'] as int? ?? 0,
      careerGoals: json['careerGoals'] as int? ?? 0,
      careerAssists: json['careerAssists'] as int? ?? 0,
      caps: json['caps'] as int? ?? 0,
      awards: json['awards'] as int? ?? 0,
      mood: json['mood'] as int? ?? 70,
      wantsOut: json['wantsOut'] as bool? ?? false,
      fitness: json['fitness'] as int? ?? 100,
    );
  }

  final String id;
  final String name;
  final PlayerPosition position;

  /// Niveau global du joueur, de 1 à 99.
  final int skill;
  final int age;

  /// Forme du moment : 0.8 (mauvaise) à 1.2 (excellente).
  final double form;

  /// Niveau maximal que le joueur peut atteindre (0 = non défini).
  final int potential;
  final String nation;

  /// Années de contrat restantes.
  final int contractYears;

  // Statistiques de la saison en cours.
  final int matches;
  final int goals;
  final int assists;
  final int cleanSheets;

  // Statistiques de carrière (saisons terminées).
  final int careerMatches;
  final int careerGoals;
  final int careerAssists;

  /// Sélections en équipe nationale.
  final int caps;

  /// Distinctions individuelles gagnées.
  final int awards;

  /// Humeur du joueur de 0 à 100 (70 = content).
  final int mood;

  /// Le joueur a demandé à partir.
  final bool wantsOut;

  /// Condition physique de 0 à 100 (100 = frais). Le coach fait tourner
  /// l'effectif selon ce niveau.
  final int fitness;

  double get effectiveSkill => skill * form;

  /// Potentiel utilisable : jamais inférieur au niveau actuel.
  int get maxSkill => potential > skill ? potential : skill;

  int get totalMatches => careerMatches + matches;
  int get totalGoals => careerGoals + goals;
  int get totalAssists => careerAssists + assists;

  Player copyWith({
    String? name,
    int? skill,
    int? age,
    double? form,
    int? potential,
    String? nation,
    int? contractYears,
    int? matches,
    int? goals,
    int? assists,
    int? cleanSheets,
    int? careerMatches,
    int? careerGoals,
    int? careerAssists,
    int? caps,
    int? awards,
    int? mood,
    bool? wantsOut,
    int? fitness,
  }) {
    return Player(
      id: id,
      name: name ?? this.name,
      position: position,
      skill: skill ?? this.skill,
      age: age ?? this.age,
      form: form ?? this.form,
      potential: potential ?? this.potential,
      nation: nation ?? this.nation,
      contractYears: contractYears ?? this.contractYears,
      matches: matches ?? this.matches,
      goals: goals ?? this.goals,
      assists: assists ?? this.assists,
      cleanSheets: cleanSheets ?? this.cleanSheets,
      careerMatches: careerMatches ?? this.careerMatches,
      careerGoals: careerGoals ?? this.careerGoals,
      careerAssists: careerAssists ?? this.careerAssists,
      caps: caps ?? this.caps,
      awards: awards ?? this.awards,
      mood: mood ?? this.mood,
      wantsOut: wantsOut ?? this.wantsOut,
      fitness: fitness ?? this.fitness,
    );
  }

  /// Ajoute les statistiques de la saison à la carrière et les remet à zéro.
  Player closeSeason() {
    return copyWith(
      careerMatches: careerMatches + matches,
      careerGoals: careerGoals + goals,
      careerAssists: careerAssists + assists,
      matches: 0,
      goals: 0,
      assists: 0,
      cleanSheets: 0,
    );
  }

  /// Seuls les champs différents de la valeur par défaut sont écrits :
  /// la sauvegarde reste légère même avec des milliers de joueurs.
  Map<String, Object?> toJson() {
    return {
      'id': id,
      'name': name,
      'position': position.name,
      'skill': skill,
      'age': age,
      if (form != 1.0) 'form': form,
      if (potential != 0) 'potential': potential,
      if (nation.isNotEmpty) 'nation': nation,
      if (contractYears != 3) 'contractYears': contractYears,
      if (matches != 0) 'matches': matches,
      if (goals != 0) 'goals': goals,
      if (assists != 0) 'assists': assists,
      if (cleanSheets != 0) 'cleanSheets': cleanSheets,
      if (careerMatches != 0) 'careerMatches': careerMatches,
      if (careerGoals != 0) 'careerGoals': careerGoals,
      if (careerAssists != 0) 'careerAssists': careerAssists,
      if (caps != 0) 'caps': caps,
      if (awards != 0) 'awards': awards,
      if (mood != 70) 'mood': mood,
      if (wantsOut) 'wantsOut': true,
      if (fitness != 100) 'fitness': fitness,
    };
  }
}
