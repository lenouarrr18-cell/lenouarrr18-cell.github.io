class City {
  const City({
    required this.name,
    required this.population,
    required this.wealth,
  });

  final String name;

  /// Population en milliers d'habitants (valeur de jeu).
  final int population;

  /// Richesse locale de 1 à 10 (valeur de jeu).
  final int wealth;
}

class Country {
  const Country({required this.id, required this.name, required this.cities});

  final String id;
  final String name;
  final List<City> cities;
}
