import 'dart:math';

import 'player.dart';
import 'spots.dart';
import 'tactic.dart';
import 'team_strength.dart';

/// Formation 4-4-2 (seule disposition disponible pour l'instant).
const Map<PlayerPosition, int> startingSlots = {
  PlayerPosition.goalkeeper: 1,
  PlayerPosition.defender: 4,
  PlayerPosition.midfielder: 4,
  PlayerPosition.forward: 2,
};

const int startingXiSize = 11;

const int maxSquadSize = 30;

/// Effectif minimum par poste, pour pouvoir toujours composer une équipe.
const Map<PlayerPosition, int> minSquadByPosition = {
  PlayerPosition.goalkeeper: 2,
  PlayerPosition.defender: 5,
  PlayerPosition.midfielder: 5,
  PlayerPosition.forward: 3,
};

/// Coefficient de condition physique : 1.0 (frais) à 0.8 (épuisé).
double fitnessFactor(int fitness) => 0.8 + 0.2 * (fitness.clamp(0, 100) / 100);

/// Valeur d'un joueur à un poste : niveau, forme, adéquation au poste et
/// fraîcheur. Ce n'est jamais la seule note générale.
double slotScore(Player p, SpotSlot slot) {
  var v = p.skill * p.form * spotFit(p, slot.spot) * fitnessFactor(p.fitness);
  // Un joueur éreinté ne joue que s'il n'y a vraiment pas d'alternative.
  if (p.fitness < 50) v *= 0.92;
  return v;
}

/// Affecte des joueurs aux postes d'une disposition (11 postes) :
/// meilleur joueur disponible par poste, puis échanges et remplacements
/// tant que la valeur totale progresse. Un poste peut rester vide
/// (`null`) si l'effectif est insuffisant.
List<Player?> assignToSlots(List<Player> pool, List<SpotSlot> slots) {
  final n = slots.length;
  final chosen = List<Player?>.filled(n, null);
  final used = <String>{};
  final order = [for (var i = 0; i < n; i++) i]
    ..sort((a, b) {
      final ga = slots[a].spot == Spot.gb ? 0 : 1;
      final gb = slots[b].spot == Spot.gb ? 0 : 1;
      return ga != gb ? ga.compareTo(gb) : a.compareTo(b);
    });
  for (final i in order) {
    Player? best;
    var bestScore = -1.0;
    for (final p in pool) {
      if (used.contains(p.id)) continue;
      final v = slotScore(p, slots[i]);
      if (v > bestScore) {
        bestScore = v;
        best = p;
      }
    }
    if (best != null) {
      chosen[i] = best;
      used.add(best.id);
    }
  }
  for (var pass = 0; pass < 4; pass++) {
    var improved = false;
    for (var i = 0; i < n; i++) {
      for (var j = i + 1; j < n; j++) {
        final a = chosen[i];
        final b = chosen[j];
        if (a == null || b == null) continue;
        final cur = slotScore(a, slots[i]) + slotScore(b, slots[j]);
        final alt = slotScore(b, slots[i]) + slotScore(a, slots[j]);
        if (alt > cur + 1e-6) {
          chosen[i] = b;
          chosen[j] = a;
          improved = true;
        }
      }
    }
    for (var i = 0; i < n; i++) {
      final current = chosen[i];
      var bestScore =
          current == null ? -1.0 : slotScore(current, slots[i]);
      Player? swap;
      for (final p in pool) {
        if (used.contains(p.id)) continue;
        final v = slotScore(p, slots[i]);
        if (v > bestScore + 1e-6) {
          bestScore = v;
          swap = p;
        }
      }
      if (swap != null) {
        if (current != null) used.remove(current.id);
        chosen[i] = swap;
        used.add(swap.id);
        improved = true;
      }
    }
    if (!improved) break;
  }
  return chosen;
}

/// Choisit les titulaires d'une formation (à la manière d'un coach).
List<String> pickBestStarters(
  List<Player> squad, [
  Formation formation = Formation.f442,
]) {
  final chosen = assignToSlots(squad, layoutOf(formation));
  return [for (final p in chosen) if (p != null) p.id];
}

/// Postes de la disposition occupés par les titulaires actuels.
List<Player?> lineupSlots(List<Player> starters, Formation formation) {
  return assignToSlots(starters, layoutOf(formation));
}

/// Force par ligne d'une composition réelle : chaque joueur compte selon
/// son poste, son rôle, son adéquation et sa fraîcheur.
TeamStrength lineupStrength(List<Player> starters, Tactic tactic) {
  final slots = layoutOf(tactic.formation);
  final xi = lineupSlots(starters, tactic.formation);
  var a = 0.0, aw = 0.0, m = 0.0, mw = 0.0, d = 0.0, dw = 0.0;
  var gk = 0.0, gkw = 0.0;
  for (var i = 0; i < slots.length; i++) {
    final p = xi[i];
    if (p == null) continue;
    final q = slotScore(p, slots[i]);
    final role = tactic.roleAt(i);
    var wa = 0.0, wm = 0.0, wd = 0.0;
    switch (slots[i].spot) {
      case Spot.gb:
        gk += q;
        gkw += 1;
        continue;
      case Spot.dc:
        wd = 1;
        break;
      case Spot.dg:
      case Spot.dd:
        wd = 0.85;
        wm = 0.15;
        break;
      case Spot.pg:
      case Spot.pd:
        wd = 0.6;
        wm = 0.3;
        wa = 0.1;
        break;
      case Spot.mdc:
        wd = 0.35;
        wm = 0.65;
        break;
      case Spot.mc:
      case Spot.mcg:
      case Spot.mcd:
        wm = 1;
        break;
      case Spot.moc:
        wm = 0.55;
        wa = 0.45;
        break;
      case Spot.mg:
      case Spot.md:
        wm = 0.6;
        wa = 0.4;
        break;
      case Spot.ag:
      case Spot.ad:
        wa = 0.8;
        wm = 0.2;
        break;
      case Spot.bu:
        wa = 1;
        break;
      case Spot.ac:
      case Spot.bt:
        wa = 0.85;
        wm = 0.15;
        break;
    }
    wa += max(0.0, role.advance) * 0.02;
    wd += role.defWork * 0.08;
    a += q * wa;
    aw += wa;
    m += q * wm;
    mw += wm;
    d += q * wd;
    dw += wd;
  }
  double avg(double sum, double w) => w <= 0 ? TeamStrength.fallback : sum / w;
  return TeamStrength(
    attack: avg(a, aw),
    midfield: avg(m, mw),
    defense: avg(d, dw),
    goalkeeper: avg(gk, gkw),
  );
}

/// Bilan de l'équilibre tactique : calculé à partir des postes, des
/// rôles, des consignes et de la qualité des joueurs.
class TacticalBalance {
  const TacticalBalance({
    required this.total,
    required this.solidity,
    required this.control,
    required this.power,
    required this.notes,
    required this.warnings,
  });

  final int total;
  final int solidity;
  final int control;
  final int power;

  /// Constats (positifs ou à risque) sur la composition.
  final List<String> notes;

  /// Joueurs hors poste ou postes mal couverts.
  final List<String> warnings;
}

TacticalBalance tacticalBalance(List<Player> starters, Tactic tactic) {
  final slots = layoutOf(tactic.formation);
  final xi = lineupSlots(starters, tactic.formation);
  final notes = <String>[];
  final warnings = <String>[];

  var centralBacks = 0;
  var protection = 0;
  var wingers = 0;
  var attackingBacks = 0;
  var midfielders = 0;
  var strikers = 0;
  var creators = 0;
  var qDef = 0.0, nDef = 0, qMid = 0.0, nMid = 0, qAtt = 0.0, nAtt = 0;
  final strikerRoles = <Role>[];

  for (var i = 0; i < slots.length; i++) {
    final s = slots[i].spot;
    final role = tactic.roleAt(i);
    final instr = tactic.instructionAt(i);
    final p = xi[i];
    if (p != null) {
      final q = slotScore(p, slots[i]);
      if (s != Spot.gb) {
        final fit = spotFit(p, s);
        if (fit < 0.8) {
          warnings.add(
            '${p.name} joue hors poste en ${s.label} '
            '(poste naturel : ${naturalSpot(p).label}).',
          );
        }
      }
      switch (s.line) {
        case PlayerPosition.defender:
          qDef += q;
          nDef++;
          break;
        case PlayerPosition.midfielder:
          qMid += q;
          nMid++;
          break;
        case PlayerPosition.forward:
          qAtt += q;
          nAtt++;
          break;
        case PlayerPosition.goalkeeper:
          break;
      }
    } else {
      warnings.add('Poste non couvert : ${s.fullName}.');
    }
    if (s == Spot.dc) centralBacks++;
    if (s == Spot.mdc ||
        role == Role.sentinelle ||
        role == Role.recuperateur ||
        role == Role.milieuRecup) {
      protection++;
    }
    if (s == Spot.ag || s == Spot.ad || s == Spot.mg || s == Spot.md) {
      if (role != Role.ailierInterieur && role != Role.attaquantInterieur) {
        wingers++;
      }
    }
    final isBack =
        s == Spot.dg || s == Spot.dd || s == Spot.pg || s == Spot.pd;
    if (isBack &&
        (role == Role.lateralOffensif ||
            instr == Instruction.joinAttack ||
            instr == Instruction.overlap)) {
      attackingBacks++;
    }
    if (s == Spot.mc || s == Spot.mcg || s == Spot.mcd) midfielders++;
    if (s == Spot.bu || s == Spot.ac || s == Spot.bt) {
      strikers++;
      strikerRoles.add(role);
    }
    if (role.playmaking > 1.2) creators++;
  }

  double avg(double sum, int n) => n == 0 ? 55 : sum / n;
  final dq = (avg(qDef, nDef) - 60) * 0.4;
  final mq = (avg(qMid, nMid) - 60) * 0.4;
  final aq = (avg(qAtt, nAtt) - 60) * 0.4;
  final m = tactic.style.level;

  var solidity = 42.0 +
      6 * min(3, centralBacks) +
      12 * min(2, protection) -
      8 * attackingBacks -
      5 * m +
      (2 - tactic.lineHeight) * 2 +
      dq;
  var control = 38.0 +
      7 * min(3, midfielders) +
      8 * min(2, protection) +
      6 * min(2, creators) +
      (tactic.playStyle == PlayStyle.possession ? 5 : 0) +
      mq;
  var power = 36.0 +
      7 * min(3, strikers) +
      6 * min(2, wingers) +
      5 * min(2, attackingBacks) +
      5 * m +
      aq;
  if (protection == 0) {
    solidity -= 10;
    notes.add('Aucun milieu défensif : risque de déséquilibre.');
  } else if (protection >= 2) {
    notes.add('Deux milieux défensifs axiaux : bonne protection devant la défense.');
  }
  if (wingers >= 2) {
    notes.add('Deux ailiers offensifs : bonne largeur offensive.');
  }
  if (attackingBacks >= 2) {
    notes.add('Deux latéraux offensifs : risque de contre-attaque.');
  }
  if (strikers >= 2 && strikerRoles.toSet().length >= 2) {
    notes.add('Deux attaquants complémentaires : meilleure complémentarité offensive.');
    power += 4;
  }
  if (centralBacks < 2) {
    notes.add('Peu de défenseurs centraux : l\'axe est vulnérable.');
  }
  if (tactic.lineHeight >= 3 && tactic.pressing == Pressing.low) {
    notes.add('Ligne haute avec un bloc bas : les lignes sont trop écartées.');
    control -= 6;
  }
  if (m >= 2 && protection == 0) {
    notes.add('Équipe très offensive sans protection : gros risque défensif.');
  }

  int clampScore(double v) => v.round().clamp(0, 100).toInt();
  final sol = clampScore(solidity);
  final con = clampScore(control);
  final pow2 = clampScore(power);
  var total = (sol + con + pow2) / 3;
  total -= warnings.length * 3.0;
  return TacticalBalance(
    total: clampScore(total),
    solidity: sol,
    control: con,
    power: pow2,
    notes: notes,
    warnings: warnings,
  );
}
