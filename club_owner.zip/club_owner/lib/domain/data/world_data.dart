import '../entities/country.dart';

/// Pays et villes proposés à la création du club.
/// Les chiffres sont des valeurs de jeu, pas des statistiques officielles.
const List<Country> worldCountries = [
  Country(
    id: 'ci',
    name: "Côte d'Ivoire",
    cities: [
      City(name: 'Abidjan', population: 5600, wealth: 7),
      City(name: 'Bouaké', population: 830, wealth: 4),
      City(name: 'Yamoussoukro', population: 360, wealth: 5),
      City(name: 'San-Pédro', population: 390, wealth: 5),
    ],
  ),
  Country(
    id: 'fr',
    name: 'France',
    cities: [
      City(name: 'Paris', population: 2100, wealth: 10),
      City(name: 'Lyon', population: 520, wealth: 8),
      City(name: 'Lille', population: 235, wealth: 7),
      City(name: 'Saint-Étienne', population: 175, wealth: 5),
    ],
  ),
  Country(
    id: 'sn',
    name: 'Sénégal',
    cities: [
      City(name: 'Dakar', population: 1200, wealth: 6),
      City(name: 'Thiès', population: 320, wealth: 4),
      City(name: 'Saint-Louis', population: 230, wealth: 4),
      City(name: 'Touba', population: 700, wealth: 3),
    ],
  ),
  Country(
    id: 'ma',
    name: 'Maroc',
    cities: [
      City(name: 'Casablanca', population: 3350, wealth: 7),
      City(name: 'Rabat', population: 580, wealth: 7),
      City(name: 'Marrakech', population: 930, wealth: 6),
      City(name: 'Tanger', population: 950, wealth: 6),
    ],
  ),
  Country(
    id: 'cm',
    name: 'Cameroun',
    cities: [
      City(name: 'Douala', population: 3700, wealth: 6),
      City(name: 'Yaoundé', population: 4100, wealth: 6),
      City(name: 'Bafoussam', population: 350, wealth: 4),
      City(name: 'Garoua', population: 400, wealth: 3),
    ],
  ),
  Country(
    id: 'en',
    name: 'Angleterre',
    cities: [
      City(name: 'Londres', population: 8900, wealth: 10),
      City(name: 'Manchester', population: 550, wealth: 8),
      City(name: 'Liverpool', population: 495, wealth: 7),
      City(name: 'Birmingham', population: 1140, wealth: 7),
    ],
  ),
];
