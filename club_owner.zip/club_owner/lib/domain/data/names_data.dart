/// Prénoms et noms de famille par culture, pour que chaque joueur porte un
/// nom crédible pour sa nationalité (un Sénégalais s'appelle Diop ou Ndiaye,
/// un Néerlandais de Vries ou Bakker...). Combinaisons tirées au hasard :
/// toute ressemblance avec un joueur réel est fortuite.
library;

class NameGroup {
  const NameGroup(this.first, this.last, {this.familyFirst = false});

  final List<String> first;
  final List<String> last;

  /// Nom de famille en premier (Chine, Corée, Vietnam).
  final bool familyFirst;
}

const NameGroup _ivorian = NameGroup([
  'Yao', 'Serge', 'Wilfried', 'Franck', 'Seko', 'Hamed', 'Odilon', 'Evan',
  'Jean-Philippe', 'Max-Alain', 'Simon', 'Ibrahim', 'Christian', 'Junior',
  'Lassina', 'Karim', 'Oumar', 'Arsène', 'Hervé', 'Siaka',
], [
  'Kouassi', 'Koné', 'Kouamé', 'Bamba', 'Traoré', 'Yao', 'Gnagnon', 'Zaha',
  'Aké', 'Boga', 'Gbamin', 'Kessié', 'Diomandé', 'Ouattara', 'Coulibaly',
  'Konan', "N'Guessan", 'Gradel', 'Tiéné', 'Doumbia', 'Fofana', 'Sangaré',
]);

const NameGroup _senegalese = NameGroup([
  'Moussa', 'Cheikh', 'Ibrahima', 'Mamadou', 'Pape', 'Idrissa', 'Abdou',
  'Lamine', 'Youssouf', 'Babacar', 'Alioune', 'Saliou', 'Bamba', 'Ismaïla',
  'Habib', 'Ousmane', 'Malick', 'Assane',
], [
  'Diop', 'Ndiaye', 'Sarr', 'Diallo', 'Faye', 'Gueye', 'Fall', 'Sow', 'Ba',
  'Cissé', 'Diouf', 'Niang', 'Seck', 'Thiam', 'Kouyaté', 'Mbaye', 'Ndoye',
  'Badji', 'Diatta', 'Sané',
]);

const NameGroup _maghreb = NameGroup([
  'Youssef', 'Hamza', 'Ayoub', 'Karim', 'Mehdi', 'Omar', 'Bilal', 'Anis',
  'Yassine', 'Walid', 'Nabil', 'Sofiane', 'Ismaël', 'Amine', 'Riad',
  'Zakaria', 'Hakim', 'Adel', 'Rachid', 'Sami',
], [
  'El Amrani', 'Benali', 'Haddad', 'Mansouri', 'Bouzid', 'Chakir',
  'Belkacem', 'Saïdi', 'Toumi', 'El Idrissi', 'Bennani', 'Ziani', 'Brahimi',
  'Khelifi', 'Ben Salah', 'Jaziri', 'Hamdi', 'Tazi', 'Ouali', 'Aït Nouri',
]);

const NameGroup _egyptian = NameGroup([
  'Mohamed', 'Ahmed', 'Mahmoud', 'Omar', 'Mostafa', 'Abdelrahman', 'Karim',
  'Amr', 'Tarek', 'Hossam', 'Ramadan', 'Emam', 'Akram', 'Hany',
], [
  'Hassan', 'Fathi', 'Abdelaziz', 'Gaber', 'Shawky', 'Hamed', 'Soliman',
  'Ashour', 'Mansour', 'El Shenawy', 'Fawzy', 'Hegazy', 'Ragab', 'Zaki',
]);

const NameGroup _gulf = NameGroup([
  'Salem', 'Faisal', 'Khalid', 'Abdullah', 'Fahad', 'Saud', 'Nasser',
  'Hassan', 'Ali', 'Mohammed', 'Sultan', 'Turki', 'Hamad', 'Yaser', 'Ayman',
], [
  'Al-Harbi', 'Al-Dosari', 'Al-Shehri', 'Al-Qahtani', 'Al-Mutairi',
  'Al-Ghamdi', 'Al-Hajri', 'Al-Kuwari', 'Al-Hammadi', 'Al-Abri', 'Al-Saadi',
  'Al-Mansoori', 'Al-Rawi', 'Al-Tamari', 'Al-Busaidi', 'Al-Ali',
]);

const NameGroup _centralAfrica = NameGroup([
  'Jean', 'Samuel', 'Éric', 'Vincent', 'Joël', 'Patrick', 'Arnaud', 'Cédric',
  'Junior', 'Stéphane', 'Landry', 'Fabrice', 'Christian', 'Gaël', 'Yannick',
  'Dieumerci', 'Chancel', 'Merveille', 'Olivier', 'Bertrand',
], [
  'Mbarga', 'Nguema', 'Ndong', 'Mabika', 'Ekambi', 'Owona', 'Kalonji',
  'Mbemba', 'Kabasele', 'Mulumba', 'Ilunga', 'Tshibangu', 'Moukandjo',
  'Abessolo', 'Nkounkou', 'Bakambu', 'Essomba', 'Fouda', 'Ngadeu', 'Mavuba',
]);

const NameGroup _gulfOfGuinea = NameGroup([
  'Komlan', 'Kodjo', 'Sessi', 'Rodrigue', 'Steve', 'Jodel', 'Mickaël',
  'Serge', 'Emmanuel', 'Kossi', 'Désiré', 'Florent', 'Hervé', 'Yao',
], [
  'Agbo', 'Akakpo', 'Adjovi', 'Dossou', 'Sossa', 'Hounkpatin', 'Adebayor',
  'Gnonlonfin', 'Ayité', 'Dovi', 'Laba', 'Romao', 'Kpodo', 'Atchou',
  'Houssou', 'Assogba',
]);

const NameGroup _nigerian = NameGroup([
  'Chidi', 'Emeka', 'Samuel', 'Victor', 'Tunde', 'Kelechi', 'Ademola',
  'Femi', 'Uche', 'Joseph', 'Chukwuemeka', 'Wilfred', 'Taiwo', 'Ola',
  'Ifeanyi', 'Moses', 'Ikenna', 'Babatunde',
], [
  'Chukwu', 'Okafor', 'Adeyemi', 'Eze', 'Okonkwo', 'Balogun', 'Ogunleye',
  'Nwankwo', 'Ibe', 'Obi', 'Onyekuru', 'Ndidi', 'Aribo', 'Okoye', 'Lawal',
  'Abubakar', 'Oladipo', 'Uzoho', 'Ejuke', 'Musa',
]);

const NameGroup _ghanaian = NameGroup([
  'Kwame', 'Kofi', 'Kwesi', 'Yaw', 'Kwadwo', 'Daniel', 'Emmanuel', 'Thomas',
  'Abdul', 'Mohammed', 'Jordan', 'Richmond', 'Kojo', 'Ebenezer',
], [
  'Mensah', 'Asante', 'Boateng', 'Owusu', 'Addo', 'Ofori', 'Appiah',
  'Agyemang', 'Amartey', 'Sarpong', 'Acheampong', 'Badu', 'Danso',
  'Opoku', 'Wakaso', 'Djiku', 'Lamptey', 'Quaye',
]);

const NameGroup _mande = NameGroup([
  'Moussa', 'Adama', 'Souleymane', 'Seydou', 'Bakary', 'Mohamed', 'Issa',
  'Amadou', 'Hamari', 'Yves', 'Boubacar', 'Mahamadou', 'Ibrahim', 'Naby',
  'Sékou', 'Abdoulaye', 'Bertrand', 'Issoufou',
], [
  'Traoré', 'Coulibaly', 'Keïta', 'Diarra', 'Konaté', 'Sangaré', 'Camara',
  'Sylla', 'Bangoura', 'Ouédraogo', 'Kaboré', 'Sawadogo', 'Touré', 'Doucouré',
  'Haïdara', 'Samassékou', 'Bissouma', 'Zongo', 'Tapsoba', 'Soumah',
]);

const NameGroup _southAfrican = NameGroup([
  'Thabo', 'Sipho', 'Themba', 'Lebo', 'Teboho', 'Bongani', 'Percy',
  'Siyabonga', 'Mandla', 'Lyle', 'Ronwen', 'Thapelo', 'Keagan', 'Evidence',
  'Mothobi', 'Zakhele', 'Grant', 'Ethan',
], [
  'Mokoena', 'Zwane', 'Dlamini', 'Nkosi', 'Mahlangu', 'Khumalo', 'Modise',
  'Ndlovu', 'Tau', 'Mthethwa', 'Van Heerden', 'Sithole', 'Mvala', 'Morena',
  'Mabasa', 'Foster', 'Williams', 'Maseko', 'Ngcobo', 'Botha',
]);

const NameGroup _lusoAfrica = NameGroup([
  'João', 'Ricardo', 'Hélder', 'Gelson', 'Jamiro', 'Kenny', 'Ivan', 'Fredy',
  'Stopira', 'Garry', 'Jovane', 'Bebé', 'Gilson', 'Mateus', 'Djalma',
], [
  'Tavares', 'Semedo', 'Monteiro', 'Lopes', 'Mendes', 'Fortes', 'Gomes',
  'Cabral', 'Mateus', 'Neto', 'Rodrigues', 'Varela', 'Borges', 'Pires',
  'Dala', 'Mabululu',
]);

const NameGroup _zambian = NameGroup([
  'Patson', 'Enock', 'Kings', 'Clatous', 'Lameck', 'Rainford', 'Fashion',
  'Emmanuel', 'Augustine', 'Stoppila', 'Collins', 'Evans', 'Lubambo',
], [
  'Banda', 'Mwila', 'Phiri', 'Chama', 'Mulenga', 'Sakala', 'Kangwa',
  'Musonda', 'Daka', 'Mwepu', 'Chisamba', 'Kalaba', 'Zulu', 'Tembo',
]);

const NameGroup _french = NameGroup([
  'Lucas', 'Hugo', 'Théo', 'Antoine', 'Maxime', 'Julien', 'Nicolas',
  'Quentin', 'Romain', 'Baptiste', 'Mathis', 'Clément', 'Florian', 'Adrien',
  'Bastien', 'Enzo', 'Kévin', 'Jordan', 'Yanis', 'Rayan',
], [
  'Martin', 'Bernard', 'Dubois', 'Moreau', 'Laurent', 'Lefebvre', 'Girard',
  'Roux', 'Fournier', 'Mercier', 'Blanc', 'Garnier', 'Faure', 'Lemaire',
  'Chevalier', 'Perrin', 'Gauthier', 'Morel', 'Rousseau', 'Lambert',
]);

const NameGroup _belgian = NameGroup([
  'Thibault', 'Arnaud', 'Wout', 'Jens', 'Senne', 'Arthur', 'Maxime', 'Hans',
  'Pieter', 'Lander', 'Siebe', 'Robin', 'Thomas', 'Loïs', 'Zeno',
], [
  'Peeters', 'Janssens', 'Maes', 'Jacobs', 'Willems', 'Claes', 'Dupont',
  'Wouters', 'De Smet', 'Goossens', 'Vermeulen', 'Lemmens', 'Dewaele',
  'Verschueren', 'Lambert', 'Mathys',
]);

const NameGroup _english = NameGroup([
  'Jack', 'Harry', 'James', 'Oliver', 'Charlie', 'Mason', 'Jordan',
  'Callum', 'Ryan', 'Tyler', 'Luke', 'Josh', 'Reece', 'Ben', 'Jamie',
  'Kieran', 'Aaron', 'Dominic', 'Ethan', 'Marcus',
], [
  'Smith', 'Taylor', 'Walker', 'Wright', 'Hughes', 'Bennett', 'Clarke',
  'Turner', 'Robinson', 'Ward', 'Cooper', 'Hill', 'Harris', 'Lewis',
  'Mitchell', 'Johnson', 'Parker', 'Morgan', 'Stone', 'Fletcher',
]);

const NameGroup _scottish = NameGroup([
  'Callum', 'Ross', 'Scott', 'Andrew', 'Kenny', 'Ryan', 'Stuart', 'Lewis',
  'Jamie', 'Craig', 'Liam', 'Grant', 'Fraser', 'Kieran',
], [
  'McGregor', 'Robertson', 'Campbell', 'Fraser', 'Murray', 'Stewart',
  'McLean', 'McKenna', 'Ferguson', 'McGinn', 'Henderson', 'Hendry', 'Christie',
  'Gordon', 'Paterson', 'Mackay',
]);

const NameGroup _northAmerican = NameGroup([
  'Tyler', 'Christian', 'Weston', 'Brenden', 'Jordan', 'Miles', 'Alphonso',
  'Cyle', 'Jonathan', 'Ricardo', 'Kellyn', 'Josh', 'Gianluca', 'Ike',
  'Mark', 'Zack',
], [
  'Johnson', 'Miller', 'Davis', 'Anderson', 'Adams', 'Robinson', 'Morris',
  'Brooks', 'Larin', 'Cavallini', 'Hutchinson', 'Turner', 'Ream', 'Sargent',
  'Acosta', 'Wright',
]);

const NameGroup _jamaican = NameGroup([
  'Leon', 'Michail', 'Damion', 'Shamar', 'Andre', 'Kemar', 'Bobby', 'Dexter',
  'Ravel', 'Demarai', 'Javain', 'Kasey',
], [
  'Bailey', 'Campbell', 'Brown', 'Williams', 'Reid', 'Gordon', 'Lowe',
  'Nicholson', 'Morrison', 'Blake', 'Antonio', 'Palmer', 'Grant',
]);

const NameGroup _australian = NameGroup([
  'Mitchell', 'Mathew', 'Jackson', 'Riley', 'Aaron', 'Harry', 'Connor',
  'Kye', 'Craig', 'Nathaniel', 'Garang', 'Awer', 'Cameron', 'Brandon',
], [
  'Ryan', 'Leckie', 'Irvine', 'Souttar', 'Mooy', 'Atkinson', 'Boyle',
  'Rowles', 'Goodwin', 'Kuol', 'Duke', 'Behich', 'Metcalfe', "O'Neill",
]);

const NameGroup _spanish = NameGroup([
  'Pablo', 'Sergio', 'Álvaro', 'Javier', 'Diego', 'Adrián', 'Marcos', 'Iker',
  'Rubén', 'Dani', 'Mikel', 'Unai', 'Hugo', 'Jorge', 'Raúl', 'Íñigo',
  'Carlos', 'Fermín',
], [
  'García', 'Fernández', 'López', 'Martínez', 'Sánchez', 'Romero', 'Navarro',
  'Torres', 'Ruiz', 'Moreno', 'Iglesias', 'Herrera', 'Gil', 'Serrano',
  'Muñoz', 'Ortega', 'Delgado', 'Castillo', 'Molina', 'Prieto',
]);

const NameGroup _rioplatense = NameGroup([
  'Juan', 'Matías', 'Santiago', 'Facundo', 'Nicolás', 'Lautaro', 'Agustín',
  'Federico', 'Gonzalo', 'Rodrigo', 'Thiago', 'Franco', 'Valentín', 'Ezequiel',
  'Gastón', 'Maximiliano', 'Lucas', 'Joaquín',
], [
  'González', 'Rodríguez', 'Gómez', 'Fernández', 'Díaz', 'Pérez', 'Álvarez',
  'Romero', 'Sosa', 'Benítez', 'Acosta', 'Medina', 'Herrera', 'Suárez',
  'Cabrera', 'Ojeda', 'Paredes', 'Villalba', 'Giménez', 'Correa',
]);

const NameGroup _andean = NameGroup([
  'Andrés', 'Sebastián', 'Jhon', 'Cristian', 'Luis', 'Carlos', 'Jefferson',
  'Yerry', 'Moisés', 'Pervis', 'Alexis', 'Arturo', 'Renato', 'Edison',
  'Duván', 'Wilmar', 'Gianluca', 'André',
], [
  'Rojas', 'Castro', 'Vargas', 'Cuadrado', 'Mina', 'Quintero', 'Valencia',
  'Estupiñán', 'Plata', 'Caicedo', 'Vidal', 'Aránguiz', 'Tapia', 'Advíncula',
  'Cueva', 'Carrillo', 'Zapata', 'Muñoz', 'Arboleda', 'Hurtado',
]);

const NameGroup _mexican = NameGroup([
  'Hirving', 'Edson', 'Raúl', 'Héctor', 'Jesús', 'Luis', 'Orbelín', 'Alexis',
  'César', 'Santiago', 'Uriel', 'Erick', 'Diego', 'Julián',
], [
  'Hernández', 'Lozano', 'Álvarez', 'Jiménez', 'Moreno', 'Corona', 'Vega',
  'Gallardo', 'Montes', 'Pineda', 'Sánchez', 'Romo', 'Antuna', 'Ochoa',
  'Guardado', 'Vásquez',
]);

const NameGroup _centralAmerican = NameGroup([
  'Bryan', 'Kendall', 'Joel', 'Celso', 'Keysher', 'Francisco', 'Óscar',
  'Johan', 'Aníbal', 'Alberth', 'Romell', 'Ismael', 'Adalberto', 'Yoel',
  'Rolando', 'Michael',
], [
  'Mora', 'Vargas', 'Solano', 'Jiménez', 'Araya', 'Calvo', 'Chacón', 'Ureña',
  'Quesada', 'Fuller', 'Bennette', 'Godoy', 'Elis', 'Quioto', 'Blackburn',
  'Murillo', 'Carrasquilla', 'Pérez', 'Rodríguez', 'Waterman',
]);

const NameGroup _brazilian = NameGroup([
  'Gabriel', 'Lucas', 'Rafael', 'Vinícius', 'Matheus', 'Thiago', 'Bruno',
  'Felipe', 'Rodrigo', 'Igor', 'Éder', 'Wesley', 'Douglas', 'Danilo',
  'Willian', 'Renan', 'Caio', 'Endrick',
], [
  'Silva', 'Santos', 'Oliveira', 'Souza', 'Pereira', 'Costa', 'Almeida',
  'Ribeiro', 'Carvalho', 'Barbosa', 'Ferreira', 'Lima', 'Araújo', 'Rocha',
  'Martins', 'Nascimento', 'Moura', 'Teixeira', 'Cardoso', 'Freitas',
]);

const NameGroup _portuguese = NameGroup([
  'João', 'Diogo', 'Tiago', 'Rúben', 'Gonçalo', 'Rafael', 'Nuno', 'André',
  'Pedro', 'Bernardo', 'Vitinha', 'Francisco', 'Rui', 'Hugo', 'Duarte',
], [
  'Silva', 'Costa', 'Ferreira', 'Pereira', 'Rodrigues', 'Martins', 'Sousa',
  'Fernandes', 'Gonçalves', 'Carvalho', 'Neves', 'Mendes', 'Dias', 'Ramos',
  'Leão', 'Palhinha', 'Horta', 'Nunes',
]);

const NameGroup _german = NameGroup([
  'Lukas', 'Leon', 'Jonas', 'Felix', 'Maximilian', 'Niklas', 'Tim',
  'Florian', 'Jannik', 'Moritz', 'Julian', 'Kai', 'Marvin', 'Leroy', 'Nico',
  'Tobias', 'Paul', 'Jamal',
], [
  'Müller', 'Schmidt', 'Schneider', 'Fischer', 'Weber', 'Wagner', 'Becker',
  'Hoffmann', 'Schulz', 'Koch', 'Richter', 'Krüger', 'Neumann', 'Schwarz',
  'Zimmermann', 'Braun', 'Hartmann', 'Lange', 'Werner', 'Kramer',
]);

const NameGroup _swiss = NameGroup([
  'Granit', 'Yann', 'Manuel', 'Remo', 'Fabian', 'Nico', 'Denis', 'Silvan',
  'Ricardo', 'Breel', 'Noah', 'Cédric', 'Luca', 'Dan',
], [
  'Frei', 'Huber', 'Brunner', 'Keller', 'Meier', 'Steffen', 'Widmer',
  'Zuber', 'Elvedi', 'Sommer', 'Freuler', 'Aebischer', 'Rieder', 'Kobel',
  'Okafor', 'Vargas',
]);

const NameGroup _italian = NameGroup([
  'Lorenzo', 'Matteo', 'Alessandro', 'Federico', 'Davide', 'Andrea',
  'Riccardo', 'Simone', 'Gianluca', 'Nicolò', 'Giacomo', 'Sandro', 'Manuel',
  'Mattia', 'Destiny', 'Raoul',
], [
  'Rossi', 'Russo', 'Ferrari', 'Esposito', 'Bianchi', 'Romano', 'Colombo',
  'Ricci', 'Marino', 'Greco', 'Bruno', 'Conti', 'De Luca', 'Mancini',
  'Costa', 'Giordano', 'Rizzo', 'Lombardi', 'Moretti', 'Barbieri',
]);

const NameGroup _dutch = NameGroup([
  'Daan', 'Bram', 'Sem', 'Thijs', 'Jesse', 'Ruben', 'Stijn', 'Lars', 'Joris',
  'Teun', 'Milan', 'Jurriën', 'Tijjani', 'Xavi', 'Wout', 'Jeremie',
  'Quinten', 'Mats',
], [
  'de Jong', 'Jansen', 'de Vries', 'Bakker', 'Visser', 'Smit', 'Meijer',
  'de Boer', 'Mulder', 'van den Berg', 'Dekker', 'Bos', 'Vermeer',
  'van Leeuwen', 'Hendriks', 'Kuipers', 'Timmer', 'Brouwer', 'de Groot',
  'Veltman',
]);

const NameGroup _balkan = NameGroup([
  'Luka', 'Ivan', 'Marko', 'Josip', 'Mateo', 'Nikola', 'Dušan', 'Filip',
  'Stefan', 'Aleksandar', 'Lovro', 'Andrej', 'Mario', 'Sergej', 'Strahinja',
  'Borna', 'Domagoj', 'Nemanja',
], [
  'Horvat', 'Kovačević', 'Babić', 'Marić', 'Jurić', 'Petrović', 'Jovanović',
  'Nikolić', 'Đorđević', 'Ilić', 'Pavlović', 'Vlahović', 'Šutalo', 'Sučić',
  'Mitrović', 'Lukić', 'Gvardiol', 'Kramarić', 'Tadić', 'Milenković',
]);

const NameGroup _scandinavian = NameGroup([
  'Mikkel', 'Rasmus', 'Jonas', 'Emil', 'Oliver', 'Viktor', 'Gustav', 'Anton',
  'Elias', 'Isak', 'Kasper', 'Joakim', 'Andreas', 'Mathias', 'Dejan',
  'Jesper', 'Albin', 'Hugo',
], [
  'Jensen', 'Nielsen', 'Hansen', 'Pedersen', 'Andersen', 'Larsen',
  'Johansson', 'Karlsson', 'Nilsson', 'Lindqvist', 'Berg', 'Christensen',
  'Mæhle', 'Hjulmand', 'Lindelöf', 'Ekdal', 'Forsberg', 'Olsen', 'Svensson',
  'Holm',
]);

const NameGroup _polish = NameGroup([
  'Jakub', 'Kacper', 'Mateusz', 'Piotr', 'Bartosz', 'Kamil', 'Krzysztof',
  'Michał', 'Przemysław', 'Arkadiusz', 'Sebastian', 'Paweł', 'Nicola',
  'Karol',
], [
  'Nowak', 'Kowalski', 'Wiśniewski', 'Wójcik', 'Kamiński', 'Szymański',
  'Woźniak', 'Kaczmarek', 'Piątek', 'Bednarek', 'Kiwior', 'Frankowski',
  'Moder', 'Świderski', 'Grabara', 'Zalewski',
]);

const NameGroup _turkish = NameGroup([
  'Emre', 'Burak', 'Mert', 'Arda', 'Kerem', 'Cengiz', 'Ozan', 'Hakan',
  'Yusuf', 'Barış', 'Okay', 'Ferdi', 'Kaan', 'Orkun', 'Salih', 'Abdülkerim',
], [
  'Yılmaz', 'Kaya', 'Demir', 'Şahin', 'Çelik', 'Yıldız', 'Aydın', 'Öztürk',
  'Arslan', 'Doğan', 'Kılıç', 'Aktürkoğlu', 'Kadıoğlu', 'Bardakcı',
  'Ayhan', 'Kökçü',
]);

const NameGroup _japanese = NameGroup([
  'Takumi', 'Daichi', 'Kaoru', 'Ritsu', 'Wataru', 'Yuto', 'Kenta', 'Shogo',
  'Hiroki', 'Takehiro', 'Ayase', 'Junya', 'Koki', 'Takefusa', 'Daizen',
  'Reo',
], [
  'Tanaka', 'Suzuki', 'Takahashi', 'Watanabe', 'Ito', 'Yamamoto', 'Nakamura',
  'Kobayashi', 'Kato', 'Yoshida', 'Endo', 'Morita', 'Ueda', 'Hatate',
  'Maeda', 'Asano', 'Sugawara', 'Machida',
]);

const NameGroup _korean = NameGroup([
  'Jun-ho', 'Min-seok', 'Dong-hyun', 'Sung-woo', 'Tae-hwan', 'Ji-hoon',
  'Young-woo', 'Seung-ho', 'Woo-yeong', 'Hyun-jun', 'Gue-sung', 'Jae-sung',
  'In-beom', 'Chang-hoon',
], [
  'Kim', 'Lee', 'Park', 'Choi', 'Jung', 'Kang', 'Cho', 'Yoon', 'Jang', 'Hwang',
  'Seol', 'Hong', 'Paik', 'Oh',
], familyFirst: true);

const NameGroup _iranian = NameGroup([
  'Mehdi', 'Ali', 'Reza', 'Saman', 'Alireza', 'Sardar', 'Ehsan', 'Milad',
  'Morteza', 'Saeid', 'Hossein', 'Omid', 'Majid', 'Karim',
], [
  'Karimi', 'Hosseini', 'Rezaei', 'Ahmadi', 'Mohammadi', 'Moradi', 'Rahimi',
  'Nouri', 'Shojaei', 'Ezatolahi', 'Hajsafi', 'Pouraliganji', 'Kanaani',
  'Beiranvand', 'Mohebi', 'Ghayedi',
]);

const NameGroup _uzbek = NameGroup([
  'Eldor', 'Jaloliddin', 'Otabek', 'Abbosbek', 'Dostonbek', 'Rustam',
  'Jasurbek', 'Odiljon', 'Khojimat', 'Sherzod', 'Bobur', 'Islom',
], [
  'Ergashev', 'Yusupov', 'Tursunov', 'Rakhimov', 'Nasrullaev', 'Karimov',
  'Khamrobekov', 'Alikulov', 'Fayzullaev', 'Sayfiev', 'Ashurmatov', 'Urunov',
]);

const NameGroup _chinese = NameGroup([
  'Wei', 'Lei', 'Hao', 'Jun', 'Yang', 'Ming', 'Tao', 'Bin', 'Peng', 'Xi',
  'Yuning', 'Tianyi', 'Zhiyi', 'Linpeng',
], [
  'Wang', 'Li', 'Zhang', 'Liu', 'Chen', 'Yang', 'Zhao', 'Huang', 'Zhou',
  'Wu', 'Xu', 'Sun', 'Gao', 'Jiang',
], familyFirst: true);

const NameGroup _thai = NameGroup([
  'Supachai', 'Ekanit', 'Theerathon', 'Sarach', 'Kritsada', 'Pansa',
  'Weerathep', 'Suphanat', 'Bordin', 'Chalermsak', 'Nicholas', 'Supachok',
], [
  'Srisuk', 'Chaiyaphum', 'Boonmak', 'Panya', 'Saengchan', 'Wongsa',
  'Kaewdee', 'Hemvipat', 'Phala', 'Mueanta', 'Sarachat', 'Pomphan',
]);

const NameGroup _indian = NameGroup([
  'Rahul', 'Anirudh', 'Sandesh', 'Akash', 'Vikram', 'Arjun', 'Rohit',
  'Lallianzuala', 'Udanta', 'Brandon', 'Manvir', 'Liston', 'Gurpreet',
  'Subhasish',
], [
  'Singh', 'Kumar', 'Sharma', 'Thapa', 'Das', 'Nair', 'Bose', 'Reddy',
  'Chhangte', 'Colaco', 'Bheke', 'Fernandes', 'Mishra', 'Bhattacharya',
]);

const NameGroup _vietnamese = NameGroup([
  'Quang Hải', 'Văn Toàn', 'Tiến Linh', 'Hoàng Đức', 'Văn Hậu', 'Tuấn Anh',
  'Văn Thanh', 'Đình Trọng', 'Xuân Mạnh', 'Văn Lâm', 'Thành Chung',
  'Tuấn Hải',
], [
  'Nguyễn', 'Trần', 'Lê', 'Phạm', 'Hoàng', 'Đỗ', 'Vũ', 'Bùi', 'Đặng', 'Phan',
], familyFirst: true);

/// Culture des noms selon la nationalité (nom du pays tel qu'il apparaît
/// dans le jeu).
const Map<String, NameGroup> nameGroupsByNation = {
  "Côte d'Ivoire": _ivorian,
  'Sénégal': _senegalese,
  'Maroc': _maghreb,
  'Algérie': _maghreb,
  'Tunisie': _maghreb,
  'Égypte': _egyptian,
  'Cameroun': _centralAfrica,
  'Gabon': _centralAfrica,
  'RD Congo': _centralAfrica,
  'Congo': _centralAfrica,
  'Bénin': _gulfOfGuinea,
  'Togo': _gulfOfGuinea,
  'Nigeria': _nigerian,
  'Ghana': _ghanaian,
  'Mali': _mande,
  'Burkina Faso': _mande,
  'Guinée': _mande,
  'Afrique du Sud': _southAfrican,
  'Cap-Vert': _lusoAfrica,
  'Angola': _lusoAfrica,
  'Zambie': _zambian,
  'France': _french,
  'Belgique': _belgian,
  'Angleterre': _english,
  'Écosse': _scottish,
  'États-Unis': _northAmerican,
  'Canada': _northAmerican,
  'Jamaïque': _jamaican,
  'Australie': _australian,
  'Espagne': _spanish,
  'Argentine': _rioplatense,
  'Uruguay': _rioplatense,
  'Paraguay': _rioplatense,
  'Colombie': _andean,
  'Équateur': _andean,
  'Chili': _andean,
  'Pérou': _andean,
  'Mexique': _mexican,
  'Costa Rica': _centralAmerican,
  'Panama': _centralAmerican,
  'Honduras': _centralAmerican,
  'Cuba': _centralAmerican,
  'Brésil': _brazilian,
  'Portugal': _portuguese,
  'Allemagne': _german,
  'Autriche': _german,
  'Suisse': _swiss,
  'Italie': _italian,
  'Pays-Bas': _dutch,
  'Croatie': _balkan,
  'Serbie': _balkan,
  'Danemark': _scandinavian,
  'Suède': _scandinavian,
  'Norvège': _scandinavian,
  'Pologne': _polish,
  'Turquie': _turkish,
  'Japon': _japanese,
  'Corée du Sud': _korean,
  'Iran': _iranian,
  'Ouzbékistan': _uzbek,
  'Chine': _chinese,
  'Thaïlande': _thai,
  'Inde': _indian,
  'Vietnam': _vietnamese,
  'Arabie saoudite': _gulf,
  'Qatar': _gulf,
  'Irak': _gulf,
  'Jordanie': _gulf,
  'Émirats arabes unis': _gulf,
  'Bahreïn': _gulf,
  'Oman': _gulf,
};

/// Joueurs binationaux ou issus de la diaspora : une part des sélectionnables
/// porte un nom d'une autre culture (un Français peut s'appeler Kanté,
/// Dembélé ou Benali, un Allemand Yılmaz, un Suisse Kovačević...).
/// Part de ces noms et cultures d'origine, par nationalité.
const Map<String, (double, List<NameGroup>)> heritageByNation = {
  'France': (0.32, [_mande, _senegalese, _maghreb, _centralAfrica, _ivorian]),
  'Belgique': (0.25, [_centralAfrica, _maghreb]),
  'Angleterre': (0.25, [_nigerian, _ghanaian, _jamaican]),
  'Pays-Bas': (0.18, [_maghreb, _jamaican, _ghanaian]),
  'Allemagne': (0.22, [_turkish, _balkan, _ghanaian]),
  'Suisse': (0.25, [_balkan, _lusoAfrica, _maghreb]),
  'Portugal': (0.2, [_lusoAfrica]),
  'Espagne': (0.1, [_lusoAfrica, _maghreb]),
  'Italie': (0.08, [_nigerian, _maghreb]),
  'Suède': (0.15, [_balkan, _maghreb]),
  'Danemark': (0.1, [_balkan]),
  'États-Unis': (0.2, [_mexican, _jamaican, _nigerian]),
  'Canada': (0.2, [_jamaican, _ghanaian, _mande]),
  'Australie': (0.12, [_balkan, _southAfrican]),
};
