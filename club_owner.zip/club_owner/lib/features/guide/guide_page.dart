import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../common/crest.dart';

class _GuideStep {
  const _GuideStep(this.icon, this.color, this.title, this.lines);

  final IconData icon;
  final Color color;
  final String title;
  final List<String> lines;
}

const List<_GuideStep> _steps = [
  _GuideStep(
    Icons.emoji_events,
    Color(0xFFF9A825),
    'Bienvenue, président !',
    [
      'Vous venez de fonder un club de football. Vous n\'êtes pas '
          'l\'entraîneur : vous êtes le propriétaire.',
      'Votre mission : faire grandir votre club, de la division amateur '
          'jusqu\'au sommet du football mondial.',
      'Ce guide vous explique tout en quelques minutes. Vous pourrez le '
          'relire à tout moment depuis les Paramètres.',
    ],
  ),
  _GuideStep(
    Icons.home_outlined,
    Color(0xFF2E7D32),
    'L\'accueil et les journées',
    [
      'Chaque saison compte 38 journées, jouées chaque samedi de la '
          'mi-août à mai. La date est affichée à l\'accueil.',
      'Touchez « Jouer la journée » pour simuler le match de votre club : '
          'tous les autres championnats du monde jouent en même temps.',
      'Le conseil d\'administration fixe un objectif de classement. '
          'L\'atteindre augmente sa confiance.',
    ],
  ),
  _GuideStep(
    Icons.groups_outlined,
    Color(0xFF3F51B5),
    'L\'effectif',
    [
      'Votre club a trois équipes : l\'équipe première, la réserve (à '
          'partir de la D3) et le centre de formation.',
      'Touchez un joueur de l\'équipe première pour le titulariser. '
          'L\'icône ⋮ ouvre sa fiche : contrat, vente, prêt, discussion.',
      'Les postes sont détaillés : GB gardien, DC défenseur central, '
          'ArG/ArD arrières, MDC/MC/MO milieux, AG/AD ailiers, BU buteur.',
    ],
  ),
  _GuideStep(
    Icons.sports_soccer,
    Color(0xFF558B2F),
    'La tactique',
    [
      'Choisissez une formation (4-4-2, 4-3-3...), un style de jeu et un '
          'pressing. Chaque choix renforce certains secteurs.',
      'Après un match, « Revoir le match en 2D » montre la partie avec les '
          'pions sur le terrain.',
    ],
  ),
  _GuideStep(
    Icons.badge_outlined,
    Color(0xFF3F51B5),
    'Le staff',
    [
      'Engagez d\'abord un manager et un directeur sportif.',
      'Le directeur sportif recrute les recruteurs et les coachs, mène les '
          'négociations de transferts et de prêts.',
      'Avec la délégation activée, il gère seul les affaires courantes : '
          'promotion des jeunes, agents libres, prêts, libérations. Vous '
          'gardez la main sur les gros dossiers.',
    ],
  ),
  _GuideStep(
    Icons.swap_horizontal_circle_outlined,
    Color(0xFFE65100),
    'Les transferts',
    [
      'Agents libres, offres aux autres clubs du monde, prêts, prêts avec '
          'option d\'achat : tout se passe dans « Transferts ».',
      'Le club vendeur peut accepter, contre-proposer ou refuser. Les '
          'superstars coûtent très cher, les jeunes et joueurs moyens '
          'beaucoup moins.',
      'Un joueur épanoui peut refuser de partir ; un joueur frustré '
          'accepte plus vite et coûte moins cher.',
    ],
  ),
  _GuideStep(
    Icons.mood,
    Color(0xFFD81B60),
    'L\'humeur des joueurs',
    [
      'Un joueur content (😄) joue bien. S\'il ne joue pas assez, '
          'il se plaint, puis peut réclamer son départ.',
      'Discutez avec lui (fiche du joueur) pour le calmer. Les '
          'altercations du vestiaire et vos réponses à la presse '
          'changent aussi l\'humeur.',
    ],
  ),
  _GuideStep(
    Icons.account_balance_wallet_outlined,
    Color(0xFF00897B),
    'L\'argent',
    [
      'Revenus : billetterie, sponsors, droits TV, boutique, fan zone, '
          'parking. Dépenses : salaires, entretien, travaux.',
      'Un sponsor principal se signe dans « Sponsors et banque ». La '
          'banque prête de l\'argent avec intérêts.',
      'Surveillez votre trésorerie : sans argent, plus de recrutements ni '
          'de travaux.',
    ],
  ),
  _GuideStep(
    Icons.stadium_outlined,
    Color(0xFF2E7D32),
    'Les installations',
    [
      'Améliorez le stade (renommable), le centre d\'entraînement, le '
          'centre de formation, la fan zone, le parking et la boutique.',
      'Un seul chantier à la fois. Les grands clubs des divisions '
          'supérieures ont de meilleures installations et plus de fans : '
          'à vous de les rattraper.',
    ],
  ),
  _GuideStep(
    Icons.newspaper,
    Color(0xFF6D4C41),
    'Presse, supporters et réseau',
    [
      'Après certains matchs, la presse vous pose une question : votre '
          'réponse influence les supporters et l\'ambiance.',
      'Le journal rassemble les gros titres du monde du football : '
          'transferts, clashs, limogeages, trophées.',
      'Le réseau social et l\'humeur des supporters font grandir votre '
          'affluence et votre prestige.',
    ],
  ),
  _GuideStep(
    Icons.public,
    Color(0xFF0277BD),
    'Saisons, trophées et sélections',
    [
      'Terminez dans les deux premiers pour monter, dans les deux '
          'derniers pour descendre.',
      'Les distinctions (Ballon d\'or, Soulier d\'or, Kopa, Yachine) '
          'récompensent les joueurs des clubs de première division, dans '
          'tous les pays simulés.',
      'Tous les deux ans, les nations s\'affrontent (Coupe du monde, '
          'CAN, Euro...). Vos internationaux font grandir votre prestige.',
    ],
  ),
  _GuideStep(
    Icons.lightbulb_outline,
    Color(0xFFF9A825),
    'Cinq conseils pour bien débuter',
    [
      '1. Engagez un manager puis un directeur sportif dès les premières '
          'journées.',
      '2. Gardez toujours une réserve d\'argent : ne dépensez pas toute '
          'la trésorerie.',
      '3. Gardez un œil sur les jeunes du centre de formation et sur '
          'l\'humeur de vos titulaires.',
      '4. Signez un sponsor et améliorez le stade pour augmenter vos '
          'revenus.',
      '5. Sauvegardez dans un emplacement avant une grosse décision. '
          'Mais le foot reste le foot : tout est possible !',
    ],
  ),
];

/// Guide interactif pour les débutants.
class GuidePage extends StatefulWidget {
  const GuidePage({super.key});

  @override
  State<GuidePage> createState() => _GuidePageState();
}

class _GuidePageState extends State<GuidePage> {
  final PageController _controller = PageController();
  int _index = 0;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _finish() {
    if (context.canPop()) {
      context.pop();
    } else {
      context.go('/home');
    }
  }

  void _next() {
    if (_index >= _steps.length - 1) {
      _finish();
      return;
    }
    _controller.nextPage(
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOut,
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final last = _index >= _steps.length - 1;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Guide du débutant'),
        actions: [
          TextButton(onPressed: _finish, child: const Text('Passer')),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: PageView.builder(
              controller: _controller,
              itemCount: _steps.length,
              onPageChanged: (i) => setState(() => _index = i),
              itemBuilder: (context, i) {
                final step = _steps[i];
                return Row(
                  children: [
                    SizedBox(
                      width: 200,
                      child: Center(
                        child: i == 0
                            ? const AppLogo(size: 110)
                            : CircleAvatar(
                                radius: 54,
                                backgroundColor: step.color,
                                child: Icon(step.icon,
                                    size: 54, color: Colors.white),
                              ),
                      ),
                    ),
                    Expanded(
                      child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(8, 20, 24, 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(step.title, style: theme.textTheme.headlineSmall),
                      const SizedBox(height: 16),
                      for (final line in step.lines)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: Text(line, style: theme.textTheme.bodyLarge),
                        ),
                    ],
                  ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 4, 16, 12),
            child: Row(
            children: [
              for (var i = 0; i < _steps.length; i++)
                Container(
                  width: i == _index ? 18 : 8,
                  height: 8,
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  decoration: BoxDecoration(
                    color: i == _index
                        ? theme.colorScheme.primary
                        : theme.colorScheme.outlineVariant,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              const Spacer(),
              FilledButton.icon(
                onPressed: _next,
                icon: const Icon(Icons.arrow_forward),
                label: Text(last ? 'Commencer l\'aventure' : 'Suivant'),
              ),
            ],
          ),
          ),
        ],
      ),
    );
  }
}
