import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/utils/format.dart';
import '../../domain/entities/staff.dart';
import '../../engine/staff/staff_factory.dart';
import '../../engine/world/nations.dart';
import '../common/labels.dart';
import '../common/pro_page.dart';
import '../common/widgets.dart';
import '../game/game_state.dart';

String _effectText(StaffMember member) {
  switch (member.role) {
    case StaffRole.manager:
      final percent = ((managerBoostFor(member.level) - 1) * 100)
          .toStringAsFixed(1)
          .replaceAll('.', ',');
      return '+$percent % de force en match';
    case StaffRole.sportingDirector:
      return 'Négocie mieux, engage de meilleurs recruteurs et coachs';
    case StaffRole.scout:
      final bonus = (member.level / 20).toStringAsFixed(1).replaceAll('.', ',');
      return '+$bonus niveau aux joueurs détectés';
    case StaffRole.coachFirst:
      return 'Fait progresser l\'équipe première';
    case StaffRole.coachReserve:
      return 'Fait progresser l\'équipe réserve';
    case StaffRole.coachAcademy:
      return 'Fait progresser les jeunes du centre de formation';
    case StaffRole.communityManager:
      return 'Anime le compte du club, fait grandir les abonnés';
  }
}

const Color _accent = Color(0xFF5C6BC0);

IconData _roleIcon(StaffRole role) {
  switch (role) {
    case StaffRole.manager:
      return Icons.sports_outlined;
    case StaffRole.sportingDirector:
      return Icons.business_center_outlined;
    case StaffRole.scout:
      return Icons.travel_explore;
    case StaffRole.coachFirst:
      return Icons.fitness_center;
    case StaffRole.coachReserve:
      return Icons.group_work_outlined;
    case StaffRole.coachAcademy:
      return Icons.school_outlined;
    case StaffRole.communityManager:
      return Icons.campaign_outlined;
  }
}

class StaffPage extends ConsumerWidget {
  const StaffPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();

    final theme = Theme.of(context);
    final candidates = game.staffCandidates;
    final hasDirector = game.sportingDirector != null;

    final wages = staffAnnualWages(game.staff);
    return ProPage(
      title: 'Staff',
      subtitle: hasDirector
          ? 'Votre directeur sportif recrute recruteurs et coachs'
          : 'Engagez d\'abord un directeur sportif',
      icon: Icons.badge_outlined,
      accent: _accent,
      stats: [
        ProStat('Trésorerie', formatMoney(game.finance.treasury),
            icon: Icons.account_balance_wallet_outlined),
        ProStat('Masse salariale', formatMoney(wages),
            icon: Icons.payments_outlined),
        ProStat('Membres', '${game.staff.length}', icon: Icons.groups_outlined),
        ProStat('Recruteurs', '${game.scouts.length}/$maxScouts',
            icon: Icons.travel_explore),
      ],
      side: [
        ProCard(
          padding: const EdgeInsets.all(12),
          child: Text(
            hasDirector
                ? 'Votre directeur sportif mène les négociations et engage '
                    'pour vous les recruteurs et les coachs.'
                : 'Lui seul pourra recruter les recruteurs et les coachs.',
            style: theme.textTheme.bodySmall,
          ),
        ),
      ],
      children: [
          ProGrid(
            minWidth: 380,
            children: [
              for (final role in StaffRole.values)
                ProCard(
                  title: role == StaffRole.scout
                      ? 'Recruteurs (${game.scouts.length} sur $maxScouts)'
                      : staffRoleLabel(role),
                  icon: _roleIcon(role),
                  accent: _accent,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: _section(context, ref, game, role, candidates),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 24),
          Text('Prospection mondiale', style: theme.textTheme.titleLarge),
          const SizedBox(height: 4),
          Text(
            'Chaque campagne coûte ${formatMoney(prospectingCost)} et ajoute '
            '$prospectsPerRun joueurs au mercato (jeunes pépites comprises). '
            'Vous les placez ensuite en équipe première, réserve ou '
            'centre de formation.',
            style: theme.textTheme.bodySmall,
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ActionChip(
                avatar: const Icon(Icons.public, size: 18),
                label: const Text('Monde entier'),
                onPressed: () => _prospect(context, ref, const []),
              ),
              for (final continent in Continent.values)
                ActionChip(
                  avatar: const Icon(Icons.travel_explore, size: 18),
                  label: Text(continentLabel(continent)),
                  onPressed: () =>
                      _prospect(context, ref, nationNamesOf(continent)),
                ),
            ],
          ),
        ],
    );
  }

  List<Widget> _section(
    BuildContext context,
    WidgetRef ref,
    GameState game,
    StaffRole role,
    List<StaffMember> candidates,
  ) {
    if (role == StaffRole.coachReserve && game.division > 3) {
      return const [
        Text("Votre division n'a pas d'équipe réserve (à partir de la D3)."),
      ];
    }
    final holders = game.staff.where((m) => m.role == role).toList();
    final available = candidates.where((c) => c.role == role).toList();
    final full = holders.length >= roleLimit(role);
    return [
      if (holders.isEmpty)
        const Padding(
          padding: EdgeInsets.only(bottom: 8),
          child: ProTag('Poste vacant', color: Color(0xFFFFB74D),
              icon: Icons.person_off_outlined),
        ),
      for (final holder in holders)
        Card(
          margin: const EdgeInsets.only(bottom: 8),
          color: _accent.withAlpha(45),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: _accent,
              child: Text(
                '${holder.level}',
                style: const TextStyle(color: Colors.white),
              ),
            ),
            title: Text(holder.name),
            subtitle: Text(
              '${_effectText(holder)}\n'
              'Salaire : ${formatMoney(staffAnnualWage(holder))} par saison',
            ),
            isThreeLine: true,
            trailing: IconButton(
              tooltip: 'Licencier',
              icon: const Icon(Icons.person_remove_outlined),
              onPressed: () => _confirmFire(context, ref, holder),
            ),
          ),
        ),
      if (!full && available.isEmpty && needsDirector(role))
        const Text('Aucun candidat : engagez un directeur sportif.'),
      if (!full)
        for (final candidate in available)
          Card(
            color: Colors.white.withAlpha(8),
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: CircleAvatar(child: Text('${candidate.level}')),
              title: Text('${candidate.name} (candidat)'),
              subtitle: Text(
                '${_effectText(candidate)}\n'
                'Prime ${formatMoney(hiringFee(candidate))}, '
                'salaire ${formatMoney(staffAnnualWage(candidate))}',
              ),
              isThreeLine: true,
              trailing: const Icon(Icons.add_circle_outline),
              onTap: () => _confirmHire(context, ref, candidate),
            ),
          ),
    ];
  }

  Future<void> _prospect(
    BuildContext context,
    WidgetRef ref,
    List<String> pool,
  ) async {
    final error = ref.read(gameProvider.notifier).prospect(nationPool: pool);
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          error ?? '$prospectsPerRun joueurs détectés : voir les agents '
              'libres dans Transferts.',
        ),
      ),
    );
  }

  Future<void> _confirmHire(
    BuildContext context,
    WidgetRef ref,
    StaffMember member,
  ) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text('Embaucher ${member.name} ?'),
        content: Text(
          '${staffRoleLabel(member.role)}, niveau ${member.level}.\n'
          'Prime d\'embauche : ${formatMoney(hiringFee(member))}.\n'
          'Salaire : ${formatMoney(staffAnnualWage(member))} par saison.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Annuler'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Embaucher'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    final error = ref.read(gameProvider.notifier).hireStaff(member.id);
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(error ?? '${member.name} rejoint le staff.')),
    );
  }

  Future<void> _confirmFire(
    BuildContext context,
    WidgetRef ref,
    StaffMember member,
  ) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text('Licencier ${member.name} ?'),
        content: Text(
          'Indemnité de départ : ${formatMoney(severancePay(member))}.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Annuler'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Licencier'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    final error = ref.read(gameProvider.notifier).fireStaff(member.id);
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(error ?? '${member.name} a quitté le club.')),
    );
  }
}
