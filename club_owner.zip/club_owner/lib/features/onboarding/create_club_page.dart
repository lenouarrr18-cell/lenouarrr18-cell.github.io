import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/utils/format.dart';
import '../../domain/data/world_data.dart';
import '../../domain/entities/country.dart';
import '../../core/audio/audio_service.dart';
import '../cloud/google_account_card.dart';
import '../common/crest.dart';
import '../game/game_state.dart';

class CreateClubPage extends ConsumerStatefulWidget {
  const CreateClubPage({super.key});

  @override
  ConsumerState<CreateClubPage> createState() => _CreateClubPageState();
}

class _CreateClubPageState extends ConsumerState<CreateClubPage> {
  final _nameController = TextEditingController();
  Country _country = worldCountries.first;
  City _city = worldCountries.first.cities.first;

  bool get _canCreate => _nameController.text.trim().length >= 3;

  @override
  void initState() {
    super.initState();
    _nameController.addListener(() => setState(() {}));
    // Pas de musique pendant la création du club : elle démarre quand la
    // partie commence vraiment.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) ref.read(audioProvider.notifier).stopGameMusic();
    });
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  void _create() {
    ref
        .read(gameProvider.notifier)
        .startNewGame(
          clubName: _nameController.text,
          country: _country,
          city: _city,
        );
    context.go('/home');
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final brand = Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0F5C3C), Color(0xFF051A11)],
        ),
      ),
      padding: const EdgeInsets.all(28),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const AppLogo(size: 92),
          const SizedBox(height: 18),
          Text(
            'CLUB OWNER',
            style: theme.textTheme.headlineMedium?.copyWith(
              color: const Color(0xFFF5C04A),
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Fondez votre club, bâtissez votre empire.',
            style: theme.textTheme.titleMedium?.copyWith(color: Colors.white),
          ),
          const SizedBox(height: 12),
          const Text(
            'Vous êtes le président : stade, finances, staff, mercato. '
            'Le coach s\'occupe du terrain.',
            style: TextStyle(color: Colors.white70),
          ),
          const SizedBox(height: 22),
          const GoogleAccountCard(allowRestore: true, dark: true),
        ],
      ),
    );

    final form = ListView(
          padding: const EdgeInsets.all(24),
          children: [
            if (MediaQuery.sizeOf(context).width <=
                MediaQuery.sizeOf(context).height) ...[
              const GoogleAccountCard(allowRestore: true),
              const SizedBox(height: 16),
            ],
            Text('Fondez votre club', style: theme.textTheme.headlineSmall),
            const SizedBox(height: 8),
            const Text(
              'Choisissez un nom, un pays et une ville. '
              'Votre club démarre en championnat amateur.',
            ),
            const SizedBox(height: 20),
            TextField(
              key: const Key('club-name-field'),
              controller: _nameController,
              textCapitalization: TextCapitalization.words,
              maxLength: 24,
              decoration: const InputDecoration(
                labelText: 'Nom du club',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 8),
            DropdownMenu<Country>(
              expandedInsets: EdgeInsets.zero,
              label: const Text('Pays'),
              initialSelection: _country,
              dropdownMenuEntries: [
                for (final c in worldCountries)
                  DropdownMenuEntry<Country>(value: c, label: c.name),
              ],
              onSelected: (value) {
                if (value == null) return;
                setState(() {
                  _country = value;
                  _city = value.cities.first;
                });
              },
            ),
            const SizedBox(height: 16),
            DropdownMenu<City>(
              key: ValueKey(_country.id),
              expandedInsets: EdgeInsets.zero,
              label: const Text('Ville'),
              initialSelection: _city,
              dropdownMenuEntries: [
                for (final c in _country.cities)
                  DropdownMenuEntry<City>(value: c, label: c.name),
              ],
              onSelected: (value) {
                if (value == null) return;
                setState(() => _city = value);
              },
            ),
            const SizedBox(height: 12),
            Text(
              '${_city.name} : ${formatPopulation(_city.population)}, '
              'richesse locale ${_city.wealth}/10. '
              'Une ville riche donne un meilleur départ.',
              style: theme.textTheme.bodySmall,
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _canCreate ? _create : null,
              icon: const Icon(Icons.flag),
              label: const Text('Créer mon club'),
            ),
          ],
        );

    return Scaffold(
      body: LayoutBuilder(
        builder: (context, box) {
          if (box.maxWidth > box.maxHeight) {
            return Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(flex: 5, child: SafeArea(right: false, child: brand)),
                Expanded(flex: 6, child: SafeArea(left: false, child: form)),
              ],
            );
          }
          return SafeArea(child: form);
        },
      ),
    );
  }
}
