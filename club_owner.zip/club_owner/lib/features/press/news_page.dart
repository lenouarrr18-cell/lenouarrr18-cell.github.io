import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/utils/calendar.dart';
import '../../domain/entities/owner.dart';
import '../common/pro_page.dart';
import '../game/game_state.dart';

const Color _accent = Color(0xFFB0874F);
const Color _paper = Color(0xFFF3EBDD);
const Color _ink = Color(0xFF1E1A16);

IconData _kindIcon(NewsKind kind) {
  switch (kind) {
    case NewsKind.match:
      return Icons.sports_soccer;
    case NewsKind.transfer:
      return Icons.swap_horiz;
    case NewsKind.press:
      return Icons.mic_none;
    case NewsKind.locker:
      return Icons.warning_amber_rounded;
    case NewsKind.club:
      return Icons.shield_outlined;
    case NewsKind.world:
      return Icons.public;
    case NewsKind.award:
      return Icons.emoji_events;
  }
}

String _kindLabel(NewsKind kind) {
  switch (kind) {
    case NewsKind.match:
      return 'MATCH';
    case NewsKind.transfer:
      return 'MERCATO';
    case NewsKind.press:
      return 'DÉCLARATION';
    case NewsKind.locker:
      return 'VESTIAIRE';
    case NewsKind.club:
      return 'CLUB';
    case NewsKind.world:
      return 'MONDE';
    case NewsKind.award:
      return 'DISTINCTION';
  }
}

Color _kindColor(NewsKind kind) {
  switch (kind) {
    case NewsKind.match:
      return const Color(0xFF2E7D32);
    case NewsKind.transfer:
      return const Color(0xFF1565C0);
    case NewsKind.press:
      return const Color(0xFF00897B);
    case NewsKind.locker:
      return const Color(0xFFC62828);
    case NewsKind.club:
      return const Color(0xFF6A1B9A);
    case NewsKind.world:
      return const Color(0xFF455A64);
    case NewsKind.award:
      return const Color(0xFFB8860B);
  }
}

/// Le journal : une vraie une de quotidien sportif.
class NewsPage extends ConsumerStatefulWidget {
  const NewsPage({super.key});

  @override
  ConsumerState<NewsPage> createState() => _NewsPageState();
}

class _NewsPageState extends ConsumerState<NewsPage> {
  NewsKind? _filter;

  @override
  Widget build(BuildContext context) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();

    final today = roundDate(
      game.seasonNumber,
      game.season.currentRound.clamp(1, 38).toInt(),
    );
    final all = game.owner.news;
    final items =
        _filter == null ? all : all.where((n) => n.kind == _filter).toList();
    int count(NewsKind k) => all.where((n) => n.kind == k).length;

    return ProPage(
      title: 'Le journal',
      subtitle: formatDateFr(today),
      icon: Icons.newspaper,
      accent: _accent,
      stats: [
        ProStat('Articles', '${all.length}', icon: Icons.article_outlined),
        ProStat('Mercato', '${count(NewsKind.transfer)}',
            icon: Icons.swap_horiz),
        ProStat('Matchs', '${count(NewsKind.match)}',
            icon: Icons.sports_soccer),
        ProStat('Vestiaire', '${count(NewsKind.locker)}',
            icon: Icons.warning_amber_rounded),
      ],
      side: [
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: [
            ChoiceChip(
              label: const Text('Tout'),
              selected: _filter == null,
              onSelected: (_) => setState(() => _filter = null),
            ),
            for (final k in NewsKind.values)
              if (count(k) > 0)
                ChoiceChip(
                  label: Text(_kindLabel(k)),
                  selected: _filter == k,
                  onSelected: (_) => setState(() => _filter = k),
                ),
          ],
        ),
      ],
      children: [
        Container(
          decoration: BoxDecoration(
            color: _paper,
            borderRadius: BorderRadius.circular(6),
            boxShadow: const [
              BoxShadow(blurRadius: 12, color: Colors.black54),
            ],
          ),
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _Masthead(date: formatDateFr(today), season: game.seasonNumber),
              if (items.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 30),
                  child: Text(
                    'Pas encore de une. Jouez des journées : transferts, '
                    'clashs, limogeages et trophées feront les gros titres.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: _ink,
                      fontFamily: 'serif',
                      fontSize: 16,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                )
              else ...[
                _Lead(item: items.first),
                if (items.length > 1)
                  const Divider(color: _ink, thickness: 1, height: 24),
                LayoutBuilder(
                  builder: (context, box) {
                    final cols = box.maxWidth > 700
                        ? 3
                        : (box.maxWidth > 440 ? 2 : 1);
                    final rest = items.skip(1).toList();
                    final columns = List.generate(cols, (_) => <Widget>[]);
                    for (var i = 0; i < rest.length; i++) {
                      columns[i % cols].add(_Brief(item: rest[i]));
                    }
                    return IntrinsicHeight(
                      child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        for (var c = 0; c < cols; c++) ...[
                          if (c > 0)
                            VerticalDivider(
                              width: 20,
                              thickness: 1,
                              color: _ink.withAlpha(60),
                            ),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: columns[c],
                            ),
                          ),
                        ],
                      ],
                      ),
                    );
                  },
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }
}

class _Masthead extends StatelessWidget {
  const _Masthead({required this.date, required this.season});

  final String date;
  final int season;

  @override
  Widget build(BuildContext context) {
    const small = TextStyle(color: _ink, fontSize: 11, letterSpacing: 0.5);
    return Column(
      children: [
        const Text(
          'LE QUOTIDIEN DU FOOT',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: _ink,
            fontFamily: 'serif',
            fontWeight: FontWeight.w900,
            fontSize: 30,
            letterSpacing: 2,
          ),
        ),
        const SizedBox(height: 4),
        Container(height: 2, color: _ink),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(
            children: [
              Text(date.toUpperCase(), style: small),
              const Spacer(),
              Text('SAISON $season · ÉDITION DU JOUR', style: small),
            ],
          ),
        ),
        Container(height: 1, color: _ink),
        const SizedBox(height: 12),
      ],
    );
  }
}

class _Lead extends StatelessWidget {
  const _Lead({required this.item});

  final NewsItem item;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _Kicker(item: item, big: true),
        const SizedBox(height: 6),
        Text(
          item.headline,
          style: const TextStyle(
            color: _ink,
            fontFamily: 'serif',
            fontWeight: FontWeight.w900,
            fontSize: 26,
            height: 1.15,
          ),
        ),
        if (item.body.isNotEmpty) ...[
          const SizedBox(height: 8),
          Text(
            item.body,
            style: const TextStyle(
              color: _ink,
              fontFamily: 'serif',
              fontSize: 15,
              height: 1.4,
            ),
          ),
        ],
      ],
    );
  }
}

class _Kicker extends StatelessWidget {
  const _Kicker({required this.item, this.big = false});

  final NewsItem item;
  final bool big;

  @override
  Widget build(BuildContext context) {
    final color = _kindColor(item.kind);
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          color: color,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(_kindIcon(item.kind), size: 12, color: Colors.white),
              const SizedBox(width: 4),
              Text(
                big ? 'À LA UNE · ${_kindLabel(item.kind)}' : _kindLabel(item.kind),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.8,
                ),
              ),
            ],
          ),
        ),
        const Spacer(),
        Text(
          shortDateFr(roundDate(item.season, item.round)),
          style: TextStyle(color: _ink.withAlpha(170), fontSize: 11),
        ),
      ],
    );
  }
}

class _Brief extends StatelessWidget {
  const _Brief({required this.item});

  final NewsItem item;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _Kicker(item: item),
          const SizedBox(height: 4),
          Text(
            item.headline,
            style: const TextStyle(
              color: _ink,
              fontFamily: 'serif',
              fontWeight: FontWeight.w800,
              fontSize: 16,
              height: 1.2,
            ),
          ),
          if (item.body.isNotEmpty) ...[
            const SizedBox(height: 3),
            Text(
              item.body,
              maxLines: 4,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: _ink.withAlpha(210),
                fontFamily: 'serif',
                fontSize: 13,
                height: 1.35,
              ),
            ),
          ],
        ],
      ),
    );
  }
}
