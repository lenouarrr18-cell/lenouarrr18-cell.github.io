import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/entities/owner.dart';
import '../common/pro_page.dart';
import '../game/game_state.dart';

const Color _accent = Color(0xFF26A69A);

/// Conférence de presse : la question du jour et vos réponses possibles.
class PressPage extends ConsumerWidget {
  const PressPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();

    final theme = Theme.of(context);
    final owner = game.owner;
    final press = owner.press;
    final quotes = owner.news.where((n) => n.kind == NewsKind.press).toList();

    return ProPage(
      title: 'Salle de presse',
      subtitle: press == null ? 'Aucun journaliste en attente' : press.context,
      icon: Icons.mic_none,
      accent: _accent,
      stats: [
        ProStat('Réputation', '${owner.reputation}/100',
            icon: Icons.workspace_premium_outlined),
        ProStat('Supporters', '${owner.fanMood}/100', icon: Icons.mood),
        ProStat('Coach', '${owner.managerTrust}/100',
            icon: Icons.sports_outlined),
        ProStat('Tension', '${owner.tension}',
            icon: Icons.bolt,
            color: owner.tension > 50 ? const Color(0xFFEF5350) : null),
      ],
      children: [
        if (press == null) ...[
          const ProEmpty(
            icon: Icons.mic_off_outlined,
            title: 'La salle est vide',
            message: 'Aucun journaliste ne vous attend. Après les matchs, les '
                'transferts ou les crises, la presse viendra chercher votre '
                'réaction.',
            accent: _accent,
          ),
          const ProSection('Ce que la presse surveille'),
          const ProGrid(
            minWidth: 260,
            children: [
              _Topic(
                icon: Icons.sports_soccer,
                title: 'Les résultats',
                text: 'Série de victoires ou de défaites, derby, objectif du '
                    'conseil.',
              ),
              _Topic(
                icon: Icons.swap_horiz,
                title: 'Le mercato',
                text: 'Départs de cadres, recrues chères, ventes contestées.',
              ),
              _Topic(
                icon: Icons.warning_amber_rounded,
                title: 'Le vestiaire',
                text: 'Joueurs mécontents, tensions avec le coach, vos veto.',
              ),
            ],
          ),
        ] else ...[
          ProCard(
            accent: _accent,
            highlight: true,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.format_quote, color: _accent, size: 30),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        press.context.toUpperCase(),
                        style: theme.textTheme.labelSmall?.copyWith(
                          letterSpacing: 1,
                          color: Colors.white60,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  press.question,
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w800,
                    height: 1.25,
                  ),
                ),
              ],
            ),
          ),
          const ProSection('Votre réponse'),
          ProGrid(
            minWidth: 300,
            children: [
              for (var i = 0; i < press.options.length; i++)
                _Answer(
                  option: press.options[i],
                  onTap: () {
                    ref.read(gameProvider.notifier).answerPress(i);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Votre réponse fera la une.'),
                      ),
                    );
                  },
                ),
            ],
          ),
          Text(
            'Sans réponse avant le prochain match, la presse parlera de votre '
            'silence.',
            style: theme.textTheme.bodySmall,
          ),
        ],
        const ProSection('Vos dernières déclarations'),
        if (quotes.isEmpty)
          Text(
            'Aucune déclaration publiée pour le moment.',
            style: theme.textTheme.bodySmall,
          ),
        for (final q in quotes.take(6))
          ProCard(
            padding: const EdgeInsets.all(12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.record_voice_over_outlined,
                    size: 18, color: _accent),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        q.headline,
                        style: theme.textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        'Saison ${q.season}, journée ${q.round}',
                        style: theme.textTheme.labelSmall,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
}

class _Topic extends StatelessWidget {
  const _Topic({required this.icon, required this.title, required this.text});

  final IconData icon;
  final String title;
  final String text;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return ProCard(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: _accent),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 2),
                Text(text, style: theme.textTheme.bodySmall),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Answer extends StatelessWidget {
  const _Answer({required this.option, required this.onTap});

  final PressOption option;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    Widget trend(String label, int v) {
      final color = v > 0
          ? const Color(0xFF43A047)
          : (v < 0 ? const Color(0xFFE53935) : Colors.white38);
      final icon = v > 0
          ? Icons.trending_up
          : (v < 0 ? Icons.trending_down : Icons.trending_flat);
      return ProTag(label, color: color, icon: icon);
    }

    return ProCard(
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '« ${option.label} »',
            style: theme.textTheme.bodyLarge?.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              trend('Supporters', option.fanMood),
              trend('Réputation', option.reputation),
              trend('Vestiaire', option.teamMood),
            ],
          ),
        ],
      ),
    );
  }
}
