import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../domain/entities/staff.dart';
import '../../engine/fans/fans.dart';
import '../../engine/finance/finance.dart';
import '../../engine/owner/infrastructure.dart';
import '../../engine/staff/staff_factory.dart';
import '../common/crest.dart';
import '../common/pro_page.dart';
import '../common/widgets.dart';
import '../game/game_state.dart';

const Color _accent = Color(0xFF7E57C2);

class SocialPage extends ConsumerStatefulWidget {
  const SocialPage({super.key});

  @override
  ConsumerState<SocialPage> createState() => _SocialPageState();
}

class _SocialPageState extends ConsumerState<SocialPage> {
  final TextEditingController _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _publish() {
    final error = ref.read(gameProvider.notifier).publishPost(_controller.text);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(error ?? 'Message publié.')),
    );
    if (error == null) _controller.clear();
  }

  @override
  Widget build(BuildContext context) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();

    final theme = Theme.of(context);
    final owner = game.owner;
    final supporters = supportersCount(
      populationThousands: game.city.population,
      prestige: owner.reputation,
    );
    final ultras = ultrasCount(supporters);
    final communityLevel = bestLevel(game.staff, StaffRole.communityManager);
    final capacity = stadiumCapacity(owner.stadium);
    final rank = game.season.userRank < 1 ? 10 : game.season.userRank;
    final attendance = attendanceFor(
      populationThousands: game.city.population,
      rank: rank,
      clubCount: game.season.clubs.length,
      prestige: owner.reputation,
      fanMood: owner.fanMood,
      capacity: capacity,
    );
    final fill = capacity == 0 ? 0.0 : attendance / capacity;
    final moodColor = Color.lerp(
      const Color(0xFFE53935),
      const Color(0xFF43A047),
      owner.fanMood / 100,
    )!;

    return ProPage(
      title: 'Supporters',
      subtitle: '${game.userClub.name} · ${game.city.name}',
      icon: Icons.campaign_outlined,
      accent: _accent,
      leading: ClubCrest(name: game.userClub.name, size: 46),
      stats: [
        ProStat('Abonnés', compactNumber(owner.followers),
            icon: Icons.people_alt_outlined),
        ProStat('Supporters', compactNumber(supporters),
            icon: Icons.groups_2_outlined),
        ProStat('Ultras', compactNumber(ultras),
            icon: Icons.local_fire_department_outlined),
        ProStat('Humeur', '${owner.fanMood}/100',
            icon: Icons.mood, color: moodColor),
      ],
      side: [
        ProMeter(
          label: 'Remplissage prévu du stade',
          value: (fill * 100).round(),
          suffix: '${(fill * 100).round()} %',
        ),
      ],
      children: [
        ProGrid(
          minWidth: 320,
          children: [
            ProCard(
              title: 'Tribunes',
              icon: Icons.stadium_outlined,
              accent: _accent,
              highlight: true,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    fanMoodLabel(owner.fanMood),
                    style: theme.textTheme.titleMedium?.copyWith(
                      color: moodColor,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  ProMeter(label: 'Humeur des supporters', value: owner.fanMood),
                  ProMeter(
                    label: 'Affluence attendue',
                    value: attendance,
                    max: capacity,
                    suffix: '${compactNumber(attendance)} / '
                        '${compactNumber(capacity)}',
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'L\'humeur dépend des résultats, de vos déclarations et de '
                    'vos choix. Elle agit sur l\'affluence, la billetterie et '
                    'l\'avantage du terrain.',
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
            ProCard(
              title: 'Ce qui fait vibrer les tribunes',
              icon: Icons.tips_and_updates_outlined,
              accent: _accent,
              child: Column(
                children: [
                  _Lever(
                    icon: Icons.emoji_events_outlined,
                    text: 'Gagner, surtout à domicile',
                    ok: owner.fanMood >= 60,
                  ),
                  _Lever(
                    icon: Icons.celebration_outlined,
                    text: 'Fan zone : niveau ${owner.fanZone}',
                    ok: owner.fanZone >= 2,
                  ),
                  _Lever(
                    icon: Icons.mic_none,
                    text: owner.press == null
                        ? 'Aucune question de presse en attente'
                        : 'Une question de presse attend votre réponse',
                    ok: owner.press == null,
                  ),
                  _Lever(
                    icon: Icons.campaign_outlined,
                    text: communityLevel > 0
                        ? 'Community manager niveau $communityLevel'
                        : 'Aucun community manager',
                    ok: communityLevel > 0,
                  ),
                ],
              ),
            ),
          ],
        ),
        const ProSection('Compte officiel du club'),
        if (communityLevel == 0)
          ProEmpty(
            icon: Icons.lock_outline,
            title: 'Compte en sommeil',
            message: 'Engagez un community manager pour animer le compte du '
                'club, gagner des abonnés et publier vous-même.',
            accent: _accent,
            action: FilledButton.tonalIcon(
              onPressed: () => context.push('/staff'),
              icon: const Icon(Icons.person_add_alt_1_outlined),
              label: const Text('Ouvrir le staff'),
            ),
          )
        else
          ProCard(
            accent: _accent,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ClubCrest(name: game.userClub.name, size: 36),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      TextField(
                        controller: _controller,
                        maxLength: 140,
                        maxLines: 2,
                        decoration: const InputDecoration(
                          hintText: 'Un message pour vos supporters…',
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                      ),
                      FilledButton.icon(
                        onPressed: _publish,
                        icon: const Icon(Icons.send, size: 18),
                        label: const Text('Publier'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ProSection(
          'Fil d\'actualité',
          trailing: ProTag('${game.social.length}', color: _accent),
        ),
        if (game.social.isEmpty)
          const ProEmpty(
            icon: Icons.dynamic_feed_outlined,
            title: 'Le fil est calme',
            message: 'Jouez une journée : supporters, journalistes et rivaux '
                'réagiront à vos résultats et à vos décisions.',
            accent: _accent,
          ),
        ProGrid(
          minWidth: 340,
          children: [
            for (final post in game.social)
              ProCard(
                highlight: post.isUser,
                accent: _accent,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(
                      radius: 18,
                      backgroundColor: _accent.withAlpha(90),
                      child: Text(
                        post.author.isEmpty
                            ? '?'
                            : post.author.substring(0, 1).toUpperCase(),
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  post.author,
                                  style: theme.textTheme.labelLarge?.copyWith(
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ),
                              Text(
                                'S${post.season} · J${post.round}',
                                style: theme.textTheme.labelSmall,
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(post.text),
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              const Icon(Icons.favorite,
                                  size: 14, color: Color(0xFFEF5350)),
                              const SizedBox(width: 4),
                              Text(
                                compactNumber(post.likes),
                                style: theme.textTheme.labelSmall,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ],
    );
  }
}

class _Lever extends StatelessWidget {
  const _Lever({required this.icon, required this.text, required this.ok});

  final IconData icon;
  final String text;
  final bool ok;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, size: 18, color: Colors.white70),
          const SizedBox(width: 10),
          Expanded(child: Text(text)),
          Icon(
            ok ? Icons.check_circle : Icons.radio_button_unchecked,
            size: 18,
            color: ok ? const Color(0xFF43A047) : Colors.white38,
          ),
        ],
      ),
    );
  }
}
