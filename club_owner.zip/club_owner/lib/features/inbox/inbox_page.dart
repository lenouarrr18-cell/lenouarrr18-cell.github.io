import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/entities/owner.dart';
import '../../engine/game/governance.dart';
import '../game/game_state.dart';

enum _Box { inbox, unread, archive }

IconData _senderIcon(String s) {
  switch (s) {
    case 'ds':
      return Icons.business_center_outlined;
    case 'manager':
      return Icons.sports_outlined;
    case 'finance':
      return Icons.account_balance_wallet_outlined;
    case 'academy':
      return Icons.school_outlined;
    case 'medical':
      return Icons.medical_services_outlined;
    case 'commercial':
      return Icons.storefront_outlined;
    case 'supporters':
      return Icons.groups_outlined;
    case 'board':
      return Icons.gavel_outlined;
    default:
      return Icons.shield_outlined;
  }
}

/// Messagerie du président : un message n'est marqué lu qu'à son
/// ouverture ; on peut ensuite le garder non lu, l'archiver ou le
/// supprimer, seul ou par sélection multiple.
class InboxPage extends ConsumerStatefulWidget {
  const InboxPage({super.key});

  @override
  ConsumerState<InboxPage> createState() => _InboxPageState();
}

class _InboxPageState extends ConsumerState<InboxPage> {
  _Box _box = _Box.inbox;
  int? _open;
  final Set<int> _selected = {};

  bool get _selecting => _selected.isNotEmpty;

  void _openMessage(int index, InboxMessage m) {
    if (_selecting) {
      setState(() {
        _selected.contains(index) ? _selected.remove(index) : _selected.add(index);
      });
      return;
    }
    setState(() => _open = index);
    if (!m.read) ref.read(gameProvider.notifier).flagMessages({index}, read: true);
  }

  void _act(Set<int> indices, {bool? read, bool? archived, bool delete = false}) {
    final notifier = ref.read(gameProvider.notifier);
    if (delete) {
      notifier.deleteMessages(indices);
    } else {
      notifier.flagMessages(indices, read: read, archived: archived);
    }
    setState(() {
      _selected.clear();
      if (delete || archived != null || read == false) _open = null;
    });
    final n = indices.length;
    final what = delete
        ? 'supprimé'
        : (archived == true
            ? 'archivé'
            : (archived == false ? 'remis dans la boîte' : (read == false ? 'gardé non lu' : 'marqué lu')));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(n > 1 ? '$n messages : $what.' : 'Message $what.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();
    final theme = Theme.of(context);
    final all = game.owner.inbox;
    final entries = <int>[
      for (var i = 0; i < all.length; i++)
        if (switch (_box) {
          _Box.inbox => !all[i].archived,
          _Box.unread => !all[i].archived && !all[i].read,
          _Box.archive => all[i].archived,
        })
          i,
    ];
    final openIndex = _open != null && _open! < all.length ? _open : null;
    final open = openIndex == null ? null : all[openIndex];
    final archivedCount = all.where((m) => m.archived).length;

    final list = Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(10, 8, 10, 4),
          child: SegmentedButton<_Box>(
            showSelectedIcon: false,
            segments: [
              ButtonSegment(
                value: _Box.inbox,
                icon: const Icon(Icons.inbox, size: 18),
                label: const Text('Réception'),
              ),
              ButtonSegment(
                value: _Box.unread,
                icon: const Icon(Icons.mark_email_unread_outlined, size: 18),
                label: Text('Non lus (${game.owner.unreadCount})'),
              ),
              ButtonSegment(
                value: _Box.archive,
                icon: const Icon(Icons.archive_outlined, size: 18),
                label: Text('Archives ($archivedCount)'),
              ),
            ],
            selected: {_box},
            onSelectionChanged: (s) => setState(() {
              _box = s.first;
              _selected.clear();
            }),
          ),
        ),
        if (_selecting)
          Container(
            color: theme.colorScheme.surfaceContainerHigh,
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => setState(_selected.clear),
                ),
                Text('${_selected.length} sélectionné(s)'),
                const Spacer(),
                IconButton(
                  tooltip: 'Marquer lu',
                  icon: const Icon(Icons.drafts_outlined),
                  onPressed: () => _act({..._selected}, read: true),
                ),
                IconButton(
                  tooltip: 'Garder non lu',
                  icon: const Icon(Icons.mark_email_unread_outlined),
                  onPressed: () => _act({..._selected}, read: false),
                ),
                IconButton(
                  tooltip: _box == _Box.archive ? 'Désarchiver' : 'Archiver',
                  icon: Icon(
                    _box == _Box.archive ? Icons.unarchive_outlined : Icons.archive_outlined,
                  ),
                  onPressed: () =>
                      _act({..._selected}, archived: _box != _Box.archive),
                ),
                IconButton(
                  tooltip: 'Supprimer',
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () => _act({..._selected}, delete: true),
                ),
              ],
            ),
          ),
        Expanded(
          child: entries.isEmpty
              ? Center(
                  child: Text(
                    _box == _Box.archive
                        ? 'Aucun message archivé.'
                        : 'Aucun message.',
                    style: theme.textTheme.bodySmall,
                  ),
                )
              : ListView.separated(
                  itemCount: entries.length,
                  separatorBuilder: (_, __) =>
                      const Divider(height: 1, color: Colors.white10),
                  itemBuilder: (context, k) {
                    final i = entries[k];
                    final m = all[i];
                    final selected = _selected.contains(i);
                    return Material(
                      color: selected
                          ? theme.colorScheme.primary.withAlpha(40)
                          : (openIndex == i
                              ? Colors.white.withAlpha(12)
                              : Colors.transparent),
                      child: InkWell(
                        onTap: () => _openMessage(i, m),
                        onLongPress: () => setState(() => _selected.add(i)),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 10,
                          ),
                          child: Row(
                            children: [
                              if (_selecting)
                                Checkbox(
                                  value: selected,
                                  onChanged: (_) => _openMessage(i, m),
                                )
                              else
                                CircleAvatar(
                                  radius: 17,
                                  backgroundColor: m.read
                                      ? Colors.white10
                                      : theme.colorScheme.primary.withAlpha(70),
                                  child: Icon(
                                    _senderIcon(m.sender),
                                    size: 18,
                                    color: Colors.white,
                                  ),
                                ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Text(
                                            senderLabels[m.sender] ?? 'Club',
                                            style: theme.textTheme.labelSmall,
                                          ),
                                        ),
                                        Text(
                                          'S${m.season} · J${m.round}',
                                          style: theme.textTheme.labelSmall,
                                        ),
                                      ],
                                    ),
                                    Text(
                                      m.title,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontWeight: m.read
                                            ? FontWeight.w500
                                            : FontWeight.w800,
                                      ),
                                    ),
                                    Text(
                                      m.body,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: theme.textTheme.bodySmall,
                                    ),
                                  ],
                                ),
                              ),
                              if (!m.read && !_selecting)
                                Container(
                                  width: 9,
                                  height: 9,
                                  margin: const EdgeInsets.only(left: 6),
                                  decoration: BoxDecoration(
                                    color: theme.colorScheme.primary,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );

    final reader = open == null
        ? Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.mail_outline, size: 48, color: Colors.white24),
                const SizedBox(height: 8),
                Text(
                  'Touchez un message pour le lire.\n'
                  'Appui long pour en sélectionner plusieurs.',
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodySmall,
                ),
              ],
            ),
          )
        : ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Row(
                children: [
                  CircleAvatar(
                    child: Icon(_senderIcon(open.sender), size: 20),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          senderLabels[open.sender] ?? 'Club',
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                        Text(
                          'Saison ${open.season}, journée ${open.round}',
                          style: theme.textTheme.labelSmall,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                open.title,
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 10),
              Text(open.body, style: theme.textTheme.bodyLarge?.copyWith(height: 1.5)),
              const SizedBox(height: 20),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  OutlinedButton.icon(
                    onPressed: () => _act({openIndex!}, read: false),
                    icon: const Icon(Icons.mark_email_unread_outlined),
                    label: const Text('Garder non lu'),
                  ),
                  OutlinedButton.icon(
                    onPressed: () =>
                        _act({openIndex!}, archived: !open.archived),
                    icon: Icon(
                      open.archived ? Icons.unarchive_outlined : Icons.archive_outlined,
                    ),
                    label: Text(open.archived ? 'Désarchiver' : 'Archiver'),
                  ),
                  FilledButton.tonalIcon(
                    onPressed: () => _act({openIndex!}, delete: true),
                    icon: const Icon(Icons.delete_outline),
                    label: const Text('Supprimer'),
                  ),
                ],
              ),
            ],
          );

    return Scaffold(
      appBar: AppBar(
        title: Text(
          game.owner.unreadCount > 0
              ? 'Messagerie (${game.owner.unreadCount})'
              : 'Messagerie',
        ),
        actions: [
          if (entries.isNotEmpty)
            TextButton(
              onPressed: () => setState(() {
                if (_selected.length == entries.length) {
                  _selected.clear();
                } else {
                  _selected
                    ..clear()
                    ..addAll(entries);
                }
              }),
              child: Text(
                _selected.length == entries.length ? 'Désélectionner' : 'Tout sélectionner',
              ),
            ),
        ],
      ),
      body: LayoutBuilder(
        builder: (context, box) {
          if (box.maxWidth < 640) {
            return open == null
                ? list
                : Column(
                    children: [
                      Align(
                        alignment: Alignment.centerLeft,
                        child: TextButton.icon(
                          onPressed: () => setState(() => _open = null),
                          icon: const Icon(Icons.arrow_back),
                          label: const Text('Retour à la liste'),
                        ),
                      ),
                      Expanded(child: reader),
                    ],
                  );
          }
          return Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(width: (box.maxWidth * 0.42).clamp(300.0, 460.0), child: list),
              const VerticalDivider(width: 1),
              Expanded(child: reader),
            ],
          );
        },
      ),
    );
  }
}
