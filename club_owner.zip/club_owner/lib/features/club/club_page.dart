import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/utils/format.dart';
import '../../domain/entities/division.dart';
import '../../domain/entities/tactic.dart';
import '../../domain/entities/transfer.dart';
import '../../engine/fans/fans.dart';
import '../common/crest.dart';
import '../common/labels.dart';
import '../common/pro_page.dart';
import '../common/widgets.dart';
import '../../core/l10n/l10n.dart';
import '../game/game_state.dart';

class ClubPage extends ConsumerWidget {
  const ClubPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();

    final theme = Theme.of(context);
    final owner = game.owner;
    final history = game.history.reversed.toList();
    final supporters = supportersCount(
      populationThousands: game.city.population,
      prestige: owner.reputation,
    );
    final unread = owner.unreadCount;
    final pendingOffers = game.offers
        .where((o) => o.incoming || o.status == OfferStatus.countered)
        .length;

    final tiles = <Widget>[
      MenuTile(
        icon: Icons.badge_outlined,
        title: ref.t('club.staff'),
        subtitle: game.manager == null
            ? 'Engagez un manager'
            : '${game.staff.length} membres',
        color: const Color(0xFF3F51B5),
        onTap: () => context.push('/staff'),
      ),
      MenuTile(
        icon: Icons.swap_horizontal_circle_outlined,
        title: ref.t('club.transfers'),
        subtitle: 'Mercato mondial, offres, prêts',
        color: const Color(0xFFE65100),
        badge: pendingOffers > 0 ? '$pendingOffers' : null,
        onTap: () => context.push('/transfers'),
      ),
      MenuTile(
        icon: Icons.stadium_outlined,
        title: ref.t('club.infrastructure'),
        subtitle: owner.stadiumName.isEmpty ? 'Stade' : owner.stadiumName,
        color: const Color(0xFF2E7D32),
        onTap: () => context.push('/infrastructure'),
      ),
      MenuTile(
        icon: Icons.handshake_outlined,
        title: 'Sponsors et banque',
        subtitle: owner.deal == null ? 'Aucun sponsor' : owner.deal!.name,
        color: const Color(0xFF00897B),
        onTap: () => context.push('/business'),
      ),
      MenuTile(
        icon: Icons.sports_soccer,
        title: 'Tactique',
        subtitle: game.userClub.tactic.formation.label,
        color: const Color(0xFF558B2F),
        onTap: () => context.push('/tactics'),
      ),
      MenuTile(
        icon: Icons.groups_2_outlined,
        title: 'Supporters et réseau',
        subtitle: '${compactNumber(supporters)} fans, '
            '${compactNumber(owner.followers)} abonnés',
        color: const Color(0xFFD81B60),
        onTap: () => context.push('/social'),
      ),
      MenuTile(
        icon: Icons.emoji_events_outlined,
        title: 'Palmarès',
        subtitle: 'Distinctions, buteurs, GOAT',
        color: const Color(0xFFF9A825),
        onTap: () => context.push('/honours'),
      ),
      MenuTile(
        icon: Icons.workspace_premium_outlined,
        title: 'Compétitions de clubs',
        subtitle: 'Ligue des champions, Europa...',
        color: const Color(0xFF283593),
        onTap: () => context.push('/cups'),
      ),
      MenuTile(
        icon: Icons.public,
        title: 'Sélections',
        subtitle: 'Coupe du monde, CAN, Euro...',
        color: const Color(0xFF0277BD),
        onTap: () => context.push('/international'),
      ),
      MenuTile(
        icon: Icons.public_outlined,
        title: 'Championnats du monde',
        subtitle: 'Classements, buteurs, clubs',
        color: const Color(0xFF6D4C41),
        onTap: () => context.push('/leagues'),
      ),
      MenuTile(
        icon: Icons.newspaper,
        title: 'Journal',
        subtitle: owner.news.isEmpty ? 'Gros titres' : owner.news.first.headline,
        color: const Color(0xFF455A64),
        onTap: () => context.push('/news'),
      ),
      MenuTile(
        icon: Icons.mic_none,
        title: 'Presse',
        subtitle: owner.press == null ? 'Aucune question' : 'Une question vous attend',
        color: const Color(0xFFAD1457),
        badge: owner.press == null ? null : '1',
        onTap: () => context.push('/press'),
      ),
      MenuTile(
        icon: Icons.menu_book_outlined,
        title: 'Guide',
        subtitle: 'Tout comprendre',
        color: const Color(0xFF00695C),
        onTap: () => context.push('/guide'),
      ),
      MenuTile(
        icon: Icons.psychology_alt_outlined,
        title: 'Conseiller',
        subtitle: 'Analyse de votre club',
        color: const Color(0xFF00838F),
        onTap: () => context.push('/advisor'),
      ),
      MenuTile(
        icon: Icons.account_balance_outlined,
        title: 'Bureau du président',
        subtitle: owner.decisions.isEmpty
            ? 'Direction, missions'
            : '${owner.decisions.length} décision(s) à valider',
        color: const Color(0xFFB8860B),
        badge: owner.decisions.isEmpty ? null : '${owner.decisions.length}',
        onTap: () => context.push('/office'),
      ),
      MenuTile(
        icon: Icons.mail_outline,
        title: 'Messagerie',
        subtitle: unread > 0 ? '$unread non lus' : 'Aucun nouveau message',
        color: const Color(0xFF8E24AA),
        badge: unread > 0 ? '$unread' : null,
        onTap: () => context.push('/inbox'),
      ),
      MenuTile(
        icon: Icons.save_outlined,
        title: 'Sauvegardes',
        subtitle: '3 emplacements',
        color: const Color(0xFF546E7A),
        onTap: () => context.push('/saves'),
      ),
      MenuTile(
        icon: Icons.settings_outlined,
        title: 'Paramètres',
        subtitle: 'Difficulté, nouvelle partie',
        color: const Color(0xFF757575),
        onTap: () => context.push('/settings'),
      ),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Club')),
      body: ProColumns(
        flex: const [2, 5],
        columns: [
          [
            HeroHeader(
              crest: ClubCrest(name: game.userClub.name, size: 56),
              title: game.userClub.name,
              subtitle: '${game.city.name}, ${game.country.name}',
              chips: [
                InfoChip(divisionName(game.division), icon: Icons.emoji_events),
                InfoChip(
                  owner.stadiumName.isEmpty ? 'Stade' : owner.stadiumName,
                  icon: Icons.stadium_outlined,
                ),
              ],
            ),
            const SizedBox(height: 12),
            ProMeter(label: 'Prestige', value: owner.reputation),
            ProMeter(label: 'Humeur des supporters', value: owner.fanMood),
            ProMeter(label: 'Confiance du conseil', value: owner.confidence),
            const SizedBox(height: 12),
            Text('HISTORIQUE DES SAISONS', style: theme.textTheme.labelSmall),
            const SizedBox(height: 6),
            if (history.isEmpty)
              Text('Aucune saison terminée.', style: theme.textTheme.bodySmall),
            for (final record in history)
              ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: CircleAvatar(radius: 14, child: Text('${record.season}')),
                title: Text(
                  '${ordinalFr(record.rank)} en ${divisionName(record.division)}',
                ),
                subtitle: Text(outcomeLabel(record.outcome)),
              ),
          ],
          [
            for (final section in [
              ('Direction du club', [0, 1, 2, 3, 14]),
              ('Équipe et médias', [4, 5, 10, 11]),
              ('Compétitions', [7, 9, 8, 6]),
              ('Outils', [13, 12, 16]),
            ]) ...[
              ProSection(section.$1),
              LayoutBuilder(
                builder: (context, box) => GridView.count(
                  crossAxisCount:
                      (box.maxWidth / 170).floor().clamp(2, 5).toInt(),
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  childAspectRatio: 1.45,
                  mainAxisSpacing: 4,
                  crossAxisSpacing: 4,
                  children: [
                    for (final i in section.$2)
                      if (i < tiles.length) tiles[i],
                  ],
                ),
              ),
              const SizedBox(height: 8),
            ],
          ],
        ],
      ),
    );
  }
}
