import 'dart:convert';
import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../engine/game/game_codec.dart';
import '../../engine/game/game_state.dart';
import '../../engine/world/world_engine.dart';

/// Doit être surchargé au démarrage avec l'instance chargée.
final sharedPreferencesProvider = Provider<SharedPreferences>(
  (ref) => throw UnimplementedError('sharedPreferencesProvider non fourni'),
);

final gameRepositoryProvider = Provider<GameRepository>(
  (ref) => GameRepository(ref.watch(sharedPreferencesProvider)),
);

/// Sauvegarde de la partie (un seul emplacement pour l'instant).
class GameRepository {
  GameRepository(this._prefs);

  static const String key = 'game_save_v2';

  /// Nombre d'emplacements de sauvegarde manuels.
  static const int slotCount = 3;

  /// Copie de sécurité de la dernière sauvegarde saine.
  static const String backupKey = 'game_save_backup_v1';

  static String slotKey(int slot) => 'game_slot_v2_$slot';

  final SharedPreferences _prefs;

  GameState? _decode(String? raw) {
    if (raw == null) return null;
    try {
      return decodeGame(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      // Sauvegarde illisible ou corrompue : on l'ignore.
      return null;
    }
  }

  /// Clé du cliché compressé du monde simulé.
  static const String worldKey = 'game_world_v1';

  int _worldSeason = -1;
  int _worldRound = -1;

  static String _pack(Map<String, Object?> json) {
    return base64Encode(gzip.encode(utf8.encode(jsonEncode(json))));
  }

  static Map<String, dynamic> _unpack(String raw) {
    return jsonDecode(utf8.decode(gzip.decode(base64Decode(raw))))
        as Map<String, dynamic>;
  }

  /// Charge la partie. Le monde simulé est relu depuis son cliché puis
  /// rattrapé jusqu'à la journée en cours (la simulation est déterministe).
  GameState? load() {
    // Si la sauvegarde principale est illisible, on retombe sur la copie.
    final main =
        _decode(_prefs.getString(key)) ?? _decode(_prefs.getString(backupKey));
    if (main == null) return null;
    final rawWorld = _prefs.getString(worldKey);
    if (rawWorld == null) return main;
    try {
      final decoded = decodeWorldSnapshot(
        _unpack(rawWorld),
        seasonNumber: main.seasonNumber,
      );
      if (decoded == null || decoded.isEmpty) return main;
      var leagues = decoded;
      final target = main.season.currentRound;
      for (var guard = 0; guard < 40; guard++) {
        final behind = leagues.any(
          (l) => !l.season.isFinished && l.season.currentRound < target,
        );
        if (!behind) break;
        leagues = playWorldRound(leagues);
      }
      _worldSeason = main.seasonNumber;
      _worldRound = main.season.currentRound;
      return main.copyWith(world: leagues);
    } catch (_) {
      return main;
    }
  }

  /// Les emplacements manuels ne contiennent pas le monde simulé : il est
  /// régénéré et mis à la bonne journée au chargement.
  GameState? loadSlot(int slot) => _decode(_prefs.getString(slotKey(slot)));

  /// Lit une sauvegarde brute (JSON), par exemple venue du cloud.
  GameState? decodeRaw(String raw) => _decode(raw);

  Future<void> saveSlot(int slot, GameState state) async {
    await _prefs.setString(
      slotKey(slot),
      jsonEncode(encodeGame(state, includeWorld: false)),
    );
  }

  /// Sauvegarde la partie. Le monde simulé, plus lourd, n'est écrit (en
  /// compressé) que toutes les 5 journées, à chaque changement de saison
  /// ou quand [forceWorld] est vrai.
  Future<void> save(GameState state, {bool forceWorld = false}) async {
    final previous = _prefs.getString(key);
    final encoded = jsonEncode(encodeGame(state, includeWorld: false));
    // La copie est la sauvegarde précédente, tant qu'elle se relit bien.
    if (previous != null && previous != encoded && previous.startsWith('{')) {
      await _prefs.setString(backupKey, previous);
    }
    await _prefs.setString(key, encoded);
    if (state.world.isEmpty) return;
    final round = state.season.currentRound;
    final due =
        forceWorld ||
        _worldSeason != state.seasonNumber ||
        (round - _worldRound).abs() >= 5;
    if (!due) return;
    await _prefs.setString(worldKey, _pack(encodeWorldSnapshot(state)));
    _worldSeason = state.seasonNumber;
    _worldRound = round;
  }

  Future<void> clear() async {
    await _prefs.remove(key);
    await _prefs.remove(backupKey);
    await _prefs.remove(worldKey);
    _worldSeason = -1;
    _worldRound = -1;
  }
}
