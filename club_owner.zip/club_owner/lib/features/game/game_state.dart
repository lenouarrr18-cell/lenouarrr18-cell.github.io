import 'dart:async';
import 'dart:math';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/entities/country.dart';
import '../../domain/entities/owner.dart';
import '../../domain/entities/tactic.dart';
import '../../domain/entities/transfer.dart';
import '../../engine/game/game_state.dart';
import '../../engine/game/governance.dart';
import '../../engine/game/owner_actions.dart';
import '../../engine/game/press_actions.dart';
import '../../engine/game/budgets.dart';
import '../../engine/game/recruitment.dart';
import '../../engine/game/round_hooks.dart';
import '../../engine/game/transfer_actions.dart';
import 'game_repository.dart';

export '../../engine/game/game_state.dart';
export '../../engine/game/owner_actions.dart';
export '../../engine/game/press_actions.dart';
export '../../engine/game/budgets.dart';
export '../../engine/game/recruitment.dart';
export '../../engine/game/round_hooks.dart';
export '../../engine/game/transfer_actions.dart';

/// Expose la partie à l'interface et la sauvegarde à chaque changement.
/// Toute la logique de jeu vit dans `GameState` (Dart pur, testé).
class GameNotifier extends Notifier<GameState?> {
  @override
  GameState? build() => ref.read(gameRepositoryProvider).load();

  int _newSeed() => Random().nextInt(1 << 31);

  void _commit(GameState? next, {bool forceWorld = false}) {
    state = next;
    final repository = ref.read(gameRepositoryProvider);
    if (next == null) {
      unawaited(repository.clear());
    } else {
      unawaited(repository.save(next, forceWorld: forceWorld));
    }
  }

  void startNewGame({
    required String clubName,
    required Country country,
    required City city,
  }) {
    _commit(
      GameState.newGame(
        clubName: clubName,
        country: country,
        city: city,
        seed: _newSeed(),
      ),
      forceWorld: true,
    );
  }

  void resetGame() => _commit(null);

  /// Prime hors match (fidélité, défi du jour) : versée en trésorerie,
  /// comptée dans les recettes diverses, annoncée par un message.
  void grantBonus(int amount, String title, String body) {
    final game = state;
    if (game == null || amount <= 0) return;
    final f = game.finance;
    _commit(game.copyWith(
      finance: f.copyWith(treasury: f.treasury + amount, extras: f.extras + amount),
      owner: game.owner.addMessage(
        InboxMessage(
          title: title,
          body: body,
          season: game.seasonNumber,
          round: game.season.currentRound,
          sender: 'board',
        ),
      ),
    ));
  }

  void playNextRound() {
    final current = state;
    if (current == null) return;
    _commit(current.playNextRound());
  }

  /// Simule jusqu'à [count] journées d'affilée (arrêt si la composition est
  /// incomplète). Renvoie le nombre de journées jouées.
  int simulateRounds(int count) {
    final current = state;
    if (current == null) return 0;
    var next = current;
    var played = 0;
    while (played < count && next.canPlayNextRound) {
      next = next.playNextRound();
      played++;
    }
    if (played > 0) _commit(next);
    return played;
  }

  void startNextSeason() {
    final current = state;
    if (current == null) return;
    _commit(current.startNextSeason(_newSeed()));
  }

  void autoPickStarters() {
    final current = state;
    if (current == null) return;
    _commit(current.autoPickStarters());
  }

  /// Renvoie un message d'erreur si l'action est refusée, sinon `null`.
  String? toggleStarter(String playerId) {
    final current = state;
    if (current == null) return null;
    final error = current.validateToggleStarter(playerId);
    if (error == null) _commit(current.toggleStarter(playerId));
    return error;
  }

  String? buyPlayer(String playerId, {SquadSlot slot = SquadSlot.first}) {
    final current = state;
    if (current == null) return null;
    final error = current.validateBuy(playerId, slot: slot);
    if (error == null) _commit(current.buyPlayer(playerId, slot: slot));
    return error;
  }

  String? hireStaff(String candidateId) {
    final current = state;
    if (current == null) return null;
    final error = current.validateHire(candidateId);
    if (error == null) _commit(current.hireStaff(candidateId));
    return error;
  }

  String? fireStaff(String staffId) {
    final current = state;
    if (current == null) return null;
    final error = current.validateFire(staffId);
    if (error == null) _commit(current.fireStaff(staffId));
    return error;
  }

  String? prospect({List<String> nationPool = const []}) {
    final current = state;
    if (current == null) return null;
    final error = current.validateProspecting();
    if (error == null) _commit(current.prospect(nationPool: nationPool));
    return error;
  }

  // ---------- tactique ----------

  void setTactic(Tactic tactic) {
    final current = state;
    if (current == null) return;
    _commit(current.setTactic(tactic));
  }

  void savePreset(int index) {
    final current = state;
    if (current == null) return;
    _commit(current.savePreset(index));
  }

  void loadPreset(int index) {
    final current = state;
    if (current == null) return;
    _commit(current.loadPreset(index));
  }

  void setFormation(Formation formation) {
    final current = state;
    if (current == null) return;
    _commit(current.setFormation(formation));
  }

  void setStyle(TacticStyle style) {
    final current = state;
    if (current == null) return;
    _commit(current.setStyle(style));
  }

  void setPressing(Pressing pressing) {
    final current = state;
    if (current == null) return;
    _commit(current.setPressing(pressing));
  }

  // ---------- budgets du président ----------

  void setBudgets({int? transfer, int? wage}) =>
      _apply((g) => g.setBudgets(transfer: transfer, wage: wage));

  void toggleSellList(String playerId) =>
      _apply((g) => g.toggleSellList(playerId));

  // ---------- recrutement (via le directeur sportif) ----------

  String? requestRecruit(String playerId, int maxFee, {bool loan = false}) {
    final current = state;
    if (current == null) return null;
    final error = current.validateRecruit(playerId, maxFee);
    if (error == null) {
      _commit(current.requestRecruit(playerId, maxFee, loan: loan));
    }
    return error;
  }

  void insistRecruit(String id) {
    final current = state;
    if (current == null) return;
    _commit(current.insistRecruit(id));
  }

  void cancelRecruit(String id) {
    final current = state;
    if (current == null) return;
    _commit(current.cancelRecruit(id));
  }

  // ---------- transferts ----------

  /// Renvoie un message d'erreur, ou `null` si l'offre est partie.
  String? makeOffer({
    required String playerId,
    required OfferKind kind,
    required int fee,
    int optionFee = 0,
  }) {
    final current = state;
    if (current == null) return null;
    final error = current.validateOffer(
      playerId: playerId,
      kind: kind,
      fee: fee,
      optionFee: optionFee,
    );
    if (error == null) {
      _commit(
        current.makeOffer(
          playerId: playerId,
          kind: kind,
          fee: fee,
          optionFee: optionFee,
        ),
        forceWorld: true,
      );
    }
    return error;
  }

  String? raiseOffer(String offerId, int newFee) {
    final current = state;
    if (current == null) return null;
    final error = current.validateRaise(offerId, newFee);
    if (error == null) {
      _commit(current.raiseOffer(offerId, newFee), forceWorld: true);
    }
    return error;
  }

  String? acceptCounter(String offerId) {
    final current = state;
    if (current == null) return null;
    final error = current.validateAcceptCounter(offerId);
    if (error == null) {
      _commit(current.acceptCounter(offerId), forceWorld: true);
    }
    return error;
  }

  void withdrawOffer(String offerId) {
    final current = state;
    if (current == null) return;
    _commit(current.withdrawOffer(offerId));
  }

  String? respondIncoming(String offerId, {required bool accept}) {
    final current = state;
    if (current == null) return null;
    final error = accept ? current.validateAcceptIncoming(offerId) : null;
    if (error == null) {
      _commit(current.respondIncoming(offerId, accept: accept));
    }
    return error;
  }

  String? releasePlayer(String playerId) {
    final current = state;
    if (current == null) return null;
    final error = current.validateRelease(playerId);
    if (error == null) _commit(current.releasePlayer(playerId));
    return error;
  }

  String? renewContract(String playerId, int years) {
    final current = state;
    if (current == null) return null;
    final error = current.validateRenew(playerId, years);
    if (error == null) _commit(current.renewContract(playerId, years));
    return error;
  }

  String? moveToTeam(String playerId, SquadSlot target) {
    final current = state;
    if (current == null) return null;
    final error = current.validateMoveTo(playerId, target);
    if (error == null) _commit(current.moveToTeam(playerId, target));
    return error;
  }

  String? exerciseOption(String playerId) {
    final current = state;
    if (current == null) return null;
    final error = current.validateExerciseOption(playerId);
    if (error == null) {
      _commit(current.exerciseOption(playerId), forceWorld: true);
    }
    return error;
  }

  // ---------- presse, humeur, prêts, délégation ----------

  void answerPress(int index) {
    final current = state;
    if (current == null) return;
    _commit(current.answerPress(index));
  }

  String? talkToPlayer(String playerId) {
    final current = state;
    if (current == null) return null;
    final error = current.validateTalk(playerId);
    if (error == null) _commit(current.talkToPlayer(playerId));
    return error;
  }

  String? sendOnLoan(String playerId, String clubId) {
    final current = state;
    if (current == null) return null;
    final error = current.validateSendOnLoan(playerId, clubId);
    if (error == null) _commit(current.sendOnLoan(playerId, clubId));
    return error;
  }

  void setDelegate(bool value) {
    final current = state;
    if (current == null) return;
    _commit(current.copyWith(owner: current.owner.copyWith(delegate: value)));
  }

  // ---------- réglages et réseau social ----------

  String? renameStadium(String name) {
    final current = state;
    if (current == null) return null;
    final error = current.validateStadiumName(name);
    if (error == null) _commit(current.renameStadium(name));
    return error;
  }

  void setSeatColor(int index) {
    final current = state;
    if (current == null) return;
    _commit(current.setSeatColor(index));
  }

  void setDifficulty(int level) {
    final current = state;
    if (current == null) return;
    _commit(current.setDifficulty(level));
  }

  String? publishPost(String text) {
    final current = state;
    if (current == null) return null;
    final trimmed = text.trim();
    if (trimmed.isEmpty) return 'Écrivez un message.';
    final error = current.validatePost();
    if (error == null) _commit(current.publishPost(trimmed));
    return error;
  }

  String? startUpgrade(InfraKind kind) {
    final current = state;
    if (current == null) return null;
    final error = current.validateUpgrade(kind);
    if (error == null) _commit(current.startUpgrade(kind));
    return error;
  }

  String? signSponsor(String offerId) {
    final current = state;
    if (current == null) return null;
    final error = current.validateSignSponsor(offerId);
    if (error == null) _commit(current.signSponsor(offerId));
    return error;
  }

  String? cancelSponsor() {
    final current = state;
    if (current == null) return null;
    final error = current.validateCancelSponsor();
    if (error == null) _commit(current.cancelSponsor());
    return error;
  }

  String? takeLoan(int amount) {
    final current = state;
    if (current == null) return null;
    final error = current.validateLoan(amount);
    if (error == null) _commit(current.takeLoan(amount));
    return error;
  }

  String? repayLoan() {
    final current = state;
    if (current == null) return null;
    final error = current.validateRepay();
    if (error == null) _commit(current.repayLoan());
    return error;
  }

  void _apply(GameState Function(GameState g) action) {
    final current = state;
    if (current == null) return;
    _commit(action(current));
  }

  void approveDecision(String id) => _apply((g) => g.approveDecision(id));
  void blockDecision(String id) => _apply((g) => g.blockDecision(id));
  void alternativeDecision(String id) =>
      _apply((g) => g.requestAlternative(id));
  void deleteMessage(int index) => _apply((g) => g.deleteMessage(index));

  void deleteMessages(Set<int> indices) =>
      _apply((g) => g.deleteMessages(indices));

  void flagMessages(Set<int> indices, {bool? read, bool? archived}) =>
      _apply((g) => g.flagMessages(indices, read: read, archived: archived));
  void clearReadMessages() => _apply((g) => g.clearReadMessages());
  void completeMission(String id) => _apply((g) => g.completeMission(id));
  void finishIntro() => _apply((g) => g.finishIntro());
  void seeTip(String id) => _apply((g) => g.seeTip(id));
  void setTipsEnabled(bool value) => _apply((g) => g.setTipsEnabled(value));

  void markInboxRead() {
    final current = state;
    if (current == null) return;
    _commit(current.markInboxRead());
  }

  Future<void> saveToSlot(int slot) async {
    final current = state;
    if (current == null) return;
    await ref.read(gameRepositoryProvider).saveSlot(slot, current);
  }

  /// Charge une sauvegarde brute (cloud). Renvoie `false` si illisible.
  bool loadFromRaw(String raw) {
    final loaded = ref.read(gameRepositoryProvider).decodeRaw(raw);
    if (loaded == null) return false;
    _commit(loaded, forceWorld: true);
    return true;
  }

  /// Renvoie `false` si l'emplacement est vide ou illisible.
  bool loadFromSlot(int slot) {
    final loaded = ref.read(gameRepositoryProvider).loadSlot(slot);
    if (loaded == null) return false;
    _commit(loaded, forceWorld: true);
    return true;
  }

  String? sellPlayer(String playerId) {
    final current = state;
    if (current == null) return null;
    final error = current.validateSell(playerId);
    if (error == null) _commit(current.sellPlayer(playerId));
    return error;
  }
}

final gameProvider = NotifierProvider<GameNotifier, GameState?>(
  GameNotifier.new,
);
