import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/utils/format.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/roles.dart';
import '../../domain/entities/spots.dart';
import '../../domain/entities/transfer.dart';
import '../../engine/finance/finance.dart';
import '../../engine/world/nations.dart';
import '../common/labels.dart';
import '../game/game_state.dart';

/// Fiche d'un joueur du club avec toutes les actions de gestion.
Future<void> showOwnPlayerSheet(BuildContext context, String playerId) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (_) => _OwnPlayerSheet(playerId: playerId),
  );
}

/// Statistiques détaillées d'un joueur (réutilisées pour les adversaires).
Widget playerStatsBlock(BuildContext context, Player player, {bool full = true}) {
  final theme = Theme.of(context);
  final lines = <String>[
    'Niveau ${player.skill}, potentiel ${player.maxSkill}',
    'Valeur ${formatMoney(playerValue(player))}, '
        'salaire ${formatMoney(annualWage(player))} par saison',
    'Contrat : ${player.contractYears} an(s)',
    'Saison : ${player.matches} matchs, ${player.goals} buts, '
        '${player.assists} passes, ${player.cleanSheets} sans but',
    if (full)
      'Carrière : ${player.totalMatches} matchs, ${player.totalGoals} buts, '
          '${player.totalAssists} passes',
    'Sélections : ${player.caps}, distinctions : ${player.awards}',
  ];
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      for (final line in lines)
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 2),
          child: Text(line, style: theme.textTheme.bodyMedium),
        ),
    ],
  );
}

class _OwnPlayerSheet extends ConsumerWidget {
  const _OwnPlayerSheet({required this.playerId});

  final String playerId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();
    final player = game.ownPlayer(playerId);
    if (player == null) {
      return const Padding(
        padding: EdgeInsets.all(24),
        child: Text('Ce joueur a quitté le club.'),
      );
    }

    final theme = Theme.of(context);
    final slot = game.slotOf(playerId);
    final notifier = ref.read(gameProvider.notifier);
    final reserveAvailable = game.division <= 3;

    void run(String? error, String done, {bool close = false}) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error ?? done)),
      );
      if (close && error == null) Navigator.of(context).pop();
    }

    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${flagOf(player.nation)} ${player.name}',
              style: theme.textTheme.titleLarge,
            ),
            Text(
              '${naturalSpot(player).fullName}, ${player.age} ans, '
              '${player.nation.isEmpty ? 'nationalité inconnue' : player.nation}',
            ),
            const SizedBox(height: 4),
            Text('Condition physique : ${player.fitness} %'),
            const SizedBox(height: 4),
            Text(
              '${moodEmoji(player.mood)} ${moodLabel(player.mood)}'
              '${player.wantsOut ? ' · réclame son départ' : ''}',
              style: theme.textTheme.titleSmall,
            ),
            const SizedBox(height: 12),
            playerStatsBlock(context, player),
            const SizedBox(height: 16),
            Text('Contrat', style: theme.textTheme.titleSmall),
            const SizedBox(height: 6),
            Text(
              '${player.contractYears} an(s) restant(s) · salaire '
              '${formatMoney(annualWage(player))} par an',
            ),
            const SizedBox(height: 4),
            Text(
              'Prolongations, prêts et départs sont gérés par votre staff, '
              'dans les budgets que vous fixez dans les finances.',
              style: theme.textTheme.bodySmall,
            ),
            const SizedBox(height: 16),
            Text('Vos décisions de président', style: theme.textTheme.titleSmall),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                OutlinedButton.icon(
                  onPressed: () => run(
                    notifier.talkToPlayer(playerId),
                    '${player.name} se sent mieux écouté.',
                  ),
                  icon: const Icon(Icons.chat_bubble_outline),
                  label: const Text('Discuter avec lui'),
                ),
                FilterChip(
                  selected: game.owner.sellList.contains(playerId),
                  onSelected: (_) {
                    notifier.toggleSellList(playerId);
                  },
                  avatar: const Icon(Icons.sell_outlined, size: 18),
                  label: Text(
                    game.owner.sellList.contains(playerId)
                        ? 'Vente demandée au directeur sportif'
                        : 'Demander sa vente au directeur sportif',
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _chooseLoan(
    BuildContext context,
    WidgetRef ref,
    GameState game,
    Player player,
  ) async {
    final clubs = game.otherClubs
      ..sort((a, b) => a.squad.length.compareTo(b.squad.length));
    final chosen = await showDialog<String>(
      context: context,
      builder: (dialogContext) => SimpleDialog(
        title: Text('Prêter ${player.name} à...'),
        children: [
          for (final club in clubs.take(12))
            SimpleDialogOption(
              onPressed: () => Navigator.of(dialogContext).pop(club.id),
              child: Text('${club.name} (${club.squad.length} joueurs)'),
            ),
        ],
      ),
    );
    if (chosen == null || !context.mounted) return;
    final error = ref.read(gameProvider.notifier).sendOnLoan(player.id, chosen);
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          error ?? '${player.name} part en prêt : il gagnera des niveaux.',
        ),
      ),
    );
    if (error == null) Navigator.of(context).pop();
  }

  Future<void> _confirm(
    BuildContext context,
    String title,
    String body,
    VoidCallback onYes,
  ) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(title),
        content: Text(body),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Annuler'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Confirmer'),
          ),
        ],
      ),
    );
    if (ok == true) onYes();
  }
}
