import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../domain/entities/club.dart';
import '../../domain/entities/lineup.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/tactic.dart';
import '../common/labels.dart';
import '../common/pro_page.dart';
import '../common/widgets.dart';
import '../game/game_state.dart';
import 'player_sheet.dart';

class SquadPage extends ConsumerWidget {
  const SquadPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();

    final club = game.userClub;
    final hasReserve = game.division <= 3;

    return DefaultTabController(
      length: hasReserve ? 3 : 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Effectif'),
          actions: [
            IconButton(
              tooltip: 'Tactique',
              icon: const Icon(Icons.sports_soccer),
              onPressed: () => context.push('/tactics'),
            ),
            IconButton(
              tooltip: 'Transferts',
              icon: const Icon(Icons.swap_horiz),
              onPressed: () => context.push('/transfers'),
            ),
            IconButton(
              tooltip: 'Composition automatique',
              icon: const Icon(Icons.auto_fix_high),
              onPressed: () =>
                  ref.read(gameProvider.notifier).autoPickStarters(),
            ),
          ],
          bottom: TabBar(
            tabs: [
              Tab(text: 'Première (${club.squad.length})'),
              if (hasReserve) Tab(text: 'Réserve (${club.reserve.length})'),
              Tab(text: 'Formation (${club.academy.length})'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _FirstTeamTab(club: club),
            if (hasReserve) _TeamList(players: club.reserve, title: 'Réserve'),
            _TeamList(players: club.academy, title: 'Formation'),
          ],
        ),
      ),
    );
  }
}

class _FirstTeamTab extends ConsumerWidget {
  const _FirstTeamTab({required this.club});

  final Club club;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final strength = club.matchStrength;
    final slots = club.tactic.formation.slots;

    final header = Padding(
      padding: const EdgeInsets.fromLTRB(4, 4, 4, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Titulaires : ${club.starters.length} sur $startingXiSize '
            '(${club.tactic.formation.label})',
            style: theme.textTheme.titleMedium,
          ),
          const SizedBox(height: 6),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              ProTag('Attaque ${strength.attack.round()}',
                  color: const Color(0xFFEF5350)),
              ProTag('Milieu ${strength.midfield.round()}',
                  color: const Color(0xFF66BB6A)),
              ProTag('Défense ${strength.defense.round()}',
                  color: const Color(0xFF42A5F5)),
              ProTag('Gardien ${strength.goalkeeper.round()}',
                  color: const Color(0xFFFFCA28)),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            'Le coach choisit les titulaires (poste, forme, fatigue). '
            'Touchez un joueur pour sa fiche.',
            style: theme.textTheme.bodySmall,
          ),
        ],
      ),
    );

    List<Widget> block(PlayerPosition position) => [
          ProSection(
            '${positionPlural(position)} '
            '(${club.starters.where((p) => p.position == position).length}'
            '/${slots[position] ?? 0})',
          ),
          for (final player in _sorted(club.squad, position))
            PlayerRow(
              player: player,
              showPotential: true,
              showMood: true,
              highlighted: club.starterIds.contains(player.id),
              trailing: IconButton(
                icon: const Icon(Icons.more_vert),
                onPressed: () => showOwnPlayerSheet(context, player.id),
              ),
              onTap: () => showOwnPlayerSheet(context, player.id),
            ),
        ];

    return ProColumns(
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 20),
      columns: [
        [
          header,
          ...block(PlayerPosition.goalkeeper),
          ...block(PlayerPosition.defender),
        ],
        [
          ...block(PlayerPosition.midfielder),
          ...block(PlayerPosition.forward),
        ],
      ],
    );
  }
}

List<Player> _sorted(List<Player> list, PlayerPosition position) {
  return list.where((p) => p.position == position).toList()
    ..sort((a, b) => b.skill.compareTo(a.skill));
}

class _TeamList extends StatelessWidget {
  const _TeamList({required this.players, required this.title});

  final List<Player> players;
  final String title;

  @override
  Widget build(BuildContext context) {
    final sorted = [...players]..sort((a, b) => b.maxSkill.compareTo(a.maxSkill));
    if (sorted.isEmpty) {
      return Center(child: Text('$title : aucun joueur pour le moment.'));
    }
    final rows = <Widget>[
      for (final player in sorted)
        PlayerRow(
          player: player,
          showPotential: true,
          showMood: true,
          trailing: const Icon(Icons.chevron_right),
          onTap: () => showOwnPlayerSheet(context, player.id),
        ),
    ];
    final cols = ProColumns.split(rows, 2);
    return ProColumns(
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 20),
      columns: [
        [
          const Padding(
            padding: EdgeInsets.all(8),
            child: Text(
              'Triés par potentiel. Le staff décide des promotions, des '
              'prêts et des contrats ; touchez un joueur pour sa fiche.',
            ),
          ),
          ...cols[0],
        ],
        cols[1],
      ],
    );
  }
}
