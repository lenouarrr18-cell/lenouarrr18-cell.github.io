import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/l10n/l10n.dart';
import '../../core/legal/legal_texts.dart';
import '../common/crest.dart';
import '../common/pro_page.dart';

const Color _accent = Color(0xFF2FBF7A);

/// Corps d'un document légal (titres + paragraphes).
class LegalBody extends ConsumerWidget {
  const LegalBody({required this.doc, this.padding, super.key});

  final LegalDoc doc;
  final EdgeInsets? padding;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final lang = ref.watch(langProvider);
    final sections = legalSections(doc, lang);
    return ListView(
      padding: padding ?? const EdgeInsets.all(18),
      children: [
        Text(
          tr(lang, 'legal.updated'),
          style: theme.textTheme.labelSmall?.copyWith(color: Colors.white54),
        ),
        const SizedBox(height: 10),
        for (final s in sections) ...[
          Text(
            s.title,
            style: theme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w800,
              color: _accent,
            ),
          ),
          const SizedBox(height: 4),
          Text(s.body, style: theme.textTheme.bodyMedium?.copyWith(height: 1.45)),
          const SizedBox(height: 14),
        ],
      ],
    );
  }
}

/// Écran d'un document légal, ouvert depuis les paramètres.
class LegalDocPage extends ConsumerWidget {
  const LegalDocPage({required this.doc, super.key});

  final LegalDoc doc;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(title: Text(ref.t(legalDocTitleKey(doc)))),
      body: LegalBody(doc: doc),
    );
  }
}

/// À propos : logo, version, liens légaux et licences.
class AboutPage extends ConsumerWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(ref.t('legal.about'))),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Center(child: AppLogo(size: 120)),
          const SizedBox(height: 12),
          Center(
            child: Text(
              'Club Owner',
              style: theme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          Center(
            child: Text(
              ref.t('about.tagline'),
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyMedium,
            ),
          ),
          const SizedBox(height: 8),
          Center(
            child: ProTag(
              '${ref.t('about.version')} $appVersion',
              color: _accent,
            ),
          ),
          const SizedBox(height: 16),
          ProCard(
            child: Row(
              children: [
                const Icon(Icons.wifi_off, color: _accent),
                const SizedBox(width: 10),
                Expanded(child: Text(ref.t('about.offline'))),
              ],
            ),
          ),
          for (final d in LegalDoc.values)
            ListTile(
              leading: const Icon(Icons.description_outlined),
              title: Text(ref.t(legalDocTitleKey(d))),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => LegalDocPage(doc: d)),
              ),
            ),
          ListTile(
            leading: const Icon(Icons.code),
            title: Text(ref.t('legal.licenses')),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => showLicensePage(
              context: context,
              applicationName: 'Club Owner',
              applicationVersion: appVersion,
              applicationIcon: const Padding(
                padding: EdgeInsets.all(8),
                child: AppLogo(size: 64),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Center(
            child: Text(
              '© 2026 ${Publisher.name}',
              style: theme.textTheme.labelSmall,
            ),
          ),
        ],
      ),
    );
  }
}

/// Écran d'accueil légal affiché tant que les conditions ne sont pas
/// acceptées. Placé dans `MaterialApp.builder` : il n'utilise pas le
/// navigateur de l'application.
class LegalGate extends ConsumerStatefulWidget {
  const LegalGate({required this.child, super.key});

  final Widget child;

  @override
  ConsumerState<LegalGate> createState() => _LegalGateState();
}

class _LegalGateState extends ConsumerState<LegalGate> {
  bool _checked = false;

  @override
  Widget build(BuildContext context) {
    if (ref.watch(legalAcceptedProvider)) return widget.child;
    final theme = Theme.of(context);
    final lang = ref.watch(langProvider);

    final intro = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        const AppLogo(size: 84),
        const SizedBox(height: 12),
        Text(
          tr(lang, 'gate.title'),
          style: theme.textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 6),
        Text(tr(lang, 'gate.intro'), style: theme.textTheme.bodyMedium),
        const SizedBox(height: 12),
        SegmentedButton<AppLang>(
          segments: [
            for (final l in AppLang.values)
              ButtonSegment<AppLang>(value: l, label: Text(appLangLabel(l))),
          ],
          selected: {lang},
          onSelectionChanged: (s) =>
              ref.read(langProvider.notifier).set(s.first),
        ),
      ],
    );

    final docs = DefaultTabController(
      length: LegalDoc.values.length,
      child: Column(
        children: [
          TabBar(
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            indicatorColor: _accent,
            tabs: [
              for (final d in LegalDoc.values)
                Tab(text: tr(lang, legalDocTitleKey(d))),
            ],
          ),
          Expanded(
            child: TabBarView(
              children: [
                for (final d in LegalDoc.values) LegalBody(doc: d),
              ],
            ),
          ),
        ],
      ),
    );

    final accept = Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        CheckboxListTile(
          value: _checked,
          onChanged: (v) => setState(() => _checked = v ?? false),
          controlAffinity: ListTileControlAffinity.leading,
          contentPadding: EdgeInsets.zero,
          title: Text(tr(lang, 'gate.check'), style: theme.textTheme.bodySmall),
        ),
        SizedBox(
          width: double.infinity,
          child: FilledButton.icon(
            onPressed: _checked
                ? () => ref.read(legalAcceptedProvider.notifier).accept()
                : null,
            icon: const Icon(Icons.check),
            label: Text(tr(lang, 'gate.accept')),
          ),
        ),
      ],
    );

    return Scaffold(
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, box) {
            if (box.maxWidth > box.maxHeight) {
              return Row(
                children: [
                  SizedBox(
                    width: box.maxWidth * 0.38,
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [intro, const SizedBox(height: 12), accept],
                      ),
                    ),
                  ),
                  const VerticalDivider(width: 1),
                  Expanded(child: docs),
                ],
              );
            }
            return Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  intro,
                  const SizedBox(height: 8),
                  Expanded(
                    child: Card(child: docs),
                  ),
                  accept,
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
