import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/entities/club.dart';
import '../../domain/entities/honours.dart';
import '../../domain/entities/player.dart';
import '../../engine/awards/awards.dart';
import '../../engine/game/game_state.dart';
import '../../engine/world/nations.dart';
import '../common/crest.dart';
import '../common/pro_page.dart';
import '../game/game_state.dart';

const Color _gold = Color(0xFFD4A62A);

class _Row {
  const _Row(this.player, this.club, {this.eligible = true, this.bonus = 0});

  final Player player;
  final Club club;
  final bool eligible;
  final double bonus;
}

IconData _awardIcon(String name) {
  if (name.contains('Ballon')) return Icons.sports_soccer;
  if (name.contains('Soulier')) return Icons.directions_run;
  if (name.contains('passeur')) return Icons.alt_route;
  if (name.contains('Golden')) return Icons.auto_awesome;
  if (name.contains('Kopa')) return Icons.star_outline;
  if (name.contains('Yachine')) return Icons.sports_handball;
  return Icons.emoji_events;
}

/// Joueurs des premières divisions, avec une projection d'éligibilité :
/// club dans les places européennes de son championnat ou international.
List<_Row> _firstDivisionRows(GameState game) {
  final out = <_Row>[];
  void addLeague(List<Club> clubs, List<String> order) {
    final top = order.take(4).toSet();
    final pos = {for (var i = 0; i < order.length; i++) order[i]: i};
    for (final c in clubs) {
      final inCup = top.contains(c.id);
      final p0 = pos[c.id] ?? 10;
      final bonus = inCup ? (4 - p0) * 2.5 + (p0 == 0 ? 8 : 0) : 0.0;
      for (final p in c.squad) {
        out.add(_Row(p, c, eligible: inCup || p.caps > 0, bonus: bonus));
      }
    }
  }

  if (game.division == 1) {
    addLeague(
      game.season.clubs,
      [for (final s in game.season.standings) s.clubId],
    );
  }
  for (final l in game.world) {
    if (l.division != 1) continue;
    addLeague(
      l.season.clubs,
      [for (final s in l.season.standings) s.clubId],
    );
  }
  return out;
}

/// Palmarès : distinctions, course au Ballon d'or, saison et GOAT.
class HonoursPage extends ConsumerWidget {
  const HonoursPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();

    final mine = <AwardRecord>[
      for (final a in game.awards)
        if (a.clubName == game.userClub.name) a,
    ];
    final ballons = game.awards.where((a) => a.category.contains('Ballon')).length;
    final ceremonies = game.awards.map((a) => a.season).toSet().length;

    return ProPage(
      title: 'Palmarès',
      subtitle: 'Distinctions individuelles et légendes',
      icon: Icons.military_tech_outlined,
      accent: _gold,
      stats: [
        ProStat('Cérémonies', '$ceremonies',
            icon: Icons.event_outlined),
        ProStat('Ballons d\'or', '$ballons', icon: Icons.sports_soccer),
        ProStat('Pour votre club', '${mine.length}',
            icon: Icons.shield_outlined, color: _gold),
        ProStat('Légendes', '${game.legends.length}',
            icon: Icons.history_edu_outlined),
      ],
      side: [
        ProCard(
          padding: const EdgeInsets.all(12),
          child: Text(
            'Comme dans la réalité, les grandes distinctions (Ballon d\'or, '
            'Golden Boy, Kopa, Yachine) récompensent les joueurs de première '
            'division qui disputent aussi une coupe continentale avec leur '
            'club ou un tournoi avec leur sélection.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
      ],
      tabs: [
        ProTab('Distinctions', _AwardsTab(awards: game.awards),
            icon: Icons.emoji_events_outlined),
        ProTab('Course au Ballon d\'or', _RaceTab(game: game),
            icon: Icons.leaderboard_outlined),
        ProTab('Votre championnat', _SeasonTab(game: game),
            icon: Icons.format_list_numbered),
        ProTab('GOAT', _GoatTab(game: game), icon: Icons.workspace_premium),
      ],
    );
  }
}

class _AwardsTab extends StatelessWidget {
  const _AwardsTab({required this.awards});

  final List<AwardRecord> awards;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final seasons = <int>{for (final a in awards) a.season}.toList()
      ..sort((a, b) => b.compareTo(a));
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        if (awards.isEmpty)
          const ProEmpty(
            icon: Icons.emoji_events_outlined,
            title: 'Première cérémonie en fin de saison',
            message: 'Les trophées sont remis après les coupes continentales '
                'et les tournois internationaux.',
            accent: _gold,
          ),
        for (final season in seasons) ...[
          ProSection('Cérémonie · saison $season'),
          ProGrid(
            minWidth: 300,
            children: [
              for (final award in awards.where((a) => a.season == season))
                _AwardCard(award: award),
            ],
          ),
        ],
        const ProSection('Les trophées et leurs règles'),
        ProGrid(
          minWidth: 300,
          children: [
            for (final info in awardCatalog)
              ProCard(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _Medal(icon: _awardIcon(info.name), size: 40),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            info.name,
                            style: theme.textTheme.titleSmall?.copyWith(
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(info.criterion, style: theme.textTheme.bodySmall),
                          const SizedBox(height: 6),
                          ProTag(
                            info.elite
                                ? 'D1 + coupe continentale ou sélection'
                                : 'Toutes les premières divisions',
                            color: info.elite ? _gold : const Color(0xFF90A4AE),
                            icon: Icons.rule,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ],
    );
  }
}

class _Medal extends StatelessWidget {
  const _Medal({required this.icon, this.size = 46});

  final IconData icon;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFFFE082), Color(0xFFB8860B)],
        ),
        boxShadow: [BoxShadow(blurRadius: 8, color: Color(0x66FFC107))],
      ),
      child: Icon(icon, color: const Color(0xFF3E2723), size: size * 0.52),
    );
  }
}

class _AwardCard extends StatelessWidget {
  const _AwardCard({required this.award});

  final AwardRecord award;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final parts = award.detail.split(' · ');
    return ProCard(
      accent: _gold,
      highlight: award.category.contains('Ballon'),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _Medal(icon: _awardIcon(award.category)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  award.category.toUpperCase(),
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: _gold,
                    letterSpacing: 1,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  award.playerName,
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Row(
                  children: [
                    ClubCrest(name: award.clubName, size: 14),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(award.clubName,
                          style: theme.textTheme.bodySmall),
                    ),
                  ],
                ),
                if (parts.isNotEmpty && parts.first.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(parts.first, style: theme.textTheme.bodySmall),
                ],
                for (final extra in parts.skip(1))
                  Text(
                    extra,
                    style: theme.textTheme.labelSmall?.copyWith(
                      color: Colors.white60,
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _RaceTab extends StatelessWidget {
  const _RaceTab({required this.game});

  final GameState game;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final rows = _firstDivisionRows(game);
    double score(_Row r) => playerScore(r.player) + r.bonus;
    final elite = rows.where((r) => r.eligible).toList()
      ..sort((a, b) => score(b).compareTo(score(a)));
    final young = elite.where((r) => r.player.age <= 21).toList()
      ..sort((a, b) => (score(b) + b.player.maxSkill * 0.6)
          .compareTo(score(a) + a.player.maxSkill * 0.6));
    final keepers = elite
        .where((r) => r.player.position == PlayerPosition.goalkeeper)
        .toList()
      ..sort((a, b) => b.player.cleanSheets.compareTo(a.player.cleanSheets));
    final userInRace = elite.any((r) => r.club.isUser);

    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        ProCard(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Icon(
                userInRace ? Icons.check_circle : Icons.info_outline,
                color: userInRace ? const Color(0xFF66BB6A) : Colors.white54,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  game.division != 1
                      ? 'Votre club joue en D${game.division} : ses joueurs ne '
                          'peuvent pas viser le Ballon d\'or. Seuls les buteurs '
                          'et passeurs de première division sont classés.'
                      : (userInRace
                          ? 'Vos joueurs sont dans la course : restez dans les '
                              'places continentales.'
                          : 'Projection : entrez dans les places continentales '
                              'pour que vos joueurs soient éligibles.'),
                  style: theme.textTheme.bodySmall,
                ),
              ),
            ],
          ),
        ),
        if (rows.isEmpty)
          const ProEmpty(
            icon: Icons.public_off,
            title: 'Aucune première division simulée',
            message: 'Les classements apparaîtront dès que des premières '
                'divisions seront jouées.',
            accent: _gold,
          ),
        ProGrid(
          minWidth: 330,
          children: [
            _Board(
              title: 'Ballon d\'or',
              icon: Icons.sports_soccer,
              rows: elite.take(10).toList(),
              value: (r) => '${score(r).round()} pts',
            ),
            _Board(
              title: 'Golden Boy · Kopa',
              icon: Icons.auto_awesome,
              rows: young.take(5).toList(),
              value: (r) => '${r.player.age} ans',
            ),
            _Board(
              title: 'Trophée Yachine',
              icon: Icons.sports_handball,
              rows: keepers.take(5).toList(),
              value: (r) => '${r.player.cleanSheets} CS',
            ),
            _Board(
              title: 'Soulier d\'or (toute la D1)',
              icon: Icons.directions_run,
              rows: ([...rows]
                    ..sort((a, b) => b.player.goals.compareTo(a.player.goals)))
                  .take(5)
                  .toList(),
              value: (r) => '${r.player.goals} buts',
            ),
          ],
        ),
      ],
    );
  }
}

class _Board extends StatelessWidget {
  const _Board({
    required this.title,
    required this.icon,
    required this.rows,
    required this.value,
  });

  final String title;
  final IconData icon;
  final List<_Row> rows;
  final String Function(_Row) value;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return ProCard(
      title: title,
      icon: icon,
      accent: _gold,
      child: rows.isEmpty
          ? Text('Pas encore de candidat.', style: theme.textTheme.bodySmall)
          : Column(
              children: [
                for (var i = 0; i < rows.length; i++)
                  Container(
                    margin: const EdgeInsets.only(bottom: 4),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                    decoration: BoxDecoration(
                      color: rows[i].club.isUser
                          ? _gold.withAlpha(40)
                          : (i.isEven ? Colors.white.withAlpha(6) : null),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 24,
                          child: Text(
                            '${i + 1}',
                            style: theme.textTheme.labelLarge?.copyWith(
                              color: i < 3 ? _gold : Colors.white60,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                        ClubCrest(name: rows[i].club.name, size: 18),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '${flagOf(rows[i].player.nation)} '
                                '${rows[i].player.name}',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: theme.textTheme.bodyMedium?.copyWith(
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              Text(
                                rows[i].club.name,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: theme.textTheme.labelSmall,
                              ),
                            ],
                          ),
                        ),
                        Text(
                          value(rows[i]),
                          style: theme.textTheme.labelLarge?.copyWith(
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
    );
  }
}

class _SeasonTab extends StatelessWidget {
  const _SeasonTab({required this.game});

  final GameState game;

  @override
  Widget build(BuildContext context) {
    final rows = [
      for (final club in game.season.clubs)
        for (final p in club.squad) _Row(p, club),
    ];
    final scorers = [...rows]
      ..sort((a, b) => b.player.goals.compareTo(a.player.goals));
    final assisters = [...rows]
      ..sort((a, b) => b.player.assists.compareTo(a.player.assists));
    final best = [...rows]
      ..sort((a, b) => playerScore(b.player).compareTo(playerScore(a.player)));
    final keepers = rows
        .where((r) => r.player.position == PlayerPosition.goalkeeper)
        .toList()
      ..sort((a, b) => b.player.cleanSheets.compareTo(a.player.cleanSheets));
    final youngs = rows.where((r) => r.player.age <= 21).toList()
      ..sort((a, b) => playerScore(b.player).compareTo(playerScore(a.player)));

    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        ProGrid(
          minWidth: 330,
          children: [
            _Board(
              title: 'Meilleurs buteurs',
              icon: Icons.sports_soccer,
              rows: scorers.take(5).toList(),
              value: (r) => '${r.player.goals} buts',
            ),
            _Board(
              title: 'Meilleurs passeurs',
              icon: Icons.alt_route,
              rows: assisters.take(5).toList(),
              value: (r) => '${r.player.assists} passes',
            ),
            _Board(
              title: 'Meilleurs joueurs',
              icon: Icons.star_outline,
              rows: best.take(5).toList(),
              value: (r) => '${playerScore(r.player).round()} pts',
            ),
            _Board(
              title: 'Jeunes (21 ans et moins)',
              icon: Icons.auto_awesome,
              rows: youngs.take(5).toList(),
              value: (r) => '${r.player.age} ans',
            ),
            _Board(
              title: 'Gardiens',
              icon: Icons.sports_handball,
              rows: keepers.take(5).toList(),
              value: (r) => '${r.player.cleanSheets} CS',
            ),
          ],
        ),
      ],
    );
  }
}

class _GoatTab extends StatelessWidget {
  const _GoatTab({required this.game});

  final GameState game;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final ranking = goatRanking(game.legends, game.season.clubs);
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        if (ranking.isEmpty)
          const ProEmpty(
            icon: Icons.workspace_premium_outlined,
            title: 'Le débat du GOAT est ouvert',
            message: 'Il s\'animera quand des joueurs auront marqué '
                'l\'histoire : buts, passes, sélections et distinctions.',
            accent: _gold,
          ),
        ProGrid(
          minWidth: 360,
          children: [
            for (var i = 0; i < ranking.length; i++)
              ProCard(
                accent: _gold,
                highlight: i == 0,
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 18,
                      backgroundColor:
                          i < 3 ? _gold : Colors.white.withAlpha(25),
                      child: Text(
                        '${i + 1}',
                        style: TextStyle(
                          color: i < 3 ? Colors.black : Colors.white,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${flagOf(ranking[i].nation)} ${ranking[i].name}',
                            style: theme.textTheme.bodyMedium?.copyWith(
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Wrap(
                            spacing: 6,
                            runSpacing: 4,
                            children: [
                              ProTag('${ranking[i].matches} m'),
                              ProTag('${ranking[i].goals} buts'),
                              ProTag('${ranking[i].assists} pd'),
                              ProTag('${ranking[i].caps} sél.',
                                  color: const Color(0xFF42A5F5)),
                              ProTag('${ranking[i].awards} trophées',
                                  color: _gold),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Text(
                      '${ranking[i].goatScore.round()}',
                      style: theme.textTheme.titleLarge?.copyWith(
                        color: _gold,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ],
    );
  }
}
