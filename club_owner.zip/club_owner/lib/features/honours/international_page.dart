import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/entities/honours.dart';
import '../../domain/entities/player.dart';
import '../../engine/international/international.dart';
import '../../engine/world/nations.dart';
import '../common/pro_page.dart';
import '../game/game_state.dart';

const Color _accent = Color(0xFF1E88E5);

Color _outlookColor(CallUpOutlook o) {
  switch (o) {
    case CallUpOutlook.star:
      return const Color(0xFFF5C04A);
    case CallUpOutlook.likely:
      return const Color(0xFF66BB6A);
    case CallUpOutlook.possible:
      return const Color(0xFF42A5F5);
    case CallUpOutlook.none:
      return const Color(0xFF78909C);
  }
}

IconData _tournamentIcon(String name) =>
    name == 'Coupe du monde' ? Icons.public : Icons.flag_circle_outlined;

/// Le football international : calendrier des tournois, vos joueurs en
/// sélection, classement mondial des nations et palmarès.
class InternationalPage extends ConsumerWidget {
  const InternationalPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();

    final theme = Theme.of(context);
    final nextSeason = nextTournamentSeason(game.seasonNumber);
    final upcoming = tournamentsForSeason(nextSeason);
    final wait = nextSeason - game.seasonNumber;
    final ranking = worldRanking(game.intl, game.seasonNumber);
    final players = [...game.userClub.allPlayers]
      ..sort((a, b) => b.skill.compareTo(a.skill));
    final outlooks = {
      for (final p in players) p.id: callUpOutlook(p, game.division),
    };
    final selectable = players
        .where((p) => outlooks[p.id] != CallUpOutlook.none)
        .toList();
    final caps = players.fold<int>(0, (s, p) => s + p.caps);
    final homeNation = game.country.name;
    final homeRank = ranking.indexWhere((r) => r.nation.name == homeNation);

    return ProPage(
      title: 'International',
      subtitle: 'Sélections nationales et grands tournois',
      icon: Icons.public,
      accent: _accent,
      stats: [
        ProStat(
          'Prochain tournoi',
          wait == 0 ? 'Cette saison' : 'Dans $wait saison(s)',
          icon: Icons.event,
        ),
        ProStat('Sélectionnables', '${selectable.length}',
            icon: Icons.how_to_reg),
        ProStat('Sélections cumulées', '$caps', icon: Icons.military_tech),
        ProStat(
          homeNation,
          homeRank < 0 ? '-' : '${homeRank + 1}e mondial',
          icon: Icons.flag,
        ),
      ],
      side: [
        ProCard(
          padding: const EdgeInsets.all(12),
          child: Text(
            'Vos joueurs appelés gagnent en valeur et en prestige, et '
            'pèsent dans le Ballon d\'or. Un titre en sélection rejaillit '
            'sur tout le club.',
            style: theme.textTheme.bodySmall,
          ),
        ),
      ],
      tabs: [
        ProTab(
          'Calendrier',
          ListView(
            padding: const EdgeInsets.all(18),
            children: [
              ProSection(
                wait == 0
                    ? 'À la fin de cette saison'
                    : 'À la fin de la saison $nextSeason',
              ),
              ProGrid(
                minWidth: 260,
                children: [
                  for (final name in upcoming)
                    ProCard(
                      highlight: true,
                      accent: _accent,
                      child: Row(
                        children: [
                          Icon(_tournamentIcon(name), size: 34, color: _accent),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  name,
                                  style: theme.textTheme.titleSmall?.copyWith(
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                                Text(
                                  name == 'Coupe du monde'
                                      ? '32 nations, tous les 4 ans'
                                      : '16 nations, tous les 4 ans',
                                  style: theme.textTheme.bodySmall,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
              const ProSection('Le cycle international'),
              ProCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    for (var k = 0; k < 4; k++)
                      Builder(
                        builder: (context) {
                          final s = game.seasonNumber + k;
                          final t = tournamentsForSeason(s);
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90,
                                  child: Text(
                                    'Saison $s',
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Text(
                                    t.isEmpty ? 'Pas de grand tournoi' : t.join(' · '),
                                    style: theme.textTheme.bodySmall,
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                  ],
                ),
              ),
            ],
          ),
          icon: Icons.event,
        ),
        ProTab(
          'Vos internationaux',
          ListView(
            padding: const EdgeInsets.all(18),
            children: [
              if (selectable.isEmpty)
                const ProEmpty(
                  icon: Icons.person_search,
                  title: 'Aucun joueur au niveau international',
                  message: 'Les sélectionneurs regardent le niveau des '
                      'joueurs et la division du club. Montez en division '
                      'et recrutez des talents pour voir vos joueurs appelés.',
                  accent: _accent,
                ),
              ProGrid(
                minWidth: 300,
                children: [
                  for (final p in selectable)
                    _PlayerCard(player: p, outlook: outlooks[p.id]!),
                ],
              ),
            ],
          ),
          icon: Icons.how_to_reg,
        ),
        ProTab(
          'Classement mondial',
          ListView(
            padding: const EdgeInsets.all(18),
            children: [
              ProGrid(
                minWidth: 320,
                children: [
                  for (var i = 0; i < ranking.length && i < 40; i++)
                    _RankRow(
                      rank: i + 1,
                      entry: ranking[i],
                      highlight: ranking[i].nation.name == homeNation ||
                          players.any((p) => p.nation == ranking[i].nation.name),
                    ),
                ],
              ),
            ],
          ),
          icon: Icons.leaderboard,
        ),
        ProTab(
          'Palmarès',
          ListView(
            padding: const EdgeInsets.all(18),
            children: [
              if (game.intl.isEmpty)
                const ProEmpty(
                  icon: Icons.emoji_events_outlined,
                  title: 'Aucun tournoi disputé',
                  message: 'Les vainqueurs des Coupes du monde et des '
                      'tournois continentaux apparaîtront ici.',
                  accent: _accent,
                ),
              ProGrid(
                minWidth: 300,
                children: [
                  for (final t in game.intl) _ResultCard(result: t),
                ],
              ),
            ],
          ),
          icon: Icons.emoji_events,
        ),
      ],
    );
  }
}

class _PlayerCard extends StatelessWidget {
  const _PlayerCard({required this.player, required this.outlook});

  final Player player;
  final CallUpOutlook outlook;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color = _outlookColor(outlook);
    return ProCard(
      accent: color,
      child: Row(
        children: [
          Text(flagOf(player.nation), style: const TextStyle(fontSize: 30)),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  player.name,
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  '${player.nation} · ${player.age} ans · niveau ${player.skill}',
                  style: theme.textTheme.bodySmall,
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    ProTag(callUpLabel(outlook), color: color),
                    const SizedBox(width: 6),
                    ProTag('${player.caps} sél.', color: _accent),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _RankRow extends StatelessWidget {
  const _RankRow({
    required this.rank,
    required this.entry,
    required this.highlight,
  });

  final int rank;
  final NationRank entry;
  final bool highlight;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: highlight
            ? _accent.withAlpha(45)
            : theme.colorScheme.surfaceContainer,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 30,
            child: Text(
              '$rank',
              style: theme.textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.w900,
                color: rank <= 3 ? const Color(0xFFF5C04A) : null,
              ),
            ),
          ),
          Text(flagOf(entry.nation.name), style: const TextStyle(fontSize: 20)),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              entry.nation.name,
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
          if (entry.titles > 0)
            Padding(
              padding: const EdgeInsets.only(right: 6),
              child: ProTag('${entry.titles} titre(s)',
                  color: const Color(0xFFF5C04A)),
            ),
          Text('${entry.points} pts', style: theme.textTheme.labelLarge),
        ],
      ),
    );
  }
}

class _ResultCard extends StatelessWidget {
  const _ResultCard({required this.result});

  final TournamentResult result;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final t = result;
    return ProCard(
      highlight: t.userPlayers.isNotEmpty,
      accent: _accent,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(_tournamentIcon(t.name), color: _accent),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  t.name,
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              Text('S${t.season}', style: theme.textTheme.labelSmall),
            ],
          ),
          const SizedBox(height: 8),
          Text('${flagOf(t.champion)}  ${t.champion}',
              style: const TextStyle(fontWeight: FontWeight.w800)),
          Text('Finaliste : ${flagOf(t.runnerUp)} ${t.runnerUp}',
              style: theme.textTheme.bodySmall),
          if (t.userPlayers.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(
              'Vos joueurs : ${t.userPlayers.join(', ')}',
              style: theme.textTheme.bodySmall,
            ),
          ],
        ],
      ),
    );
  }
}
