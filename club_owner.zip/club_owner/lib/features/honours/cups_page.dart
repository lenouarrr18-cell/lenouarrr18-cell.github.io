import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/entities/honours.dart';
import '../../engine/world/nations.dart';
import '../common/crest.dart';
import '../common/pro_page.dart';
import '../game/game_state.dart';

const Color _accent = Color(0xFF1E5BB8);

class _Comp {
  const _Comp(this.name, this.continent, this.tier, this.color);

  final String name;
  final Continent? continent;

  /// 1 = la plus prestigieuse du continent.
  final int tier;
  final Color color;
}

const List<_Comp> _competitions = [
  _Comp('Ligue des champions', Continent.europe, 1, Color(0xFF1A237E)),
  _Comp('Ligue Europa', Continent.europe, 2, Color(0xFFE65100)),
  _Comp('Ligue Europa Conférence', Continent.europe, 3, Color(0xFF2E7D32)),
  _Comp('Ligue des champions africaine', Continent.africa, 1, Color(0xFFB71C1C)),
  _Comp('Coupe de la Confédération', Continent.africa, 2, Color(0xFF8D6E63)),
  _Comp('Copa Libertadores', Continent.southAmerica, 1, Color(0xFF0D47A1)),
  _Comp('Copa Sudamericana', Continent.southAmerica, 2, Color(0xFF00838F)),
  _Comp('Ligue des champions CONCACAF', Continent.northAmerica, 1,
      Color(0xFF283593)),
  _Comp("Ligue des champions d'Asie", Continent.asia, 1, Color(0xFF4A148C)),
  _Comp("Coupe de l'AFC", Continent.asia, 2, Color(0xFF558B2F)),
  _Comp('Coupe du monde des clubs', null, 0, Color(0xFFB8860B)),
];

_Comp? _compOf(String name) {
  for (final c in _competitions) {
    if (c.name == name) return c;
  }
  return null;
}

/// Compétitions de clubs : Ligue des champions, Ligue Europa, Conférence,
/// compétitions continentales et Coupe du monde des clubs.
class CupsPage extends ConsumerWidget {
  const CupsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();

    final theme = Theme.of(context);
    final cups = game.cups;
    final seasons = <int>{for (final c in cups) c.season}.toList()
      ..sort((a, b) => b.compareTo(a));
    final continent = nationByName(game.country.name)?.continent;
    final myComps = [
      for (final c in _competitions)
        if (c.continent == continent) c,
    ];
    final participations = cups.where((c) => c.userPlayers.isNotEmpty).toList();
    final titles = cups
        .where((c) => c.champion == game.userClub.name)
        .length;
    final rank = game.season.userRank;
    final d1 = game.division == 1;

    return ProPage(
      title: 'Coupes d\'Europe et du monde',
      subtitle: continent == null
          ? 'Compétitions de clubs'
          : 'Votre confédération : ${continentLabel(continent)}',
      icon: Icons.emoji_events_outlined,
      accent: _accent,
      stats: [
        ProStat('Division', 'D${game.division}', icon: Icons.layers_outlined),
        ProStat('Classement', rank < 1 ? '-' : '$rank e',
            icon: Icons.format_list_numbered),
        ProStat('Participations', '${participations.length}',
            icon: Icons.flag_outlined),
        ProStat('Titres', '$titles',
            icon: Icons.emoji_events, color: const Color(0xFFFFD54F)),
      ],
      side: [
        ProCard(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Icon(
                d1 ? Icons.verified_outlined : Icons.lock_outline,
                color: d1 ? const Color(0xFF66BB6A) : Colors.white54,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  d1
                      ? 'Votre club peut se qualifier par le classement de '
                          'fin de saison.'
                      : 'Montez en première division pour jouer les coupes '
                          'continentales.',
                  style: theme.textTheme.bodySmall,
                ),
              ),
            ],
          ),
        ),
      ],
      tabs: [
        ProTab(
          'Votre confédération',
          ListView(
            padding: const EdgeInsets.all(18),
            children: [
              ProGrid(
                minWidth: 280,
                children: [
                  for (final c in myComps)
                    _CompCard(
                      comp: c,
                      last: _lastOf(cups, c.name),
                      userClub: game.userClub.name,
                    ),
                  _CompCard(
                    comp: _competitions.last,
                    last: _lastOf(cups, _competitions.last.name),
                    userClub: game.userClub.name,
                  ),
                ],
              ),
              const ProSection('Comment se qualifier'),
              ProCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _Rule(
                      icon: Icons.looks_one_outlined,
                      text: 'Seuls les clubs de première division sont '
                          'qualifiables, selon leur classement final.',
                    ),
                    _Rule(
                      icon: Icons.public,
                      text: 'Les grands championnats envoient plus de clubs '
                          '(jusqu\'à 4 en Ligue des champions).',
                    ),
                    _Rule(
                      icon: Icons.calendar_month_outlined,
                      text: 'Les coupes se jouent en fin de saison : phase de '
                          'groupes puis élimination directe.',
                    ),
                    _Rule(
                      icon: Icons.stars_outlined,
                      text: 'Les vainqueurs des grandes coupes jouent la Coupe '
                          'du monde des clubs.',
                    ),
                    _Rule(
                      icon: Icons.emoji_events_outlined,
                      text: 'Un beau parcours apporte du prestige au club et '
                          'pèse dans le Ballon d\'or de vos joueurs.',
                    ),
                  ],
                ),
              ),
            ],
          ),
          icon: Icons.flag_outlined,
        ),
        ProTab(
          'Palmarès',
          seasons.isEmpty
              ? ListView(
                  padding: const EdgeInsets.all(18),
                  children: const [
                    ProEmpty(
                      icon: Icons.history_toggle_off,
                      title: 'Aucune édition jouée',
                      message: 'Les premières coupes se disputent à la fin de '
                          'cette saison. Les vainqueurs apparaîtront ici.',
                      accent: _accent,
                    ),
                  ],
                )
              : ListView(
                  padding: const EdgeInsets.all(18),
                  children: [
                    for (final season in seasons) ...[
                      ProSection('Saison $season'),
                      ProGrid(
                        minWidth: 300,
                        children: [
                          for (final cup in cups.where((c) => c.season == season))
                            _ResultCard(
                              cup: cup,
                              userClub: game.userClub.name,
                            ),
                        ],
                      ),
                    ],
                  ],
                ),
          icon: Icons.history,
        ),
        ProTab(
          'Toutes',
          ListView(
            padding: const EdgeInsets.all(18),
            children: [
              for (final cont in Continent.values) ...[
                ProSection(continentLabel(cont)),
                ProGrid(
                  minWidth: 280,
                  children: [
                    for (final c in _competitions.where((c) => c.continent == cont))
                      _CompCard(
                        comp: c,
                        last: _lastOf(cups, c.name),
                        userClub: game.userClub.name,
                      ),
                  ],
                ),
              ],
            ],
          ),
          icon: Icons.public,
        ),
      ],
    );
  }
}

TournamentResult? _lastOf(List<TournamentResult> cups, String name) {
  TournamentResult? best;
  for (final c in cups) {
    if (c.name != name) continue;
    if (best == null || c.season > best.season) best = c;
  }
  return best;
}

class _CompCard extends StatelessWidget {
  const _CompCard({required this.comp, required this.last, required this.userClub});

  final _Comp comp;
  final TournamentResult? last;
  final String userClub;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final tierLabel = comp.tier == 0
        ? 'Mondial'
        : (comp.tier == 1 ? 'Élite' : (comp.tier == 2 ? 'Niveau 2' : 'Niveau 3'));
    return ProCard(
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [comp.color, comp.color.withAlpha(120)],
              ),
            ),
            child: Row(
              children: [
                const Icon(Icons.emoji_events, color: Colors.white),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    comp.name,
                    style: theme.textTheme.titleSmall?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                ProTag(tierLabel, color: Colors.white),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: last == null
                ? Text(
                    'Pas encore disputée dans votre carrière.',
                    style: theme.textTheme.bodySmall,
                  )
                : Row(
                    children: [
                      ClubCrest(name: last!.champion, size: 30),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Tenant du titre',
                              style: theme.textTheme.labelSmall,
                            ),
                            Text(
                              last!.champion,
                              style: theme.textTheme.bodyMedium?.copyWith(
                                fontWeight: FontWeight.w700,
                                color: last!.champion == userClub
                                    ? const Color(0xFFFFD54F)
                                    : null,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Text('S${last!.season}', style: theme.textTheme.labelSmall),
                    ],
                  ),
          ),
        ],
      ),
    );
  }
}

class _ResultCard extends StatelessWidget {
  const _ResultCard({required this.cup, required this.userClub});

  final TournamentResult cup;
  final String userClub;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final comp = _compOf(cup.name);
    final color = comp?.color ?? _accent;
    final mine = cup.userPlayers.isNotEmpty;
    final won = cup.champion == userClub;
    return ProCard(
      accent: won ? const Color(0xFFFFD54F) : color,
      highlight: mine || won,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.emoji_events, size: 18, color: color),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  cup.name,
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              ClubCrest(name: cup.champion, size: 26),
              const SizedBox(width: 8),
              Expanded(child: Text(cup.champion)),
              const ProTag('Vainqueur', color: Color(0xFFFFD54F)),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              ClubCrest(name: cup.runnerUp, size: 22),
              const SizedBox(width: 10),
              Expanded(
                child: Text(cup.runnerUp, style: theme.textTheme.bodySmall),
              ),
              const ProTag('Finaliste', color: Color(0xFFB0BEC5)),
            ],
          ),
          if (mine) ...[
            const SizedBox(height: 8),
            ProTag(cup.userPlayers.first, color: const Color(0xFF66BB6A),
                icon: Icons.shield_outlined),
          ],
        ],
      ),
    );
  }
}

class _Rule extends StatelessWidget {
  const _Rule({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: _accent),
          const SizedBox(width: 10),
          Expanded(child: Text(text)),
        ],
      ),
    );
  }
}
