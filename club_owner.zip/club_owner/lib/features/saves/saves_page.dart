import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/utils/format.dart';
import '../../domain/entities/division.dart';
import '../game/game_repository.dart';
import '../common/pro_page.dart';
import '../game/game_state.dart';

class SavesPage extends ConsumerStatefulWidget {
  const SavesPage({super.key});

  @override
  ConsumerState<SavesPage> createState() => _SavesPageState();
}

class _SavesPageState extends ConsumerState<SavesPage> {
  void _toast(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _save(int slot) async {
    await ref.read(gameProvider.notifier).saveToSlot(slot);
    if (!mounted) return;
    setState(() {});
    _toast('Partie sauvegardée dans l\'emplacement ${slot + 1}.');
  }

  Future<void> _load(int slot) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Charger cette partie ?'),
        content: const Text('La partie en cours sera remplacée.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Annuler'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Charger'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    final ok = ref.read(gameProvider.notifier).loadFromSlot(slot);
    if (!mounted) return;
    _toast(ok ? 'Partie chargée.' : 'Cet emplacement est vide.');
  }

  @override
  Widget build(BuildContext context) {
    final repository = ref.read(gameRepositoryProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Sauvegardes')),
      body: ProColumns(
        columns: ProColumns.split([
          const Text(
            'Votre partie est sauvegardée automatiquement. Ces '
            'emplacements vous permettent de garder des copies.',
          ),
          const SizedBox(height: 12),
          for (var slot = 0; slot < GameRepository.slotCount; slot++)
            _slotCard(repository, slot),
        ], 2),
      ),
    );
  }

  Widget _slotCard(GameRepository repository, int slot) {
    final saved = repository.loadSlot(slot);
    final subtitle = saved == null
        ? 'Aucune sauvegarde'
        : '${divisionName(saved.division)}, saison ${saved.seasonNumber}, '
              '${formatMoney(saved.finance.treasury)}';
    return Card(
      child: ListTile(
        leading: CircleAvatar(child: Text('${slot + 1}')),
        title: Text(saved == null ? 'Emplacement vide' : saved.userClub.name),
        subtitle: Text(subtitle),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              tooltip: 'Sauvegarder ici',
              icon: const Icon(Icons.save_outlined),
              onPressed: () => _save(slot),
            ),
            IconButton(
              tooltip: 'Charger',
              icon: const Icon(Icons.folder_open),
              onPressed: saved == null ? null : () => _load(slot),
            ),
          ],
        ),
      ),
    );
  }
}
