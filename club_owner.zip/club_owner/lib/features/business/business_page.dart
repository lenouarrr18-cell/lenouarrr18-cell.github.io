import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/utils/format.dart';
import '../../domain/entities/owner.dart';
import '../../engine/finance/finance.dart';
import '../../engine/owner/infrastructure.dart';
import '../common/pro_page.dart';
import '../game/game_state.dart';

const Color _accent = Color(0xFF2E9E6B);

class BusinessPage extends ConsumerWidget {
  const BusinessPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();

    final theme = Theme.of(context);
    final owner = game.owner;
    final deal = owner.deal;
    final rounds = game.season.totalRounds;
    final tv = tvIncomePerSeason(game.division);
    final local = sponsorIncomePerSeason(
      wealth: game.city.wealth,
      division: game.division,
    );
    final mult = sponsorMultiplier(owner);
    final debtColor = owner.debt == 0
        ? const Color(0xFF66BB6A)
        : (owner.debt > maxDebt * 0.6
            ? const Color(0xFFEF5350)
            : const Color(0xFFFFB74D));

    return ProPage(
      title: 'Sponsors et banque',
      subtitle: 'Revenus commerciaux et financement',
      icon: Icons.handshake_outlined,
      accent: _accent,
      stats: [
        ProStat('Trésorerie', formatMoney(game.finance.treasury),
            icon: Icons.account_balance_wallet_outlined,
            color: game.finance.treasury < 0 ? const Color(0xFFEF5350) : null),
        ProStat('Droits TV', formatMoney(tv), icon: Icons.live_tv_outlined),
        ProStat('Sponsors locaux', formatMoney((local * mult).round()),
            icon: Icons.storefront_outlined),
        ProStat('Dette', formatMoney(owner.debt),
            icon: Icons.account_balance_outlined, color: debtColor),
      ],
      side: [
        ProMeter(
          label: 'Réputation commerciale',
          value: owner.reputation,
          color: _accent,
        ),
        if (mult > 1)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: ProTag(
              'Espaces partenaires : sponsoring x${mult.toStringAsFixed(2)}',
              color: _accent,
              icon: Icons.business_center_outlined,
            ),
          ),
      ],
      children: [
        const ProSection('Sponsor principal'),
        if (deal != null)
          _DealCard(
            deal: deal,
            current: true,
            footer: 'Versé à chaque journée : '
                '${formatMoney(deal.perSeason ~/ rounds)}',
            buttonLabel:
                'Rompre (pénalité ${formatMoney(game.sponsorBreakPenalty)})',
            onPressed: () => _cancel(context, ref),
          )
        else ...[
          Text(
            'Choisissez une offre. Les contrats ambitieux paient plus mais '
            'exigent un classement minimum pour toucher la prime.',
            style: theme.textTheme.bodySmall,
          ),
          const SizedBox(height: 10),
          ProGrid(
            minWidth: 260,
            children: [
              for (final offer in game.sponsorOffers)
                _DealCard(
                  deal: offer,
                  footer: 'Réputation du club : ${owner.reputation}/100',
                  buttonLabel: 'Signer',
                  onPressed: () => _sign(context, ref, offer),
                ),
            ],
          ),
        ],
        const ProSection('Revenus garantis par saison'),
        ProCard(
          child: Column(
            children: [
              _Line(
                icon: Icons.live_tv_outlined,
                label: 'Droits TV (D${game.division})',
                value: tv,
              ),
              _Line(
                icon: Icons.storefront_outlined,
                label: 'Sponsors locaux',
                value: (local * mult).round(),
              ),
              if (deal != null)
                _Line(
                  icon: Icons.handshake_outlined,
                  label: 'Sponsor principal · ${deal.name}',
                  value: (deal.perSeason * mult).round(),
                ),
              const Divider(),
              _Line(
                icon: Icons.summarize_outlined,
                label: 'Total',
                value: tv + ((local + (deal?.perSeason ?? 0)) * mult).round(),
                bold: true,
              ),
            ],
          ),
        ),
        const ProSection('Banque'),
        ProCard(
          title: 'Ligne de crédit',
          icon: Icons.account_balance_outlined,
          accent: _accent,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ProMeter(
                label: 'Dette utilisée',
                value: owner.debt,
                max: maxDebt,
                color: debtColor,
                suffix: '${formatMoney(owner.debt)} / ${formatMoney(maxDebt)}',
              ),
              const SizedBox(height: 6),
              Text(
                'Remboursement par journée : ${formatMoney(owner.loanPerRound)}'
                ' · intérêt de ${(loanInterestRate * 100).round()} % ajouté '
                'au prêt.',
                style: theme.textTheme.bodySmall,
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final amount in loanAmounts)
                    OutlinedButton.icon(
                      onPressed: () => _borrow(context, ref, amount),
                      icon: const Icon(Icons.add, size: 18),
                      label: Text(formatMoney(amount)),
                    ),
                  if (owner.debt > 0)
                    FilledButton.tonalIcon(
                      onPressed: () => _repay(context, ref),
                      icon: const Icon(Icons.done_all, size: 18),
                      label: const Text('Tout rembourser'),
                    ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  void _toast(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _sign(
    BuildContext context,
    WidgetRef ref,
    SponsorDeal offer,
  ) async {
    final error = ref.read(gameProvider.notifier).signSponsor(offer.id);
    if (!context.mounted) return;
    _toast(context, error ?? '${offer.name} devient votre sponsor.');
  }

  Future<void> _cancel(BuildContext context, WidgetRef ref) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Rompre le contrat ?'),
        content: const Text('Vous paierez une pénalité à votre sponsor.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Annuler'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Rompre'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    final error = ref.read(gameProvider.notifier).cancelSponsor();
    if (!context.mounted) return;
    _toast(context, error ?? 'Contrat rompu.');
  }

  Future<void> _borrow(BuildContext context, WidgetRef ref, int amount) async {
    final error = ref.read(gameProvider.notifier).takeLoan(amount);
    if (!context.mounted) return;
    _toast(context, error ?? 'Prêt de ${formatMoney(amount)} accordé.');
  }

  Future<void> _repay(BuildContext context, WidgetRef ref) async {
    final error = ref.read(gameProvider.notifier).repayLoan();
    if (!context.mounted) return;
    _toast(context, error ?? 'Dette remboursée.');
  }
}

class _Line extends StatelessWidget {
  const _Line({
    required this.icon,
    required this.label,
    required this.value,
    this.bold = false,
  });

  final IconData icon;
  final String label;
  final int value;
  final bool bold;

  @override
  Widget build(BuildContext context) {
    final style = Theme.of(context).textTheme.bodyMedium?.copyWith(
          fontWeight: bold ? FontWeight.w800 : null,
        );
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, size: 18, color: Colors.white60),
          const SizedBox(width: 10),
          Expanded(child: Text(label, style: style)),
          Text(formatMoney(value), style: style),
        ],
      ),
    );
  }
}

class _DealCard extends StatelessWidget {
  const _DealCard({
    required this.deal,
    required this.footer,
    required this.buttonLabel,
    required this.onPressed,
    this.current = false,
  });

  final SponsorDeal deal;
  final String footer;
  final String buttonLabel;
  final VoidCallback onPressed;
  final bool current;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final initials = deal.name
        .split(' ')
        .where((w) => w.isNotEmpty)
        .take(2)
        .map((w) => w[0].toUpperCase())
        .join();
    final hue = (deal.name.codeUnits.fold<int>(0, (a, b) => a + b) * 37) % 360;
    final brand = HSLColor.fromAHSL(1, hue.toDouble(), 0.55, 0.45).toColor();
    final ambitious = deal.targetRank > 0;
    return ProCard(
      accent: current ? _accent : brand,
      highlight: current,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: brand,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  initials,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      deal.name,
                      style: theme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    if (current)
                      const ProTag('Contrat en cours', color: _accent),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            formatMoney(deal.perSeason),
            style: theme.textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.w900,
            ),
          ),
          Text('par saison', style: theme.textTheme.labelSmall),
          const SizedBox(height: 8),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              ProTag('${deal.seasonsLeft} saison(s)',
                  icon: Icons.schedule, color: const Color(0xFF90A4AE)),
              ProTag(
                ambitious
                    ? 'Prime ${formatMoney(deal.bonus)} si top ${deal.targetRank}'
                    : 'Sans condition sportive',
                icon: ambitious ? Icons.flag_outlined : Icons.check,
                color: ambitious
                    ? const Color(0xFFFFB74D)
                    : const Color(0xFF66BB6A),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(footer, style: theme.textTheme.bodySmall),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: current
                ? OutlinedButton(onPressed: onPressed, child: Text(buttonLabel))
                : FilledButton(onPressed: onPressed, child: Text(buttonLabel)),
          ),
        ],
      ),
    );
  }
}
