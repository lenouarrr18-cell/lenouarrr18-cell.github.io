import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/entities/lineup.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/spots.dart';
import '../../domain/entities/tactic.dart';
import '../common/landscape_scope.dart';
import '../game/game_state.dart';
import '../squad/player_sheet.dart';

Color _familyColor(PlayerPosition line) {
  switch (line) {
    case PlayerPosition.goalkeeper:
      return const Color(0xFFF9A825);
    case PlayerPosition.defender:
      return const Color(0xFF1E88E5);
    case PlayerPosition.midfielder:
      return const Color(0xFF43A047);
    case PlayerPosition.forward:
      return const Color(0xFFE53935);
  }
}

String _roleEffect(Role r) {
  final parts = <String>[];
  if (r.advance >= 3) parts.add('joue plus haut');
  if (r.advance <= -3) parts.add('reste plus bas');
  if (r.wide >= 1.1) parts.add('occupe la largeur');
  if (r.wide <= 0.6) parts.add("se rapproche de l'axe");
  if (r.defWork >= 0.8) parts.add('gros travail défensif');
  if (r.defWork <= 0.15) parts.add('peu de replis');
  if (r.playmaking >= 1.2) parts.add('crée le jeu');
  if (r.finishing >= 1.2) parts.add('cherche à conclure');
  if (r.finishing <= 0.75) parts.add('tire peu');
  return parts.isEmpty ? 'Comportement équilibré.' : '${parts.join(', ')}.';
}

const List<String> _presetNames = ['Principale', 'Offensive', 'Défensive'];

class TacticsPage extends ConsumerStatefulWidget {
  const TacticsPage({super.key});

  @override
  ConsumerState<TacticsPage> createState() => _TacticsPageState();
}

class _TacticsPageState extends ConsumerState<TacticsPage> {
  int? _selected;

  @override
  Widget build(BuildContext context) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();

    final theme = Theme.of(context);
    final club = game.userClub;
    final tactic = club.tactic;
    final notifier = ref.read(gameProvider.notifier);
    final strength = club.matchStrength;
    final slots = layoutOf(tactic.formation);
    final xi = lineupSlots(club.starters, tactic.formation);
    final balance = tacticalBalance(club.starters, tactic);
    final bench = [
      for (final p in club.squad)
        if (!club.starterIds.contains(p.id)) p,
    ]..sort((a, b) => b.skill.compareTo(a.skill));
    final sel =
        _selected != null && _selected! < slots.length ? _selected : null;

    Widget header(String text) => Padding(
          padding: const EdgeInsets.only(top: 18, bottom: 6),
          child: Text(text, style: theme.textTheme.titleMedium),
        );

    Widget chips<T>({
      required List<T> values,
      required T selected,
      required String Function(T) label,
      required void Function(T) onPick,
    }) {
      return Wrap(
        spacing: 8,
        runSpacing: 6,
        children: [
          for (final v in values)
            ChoiceChip(
              label: Text(label(v)),
              selected: v == selected,
              onSelected: (_) => onPick(v),
            ),
        ],
      );
    }

    Widget pitchFor(double w, double h, bool horizontal) {
      final cardW = horizontal ? 58.0 : (w * 0.165).clamp(50.0, 72.0).toDouble();
      const cardH = 54.0;
      return SizedBox(
        width: w,
        height: h,
        child: Stack(
          children: [
            Positioned.fill(
              child: CustomPaint(
                painter: _PitchPainter(horizontal: horizontal),
              ),
            ),
            for (var i = 0; i < slots.length; i++)
              AnimatedPositioned(
                key: ValueKey('slot$i'),
                duration: const Duration(milliseconds: 450),
                curve: Curves.easeOutCubic,
                left: horizontal
                    ? (slots[i].x * (w - 24) + 12 - cardW / 2)
                        .clamp(0.0, w - cardW)
                        .toDouble()
                    : (slots[i].y * (w - 16) + 8 - cardW / 2)
                        .clamp(0.0, w - cardW)
                        .toDouble(),
                top: horizontal
                    ? (slots[i].y * (h - 16) + 8 - cardH / 2)
                        .clamp(0.0, h - cardH)
                        .toDouble()
                    : ((1 - slots[i].x) * (h - 24) + 4 - cardH / 2)
                        .clamp(0.0, h - cardH)
                        .toDouble(),
                width: cardW,
                height: cardH,
                child: _PlayerCard(
                  slot: slots[i],
                  player: xi[i],
                  selected: sel == i,
                  onTap: () => setState(
                    () => _selected = sel == i ? null : i,
                  ),
                ),
              ),
          ],
        ),
      );
    }

    final top = <Widget>[
          SizedBox(
            height: 44,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                for (final f in Formation.values)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(f.label),
                      selected: tactic.formation == f,
                      onSelected: (_) {
                        setState(() => _selected = null);
                        notifier.setTactic(tactic.copyWith(formation: f));
                      },
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          Text(tactic.formation.description, style: theme.textTheme.bodySmall),
          const SizedBox(height: 8),
          Row(
            children: [
              for (var i = 0; i < 3; i++)
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(right: i < 2 ? 6 : 0),
                    child: OutlinedButton(
                      onPressed: () {
                        setState(() => _selected = null);
                        notifier.loadPreset(i);
                      },
                      onLongPress: () {
                        notifier.savePreset(i);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              'Configuration « ${_presetNames[i]} » '
                              'enregistrée.',
                            ),
                          ),
                        );
                      },
                      child: Text(
                        _presetNames[i],
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(top: 2),
            child: Text(
              'Touchez pour appliquer une configuration, appui long pour '
              'enregistrer le plan actuel.',
              style: theme.textTheme.bodySmall,
            ),
          ),
          const SizedBox(height: 10),
    ];
    final rest = <Widget>[
          const SizedBox(height: 8),
          if (sel != null && xi[sel] != null)
            _SelectedPanel(
              slot: slots[sel],
              player: xi[sel]!,
              role: tactic.roleAt(sel),
              instruction: tactic.instructionAt(sel),
              onRole: (r) => notifier.setTactic(tactic.withRole(sel, r)),
              onInstruction: (i) =>
                  notifier.setTactic(tactic.withInstruction(sel, i)),
            )
          else
            Text(
              'Touchez un joueur pour voir son poste, son rôle et ses '
              'consignes. Le coach choisit les titulaires : vous fixez le '
              "plan de jeu.",
              style: theme.textTheme.bodySmall,
            ),
          header("Force de l'équipe"),
          Row(
            children: [
              _Stat(label: 'Attaque', value: strength.attack),
              _Stat(label: 'Milieu', value: strength.midfield),
              _Stat(label: 'Défense', value: strength.defense),
              _Stat(label: 'Gardien', value: strength.goalkeeper),
            ],
          ),
          header('Équilibre tactique'),
          _BalanceCard(balance: balance),
          header('Mentalité'),
          chips<TacticStyle>(
            values: TacticStyleInfo.ordered,
            selected: tactic.style,
            label: (v) => v.label,
            onPick: (v) => notifier.setTactic(tactic.copyWith(style: v)),
          ),
          header('Style de jeu'),
          chips<PlayStyle>(
            values: PlayStyle.values,
            selected: tactic.playStyle,
            label: (v) => v.label,
            onPick: (v) => notifier.setTactic(tactic.copyWith(playStyle: v)),
          ),
          header('Pressing'),
          chips<Pressing>(
            values: PressingInfo.ordered,
            selected: tactic.pressing,
            label: (v) => v.label,
            onPick: (v) => notifier.setTactic(tactic.copyWith(pressing: v)),
          ),
          header('Ligne défensive'),
          chips<int>(
            values: const [0, 1, 2, 3, 4],
            selected: tactic.lineHeight,
            label: (v) => lineHeightLabels[v],
            onPick: (v) => notifier.setTactic(tactic.copyWith(lineHeight: v)),
          ),
          header('Largeur offensive'),
          chips<int>(
            values: const [0, 1, 2, 3, 4],
            selected: tactic.width,
            label: (v) => widthLabels[v],
            onPick: (v) => notifier.setTactic(tactic.copyWith(width: v)),
          ),
          header('Transitions'),
          chips<Transition>(
            values: Transition.values,
            selected: tactic.transition,
            label: (v) => v.label,
            onPick: (v) => notifier.setTactic(tactic.copyWith(transition: v)),
          ),
          header('Banc (choix du coach)'),
          for (final p in bench.take(10))
            ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              leading: CircleAvatar(
                radius: 16,
                backgroundColor: _familyColor(naturalSpot(p).line),
                child: Text(
                  '${p.skill}',
                  style: const TextStyle(fontSize: 12, color: Colors.white),
                ),
              ),
              title: Text(p.name),
              subtitle: Text(
                '${naturalSpot(p).fullName} · condition ${p.fitness} %',
              ),
              onTap: () => showOwnPlayerSheet(context, p.id),
            ),
          const SizedBox(height: 12),
          Text(
            'Chaque réglage est transmis au moteur de match : formation, '
            'rôles et consignes placent et font bouger les joueurs ; '
            'mentalité, pressing, ligne et largeur changent le rythme et '
            'les zones occupées. Les changements en cours de match ne sont '
            "pas encore disponibles : le match est simulé d'une traite avec "
            "le plan choisi avant le coup d'envoi.",
            style: theme.textTheme.bodySmall,
          ),
    ];

    return LandscapeScope(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Tactique'),
          actions: [
            IconButton(
              tooltip: "Le coach recompose l'équipe",
              icon: const Icon(Icons.auto_fix_high),
              onPressed: notifier.autoPickStarters,
            ),
          ],
        ),
        body: OrientationBuilder(
          builder: (context, orientation) {
            if (orientation == Orientation.landscape) {
              return LayoutBuilder(
                builder: (context, box) {
                  final h = box.maxHeight - 16;
                  final w = (h * 1.55).clamp(200.0, box.maxWidth * 0.6).toDouble();
                  return Padding(
                    padding: const EdgeInsets.all(8),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        pitchFor(w, h, true),
                        const SizedBox(width: 12),
                        Expanded(
                          child: ListView(
                            padding: const EdgeInsets.only(bottom: 24),
                            children: [...top, ...rest],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              );
            }
            return LayoutBuilder(
              builder: (context, box) {
                final w = box.maxWidth - 24;
                return ListView(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
                  children: [
                    ...top,
                    pitchFor(w, w * 1.28, false),
                    ...rest,
                  ],
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class _PlayerCard extends StatelessWidget {
  const _PlayerCard({
    required this.slot,
    required this.player,
    required this.selected,
    required this.onTap,
  });

  final SpotSlot slot;
  final Player? player;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = _familyColor(slot.spot.line);
    final p = player;
    final fit = p == null ? 0.0 : spotFit(p, slot.spot);
    final last = p == null ? '—' : p.name.split(' ').last;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedScale(
        scale: selected ? 1.12 : 1.0,
        duration: const Duration(milliseconds: 180),
        child: Container(
          decoration: BoxDecoration(
            color: const Color(0xE60F1B16),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: selected ? const Color(0xFFFFD54F) : color,
              width: selected ? 2.5 : 1.5,
            ),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 2),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    p == null ? '?' : '${p.skill}',
                    style: TextStyle(
                      color: color,
                      fontWeight: FontWeight.w900,
                      fontSize: 14,
                    ),
                  ),
                  Text(
                    slot.spot.label,
                    style: TextStyle(
                      color: fit < 0.8 ? Colors.orangeAccent : Colors.white70,
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              Text(
                last,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                ),
              ),
              if (p != null)
                Row(
                  children: [
                    Icon(
                      p.form > 1.05
                          ? Icons.arrow_drop_up
                          : (p.form < 0.95
                              ? Icons.arrow_drop_down
                              : Icons.remove),
                      size: 12,
                      color: p.form > 1.05
                          ? Colors.greenAccent
                          : (p.form < 0.95 ? Colors.redAccent : Colors.white54),
                    ),
                    Expanded(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(2),
                        child: LinearProgressIndicator(
                          value: p.fitness / 100,
                          minHeight: 4,
                          backgroundColor: Colors.white12,
                          color: p.fitness >= 70
                              ? Colors.greenAccent
                              : (p.fitness >= 50
                                  ? Colors.amber
                                  : Colors.redAccent),
                        ),
                      ),
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SelectedPanel extends StatelessWidget {
  const _SelectedPanel({
    required this.slot,
    required this.player,
    required this.role,
    required this.instruction,
    required this.onRole,
    required this.onInstruction,
  });

  final SpotSlot slot;
  final Player player;
  final Role role;
  final Instruction instruction;
  final void Function(Role) onRole;
  final void Function(Instruction) onInstruction;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final natural = naturalSpot(player);
    final fit = spotFit(player, slot.spot);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    player.name,
                    style: theme.textTheme.titleMedium,
                  ),
                ),
                TextButton(
                  onPressed: () => showOwnPlayerSheet(context, player.id),
                  child: const Text('Fiche'),
                ),
              ],
            ),
            Text(
              'Poste naturel : ${natural.fullName} (${natural.label}). '
              'Joue ici : ${slot.spot.fullName} (${slot.spot.label}), '
              'adéquation ${(fit * 100).round()} %.',
              style: theme.textTheme.bodySmall,
            ),
            Text(
              'Niveau ${player.skill} · forme ${(player.form * 100).round()} % '
              '· condition ${player.fitness} %',
              style: theme.textTheme.bodySmall,
            ),
            const SizedBox(height: 8),
            Text('Rôle', style: theme.textTheme.titleSmall),
            const SizedBox(height: 4),
            Wrap(
              spacing: 6,
              runSpacing: 4,
              children: [
                for (final r in rolesFor(slot.spot))
                  ChoiceChip(
                    label: Text(r.label),
                    selected: r == role,
                    onSelected: (_) => onRole(r),
                  ),
              ],
            ),
            Text(_roleEffect(role), style: theme.textTheme.bodySmall),
            if (instructionsFor(slot.spot).length > 1) ...[
              const SizedBox(height: 8),
              Text('Consigne', style: theme.textTheme.titleSmall),
              const SizedBox(height: 4),
              Wrap(
                spacing: 6,
                runSpacing: 4,
                children: [
                  for (final i in instructionsFor(slot.spot))
                    ChoiceChip(
                      label: Text(i.label),
                      selected: i == instruction,
                      onSelected: (_) => onInstruction(i),
                    ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({required this.label, required this.value});

  final String label;
  final double value;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Expanded(
      child: Column(
        children: [
          Text(
            '${value.round()}',
            style: theme.textTheme.titleLarge
                ?.copyWith(fontWeight: FontWeight.w800),
          ),
          Text(label, style: theme.textTheme.bodySmall),
        ],
      ),
    );
  }
}

class _BalanceCard extends StatelessWidget {
  const _BalanceCard({required this.balance});

  final TacticalBalance balance;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    Widget bar(String label, int v) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 3),
          child: Row(
            children: [
              SizedBox(width: 130, child: Text(label)),
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: v / 100,
                    minHeight: 8,
                    backgroundColor: Colors.white12,
                    color: v >= 70
                        ? Colors.greenAccent
                        : (v >= 50 ? Colors.amber : Colors.redAccent),
                  ),
                ),
              ),
              SizedBox(
                width: 34,
                child: Text('$v', textAlign: TextAlign.right),
              ),
            ],
          ),
        );
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'ÉQUILIBRE TACTIQUE : ${balance.total}/100',
              style: theme.textTheme.titleMedium
                  ?.copyWith(fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 6),
            bar('Solidité défensive', balance.solidity),
            bar('Contrôle du milieu', balance.control),
            bar('Puissance offensive', balance.power),
            const SizedBox(height: 6),
            for (final n in balance.notes)
              Padding(
                padding: const EdgeInsets.only(top: 2),
                child: Text('• $n', style: theme.textTheme.bodySmall),
              ),
            for (final w in balance.warnings)
              Padding(
                padding: const EdgeInsets.only(top: 2),
                child: Text(
                  '⚠ $w',
                  style: theme.textTheme.bodySmall
                      ?.copyWith(color: Colors.orangeAccent),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _PitchPainter extends CustomPainter {
  _PitchPainter({this.horizontal = false});

  final bool horizontal;

  @override
  void paint(Canvas canvas, Size size) {
    if (horizontal) {
      // Terrain dessiné à la verticale puis pivoté : l'attaque va à droite.
      canvas.save();
      canvas.translate(size.width, 0);
      canvas.rotate(1.5707963267948966);
      _draw(canvas, Size(size.height, size.width));
      canvas.restore();
    } else {
      _draw(canvas, size);
    }
  }

  void _draw(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(0, 0, w, h),
        const Radius.circular(12),
      ),
      Paint()..color = const Color(0xFF2B8A45),
    );
    const bands = 10;
    for (var i = 0; i < bands; i += 2) {
      canvas.drawRect(
        Rect.fromLTWH(0, h * i / bands, w, h / bands),
        Paint()..color = const Color(0x16000000),
      );
    }
    final line = Paint()
      ..color = const Color(0xCCFFFFFF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6;
    const m = 8.0;
    canvas.drawRect(Rect.fromLTWH(m, m, w - 2 * m, h - 2 * m), line);
    canvas.drawLine(Offset(m, h / 2), Offset(w - m, h / 2), line);
    canvas.drawCircle(Offset(w / 2, h / 2), w * 0.11, line);
    canvas.drawCircle(
      Offset(w / 2, h / 2),
      2.5,
      Paint()..color = Colors.white70,
    );
    final ph = h - 2 * m;
    final pw = w - 2 * m;
    final boxW = pw * 0.6;
    final boxH = ph * 0.16;
    final goalW = pw * 0.3;
    final goalH = ph * 0.06;
    canvas.drawRect(Rect.fromLTWH((w - boxW) / 2, m, boxW, boxH), line);
    canvas.drawRect(
      Rect.fromLTWH((w - boxW) / 2, h - m - boxH, boxW, boxH),
      line,
    );
    canvas.drawRect(Rect.fromLTWH((w - goalW) / 2, m, goalW, goalH), line);
    canvas.drawRect(
      Rect.fromLTWH((w - goalW) / 2, h - m - goalH, goalW, goalH),
      line,
    );
    final spot = Paint()..color = Colors.white70;
    canvas.drawCircle(Offset(w / 2, m + ph * 0.11), 2.2, spot);
    canvas.drawCircle(Offset(w / 2, h - m - ph * 0.11), 2.2, spot);
    final goal = Paint()..color = Colors.white;
    canvas.drawRect(Rect.fromLTWH(w / 2 - pw * 0.07, m - 5, pw * 0.14, 5), goal);
    canvas.drawRect(Rect.fromLTWH(w / 2 - pw * 0.07, h - m, pw * 0.14, 5), goal);
  }

  @override
  bool shouldRepaint(covariant _PitchPainter old) =>
      old.horizontal != horizontal;
}
