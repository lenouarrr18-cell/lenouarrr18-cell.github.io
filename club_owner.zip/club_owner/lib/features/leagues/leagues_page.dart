import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../domain/entities/club.dart';
import '../../domain/entities/division.dart';
import '../../domain/entities/player.dart';
import '../../engine/season/season.dart';
import '../../engine/world/facilities.dart';
import '../../engine/world/nations.dart';
import '../common/crest.dart';
import '../common/pro_page.dart';
import '../game/game_state.dart';

const String myLeagueId = 'mine';

/// Tous les championnats simulés : le vôtre et ceux du monde.
class LeaguesPage extends ConsumerWidget {
  const LeaguesPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();

    final leagues = [...game.world]
      ..sort((a, b) {
        final byDivision = a.division.compareTo(b.division);
        return byDivision != 0
            ? byDivision
            : a.country.compareTo(b.country);
      });

    String leader(Season season) {
      final rows = season.standings;
      if (rows.isEmpty) return '';
      return 'Leader : ${season.clubById(rows.first.clubId).name}';
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Championnats du monde')),
      body: ProColumns(
        columns: ProColumns.split([
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              'Tous ces championnats se jouent en même temps que le vôtre. '
              'Les buteurs et passeurs de la première division comptent '
              'pour le Ballon d\'or et les autres distinctions.',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ),
          ListTile(
            leading: const Icon(Icons.star, color: Color(0xFFF9A825)),
            title: Text(
              '${divisionName(game.division)} · ${game.country.name}',
            ),
            subtitle: Text('Votre championnat. ${leader(game.season)}'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => context.push('/leagues/$myLeagueId'),
          ),
          for (final league in leagues)
            ListTile(
              leading: Text(
                flagOf(league.country),
                style: const TextStyle(fontSize: 24),
              ),
              title: Text(
                '${divisionName(league.division)} · ${league.country}',
              ),
              subtitle: Text(leader(league.season)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => context.push('/leagues/${league.id}'),
            ),
        ], 2),
      ),
    );
  }
}

/// Classement, buteurs et clubs d'un championnat.
class LeaguePage extends ConsumerWidget {
  const LeaguePage({required this.leagueId, super.key});

  final String leagueId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();

    Season? season;
    var title = '';
    if (leagueId == myLeagueId) {
      season = game.season;
      title = '${divisionName(game.division)} · ${game.country.name}';
    } else {
      for (final l in game.world) {
        if (l.id == leagueId) {
          season = l.season;
          title = '${divisionName(l.division)} · ${l.country}';
        }
      }
    }
    if (season == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Championnat')),
        body: const Center(child: Text('Championnat introuvable.')),
      );
    }
    final current = season;

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text(title),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Classement'),
              Tab(text: 'Buteurs'),
              Tab(text: 'Clubs'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _Table(season: current),
            _Scorers(season: current),
            _Clubs(season: current),
          ],
        ),
      ),
    );
  }
}

class _Table extends StatelessWidget {
  const _Table({required this.season});

  final Season season;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final rows = season.standings;
    final shownRound = season.currentRound > season.totalRounds
        ? season.totalRounds
        : season.currentRound;
    return ListView(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: Text(
            'Journée $shownRound sur ${season.totalRounds}',
            style: theme.textTheme.titleSmall,
          ),
        ),
        for (var i = 0; i < rows.length; i++)
          ListTile(
            dense: true,
            tileColor: season.clubById(rows[i].clubId).isUser
                ? theme.colorScheme.primaryContainer
                : null,
            leading: SizedBox(
              width: 56,
              child: Row(
                children: [
                  SizedBox(width: 24, child: Text('${i + 1}')),
                  ClubCrest(
                    name: season.clubById(rows[i].clubId).name,
                    size: 18,
                  ),
                ],
              ),
            ),
            title: Text(season.clubById(rows[i].clubId).name),
            subtitle: Text(
              '${rows[i].played} j · ${rows[i].won}V ${rows[i].drawn}N '
              '${rows[i].lost}D · ${rows[i].goalDifference >= 0 ? '+' : ''}'
              '${rows[i].goalDifference}',
            ),
            trailing: Text(
              '${rows[i].points}',
              style: theme.textTheme.titleMedium,
            ),
          ),
      ],
    );
  }
}

class _Row {
  const _Row(this.player, this.club);

  final Player player;
  final Club club;
}

class _Scorers extends StatelessWidget {
  const _Scorers({required this.season});

  final Season season;

  @override
  Widget build(BuildContext context) {
    final rows = [
      for (final club in season.clubs)
        for (final p in club.squad)
          if (p.goals > 0 || p.assists > 0) _Row(p, club),
    ]..sort((a, b) {
        final byGoals = b.player.goals.compareTo(a.player.goals);
        return byGoals != 0
            ? byGoals
            : b.player.assists.compareTo(a.player.assists);
      });
    if (rows.isEmpty) {
      return const Center(child: Text('Aucun but pour le moment.'));
    }
    return ListView(
      children: [
        for (var i = 0; i < rows.length && i < 20; i++)
          ListTile(
            dense: true,
            leading: SizedBox(width: 28, child: Text('${i + 1}')),
            title: Text(
              '${flagOf(rows[i].player.nation)} ${rows[i].player.name}',
            ),
            subtitle: Text(rows[i].club.name),
            trailing: Text(
              '${rows[i].player.goals} buts · ${rows[i].player.assists} passes',
            ),
          ),
      ],
    );
  }
}

class _Clubs extends StatelessWidget {
  const _Clubs({required this.season});

  final Season season;

  @override
  Widget build(BuildContext context) {
    final clubs = [...season.clubs]
      ..sort((a, b) => b.prestige.compareTo(a.prestige));
    return ListView(
      children: [
        for (final club in clubs)
          ListTile(
            leading: ClubCrest(name: club.name, size: 32),
            title: Text(club.name),
            subtitle: Text(
              '${stadiumNameFor(club.name)} · prestige ${club.prestige}',
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              if (club.isUser) {
                context.go('/squad');
              } else {
                context.push('/clubs/${club.id}');
              }
            },
          ),
      ],
    );
  }
}
