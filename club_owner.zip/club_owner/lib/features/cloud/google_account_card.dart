import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/cloud/cloud_save.dart';

String _initial(String? text) {
  final v = (text ?? '').trim();
  return v.isEmpty ? '?' : v.substring(0, 1).toUpperCase();
}

/// Petit « G » multicolore dessiné (pas d'image à charger).
class GoogleMark extends StatelessWidget {
  const GoogleMark({this.size = 20, super.key});

  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: const BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
      ),
      alignment: Alignment.center,
      child: ShaderMask(
        shaderCallback: (r) => const SweepGradient(
          colors: [
            Color(0xFF4285F4),
            Color(0xFF34A853),
            Color(0xFFFBBC05),
            Color(0xFFEA4335),
            Color(0xFF4285F4),
          ],
        ).createShader(r),
        child: Text(
          'G',
          style: TextStyle(
            color: Colors.white,
            fontSize: size * 0.72,
            fontWeight: FontWeight.w900,
            height: 1,
          ),
        ),
      ),
    );
  }
}

/// Carte « Compte Google » réutilisable : connexion, état de la sauvegarde
/// et, si demandé, reprise d'une carrière enregistrée dans le cloud.
class GoogleAccountCard extends ConsumerWidget {
  const GoogleAccountCard({
    this.allowRestore = false,
    this.dark = false,
    this.compact = false,
    super.key,
  });

  /// Affiche « Reprendre ma carrière » quand une sauvegarde existe.
  final bool allowRestore;

  /// Sur fond sombre (écran de création du club).
  final bool dark;

  /// Version réduite (bandeau de l'accueil).
  final bool compact;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cloud = ref.watch(cloudProvider);
    final ctrl = ref.read(cloudProvider.notifier);
    final fg = dark ? Colors.white : Theme.of(context).colorScheme.onSurface;
    final sub = dark ? Colors.white70 : Theme.of(context).hintColor;
    if (!cloud.available) {
      if (compact) return const SizedBox.shrink();
      return Row(
        children: [
          const GoogleMark(size: 26),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'Connexion Google indisponible pour le moment '
              '(vérifiez votre connexion internet).',
              style: TextStyle(color: sub, fontSize: 12),
            ),
          ),
          TextButton(
            onPressed: ctrl.retryInit,
            child: const Text('Réessayer'),
          ),
        ],
      );
    }

    Future<void> restore() async {
      final ok = await ctrl.restore();
      if (ok && context.mounted) context.go('/home');
    }

    final Widget body;
    if (!cloud.signedIn) {
      body = Row(
        children: [
          const GoogleMark(size: 26),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  allowRestore
                      ? 'Déjà une carrière ?'
                      : 'Protégez votre carrière',
                  style: TextStyle(color: fg, fontWeight: FontWeight.w800),
                ),
                if (!compact)
                  Text(
                    allowRestore
                        ? 'Connectez-vous avec Google pour la retrouver.'
                        : 'Sauvegarde Google : progression et succès '
                            'conservés, même après une réinstallation.',
                    style: TextStyle(color: sub, fontSize: 12),
                  ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: const Color(0xFF1F1F1F),
            ),
            onPressed: cloud.busy ? null : ctrl.signIn,
            icon: cloud.busy
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const GoogleMark(size: 18),
            label: const Text('Se connecter'),
          ),
        ],
      );
    } else {
      final remote = cloud.remote;
      body = Row(
        children: [
          CircleAvatar(
            radius: 15,
            backgroundColor: const Color(0xFF4285F4),
            child: Text(
              _initial(cloud.name ?? cloud.email),
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  cloud.name ?? cloud.email ?? 'Compte Google',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: fg, fontWeight: FontWeight.w800),
                ),
                Text(
                  remote == null
                      ? 'Connecté · sauvegarde automatique active'
                      : 'Cloud : ${remote.club}, saison ${remote.season}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: sub, fontSize: 12),
                ),
              ],
            ),
          ),
          if (allowRestore && remote != null) ...[
            const SizedBox(width: 10),
            FilledButton.icon(
              onPressed: cloud.busy ? null : restore,
              icon: const Icon(Icons.cloud_download, size: 18),
              label: const Text('Reprendre'),
            ),
          ] else if (!compact) ...[
            const SizedBox(width: 6),
            TextButton(
              onPressed: () => context.push('/cloud'),
              child: const Text('Gérer'),
            ),
          ] else
            Icon(Icons.cloud_done, color: Colors.green.shade400, size: 20),
        ],
      );
    }

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 14,
        vertical: compact ? 8 : 12,
      ),
      decoration: BoxDecoration(
        color: dark
            ? Colors.white.withAlpha(22)
            : Theme.of(context).colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: const Color(0xFF4285F4).withAlpha(dark ? 120 : 90),
        ),
      ),
      child: body,
    );
  }
}
