import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/cloud/cloud_save.dart';
import '../common/pro_page.dart';
import '../game/game_state.dart';

const Color _accent = Color(0xFF4285F4);

String _date(DateTime? d) {
  if (d == null) return '-';
  String two(int v) => v.toString().padLeft(2, '0');
  return '${two(d.day)}/${two(d.month)}/${d.year} à ${two(d.hour)}h${two(d.minute)}';
}

/// Compte Google et sauvegarde de la carrière dans le cloud.
class CloudPage extends ConsumerWidget {
  const CloudPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final cloud = ref.watch(cloudProvider);
    final ctrl = ref.read(cloudProvider.notifier);
    final game = ref.watch(gameProvider);

    ref.listen(cloudProvider, (prev, next) {
      final m = next.message;
      if (m != null && m != prev?.message) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
      }
    });

    return ProPage(
      title: 'Compte et sauvegarde',
      subtitle: 'Gardez votre carrière sur tous vos appareils',
      icon: Icons.cloud_outlined,
      accent: _accent,
      landscape: true,
      stats: [
        ProStat('Compte', cloud.signedIn ? 'Connecté' : 'Non connecté',
            icon: Icons.account_circle_outlined),
        ProStat('Dernier envoi', cloud.lastSync == null ? '-' : _date(cloud.lastSync),
            icon: Icons.cloud_done_outlined),
      ],
      children: [
        if (!cloud.available)
          const ProEmpty(
            icon: Icons.cloud_off_outlined,
            title: 'Sauvegarde en ligne bientôt disponible',
            message: 'La connexion Google sera activée dans une prochaine '
                'mise à jour. En attendant, votre progression est conservée '
                'sur ce téléphone lors des mises à jour.',
            accent: _accent,
          )
        else if (!cloud.signedIn)
          ProCard(
            highlight: true,
            accent: _accent,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Connectez-vous avec Google pour sauvegarder votre carrière, '
                  'vos succès et votre progression. Vous les retrouverez après '
                  'une réinstallation ou sur un autre téléphone.',
                  style: theme.textTheme.bodyMedium,
                ),
                const SizedBox(height: 14),
                FilledButton.icon(
                  onPressed: cloud.busy ? null : ctrl.signIn,
                  icon: const Icon(Icons.login),
                  label: const Text('Se connecter avec Google'),
                ),
              ],
            ),
          )
        else ...[
          ProCard(
            accent: _accent,
            child: Row(
              children: [
                const CircleAvatar(child: Icon(Icons.person)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        cloud.name ?? 'Compte Google',
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      Text(cloud.email ?? '', style: theme.textTheme.bodySmall),
                    ],
                  ),
                ),
                TextButton(
                  onPressed: ctrl.signOut,
                  child: const Text('Se déconnecter'),
                ),
              ],
            ),
          ),
          ProCard(
            title: 'Sauvegarde dans le cloud',
            icon: Icons.cloud_upload_outlined,
            accent: _accent,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  cloud.remote == null
                      ? 'Aucune sauvegarde en ligne pour le moment.'
                      : '${cloud.remote!.club}, saison ${cloud.remote!.season} '
                          '· ${_date(cloud.remote!.updated)}',
                ),
                const SizedBox(height: 6),
                Text(
                  'La carrière est envoyée automatiquement pendant que vous '
                  'jouez et quand vous quittez le jeu.',
                  style: theme.textTheme.bodySmall,
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    FilledButton.icon(
                      onPressed: cloud.busy || game == null
                          ? null
                          : () => ctrl.upload(game),
                      icon: const Icon(Icons.cloud_upload),
                      label: const Text('Sauvegarder maintenant'),
                    ),
                    OutlinedButton.icon(
                      onPressed: cloud.busy || cloud.remote == null
                          ? null
                          : () => _confirmRestore(context, ref),
                      icon: const Icon(Icons.cloud_download),
                      label: const Text('Restaurer depuis le cloud'),
                    ),
                  ],
                ),
                if (cloud.busy)
                  const Padding(
                    padding: EdgeInsets.only(top: 12),
                    child: LinearProgressIndicator(),
                  ),
              ],
            ),
          ),
        ],
      ],
    );
  }

  Future<void> _confirmRestore(BuildContext context, WidgetRef ref) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Restaurer la carrière ?'),
        content: const Text(
          'La partie de ce téléphone sera remplacée par celle du cloud.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Annuler'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Restaurer'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    final done = await ref.read(cloudProvider.notifier).restore();
    if (done && context.mounted) context.go('/home');
  }
}
