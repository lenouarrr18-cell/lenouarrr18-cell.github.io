import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../engine/achievements/achievements.dart';
import '../common/pro_page.dart';
import '../game/game_state.dart';

const Color _accent = Color(0xFFF5C04A);

Color tierColor(int tier) => tier == 3
    ? const Color(0xFFF5C04A)
    : (tier == 2 ? const Color(0xFFB0BEC5) : const Color(0xFFCD7F32));

class AchievementsPage extends ConsumerWidget {
  const AchievementsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();
    final theme = Theme.of(context);
    final done = unlockedAchievements(game);
    final pct = (done.length * 100 / achievements.length).round();

    return ProPage(
      title: 'Succès',
      subtitle: 'Les exploits de votre présidence',
      icon: Icons.emoji_events,
      accent: _accent,
      stats: [
        ProStat('Débloqués', '${done.length}/${achievements.length}',
            icon: Icons.lock_open),
        ProStat('Progression', '$pct %', icon: Icons.trending_up),
      ],
      side: [ProMeter(label: 'Carrière', value: pct, color: _accent)],
      children: [
        ProGrid(
          minWidth: 260,
          children: [
            for (final a in achievements)
              Opacity(
                opacity: done.contains(a.id) ? 1 : 0.45,
                child: ProCard(
                  highlight: done.contains(a.id),
                  accent: tierColor(a.tier),
                  child: Row(
                    children: [
                      Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: done.contains(a.id)
                              ? tierColor(a.tier)
                              : Colors.white10,
                        ),
                        child: Icon(
                          done.contains(a.id) ? Icons.emoji_events : Icons.lock,
                          color: done.contains(a.id)
                              ? Colors.black87
                              : Colors.white54,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              a.title,
                              style: theme.textTheme.titleSmall?.copyWith(
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            Text(a.description,
                                style: theme.textTheme.bodySmall),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ],
    );
  }
}
