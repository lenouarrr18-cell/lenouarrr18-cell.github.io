import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/utils/calendar.dart';
import '../../core/utils/format.dart';
import '../../domain/entities/standing.dart';
import '../../engine/calendar/fixture_generator.dart';
import '../../engine/season/season.dart';
import '../common/pro_page.dart';
import '../game/game_state.dart';

String _promotionNote(int division) {
  if (division <= 1) {
    return 'Les deux derniers descendent en division inférieure.';
  }
  if (division >= 4) {
    return 'Les deux premiers montent en division supérieure.';
  }
  return 'Les deux premiers montent, les deux derniers descendent.';
}

class CalendarPage extends ConsumerStatefulWidget {
  const CalendarPage({super.key});

  @override
  ConsumerState<CalendarPage> createState() => _CalendarPageState();
}

class _CalendarPageState extends ConsumerState<CalendarPage> {
  /// Journée affichée ; `null` pour suivre la journée en cours.
  int? _round;

  @override
  Widget build(BuildContext context) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();
    final season = game.season;

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Calendrier'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Matchs'),
              Tab(text: 'Classement'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildMatches(context, season),
            _buildStandings(context, season),
          ],
        ),
      ),
    );
  }

  Widget _buildMatches(BuildContext context, Season season) {
    final theme = Theme.of(context);
    final canPlay = season.userClub.hasFullLineup;
    final lastRound = season.totalRounds;
    final defaultRound = season.isFinished ? lastRound : season.currentRound;
    final shown = (_round ?? defaultRound).clamp(1, lastRound).toInt();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                onPressed: shown > 1
                    ? () => setState(() => _round = shown - 1)
                    : null,
                icon: const Icon(Icons.chevron_left),
              ),
              Column(
                children: [
                  Text(
                    'Journée $shown sur $lastRound',
                    style: theme.textTheme.titleMedium,
                  ),
                  Text(
                    formatDateFr(
                      roundDate(
                        ref.read(gameProvider)?.seasonNumber ?? 1,
                        shown,
                      ),
                    ),
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
              IconButton(
                onPressed: shown < lastRound
                    ? () => setState(() => _round = shown + 1)
                    : null,
                icon: const Icon(Icons.chevron_right),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            children: [
              ProGrid(
                minWidth: 340,
                children: [
                  for (final fixture in season.fixturesOfRound(shown))
                    Card(
                      margin: const EdgeInsets.only(bottom: 8),
                      child: _fixtureTile(theme, season, fixture),
                    ),
                ],
              ),
            ],
          ),
        ),
        if (!season.isFinished)
          Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: canPlay
                    ? () {
                        ref.read(gameProvider.notifier).playNextRound();
                        setState(() => _round = null);
                      }
                    : null,
                icon: const Icon(Icons.sports_soccer),
                label: Text(
                  canPlay
                      ? 'Jouer la journée ${season.currentRound}'
                      : 'Composez votre équipe (onglet Effectif)',
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _fixtureTile(ThemeData theme, Season season, Fixture fixture) {
    final home = season.clubById(fixture.homeId);
    final away = season.clubById(fixture.awayId);
    final result = season.resultOf(fixture);
    final isUser = home.isUser || away.isUser;
    final style = isUser
        ? theme.textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.bold)
        : theme.textTheme.bodyLarge;

    return Container(
      color: isUser ? theme.colorScheme.primaryContainer : null,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Expanded(
            child: Text(home.name, textAlign: TextAlign.end, style: style),
          ),
          SizedBox(
            width: 72,
            child: Center(
              child: Text(
                result == null
                    ? '-'
                    : '${result.homeGoals} - ${result.awayGoals}',
                style: style,
              ),
            ),
          ),
          Expanded(child: Text(away.name, style: style)),
        ],
      ),
    );
  }

  Widget _buildStandings(BuildContext context, Season season) {
    final theme = Theme.of(context);
    final rows = season.standings;
    final headerStyle = theme.textTheme.labelMedium;

    Widget cell(String text, double width, {TextStyle? style}) {
      return SizedBox(
        width: width,
        child: Text(text, textAlign: TextAlign.center, style: style),
      );
    }

    Widget line({
      required Widget lead,
      required String club,
      required List<String> values,
      TextStyle? style,
      Color? background,
    }) {
      return Container(
        color: background,
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
        child: Row(
          children: [
            lead,
            Expanded(
              child: Text(club, overflow: TextOverflow.ellipsis, style: style),
            ),
            for (var i = 0; i < values.length; i++)
              cell(values[i], i == values.length - 1 ? 36 : 30, style: style),
          ],
        ),
      );
    }

    return ListView(
      children: [
        line(
          lead: const SizedBox(width: 32),
          club: 'Club',
          values: const ['J', 'G', 'N', 'P', 'Diff', 'Pts'],
          style: headerStyle,
        ),
        for (var i = 0; i < rows.length; i++)
          _standingLine(theme, season, rows[i], i + 1, line),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Text(
            _promotionNote(ref.read(gameProvider)?.division ?? 4),
            style: theme.textTheme.bodySmall,
          ),
        ),
      ],
    );
  }

  Widget _standingLine(
    ThemeData theme,
    Season season,
    Standing row,
    int rank,
    Widget Function({
      required Widget lead,
      required String club,
      required List<String> values,
      TextStyle? style,
      Color? background,
    })
    line,
  ) {
    final club = season.clubById(row.clubId);
    final style = club.isUser
        ? theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.bold)
        : theme.textTheme.bodyMedium;
    final promoted = rank <= 2;

    return line(
      lead: SizedBox(
        width: 32,
        child: Row(
          children: [
            Container(
              width: 4,
              height: 20,
              color: promoted ? theme.colorScheme.primary : Colors.transparent,
            ),
            const SizedBox(width: 4),
            Text('$rank', style: style),
          ],
        ),
      ),
      club: club.name,
      values: [
        '${row.played}',
        '${row.won}',
        '${row.drawn}',
        '${row.lost}',
        signed(row.goalDifference),
        '${row.points}',
      ],
      style: style,
      background: club.isUser ? theme.colorScheme.primaryContainer : null,
    );
  }
}
