import 'dart:math';

import 'package:flutter/material.dart';

int _hashOf(String text) {
  var hash = 17;
  for (final unit in text.codeUnits) {
    hash = (hash * 31 + unit) & 0x3fffffff;
  }
  return hash;
}

/// Couleurs du club (les mêmes que son écusson) : maillot et seconde
/// couleur.
(Color, Color) clubColors(String name) {
  final hash = _hashOf(name);
  final primary =
      HSLColor.fromAHSL(1, (hash % 360).toDouble(), 0.6, 0.36).toColor();
  final secondary =
      HSLColor.fromAHSL(1, ((hash ~/ 7) % 360).toDouble(), 0.7, 0.62)
          .toColor();
  return (primary, secondary);
}

/// Tenues du match : couleurs du club, sans confusion entre les deux
/// équipes ni avec la pelouse (l'équipe visiteuse change de maillot).
(Color, Color) matchKits(String home, String away) {
  double hue(Color c) => HSLColor.fromColor(c).hue;
  bool grassy(Color c) {
    final h = hue(c);
    return h > 85 && h < 165;
  }

  final (h1, h2) = clubColors(home);
  final (a1, a2) = clubColors(away);
  var homeKit = grassy(h1) ? h2 : h1;
  if (grassy(homeKit)) homeKit = const Color(0xFF1E5BD8);
  var awayKit = grassy(a1) ? a2 : a1;
  if (grassy(awayKit)) awayKit = const Color(0xFFD32F2F);
  final diff = (hue(homeKit) - hue(awayKit)).abs();
  final close = min(diff, 360 - diff) < 45;
  if (close) {
    // Maillot extérieur : blanc, ou noir si le domicile est déjà clair.
    awayKit = HSLColor.fromColor(homeKit).lightness > 0.6
        ? const Color(0xFF1B1B1F)
        : const Color(0xFFF2F2F2);
  }
  return (homeKit, awayKit);
}

String _initials(String name) {
  final words = name
      .split(' ')
      .where((w) => w.isNotEmpty)
      .toList();
  if (words.isEmpty) return '?';
  if (words.length == 1) return words.first.substring(0, 1).toUpperCase();
  return (words[0].substring(0, 1) + words[1].substring(0, 1)).toUpperCase();
}

/// Écusson généré à partir du nom du club (couleurs et motif uniques).
class ClubCrest extends StatelessWidget {
  const ClubCrest({required this.name, this.size = 40, super.key});

  final String name;
  final double size;

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size(size, size * 1.15),
      painter: _CrestPainter(name),
    );
  }
}

class _CrestPainter extends CustomPainter {
  _CrestPainter(this.name);

  final String name;

  @override
  void paint(Canvas canvas, Size size) {
    final hash = _hashOf(name);
    final w = size.width;
    final h = size.height;
    final primary = HSLColor.fromAHSL(1, (hash % 360).toDouble(), 0.6, 0.36)
        .toColor();
    final secondary =
        HSLColor.fromAHSL(1, ((hash ~/ 7) % 360).toDouble(), 0.7, 0.62)
            .toColor();

    final shield = Path()
      ..moveTo(w * 0.08, h * 0.06)
      ..lineTo(w * 0.92, h * 0.06)
      ..lineTo(w * 0.92, h * 0.52)
      ..quadraticBezierTo(w * 0.92, h * 0.82, w * 0.5, h * 0.97)
      ..quadraticBezierTo(w * 0.08, h * 0.82, w * 0.08, h * 0.52)
      ..close();

    canvas.drawPath(shield, Paint()..color = primary);

    canvas.save();
    canvas.clipPath(shield);
    final accent = Paint()..color = secondary;
    switch (hash % 3) {
      case 0:
        canvas.drawRect(Rect.fromLTWH(w * 0.38, 0, w * 0.24, h), accent);
        break;
      case 1:
        final band = Path()
          ..moveTo(0, h * 0.2)
          ..lineTo(w, h * 0.55)
          ..lineTo(w, h * 0.78)
          ..lineTo(0, h * 0.43)
          ..close();
        canvas.drawPath(band, accent);
        break;
      default:
        canvas.drawRect(Rect.fromLTWH(0, h * 0.5, w, h * 0.2), accent);
        break;
    }
    canvas.restore();

    canvas.drawPath(
      shield,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = w * 0.05
        ..color = Colors.white,
    );

    final painter = TextPainter(
      text: TextSpan(
        text: _initials(name),
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w900,
          fontSize: w * 0.34,
          shadows: const [Shadow(color: Colors.black54, blurRadius: 3)],
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    painter.paint(
      canvas,
      Offset((w - painter.width) / 2, h * 0.3),
    );
  }

  @override
  bool shouldRepaint(covariant _CrestPainter oldDelegate) {
    return oldDelegate.name != name;
  }
}

/// Logo de l'application : un trophée doré sur fond vert.
class AppLogo extends StatelessWidget {
  const AppLogo({this.size = 64, super.key});

  final double size;

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      'assets/branding/logo.png',
      width: size,
      height: size,
      filterQuality: FilterQuality.medium,
      errorBuilder: (_, __, ___) =>
          CustomPaint(size: Size(size, size), painter: _LogoPainter()),
    );
  }
}

class _LogoPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    final background = RRect.fromRectAndRadius(
      Rect.fromLTWH(0, 0, w, h),
      Radius.circular(w * 0.22),
    );
    canvas.drawRRect(
      background,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1B8A5A), Color(0xFF0B4F33)],
        ).createShader(Rect.fromLTWH(0, 0, w, h)),
    );

    final gold = Paint()..color = const Color(0xFFFFC83D);
    final bowl = Path()
      ..moveTo(w * 0.28, h * 0.2)
      ..lineTo(w * 0.72, h * 0.2)
      ..quadraticBezierTo(w * 0.72, h * 0.54, w * 0.5, h * 0.6)
      ..quadraticBezierTo(w * 0.28, h * 0.54, w * 0.28, h * 0.2)
      ..close();
    canvas.drawPath(bowl, gold);

    final handles = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.045
      ..color = const Color(0xFFFFC83D);
    canvas.drawArc(
      Rect.fromLTWH(w * 0.14, h * 0.2, w * 0.2, h * 0.2),
      1.57,
      3.14,
      false,
      handles,
    );
    canvas.drawArc(
      Rect.fromLTWH(w * 0.66, h * 0.2, w * 0.2, h * 0.2),
      -1.57,
      3.14,
      false,
      handles,
    );

    canvas.drawRect(Rect.fromLTWH(w * 0.46, h * 0.6, w * 0.08, h * 0.12), gold);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(w * 0.34, h * 0.72, w * 0.32, h * 0.08),
        Radius.circular(w * 0.02),
      ),
      gold,
    );

    final star = Paint()..color = const Color(0xFF0B4F33);
    canvas.drawCircle(Offset(w * 0.5, h * 0.36), w * 0.07, star);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
