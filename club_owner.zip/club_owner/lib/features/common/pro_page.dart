import 'package:flutter/material.dart';

import 'landscape_scope.dart';

/// Chiffre clé affiché dans la colonne de gauche d'un écran.
class ProStat {
  const ProStat(this.label, this.value, {this.icon, this.color});

  final String label;
  final String value;
  final IconData? icon;
  final Color? color;
}

/// Onglet d'un écran [ProPage].
class ProTab {
  const ProTab(this.label, this.child, {this.icon});

  final String label;
  final Widget child;
  final IconData? icon;
}

Color _darken(Color c, double f) {
  int ch(int v) => (v * f).clamp(0, 255).round();
  return Color.fromARGB(255, ch(c.red), ch(c.green), ch(c.blue));
}

/// Écran « pro » en paysage plein écran : une colonne d'identité à gauche
/// (titre, chiffres clés), le contenu à droite. En portrait, un bandeau
/// remplace la colonne.
class ProPage extends StatelessWidget {
  const ProPage({
    required this.title,
    required this.icon,
    required this.accent,
    this.subtitle,
    this.leading,
    this.stats = const [],
    this.side = const [],
    this.children,
    this.tabs,
    this.banner,
    this.landscape = true,
    super.key,
  });

  final String title;
  final IconData icon;
  final Color accent;
  final String? subtitle;

  /// Remplace la grande icône (blason du club, par exemple).
  final Widget? leading;
  final List<ProStat> stats;

  /// Widgets supplémentaires sous les chiffres clés.
  final List<Widget> side;

  /// Contenu simple, affiché en liste défilante.
  final List<Widget>? children;

  /// Contenu à onglets (prioritaire sur [children]).
  final List<ProTab>? tabs;

  /// Bandeau d'information au-dessus du contenu.
  final Widget? banner;

  /// Force le paysage plein écran.
  final bool landscape;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final page = Scaffold(
      backgroundColor: theme.colorScheme.surface,
      body: LayoutBuilder(
        builder: (context, box) {
          final wide = box.maxWidth > box.maxHeight && box.maxWidth > 560;
          final content = _content(context, wide);
          if (wide) {
            final railW = (box.maxWidth * 0.28).clamp(240.0, 330.0).toDouble();
            return Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(width: railW, child: _Rail(page: this)),
                Expanded(child: SafeArea(left: false, child: content)),
              ],
            );
          }
          return SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _Header(page: this),
                Expanded(child: content),
              ],
            ),
          );
        },
      ),
    );
    final wrapped = tabs == null
        ? page
        : DefaultTabController(length: tabs!.length, child: page);
    return landscape ? LandscapeScope(child: wrapped) : wrapped;
  }

  Widget _content(BuildContext context, bool wide) {
    final theme = Theme.of(context);
    final pad = EdgeInsets.fromLTRB(wide ? 20 : 14, 14, wide ? 20 : 14, 24);
    final Widget main;
    if (tabs != null) {
      main = Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Material(
            color: theme.colorScheme.surfaceContainer,
            child: TabBar(
              isScrollable: true,
              tabAlignment: TabAlignment.start,
              indicatorColor: accent,
              labelColor: Colors.white,
              unselectedLabelColor: Colors.white60,
              dividerColor: Colors.transparent,
              tabs: [
                for (final t in tabs!)
                  Tab(
                    height: 46,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (t.icon != null) ...[
                          Icon(t.icon, size: 18),
                          const SizedBox(width: 6),
                        ],
                        Text(t.label),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(children: [for (final t in tabs!) t.child]),
          ),
        ],
      );
    } else {
      main = ListView(
        padding: pad,
        children: children ?? const [],
      );
    }
    if (banner == null) return main;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [banner!, Expanded(child: main)],
    );
  }
}

class _Rail extends StatelessWidget {
  const _Rail({required this.page});

  final ProPage page;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final accent = page.accent;
    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [_darken(accent, 0.55), _darken(accent, 0.18)],
        ),
        border: const Border(right: BorderSide(color: Colors.white12)),
      ),
      child: SafeArea(
        right: false,
        child: Stack(
          fit: StackFit.expand,
          children: [
            Positioned(
              right: -30,
              bottom: -20,
              child: Icon(page.icon, size: 190, color: Colors.white.withAlpha(14)),
            ),
            ListView(
              padding: const EdgeInsets.fromLTRB(12, 8, 14, 16),
              children: [
                Align(
                  alignment: Alignment.centerLeft,
                  child: IconButton(
                    tooltip: 'Retour',
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: () => Navigator.of(context).maybePop(),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 6),
                  child: Row(
                    children: [
                      page.leading ??
                          Container(
                            width: 46,
                            height: 46,
                            decoration: BoxDecoration(
                              color: accent.withAlpha(70),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: accent.withAlpha(160)),
                            ),
                            child: Icon(page.icon, color: Colors.white),
                          ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              page.title.toUpperCase(),
                              style: theme.textTheme.titleMedium?.copyWith(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 0.8,
                                height: 1.1,
                              ),
                            ),
                            if (page.subtitle != null)
                              Padding(
                                padding: const EdgeInsets.only(top: 3),
                                child: Text(
                                  page.subtitle!,
                                  style: theme.textTheme.bodySmall?.copyWith(
                                    color: Colors.white70,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                if (page.stats.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(left: 6),
                    child: _StatGrid(stats: page.stats, accent: accent),
                  ),
                for (final w in page.side)
                  Padding(
                    padding: const EdgeInsets.only(left: 6, top: 10),
                    child: w,
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _StatGrid extends StatelessWidget {
  const _StatGrid({required this.stats, required this.accent});

  final List<ProStat> stats;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, box) {
        final w = (box.maxWidth - 8) / 2;
        return Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final s in stats)
              SizedBox(width: w, child: _StatTile(stat: s, accent: accent)),
          ],
        );
      },
    );
  }
}

class _StatTile extends StatelessWidget {
  const _StatTile({required this.stat, required this.accent});

  final ProStat stat;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 8, 8, 8),
      decoration: BoxDecoration(
        color: Colors.black.withAlpha(60),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (stat.icon != null) ...[
                Icon(stat.icon, size: 13, color: stat.color ?? accent),
                const SizedBox(width: 4),
              ],
              Expanded(
                child: Text(
                  stat.label.toUpperCase(),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: Colors.white60,
                    letterSpacing: 0.6,
                    fontSize: 10,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 3),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              stat.value,
              style: theme.textTheme.titleMedium?.copyWith(
                color: stat.color ?? Colors.white,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.page});

  final ProPage page;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.fromLTRB(4, 4, 12, 10),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [_darken(page.accent, 0.55), _darken(page.accent, 0.2)],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => Navigator.of(context).maybePop(),
              ),
              if (page.leading != null) ...[page.leading!, const SizedBox(width: 8)],
              Expanded(
                child: Text(
                  page.title,
                  style: theme.textTheme.titleLarge?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          if (page.stats.isNotEmpty)
            SizedBox(
              height: 58,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.only(left: 12),
                children: [
                  for (final s in page.stats)
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: SizedBox(
                        width: 120,
                        child: _StatTile(stat: s, accent: page.accent),
                      ),
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Briques visuelles communes
// ---------------------------------------------------------------------------

/// Carte au style uniforme, avec un titre optionnel.
class ProCard extends StatelessWidget {
  const ProCard({
    required this.child,
    this.title,
    this.icon,
    this.trailing,
    this.accent,
    this.padding = const EdgeInsets.all(14),
    this.onTap,
    this.highlight = false,
    super.key,
  });

  final Widget child;
  final String? title;
  final IconData? icon;
  final Widget? trailing;
  final Color? accent;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  final bool highlight;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color = accent ?? theme.colorScheme.primary;
    final body = Padding(
      padding: padding,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          if (title != null) ...[
            Row(
              children: [
                if (icon != null) ...[
                  Icon(icon, size: 18, color: color),
                  const SizedBox(width: 8),
                ],
                Expanded(
                  child: Text(
                    title!.toUpperCase(),
                    style: theme.textTheme.labelLarge?.copyWith(
                      letterSpacing: 0.8,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                if (trailing != null) trailing!,
              ],
            ),
            const SizedBox(height: 10),
          ],
          child,
        ],
      ),
    );
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Material(
        color: theme.colorScheme.surfaceContainer,
        borderRadius: BorderRadius.circular(16),
        clipBehavior: Clip.antiAlias,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: highlight ? color.withAlpha(200) : Colors.white10,
              width: highlight ? 1.5 : 1,
            ),
            gradient: highlight
                ? LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [color.withAlpha(45), Colors.transparent],
                  )
                : null,
          ),
          child: onTap == null ? body : InkWell(onTap: onTap, child: body),
        ),
      ),
    );
  }
}

/// État vide illustré : grande icône, titre, explication, contenu utile.
class ProEmpty extends StatelessWidget {
  const ProEmpty({
    required this.icon,
    required this.title,
    required this.message,
    this.accent,
    this.action,
    super.key,
  });

  final IconData icon;
  final String title;
  final String message;
  final Color? accent;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color = accent ?? theme.colorScheme.primary;
    return ProCard(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 22),
      child: Row(
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [color.withAlpha(110), color.withAlpha(25)],
              ),
              border: Border.all(color: color.withAlpha(140)),
            ),
            child: Icon(icon, size: 30, color: Colors.white),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 4),
                Text(message, style: theme.textTheme.bodySmall),
                if (action != null) ...[const SizedBox(height: 10), action!],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Titre de section discret, en capitales.
class ProSection extends StatelessWidget {
  const ProSection(this.text, {this.trailing, super.key});

  final String text;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(2, 6, 2, 10),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 16,
            decoration: BoxDecoration(
              color: theme.colorScheme.secondary,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text.toUpperCase(),
              style: theme.textTheme.labelLarge?.copyWith(
                letterSpacing: 1,
                fontWeight: FontWeight.w800,
                color: Colors.white70,
              ),
            ),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

/// Barre de niveau avec libellé et valeur.
class ProMeter extends StatelessWidget {
  const ProMeter({
    required this.label,
    required this.value,
    this.max = 100,
    this.color,
    this.suffix,
    super.key,
  });

  final String label;
  final num value;
  final num max;
  final Color? color;
  final String? suffix;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final ratio = max == 0 ? 0.0 : (value / max).clamp(0.0, 1.0).toDouble();
    final c = color ??
        Color.lerp(const Color(0xFFE53935), const Color(0xFF43A047), ratio)!;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(label, style: theme.textTheme.bodySmall)),
              Text(
                suffix ?? '${value.round()}',
                style: theme.textTheme.labelLarge?.copyWith(color: c),
              ),
            ],
          ),
          const SizedBox(height: 4),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: ratio,
              minHeight: 8,
              color: c,
              backgroundColor: Colors.white10,
            ),
          ),
        ],
      ),
    );
  }
}

/// Petite étiquette colorée.
class ProTag extends StatelessWidget {
  const ProTag(this.text, {this.color, this.icon, super.key});

  final String text;
  final Color? color;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    final c = color ?? Theme.of(context).colorScheme.primary;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: c.withAlpha(40),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: c.withAlpha(120)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 12, color: c),
            const SizedBox(width: 4),
          ],
          Text(
            text,
            style: TextStyle(
              color: c,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

/// Grille responsive : 1, 2 ou 3 colonnes selon la largeur.
class ProGrid extends StatelessWidget {
  const ProGrid({required this.children, this.minWidth = 300, super.key});

  final List<Widget> children;
  final double minWidth;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, box) {
        final cols = (box.maxWidth / minWidth).floor().clamp(1, 3).toInt();
        if (cols == 1) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: children,
          );
        }
        final columns = List.generate(cols, (_) => <Widget>[]);
        for (var i = 0; i < children.length; i++) {
          columns[i % cols].add(children[i]);
        }
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            for (var c = 0; c < cols; c++) ...[
              if (c > 0) const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: columns[c],
                ),
              ),
            ],
          ],
        );
      },
    );
  }
}

/// Mise en page en colonnes pour le paysage : chaque colonne défile
/// indépendamment. Sur un écran étroit, les colonnes s'empilent.
class ProColumns extends StatelessWidget {
  const ProColumns({
    required this.columns,
    this.flex,
    this.padding = const EdgeInsets.fromLTRB(14, 12, 14, 20),
    this.breakpoint = 640,
    super.key,
  });

  final List<List<Widget>> columns;
  final List<int>? flex;
  final EdgeInsets padding;
  final double breakpoint;

  /// Répartit une liste en [count] colonnes de longueur proche, en gardant
  /// l'ordre de lecture (haut de la première colonne d'abord).
  static List<List<Widget>> split(List<Widget> items, int count) {
    final out = List.generate(count, (_) => <Widget>[]);
    if (items.isEmpty) return out;
    final per = (items.length / count).ceil();
    for (var i = 0; i < items.length; i++) {
      out[(i ~/ per).clamp(0, count - 1)].add(items[i]);
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, box) {
        if (box.maxWidth < breakpoint || columns.length == 1) {
          return ListView(
            padding: padding,
            children: [for (final c in columns) ...c],
          );
        }
        return Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            for (var i = 0; i < columns.length; i++) ...[
              if (i > 0)
                const VerticalDivider(width: 1, color: Colors.white10),
              Expanded(
                flex: flex != null && i < flex!.length ? flex![i] : 1,
                child: ListView(
                  padding: EdgeInsets.fromLTRB(
                    i == 0 ? padding.left : 10,
                    padding.top,
                    i == columns.length - 1 ? padding.right : 10,
                    padding.bottom,
                  ),
                  children: columns[i],
                ),
              ),
            ],
          ],
        );
      },
    );
  }
}
