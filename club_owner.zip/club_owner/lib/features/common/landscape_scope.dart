import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Tout le jeu est en paysage plein écran (réglé au démarrage dans
/// `main.dart`). Ce widget réaffirme ce mode à l'ouverture d'un écran, au
/// cas où le système l'aurait modifié (clavier, retour d'une autre app).
class LandscapeScope extends StatefulWidget {
  const LandscapeScope({required this.child, this.immersive = true, super.key});

  final Widget child;
  final bool immersive;

  @override
  State<LandscapeScope> createState() => _LandscapeScopeState();
}

void enforceLandscape() {
  SystemChrome.setPreferredOrientations(const [
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
}

class _LandscapeScopeState extends State<LandscapeScope> {
  @override
  void initState() {
    super.initState();
    enforceLandscape();
  }

  @override
  Widget build(BuildContext context) => widget.child;
}
