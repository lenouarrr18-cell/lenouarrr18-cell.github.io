import 'package:flutter/material.dart';

import '../../domain/entities/owner.dart';

/// Vue 2D modulaire du stade : chaque niveau ajoute des tribunes, un toit
/// puis des projecteurs ; fan zone, parking et boutique apparaissent autour.
class StadiumView extends StatelessWidget {
  const StadiumView({required this.owner, super.key});

  final OwnerState owner;

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1.7,
      child: CustomPaint(
        painter: _StadiumPainter(
          stadium: owner.stadium,
          fanZone: owner.fanZone,
          parking: owner.parking,
          shop: owner.shop,
        ),
      ),
    );
  }
}

class _StadiumPainter extends CustomPainter {
  _StadiumPainter({
    required this.stadium,
    required this.fanZone,
    required this.parking,
    required this.shop,
  });

  final int stadium;
  final int fanZone;
  final int parking;
  final int shop;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(0, 0, w, h),
        const Radius.circular(16),
      ),
      Paint()..color = const Color(0xFFCFE8D5),
    );

    final bounds = Rect.fromLTWH(w * 0.2, h * 0.12, w * 0.6, h * 0.76);
    final inset = bounds.shortestSide * 0.2;
    final pitch = bounds.deflate(inset);
    final standColor = stadium >= 4
        ? const Color(0xFF546E7A)
        : const Color(0xFF90A4AE);
    final stand = Paint()..color = standColor;
    final edge = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    void drawStand(Rect rect) {
      canvas.drawRect(rect, stand);
      canvas.drawRect(rect, edge);
    }

    drawStand(Rect.fromLTRB(bounds.left, pitch.bottom + 4, bounds.right, bounds.bottom));
    if (stadium >= 2) {
      drawStand(Rect.fromLTRB(bounds.left, bounds.top, bounds.right, pitch.top - 4));
    }
    if (stadium >= 3) {
      drawStand(Rect.fromLTRB(bounds.left, pitch.top, pitch.left - 4, pitch.bottom));
      drawStand(Rect.fromLTRB(pitch.right + 4, pitch.top, bounds.right, pitch.bottom));
    }
    if (stadium >= 4) {
      final roof = Paint()..color = const Color(0x55263238);
      canvas.drawRect(
        Rect.fromLTRB(bounds.left, pitch.bottom + 4, bounds.right, bounds.bottom),
        roof,
      );
      canvas.drawRect(
        Rect.fromLTRB(bounds.left, bounds.top, bounds.right, pitch.top - 4),
        roof,
      );
    }
    if (stadium >= 5) {
      final pole = Paint()..color = const Color(0xFF37474F);
      final light = Paint()..color = const Color(0xFFFFEB3B);
      for (final corner in [
        bounds.topLeft,
        bounds.topRight,
        bounds.bottomLeft,
        bounds.bottomRight,
      ]) {
        canvas.drawCircle(corner, 5, pole);
        canvas.drawCircle(corner, 3, light);
      }
    }

    canvas.drawRect(pitch, Paint()..color = const Color(0xFF2E9E57));
    canvas.drawRect(pitch, edge);
    canvas.drawLine(
      Offset(pitch.left, pitch.center.dy),
      Offset(pitch.right, pitch.center.dy),
      edge,
    );
    canvas.drawCircle(pitch.center, pitch.shortestSide * 0.18, edge);

    // Fan zone : des tentes colorées à gauche.
    const tentColors = [
      Color(0xFFE53935),
      Color(0xFFFFB300),
      Color(0xFF1E88E5),
      Color(0xFF8E24AA),
      Color(0xFF43A047),
    ];
    for (var i = 0; i < fanZone; i++) {
      canvas.drawRect(
        Rect.fromLTWH(w * 0.03, h * 0.16 + i * h * 0.13, w * 0.11, h * 0.09),
        Paint()..color = tentColors[i % tentColors.length],
      );
    }

    // Parking : des rangées de voitures à droite.
    final car = Paint()..color = const Color(0xFF455A64);
    for (var i = 0; i < parking * 2; i++) {
      final col = i % 2;
      final row = i ~/ 2;
      canvas.drawRect(
        Rect.fromLTWH(
          w * 0.84 + col * w * 0.07,
          h * 0.36 + row * h * 0.1,
          w * 0.05,
          h * 0.06,
        ),
        car,
      );
    }

    // Boutique : un petit bâtiment en haut à droite.
    if (shop > 0) {
      canvas.drawRect(
        Rect.fromLTWH(w * 0.84, h * 0.06, w * 0.12, h * 0.16),
        Paint()..color = const Color(0xFFFF7043),
      );
      canvas.drawRect(
        Rect.fromLTWH(w * 0.84, h * 0.06, w * 0.12, h * 0.04),
        Paint()..color = const Color(0xFFBF360C),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _StadiumPainter old) {
    return old.stadium != stadium ||
        old.fanZone != fanZone ||
        old.parking != parking ||
        old.shop != shop;
  }
}
