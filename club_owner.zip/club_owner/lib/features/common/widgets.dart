import 'package:flutter/material.dart';

import '../../core/utils/format.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/roles.dart';
import '../../domain/entities/spots.dart';
import '../../engine/finance/finance.dart';
import '../../engine/world/nations.dart';
import 'crest.dart';
import 'labels.dart';

/// Titre de section avec un liseré doré.
class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key});

  final String text;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 8),
      child: Row(
        children: [
          Container(width: 4, height: 18, color: theme.colorScheme.secondary),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text.toUpperCase(),
              style: theme.textTheme.labelLarge,
            ),
          ),
        ],
      ),
    );
  }
}

/// Tuile illustrée du menu principal du club : dégradé, grande icône en
/// filigrane et libellé en capitales.
class MenuTile extends StatelessWidget {
  const MenuTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
    this.badge,
    super.key,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;
  final String? badge;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.all(3),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(14),
        clipBehavior: Clip.antiAlias,
        child: Ink(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [color.withAlpha(235), color.withAlpha(110)],
            ),
            border: Border.all(color: Colors.white12),
          ),
          child: InkWell(
            onTap: onTap,
            child: Stack(
              children: [
                Positioned(
                  right: -10,
                  bottom: -10,
                  child: Icon(icon, size: 84, color: Colors.white12),
                ),
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Icon(icon, color: Colors.white, size: 26),
                          if (badge != null)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 2,
                              ),
                              decoration: BoxDecoration(
                                color: theme.colorScheme.error,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                badge!,
                                style: TextStyle(
                                  color: theme.colorScheme.onError,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                        ],
                      ),
                      const Spacer(),
                      Text(
                        title.toUpperCase(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 13,
                          letterSpacing: 0.8,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 12,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Bandeau d'en-tête : dégradé vert, rayures de pelouse, écusson et titres.
class HeroHeader extends StatelessWidget {
  const HeroHeader({
    required this.crest,
    required this.title,
    required this.subtitle,
    this.chips = const [],
    super.key,
  });

  final Widget crest;
  final String title;
  final String subtitle;
  final List<Widget> chips;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: CustomPaint(
        painter: _StripesPainter(),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(18),
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF1E6B45), Color(0xFF0B2A1B)],
            ),
          ),
          child: Row(
            children: [
              crest,
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title.toUpperCase(),
                      style: theme.textTheme.headlineSmall?.copyWith(
                        color: Colors.white,
                        letterSpacing: 0.8,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: const TextStyle(color: Colors.white70),
                    ),
                    if (chips.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      Wrap(spacing: 6, runSpacing: 6, children: chips),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StripesPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0x12FFFFFF);
    const stripe = 26.0;
    for (var x = 0.0; x < size.width; x += stripe * 2) {
      canvas.drawRect(Rect.fromLTWH(x, 0, stripe, size.height), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Tableau d'affichage d'un match (écussons, score ou « VS »).
class ScoreboardCard extends StatelessWidget {
  const ScoreboardCard({
    required this.label,
    required this.homeName,
    required this.awayName,
    required this.center,
    required this.footer,
    this.action,
    super.key,
  });

  final String label;
  final String homeName;
  final String awayName;
  final String center;
  final String footer;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    Widget team(String name) {
      return Expanded(
        child: Column(
          children: [
            ClubCrest(name: name, size: 42),
            const SizedBox(height: 6),
            Text(
              name,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.titleSmall,
            ),
          ],
        ),
      );
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(
              label.toUpperCase(),
              style: theme.textTheme.labelSmall?.copyWith(
                color: theme.colorScheme.secondary,
              ),
            ),
            const SizedBox(height: 12),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                team(homeName),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Text(
                    center,
                    style: theme.textTheme.headlineMedium,
                  ),
                ),
                team(awayName),
              ],
            ),
            const SizedBox(height: 10),
            Text(footer, style: theme.textTheme.bodySmall),
            if (action != null) action!,
          ],
        ),
      ),
    );
  }
}

/// Pastilles V / N / D de la forme récente.
class FormChips extends StatelessWidget {
  const FormChips({required this.results, super.key});

  /// 1 victoire, 0 nul, -1 défaite (du plus ancien au plus récent).
  final List<int> results;

  @override
  Widget build(BuildContext context) {
    if (results.isEmpty) return const SizedBox.shrink();
    return Row(
      children: [
        for (final r in results)
          Container(
            width: 26,
            height: 26,
            margin: const EdgeInsets.only(right: 6),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: r > 0
                  ? const Color(0xFF2E9E57)
                  : (r == 0 ? const Color(0xFF8D8D8D) : const Color(0xFFC0392B)),
            ),
            child: Text(
              r > 0 ? 'V' : (r == 0 ? 'N' : 'D'),
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 12,
              ),
            ),
          ),
      ],
    );
  }
}

/// Ligne standard d'un joueur : niveau, drapeau, nom, poste, âge, valeur.
class PlayerRow extends StatelessWidget {
  const PlayerRow({
    required this.player,
    this.showPotential = false,
    this.trailing,
    this.onTap,
    this.onLongPress,
    this.highlighted = false,
    this.showMood = false,
    super.key,
  });

  final Player player;
  final bool showPotential;
  final Widget? trailing;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final bool highlighted;
  final bool showMood;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final potential = showPotential
        ? ', potentiel ${player.maxSkill}'
        : '';
    var moodLine = '';
    if (showMood) {
      final out = player.wantsOut ? ' · veut partir' : '';
      moodLine = '\n${moodEmoji(player.mood)} ${moodLabel(player.mood)}$out';
    }
    return ListTile(
      tileColor: highlighted ? theme.colorScheme.primaryContainer : null,
      leading: CircleAvatar(child: Text('${player.skill}')),
      title: Text('${flagOf(player.nation)} ${player.name}'),
      subtitle: Text(
        '${naturalSpot(player).label} · ${player.age} ans$potential\n'
        'Valeur ${formatMoney(playerValue(player))}, '
        'contrat ${player.contractYears} an(s)'
        '$moodLine',
      ),
      isThreeLine: true,
      trailing: trailing,
      onTap: onTap,
      onLongPress: onLongPress,
    );
  }
}

/// Petite pastille d'information.
class InfoChip extends StatelessWidget {
  const InfoChip(this.text, {this.icon, super.key});

  final String text;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    return Chip(
      avatar: icon == null ? null : Icon(icon, size: 16),
      label: Text(text),
      visualDensity: VisualDensity.compact,
    );
  }
}

/// Nombre compact : 1 250 devient 1,3 k, 2 400 000 devient 2,4 M.
String compactNumber(int n) {
  if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)} M';
  if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)} k';
  return '$n';
}
