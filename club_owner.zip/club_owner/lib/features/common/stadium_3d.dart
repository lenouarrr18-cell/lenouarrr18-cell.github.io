import 'dart:math';

import 'package:flutter/material.dart';

import '../../domain/entities/owner.dart';

/// Un point de l'espace (x droite, y haut, z profondeur).
class _V {
  const _V(this.x, this.y, this.z);

  final double x;
  final double y;
  final double z;
}

class _Face {
  _Face(this.pts, this.normal, this.color, {this.base = false, this.bias = 0});

  /// Décalage de profondeur (les spectateurs sont dessinés après leur gradin).
  final double bias;

  /// Sol, pelouse, parking : toujours dessinés avant le reste.
  final bool base;

  final List<_V> pts;
  final _V normal;
  final Color color;
}

/// Construit la scène 3D d'un complexe selon les niveaux d'installations.
class _Scene {
  _Scene(this.owner, this.night) {
    _build();
  }

  final OwnerState owner;
  final bool night;
  final List<_Face> faces = [];
  final List<_V> lamps = [];

  void _box(
    double x0,
    double y0,
    double z0,
    double x1,
    double y1,
    double z1,
    Color color,
  ) {
    _V v(double x, double y, double z) => _V(x, y, z);
    faces.add(_Face(
      [v(x0, y1, z0), v(x1, y1, z0), v(x1, y1, z1), v(x0, y1, z1)],
      const _V(0, 1, 0),
      color,
    ));
    faces.add(_Face(
      [v(x0, y0, z1), v(x1, y0, z1), v(x1, y1, z1), v(x0, y1, z1)],
      const _V(0, 0, 1),
      color,
    ));
    faces.add(_Face(
      [v(x0, y0, z0), v(x1, y0, z0), v(x1, y1, z0), v(x0, y1, z0)],
      const _V(0, 0, -1),
      color,
    ));
    faces.add(_Face(
      [v(x0, y0, z0), v(x0, y0, z1), v(x0, y1, z1), v(x0, y1, z0)],
      const _V(-1, 0, 0),
      color,
    ));
    faces.add(_Face(
      [v(x1, y0, z0), v(x1, y0, z1), v(x1, y1, z1), v(x1, y1, z0)],
      const _V(1, 0, 0),
      color,
    ));
  }

  void _dot(double x, double z, double y, Color c) {
    faces.add(_Face(
      [
        _V(x - 0.22, y, z - 0.22),
        _V(x + 0.22, y, z - 0.22),
        _V(x + 0.22, y, z + 0.22),
        _V(x - 0.22, y, z + 0.22),
      ],
      const _V(0, 1, 0),
      c,
      bias: 1.0,
    ));
  }

  void _crowd(double xa, double xb, double za, double zb, double y) {
    final r = Random((xa * 13 + za * 7 + y * 31).round());
    final palette = [
      const Color(0xFFE53935),
      const Color(0xFF1E88E5),
      const Color(0xFFFFFFFF),
      const Color(0xFFFFEB3B),
      const Color(0xFF43A047),
    ];
    for (var x = xa + 0.4; x < xb - 0.2; x += 0.9) {
      for (var z = za + 0.3; z < zb - 0.2; z += 0.9) {
        if (r.nextDouble() < 0.78) {
          _dot(x, z, y + 0.02, palette[r.nextInt(palette.length)]);
        }
      }
    }
  }

  void _quad(double x0, double z0, double x1, double z1, double y, Color c) {
    faces.add(_Face(
      [_V(x0, y, z0), _V(x1, y, z0), _V(x1, y, z1), _V(x0, y, z1)],
      const _V(0, 1, 0),
      c,
      base: true,
    ));
  }

  /// Tribune en gradins le long de l'axe x (nord/sud).
  void _standZ(double x0, double x1, double zInner, double dir, int tiers,
      double height, Color color) {
    const w = 1.6;
    for (var i = 0; i < tiers; i++) {
      final a = zInner + dir * i * w;
      final b = zInner + dir * (i + 1) * w;
      _box(x0, 0, min(a, b), x1, height * (i + 1) / tiers, max(a, b), color);
      _crowd(x0, x1, min(a, b), max(a, b), height * (i + 1) / tiers);
    }
  }

  /// Tribune en gradins le long de l'axe z (est/ouest).
  void _standX(double z0, double z1, double xInner, double dir, int tiers,
      double height, Color color) {
    const w = 1.6;
    for (var i = 0; i < tiers; i++) {
      final a = xInner + dir * i * w;
      final b = xInner + dir * (i + 1) * w;
      _box(min(a, b), 0, z0, max(a, b), height * (i + 1) / tiers, z1, color);
      _crowd(min(a, b), max(a, b), z0, z1, height * (i + 1) / tiers);
    }
  }

  void _tower(double x, double z) {
    _box(x - 0.2, 0, z - 0.2, x + 0.2, 9, z + 0.2, const Color(0xFF9E9E9E));
    _box(x - 0.9, 9, z - 0.3, x + 0.9, 9.5, z + 0.3, const Color(0xFFFFF59D));
    lamps.add(_V(x, 9.6, z));
  }

  void _build() {
    final level = owner.stadium.clamp(1, 5).toInt();
    final concrete = const Color(0xFFB0B7BD);
    final seats = HSLColor.fromAHSL(1, 210 + level * 8.0, 0.55, 0.45).toColor();
    final seats2 = HSLColor.fromAHSL(1, 20 + level * 8.0, 0.65, 0.5).toColor();

    // Sol et pelouse.
    _quad(-40, -34, 40, 34, 0,
        night ? const Color(0xFF1B3A1F) : const Color(0xFF7CB342));
    // Esplanade autour du stade.
    _quad(-22, -20, 22, 20, 0.02,
        night ? const Color(0xFF37474F) : const Color(0xFFCFD8DC));
    // Bordure de la pelouse.
    _quad(-12, -8.2, 12, 8.2, 0.04,
        night ? const Color(0xFF1B5E20) : const Color(0xFF2E7D32));
    // Arbres autour du complexe.
    final tr = Random(3);
    for (var i = 0; i < 14; i++) {
      final tx = -36 + tr.nextDouble() * 72;
      final tz = tr.nextBool() ? -33 + tr.nextDouble() * 6 : 28 + tr.nextDouble() * 5;
      _box(tx - 0.15, 0, tz - 0.15, tx + 0.15, 1.2, tz + 0.15,
          const Color(0xFF6D4C41));
      _box(tx - 0.9, 1.2, tz - 0.9, tx + 0.9, 3.0, tz + 0.9,
          const Color(0xFF2E7D32));
    }
    for (var i = 0; i < 8; i++) {
      final x0 = -10.5 + i * 21 / 8;
      _quad(
        x0,
        -6.8,
        x0 + 21 / 8,
        6.8,
        0.05,
        i.isEven
            ? (night ? const Color(0xFF2E7D32) : const Color(0xFF43A047))
            : (night ? const Color(0xFF1B5E20) : const Color(0xFF388E3C)),
      );
    }
    const line = Color(0xFFFFFFFF);
    _quad(-10.5, -6.8, 10.5, -6.65, 0.08, line);
    _quad(-10.5, 6.65, 10.5, 6.8, 0.08, line);
    _quad(-10.5, -6.8, -10.35, 6.8, 0.08, line);
    _quad(10.35, -6.8, 10.5, 6.8, 0.08, line);
    _quad(-0.08, -6.8, 0.08, 6.8, 0.08, line);
    // Panneaux publicitaires le long des lignes.
    for (var i = 0; i < 10; i++) {
      final bx = -10.0 + i * 2.1;
      final c = i.isEven ? const Color(0xFFD32F2F) : const Color(0xFFFFFFFF);
      _box(bx, 0, -7.3, bx + 2.0, 0.5, -7.1, c);
      _box(bx, 0, 7.1, bx + 2.0, 0.5, 7.3, c);
    }
    // Cages.
    for (final gx in [-10.9, 10.4]) {
      _box(gx, 0, -1.6, gx + 0.5, 1.2, 1.6, const Color(0xFFF5F5F5));
    }

    // Tribunes selon le niveau du stade.
    final tiers = level >= 5 ? 4 : (level >= 3 ? 3 : 2);
    final h = 1.5 + level * 0.9;
    _standZ(-12, 12, 8, 1, tiers, h, level.isEven ? seats : seats2);
    if (level >= 2) {
      _standZ(-12, 12, -8, -1, tiers, h, level.isEven ? seats2 : seats);
    }
    if (level >= 3) {
      _standX(-8, 8, 12, 1, tiers, h * 0.9, seats);
      _standX(-8, 8, -12, -1, tiers, h * 0.9, seats);
    }
    if (level >= 5) {
      for (final sx in [-1.0, 1.0]) {
        for (final sz in [-1.0, 1.0]) {
          _box(
            sx > 0 ? 12 : -17,
            0,
            sz > 0 ? 8 : -13,
            sx > 0 ? 17 : -12,
            h * 0.8,
            sz > 0 ? 13 : -8,
            concrete,
          );
        }
      }
    }
    // Façade extérieure (murs).
    _box(-12, 0, 8 + tiers * 1.6, 12, h + 0.6, 8 + tiers * 1.6 + 0.3, concrete);

    // Toits.
    if (level >= 4) {
      final top = h + 2.2;
      _box(-12, top, 8, 12, top + 0.3, 8 + tiers * 1.6, const Color(0xFFECEFF1));
      _box(-12, top, -8 - tiers * 1.6, 12, top + 0.3, -8, const Color(0xFFECEFF1));
    }
    if (level >= 5) {
      final top = h * 0.9 + 2.2;
      _box(12, top, -8, 12 + tiers * 1.6, top + 0.3, 8, const Color(0xFFECEFF1));
      _box(-12 - tiers * 1.6, top, -8, -12, top + 0.3, 8, const Color(0xFFECEFF1));
    }

    // Loges VIP : cabines dorées en haut de la tribune nord.
    if (owner.vip > 0 && level >= 2) {
      final count = owner.vip * 2;
      final zBase = -8 - (tiers - 1) * 1.6 - 0.2;
      final top = h;
      for (var i = 0; i < count; i++) {
        final x = -9.0 + i * (18.0 / max(1, count - 1));
        _box(x - 0.7, top, zBase - 1.2, x + 0.7, top + 0.9, zBase,
            const Color(0xFFFFC107));
      }
    }

    // Tunnel des joueurs et tableau d'affichage.
    _box(-1.2, 0, 7.4, 1.2, 1.0, 8.2, const Color(0xFF263238));
    if (level >= 3) {
      _box(-3, h * 0.9 + 0.3, -13.5 - tiers * 0.2, 3, h * 0.9 + 2.3,
          -13.2 - tiers * 0.2, const Color(0xFF212121));
      _box(-2.8, h * 0.9 + 0.5, -13.55 - tiers * 0.2, 2.8, h * 0.9 + 2.1,
          -13.5 - tiers * 0.2, const Color(0xFF29B6F6));
    }

    // Projecteurs.
    if (level >= 3) {
      _tower(-14, -10);
      _tower(14, 10);
    }
    if (level >= 4) {
      _tower(14, -10);
      _tower(-14, 10);
    }

    // Fan zone : tentes et écran géant.
    if (owner.fanZone > 0) {
      final n = owner.fanZone * 2;
      for (var i = 0; i < n; i++) {
        final z = -6 + i * (12.0 / max(1, n - 1));
        final c = i.isEven ? const Color(0xFFE53935) : const Color(0xFF1E88E5);
        _box(22, 0, z - 0.8, 23.6, 1.1, z + 0.8, c);
      }
      if (owner.fanZone >= 3) {
        _box(26, 0, -0.1, 26.3, 3.4, 4.1, const Color(0xFF212121));
        _box(25.9, 1.4, 0, 26.0, 3.2, 4, const Color(0xFF4FC3F7));
      }
    }

    // Parking.
    if (owner.parking > 0) {
      _quad(-16, 17, 16, 27, 0.04, const Color(0xFF455A64));
      final r = Random(7);
      final cars = owner.parking * 4;
      for (var i = 0; i < cars; i++) {
        final x = -14 + (i % 8) * 3.8;
        final z = 18.5 + (i ~/ 8) * 3.0;
        final c = HSLColor.fromAHSL(1, r.nextDouble() * 360, 0.7, 0.5).toColor();
        _box(x, 0, z, x + 1.6, 0.6, z + 0.8, c);
      }
    }

    // Boutique officielle.
    if (owner.shop > 0) {
      final hh = 1.5 + owner.shop * 0.5;
      _box(-26, 0, -4, -20, hh, 2, const Color(0xFFFDD835));
      _box(-26.1, hh, -4.1, -19.9, hh + 0.3, 2.1, const Color(0xFFF57F17));
    }
  }
}

/// Vue 3D du complexe : glissez pour tourner, pincez pour zoomer.
/// Rendu logiciel (projection en perspective, tri des faces, ombrage).
class Stadium3DView extends StatefulWidget {
  const Stadium3DView({required this.owner, super.key});

  final OwnerState owner;

  @override
  State<Stadium3DView> createState() => _Stadium3DViewState();
}

class _Stadium3DViewState extends State<Stadium3DView> {
  double _yaw = 0.7;
  double _pitch = 0.75;
  double _zoom = 1.0;
  double _startZoom = 1.0;
  bool _night = false;
  String _cacheKey = '';
  _Scene? _cache;

  @override
  Widget build(BuildContext context) {
    final o = widget.owner;
    final key = '${o.stadium}-${o.fanZone}-${o.parking}-${o.shop}-${o.vip}-$_night';
    if (key != _cacheKey) {
      _cacheKey = key;
      _cache = _Scene(o, _night);
    }
    final scene = _cache!;
    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: GestureDetector(
            onScaleStart: (_) => _startZoom = _zoom,
            onScaleUpdate: (d) {
              setState(() {
                _yaw += d.focalPointDelta.dx * 0.01;
                _pitch = (_pitch - d.focalPointDelta.dy * 0.006)
                    .clamp(0.25, 1.35)
                    .toDouble();
                if (d.scale != 1.0) {
                  _zoom = (_startZoom * d.scale).clamp(0.6, 2.4).toDouble();
                }
              });
            },
            child: AspectRatio(
              aspectRatio: 1.25,
              child: CustomPaint(
                painter: _Painter(
                  scene: scene,
                  yaw: _yaw,
                  pitch: _pitch,
                  zoom: _zoom,
                  night: _night,
                ),
              ),
            ),
          ),
        ),
        Row(
          children: [
            const Expanded(
              child: Text(
                'Glissez pour tourner, pincez pour zoomer.',
                style: TextStyle(fontSize: 12),
              ),
            ),
            const Icon(Icons.wb_sunny_outlined, size: 18),
            Switch(
              value: _night,
              onChanged: (v) => setState(() => _night = v),
            ),
            const Icon(Icons.nightlight_outlined, size: 18),
          ],
        ),
      ],
    );
  }
}

class _Painter extends CustomPainter {
  _Painter({
    required this.scene,
    required this.yaw,
    required this.pitch,
    required this.zoom,
    required this.night,
  });

  final _Scene scene;
  final double yaw;
  final double pitch;
  final double zoom;
  final bool night;

  static const double _camDist = 62;

  _V _rot(_V p) {
    final cy = cos(yaw);
    final sy = sin(yaw);
    final x1 = p.x * cy - p.z * sy;
    final z1 = p.x * sy + p.z * cy;
    final cp = cos(pitch);
    final sp = sin(pitch);
    final y2 = p.y * cp + z1 * sp;
    final z2 = z1 * cp - p.y * sp;
    return _V(x1, y2, z2);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final sky = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: night
            ? const [Color(0xFF0B1026), Color(0xFF1A237E)]
            : const [Color(0xFF81D4FA), Color(0xFFE1F5FE)],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, sky);

    final focal = size.width * 0.95 * zoom;
    final cx = size.width / 2;
    final cy = size.height * 0.58;

    Offset project(_V t) {
      final depth = t.z + _camDist;
      final s = focal / max(1.0, depth) * 1.0;
      return Offset(cx + t.x * s * 0.9, cy - t.y * s * 0.9);
    }

    const light = _V(0.4, 0.8, -0.45);
    final drawn = <_Projected>[];
    final ground = <_Projected>[];
    for (final face in scene.faces) {
      final pts = [for (final p in face.pts) _rot(p)];
      final n = _rot(face.normal);
      // Rotation du vecteur normal : on retire la translation (aucune ici).
      final cam = const _V(0, 0, -_camDist);
      final mid = pts.first;
      final facing = n.x * (cam.x - mid.x) +
          n.y * (cam.y - mid.y) +
          n.z * (cam.z - mid.z);
      if (facing <= 0) continue;
      var depth = 0.0;
      for (final p in pts) {
        depth += p.z;
      }
      depth = depth / pts.length - face.bias;
      final ln = _rot(light);
      final lum = (0.55 +
              0.45 * max(0.0, -(n.x * ln.x + n.y * ln.y + n.z * ln.z)))
          .clamp(0.0, 1.0)
          .toDouble();
      final k = night ? lum * 0.75 : lum;
      final c = face.color;
      final color = Color.fromARGB(
        255,
        (c.red * k).round().clamp(0, 255).toInt(),
        (c.green * k).round().clamp(0, 255).toInt(),
        (c.blue * k).round().clamp(0, 255).toInt(),
      );
      final item =
          _Projected([for (final p in pts) project(p)], depth, color);
      if (face.base) {
        ground.add(item);
      } else {
        drawn.add(item);
      }
    }
    drawn.sort((a, b) => b.depth.compareTo(a.depth));
    for (final f in [...ground, ...drawn]) {
      final path = Path()..moveTo(f.pts.first.dx, f.pts.first.dy);
      for (final p in f.pts.skip(1)) {
        path.lineTo(p.dx, p.dy);
      }
      path.close();
      canvas.drawPath(path, Paint()..color = f.color);
    }

    if (night) {
      for (final lamp in scene.lamps) {
        final t = _rot(lamp);
        if (t.z + _camDist < 1) continue;
        final o = project(t);
        canvas.drawCircle(
          o,
          18,
          Paint()
            ..shader = RadialGradient(
              colors: [
                const Color(0xCCFFF59D),
                const Color(0x00FFF59D),
              ],
            ).createShader(Rect.fromCircle(center: o, radius: 18)),
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant _Painter old) => true;
}

class _Projected {
  _Projected(this.pts, this.depth, this.color);

  final List<Offset> pts;
  final double depth;
  final Color color;
}
