import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../game/game_state.dart';

/// Conseil du président affiché à la première visite d'une page.
class TipBanner extends ConsumerWidget {
  const TipBanner({required this.id, required this.text, super.key});

  final String id;
  final String text;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();
    if (!game.owner.tipsEnabled || game.owner.seenTips.contains(id)) {
      return const SizedBox.shrink();
    }
    final notifier = ref.read(gameProvider.notifier);
    final theme = Theme.of(context);
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      color: theme.colorScheme.secondaryContainer,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.lightbulb_outline, size: 18),
                const SizedBox(width: 6),
                Text(
                  'Conseil du président',
                  style: theme.textTheme.titleSmall,
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(text),
            Align(
              alignment: Alignment.centerRight,
              child: Wrap(
                spacing: 4,
                children: [
                  TextButton(
                    onPressed: () => notifier.setTipsEnabled(false),
                    child: const Text('Désactiver les aides'),
                  ),
                  FilledButton(
                    onPressed: () => notifier.seeTip(id),
                    child: const Text('Compris'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
