import '../../domain/entities/division.dart';
import '../../domain/entities/owner.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/staff.dart';
import '../../domain/entities/transfer.dart';
import '../../engine/owner/infrastructure.dart';

String positionLabel(PlayerPosition position) {
  switch (position) {
    case PlayerPosition.goalkeeper:
      return 'Gardien';
    case PlayerPosition.defender:
      return 'Défenseur';
    case PlayerPosition.midfielder:
      return 'Milieu';
    case PlayerPosition.forward:
      return 'Attaquant';
  }
}

String positionPlural(PlayerPosition position) {
  switch (position) {
    case PlayerPosition.goalkeeper:
      return 'Gardiens';
    case PlayerPosition.defender:
      return 'Défenseurs';
    case PlayerPosition.midfielder:
      return 'Milieux';
    case PlayerPosition.forward:
      return 'Attaquants';
  }
}

String outcomeLabel(SeasonOutcome outcome) {
  switch (outcome) {
    case SeasonOutcome.promoted:
      return 'Montée';
    case SeasonOutcome.relegated:
      return 'Descente';
    case SeasonOutcome.stayed:
      return 'Maintien';
  }
}

String staffRoleLabel(StaffRole role) {
  switch (role) {
    case StaffRole.manager:
      return 'Manager';
    case StaffRole.sportingDirector:
      return 'Directeur sportif';
    case StaffRole.scout:
      return 'Recruteur';
    case StaffRole.coachFirst:
      return 'Coach équipe première';
    case StaffRole.coachReserve:
      return 'Coach équipe réserve';
    case StaffRole.coachAcademy:
      return 'Coach centre de formation';
    case StaffRole.communityManager:
      return 'Community manager';
  }
}

String infraKindLabel(InfraKind kind) => infraLabel(kind);

String offerKindLabel(OfferKind kind) {
  switch (kind) {
    case OfferKind.transfer:
      return 'Transfert';
    case OfferKind.loan:
      return 'Prêt';
    case OfferKind.loanOption:
      return "Prêt avec option d'achat";
  }
}

String offerStatusLabel(OfferStatus status) {
  switch (status) {
    case OfferStatus.pending:
      return 'En attente';
    case OfferStatus.accepted:
      return 'Acceptée';
    case OfferStatus.countered:
      return 'Contre-proposition';
    case OfferStatus.rejected:
      return 'Refusée';
  }
}
