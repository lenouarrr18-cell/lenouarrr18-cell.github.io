import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/utils/format.dart';
import '../../domain/entities/owner.dart';
import '../../engine/finance/finance.dart';
import '../../engine/game/game_state.dart';
import '../../engine/game/owner_actions.dart';
import '../../engine/owner/infrastructure.dart';
import '../common/landscape_scope.dart';
import '../game/game_state.dart';
import 'campus_view.dart';

IconData infraIcon(InfraKind kind) {
  switch (kind) {
    case InfraKind.stadium:
      return Icons.stadium_outlined;
    case InfraKind.training:
      return Icons.fitness_center;
    case InfraKind.academy:
      return Icons.school_outlined;
    case InfraKind.fanZone:
      return Icons.celebration_outlined;
    case InfraKind.parking:
      return Icons.local_parking;
    case InfraKind.shop:
      return Icons.storefront_outlined;
    case InfraKind.medical:
      return Icons.medical_services_outlined;
    case InfraKind.recruitment:
      return Icons.travel_explore;
    case InfraKind.vip:
      return Icons.workspace_premium_outlined;
    case InfraKind.youth:
      return Icons.groups_outlined;
    case InfraKind.rehab:
      return Icons.healing;
    case InfraKind.fitness:
      return Icons.directions_run;
    case InfraKind.analysis:
      return Icons.analytics_outlined;
    case InfraKind.complex:
      return Icons.sports_soccer;
    case InfraKind.pitch:
      return Icons.grass;
    case InfraKind.lighting:
      return Icons.lightbulb_outline;
    case InfraKind.screens:
      return Icons.tv;
    case InfraKind.roof:
      return Icons.roofing;
    case InfraKind.restaurant:
      return Icons.restaurant;
    case InfraKind.boxes:
      return Icons.event_seat;
    case InfraKind.ads:
      return Icons.campaign_outlined;
    case InfraKind.museum:
      return Icons.museum_outlined;
    case InfraKind.mall:
      return Icons.local_mall_outlined;
    case InfraKind.partners:
      return Icons.business_center_outlined;
    case InfraKind.hq:
      return Icons.apartment;
    case InfraKind.conference:
      return Icons.meeting_room_outlined;
    case InfraKind.hrCenter:
      return Icons.badge_outlined;
    case InfraKind.operations:
      return Icons.settings_suggest_outlined;
    case InfraKind.commercial:
      return Icons.trending_up;
  }
}

enum _Tab { detail, works, accounts, history }

String _tabLabel(_Tab t) {
  switch (t) {
    case _Tab.detail:
      return 'Détail';
    case _Tab.works:
      return 'Chantiers';
    case _Tab.accounts:
      return 'Comptes';
    case _Tab.history:
      return 'Historique';
  }
}

class InfrastructurePage extends ConsumerStatefulWidget {
  const InfrastructurePage({super.key});

  @override
  ConsumerState<InfrastructurePage> createState() => _InfrastructurePageState();
}

class _InfrastructurePageState extends ConsumerState<InfrastructurePage> {
  final TransformationController _controller = TransformationController();
  InfraKind? _selected;
  _Tab? _tab;
  CampusMood _mood = CampusMood.day;
  Size _viewport = Size.zero;
  bool _fitted = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _fit(Size viewport) {
    // Remplit tout l'écran : la scène couvre la largeur et la hauteur.
    final s = [viewport.width / 1250, viewport.height / 760]
        .reduce((a, b) => a > b ? a : b)
        .clamp(0.3, 1.6)
        .toDouble();
    const cx = 700.0;
    const cy = 480.0;
    _controller.value = Matrix4(
      s, 0, 0, 0, //
      0, s, 0, 0, //
      0, 0, 1, 0, //
      viewport.width / 2 - s * cx, viewport.height / 2 - s * cy, 0, 1,
    );
  }

  void _zoomBy(double factor) {
    final m = _controller.value;
    final s0 = m.getMaxScaleOnAxis();
    final s = (s0 * factor).clamp(0.3, 3.5).toDouble();
    final f = s / s0;
    final c = Offset(_viewport.width / 2, _viewport.height / 2);
    final tx = c.dx - f * (c.dx - m.storage[12]);
    final ty = c.dy - f * (c.dy - m.storage[13]);
    _controller.value = Matrix4(
      s, 0, 0, 0, //
      0, s, 0, 0, //
      0, 0, 1, 0, //
      tx, ty, 0, 1,
    );
  }

  void _focus(InfraKind kind) {
    final a = campusAnchor(kind);
    const s = 1.4;
    _controller.value = Matrix4(
      s, 0, 0, 0, //
      0, s, 0, 0, //
      0, 0, 1, 0, //
      _viewport.width * 0.32 - s * a.dx, _viewport.height / 2 - s * a.dy, 0, 1,
    );
  }

  void _select(InfraKind? kind) {
    setState(() {
      _selected = kind;
      if (kind != null) {
        _tab = _Tab.detail;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();
    final owner = game.owner;
    final theme = Theme.of(context);
    final name = owner.stadiumName.isEmpty ? 'Stade du club' : owner.stadiumName;

    return LandscapeScope(
      child: Scaffold(
        backgroundColor: const Color(0xFF2F6B45),
        body: SafeArea(
          left: false,
          right: false,
          top: false,
          bottom: false,
          child: LayoutBuilder(
            builder: (context, box) {
              final landscape = box.maxWidth > box.maxHeight;
              final panelOpen = _tab != null;
              final panelW = landscape ? (box.maxWidth * 0.42).clamp(300.0, 400.0).toDouble() : box.maxWidth;
              final mapW = landscape && panelOpen ? box.maxWidth - panelW : box.maxWidth;
              final mapH = !landscape && panelOpen ? box.maxHeight * 0.45 : box.maxHeight;
              final newViewport = Size(mapW, mapH);
              if (!_fitted && newViewport.width > 0) {
                _fitted = true;
                _viewport = newViewport;
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (mounted) _fit(newViewport);
                });
              }
              _viewport = newViewport;

              Widget panel() {
                return Material(
                  color: theme.colorScheme.surface,
                  elevation: 6,
                  child: _Panel(
                    tab: _tab!,
                    selected: _selected,
                    game: game,
                    onTab: (t) => setState(() => _tab = t),
                    onClose: () => setState(() => _tab = null),
                    onPick: (k) {
                      _select(k);
                      _focus(k);
                    },
                  ),
                );
              }

              return Stack(
                children: [
                  Positioned(
                    left: 0,
                    top: 0,
                    width: mapW,
                    height: mapH,
                    child: ClipRect(
                      child: CampusView(
                        owner: owner,
                        selected: _selected,
                        mood: _mood,
                        controller: _controller,
                        onSelect: _select,
                      ),
                    ),
                  ),
                  // En-tête : retour, nom du stade, trésorerie, personnel.
                  Positioned(
                    left: 8 + MediaQuery.paddingOf(context).left,
                    top: 8,
                    child: _Hud(
                      name: name,
                      treasury: game.finance.treasury,
                      employees: infraEmployees(owner),
                      capacity: staffCapacity(owner),
                      works: owner.works.length,
                      maxWorks: maxConcurrentWorks(owner),
                    ),
                  ),
                  // Zoom, ambiance et onglets.
                  Positioned(
                    left: 8 + MediaQuery.paddingOf(context).left,
                    bottom: 8,
                    child: _Controls(
                      mood: _mood,
                      tab: _tab,
                      works: owner.works.length,
                      onZoomIn: () => _zoomBy(1.35),
                      onZoomOut: () => _zoomBy(1 / 1.35),
                      onFit: () => _fit(_viewport),
                      onMood: () => setState(() {
                        _mood = CampusMood.values[
                            (_mood.index + 1) % CampusMood.values.length];
                      }),
                      onTab: (t) => setState(() => _tab = _tab == t ? null : t),
                    ),
                  ),
                  if (panelOpen && landscape)
                    Positioned(
                      right: 0,
                      top: 0,
                      bottom: 0,
                      width: panelW,
                      child: panel(),
                    ),
                  if (panelOpen && !landscape)
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      height: box.maxHeight - mapH,
                      child: panel(),
                    ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class _Hud extends StatelessWidget {
  const _Hud({
    required this.name,
    required this.treasury,
    required this.employees,
    required this.capacity,
    required this.works,
    required this.maxWorks,
  });

  final String name;
  final int treasury;
  final int employees;
  final int capacity;
  final int works;
  final int maxWorks;

  @override
  Widget build(BuildContext context) {
    const style = TextStyle(color: Colors.white, fontSize: 12);
    return Container(
      padding: const EdgeInsets.fromLTRB(4, 4, 12, 4),
      decoration: BoxDecoration(
        color: const Color(0xCC102027),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            tooltip: 'Retour',
            visualDensity: VisualDensity.compact,
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.of(context).maybePop(),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                name,
                style: style.copyWith(fontWeight: FontWeight.w700, fontSize: 14),
              ),
              Text('Trésorerie : ${formatMoney(treasury)}', style: style),
              Text(
                'Personnel $employees/$capacity · Chantiers $works/$maxWorks',
                style: style.copyWith(
                  color: employees > capacity
                      ? const Color(0xFFFF8A80)
                      : Colors.white70,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Controls extends StatelessWidget {
  const _Controls({
    required this.mood,
    required this.tab,
    required this.works,
    required this.onZoomIn,
    required this.onZoomOut,
    required this.onFit,
    required this.onMood,
    required this.onTab,
  });

  final CampusMood mood;
  final _Tab? tab;
  final int works;
  final VoidCallback onZoomIn;
  final VoidCallback onZoomOut;
  final VoidCallback onFit;
  final VoidCallback onMood;
  final ValueChanged<_Tab> onTab;

  @override
  Widget build(BuildContext context) {
    Widget round(IconData icon, String tip, VoidCallback f) {
      return Padding(
        padding: const EdgeInsets.only(right: 6),
        child: Material(
          color: const Color(0xCC102027),
          shape: const CircleBorder(),
          child: IconButton(
            tooltip: tip,
            visualDensity: VisualDensity.compact,
            icon: Icon(icon, color: Colors.white, size: 20),
            onPressed: f,
          ),
        ),
      );
    }

    Widget chip(_Tab t, IconData icon, String label) {
      final on = tab == t;
      return Padding(
        padding: const EdgeInsets.only(right: 6),
        child: ActionChip(
          avatar: Icon(icon, size: 16, color: on ? Colors.black : Colors.white),
          label: Text(
            label,
            style: TextStyle(color: on ? Colors.black : Colors.white, fontSize: 12),
          ),
          backgroundColor: on ? const Color(0xFFFFEB3B) : const Color(0xCC102027),
          side: BorderSide.none,
          onPressed: () => onTab(t),
        ),
      );
    }

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        round(Icons.add, 'Zoom avant', onZoomIn),
        round(Icons.remove, 'Zoom arrière', onZoomOut),
        round(Icons.center_focus_strong, 'Vue générale', onFit),
        round(
          mood == CampusMood.day
              ? Icons.wb_sunny
              : mood == CampusMood.night
                  ? Icons.nightlight_round
                  : Icons.grain,
          'Ambiance : ${campusMoodLabel(mood)}',
          onMood,
        ),
        chip(_Tab.works, Icons.construction, 'Chantiers ($works)'),
        chip(_Tab.accounts, Icons.account_balance_wallet_outlined, 'Comptes'),
        chip(_Tab.history, Icons.history, 'Historique'),
      ],
    );
  }
}

class _Panel extends StatelessWidget {
  const _Panel({
    required this.tab,
    required this.selected,
    required this.game,
    required this.onTab,
    required this.onClose,
    required this.onPick,
  });

  final _Tab tab;
  final InfraKind? selected;
  final GameState game;
  final ValueChanged<_Tab> onTab;
  final VoidCallback onClose;
  final ValueChanged<InfraKind> onPick;

  @override
  Widget build(BuildContext context) {
    final Widget body;
    switch (tab) {
      case _Tab.detail:
        body = selected == null
            ? const Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'Touchez un bâtiment du plan pour le gérer. Sur le stade, '
                  'touchez la pelouse, les projecteurs, les écrans ou le '
                  'toit pour améliorer chaque partie.',
                ),
              )
            : _DetailTab(game: game, kind: selected!);
      case _Tab.works:
        body = _WorksTab(game: game, onPick: onPick);
      case _Tab.accounts:
        body = _AccountsTab(game: game);
      case _Tab.history:
        body = _HistoryTab(game: game);
    }
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(8, 6, 4, 0),
          child: Row(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      for (final t in _Tab.values)
                        Padding(
                          padding: const EdgeInsets.only(right: 6),
                          child: ChoiceChip(
                            label: Text(_tabLabel(t)),
                            selected: tab == t,
                            onSelected: (_) => onTab(t),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
              IconButton(
                tooltip: 'Fermer',
                icon: const Icon(Icons.close),
                onPressed: onClose,
              ),
            ],
          ),
        ),
        const Divider(height: 1),
        Expanded(child: SingleChildScrollView(child: body)),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Détail d'un bâtiment
// ---------------------------------------------------------------------------

class _DetailTab extends ConsumerWidget {
  const _DetailTab({required this.game, required this.kind});

  final GameState game;
  final InfraKind kind;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final owner = game.owner;
    final spec = infraCatalog[kind]!;
    final level = owner.levelOf(kind);
    final atMax = level >= maxInfraLevel;
    final next = level + 1;
    InfraWork? work;
    for (final w in owner.works) {
      if (w.kind == kind) work = w;
    }
    final blockers = infraBlockers(owner, kind);
    final error = game.validateUpgrade(kind);
    final isPart = kind != InfraKind.stadium && stadiumParts.contains(kind);

    Widget row(String label, String now, String after) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 74,
              child: Text(label, style: theme.textTheme.bodySmall),
            ),
            Expanded(child: Text(now, style: theme.textTheme.bodySmall)),
            if (!atMax) ...[
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 4),
                child: Icon(Icons.arrow_forward, size: 14),
              ),
              Expanded(
                child: Text(
                  after,
                  style: theme.textTheme.bodySmall?.copyWith(
                    fontWeight: FontWeight.w700,
                    color: theme.colorScheme.primary,
                  ),
                ),
              ),
            ],
          ],
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(infraIcon(kind)),
              const SizedBox(width: 8),
              Expanded(
                child: Text(spec.label, style: theme.textTheme.titleMedium),
              ),
              Chip(
                label: Text(infraCategoryLabel(spec.category)),
                visualDensity: VisualDensity.compact,
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            'Niveau $level sur $maxInfraLevel · ${infraLevelName(kind, level)}',
            style: theme.textTheme.bodyMedium,
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              for (var i = 1; i <= maxInfraLevel; i++)
                Expanded(
                  child: Container(
                    height: 8,
                    margin: const EdgeInsets.only(right: 3),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(4),
                      color: i <= level
                          ? theme.colorScheme.primary
                          : (work != null && i == work.targetLevel
                              ? Colors.orange
                              : Colors.black12),
                    ),
                  ),
                ),
            ],
          ),
          if (isPart)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(
                'Partie du stade : son niveau dépend des tribunes.',
                style: theme.textTheme.bodySmall,
              ),
            ),
          const SizedBox(height: 10),
          Text(
            atMax ? 'Niveau maximum' : 'Avant / après amélioration',
            style: theme.textTheme.labelLarge,
          ),
          row(
            'Bâtiment',
            infraLevelName(kind, level).isEmpty
                ? '-'
                : infraLevelName(kind, level),
            atMax ? '' : infraLevelName(kind, next),
          ),
          row(
            'Effet',
            infraEffect(kind, level),
            atMax ? '' : infraEffect(kind, next),
          ),
          row(
            'Entretien',
            '${formatMoney(infraMaintenanceOf(kind, level))}/saison',
            atMax ? '' : '${formatMoney(infraMaintenanceOf(kind, next))}/saison',
          ),
          row(
            'Personnel',
            '${infraStaffOf(kind, level)} employés',
            atMax ? '' : '${infraStaffOf(kind, next)} employés',
          ),
          if (!atMax) ...[
            const SizedBox(height: 6),
            Text(
              'Coût ${formatMoney(upgradeCost(kind, next))} · '
              '${effectiveRounds(owner, kind, next)} journées de travaux',
              style: theme.textTheme.bodyMedium,
            ),
          ],
          const SizedBox(height: 10),
          if (spec.requires.isNotEmpty || spec.minReputation > 0 || spec.cap != null)
            Text('Conditions', style: theme.textTheme.labelLarge),
          for (final req in spec.requires)
            _Check(
              ok: owner.levelOf(req.kind) >= req.level,
              text: '${infraLabel(req.kind)} niveau ${req.level}',
            ),
          if (spec.minReputation > 0)
            _Check(
              ok: owner.reputation >= spec.minReputation,
              text: 'Réputation ${spec.minReputation}',
            ),
          if (spec.cap != null)
            _Check(
              ok: next <= owner.levelOf(spec.cap!) + spec.capOffset,
              text: 'Niveau limité par ${infraLabel(spec.cap!)} '
                  '(${owner.levelOf(spec.cap!) + spec.capOffset} max)',
            ),
          _Check(
            ok: infraEmployees(owner) + spec.staffPerLevel <= staffCapacity(owner),
            text: 'Personnel disponible '
                '(${infraEmployees(owner)}/${staffCapacity(owner)} employés)',
          ),
          if (work != null) ...[
            const SizedBox(height: 10),
            Text(
              'Travaux vers le niveau ${work.targetLevel} : '
              'encore ${work.roundsLeft} journées',
              style: theme.textTheme.bodyMedium,
            ),
            const SizedBox(height: 4),
            LinearProgressIndicator(
              value: (1 -
                      work.roundsLeft /
                          effectiveRounds(owner, kind, work.targetLevel))
                  .clamp(0.0, 1.0)
                  .toDouble(),
              minHeight: 8,
            ),
          ],
          const SizedBox(height: 12),
          if (!atMax)
            FilledButton.icon(
              onPressed: error == null
                  ? () => _confirm(context, ref, game, kind)
                  : null,
              icon: const Icon(Icons.construction),
              label: Text(level == 0 ? 'Construire' : 'Améliorer'),
            ),
          if (!atMax && error != null)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(
                blockers.isNotEmpty ? blockers.first : error,
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.error,
                ),
              ),
            ),
          if (kind == InfraKind.stadium) ...[
            const SizedBox(height: 16),
            _StadiumCustom(owner: owner),
          ],
        ],
      ),
    );
  }
}

class _Check extends StatelessWidget {
  const _Check({required this.ok, required this.text});

  final bool ok;
  final String text;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            ok ? Icons.check_circle : Icons.cancel,
            size: 16,
            color: ok ? Colors.green : theme.colorScheme.error,
          ),
          const SizedBox(width: 6),
          Expanded(child: Text(text, style: theme.textTheme.bodySmall)),
        ],
      ),
    );
  }
}

class _StadiumCustom extends ConsumerWidget {
  const _StadiumCustom({required this.owner});

  final OwnerState owner;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final name = owner.stadiumName.isEmpty ? 'Stade du club' : owner.stadiumName;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Divider(),
        Text('Personnalisation', style: theme.textTheme.labelLarge),
        const SizedBox(height: 6),
        Text(
          'Capacité : ${stadiumCapacity(owner.stadium)} places',
          style: theme.textTheme.bodySmall,
        ),
        const SizedBox(height: 6),
        OutlinedButton.icon(
          onPressed: () => _rename(context, ref, name),
          icon: const Icon(Icons.edit_outlined, size: 18),
          label: Text('Nom : $name'),
        ),
        const SizedBox(height: 8),
        Text('Couleur des sièges', style: theme.textTheme.bodySmall),
        const SizedBox(height: 4),
        Wrap(
          spacing: 8,
          children: [
            for (var i = 0; i < seatPalette.length; i++)
              Tooltip(
                message: seatPaletteNames[i],
                child: GestureDetector(
                  onTap: () => ref.read(gameProvider.notifier).setSeatColor(i),
                  child: Container(
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(
                      color: seatPalette[i],
                      shape: BoxShape.circle,
                      border: Border.all(
                        width: owner.seatColor == i ? 3 : 1,
                        color: owner.seatColor == i
                            ? theme.colorScheme.primary
                            : Colors.black26,
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ],
    );
  }
}

Future<void> _rename(BuildContext context, WidgetRef ref, String current) async {
  final controller = TextEditingController(text: current);
  final name = await showDialog<String>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: const Text('Nom du stade'),
      content: TextField(
        controller: controller,
        maxLength: 32,
        decoration: const InputDecoration(labelText: 'Nom'),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(dialogContext).pop(),
          child: const Text('Annuler'),
        ),
        FilledButton(
          onPressed: () => Navigator.of(dialogContext).pop(controller.text),
          child: const Text('Enregistrer'),
        ),
      ],
    ),
  );
  controller.dispose();
  if (name == null) return;
  final error = ref.read(gameProvider.notifier).renameStadium(name);
  if (!context.mounted) return;
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(error ?? 'Stade renommé.')),
  );
}

Future<void> _confirm(
  BuildContext context,
  WidgetRef ref,
  GameState game,
  InfraKind kind,
) async {
  final owner = game.owner;
  final target = owner.levelOf(kind) + 1;
  if (target > maxInfraLevel) return;
  final extraUpkeep = infraMaintenanceOf(kind, target) -
      infraMaintenanceOf(kind, target - 1);
  final extraStaff = infraStaffOf(kind, target) - infraStaffOf(kind, target - 1);

  final confirmed = await showDialog<bool>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: Text(owner.levelOf(kind) == 0 ? 'Construire ?' : 'Améliorer ?'),
      content: Text(
        '${infraLevelName(kind, target)}\n'
        'Coût : ${formatMoney(upgradeCost(kind, target))}\n'
        'Durée : ${effectiveRounds(owner, kind, target)} journées\n'
        'Entretien : +${formatMoney(extraUpkeep)} par saison\n'
        'Personnel : +$extraStaff employés\n\n'
        '${infraEffect(kind, target)}.',
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(dialogContext).pop(false),
          child: const Text('Annuler'),
        ),
        FilledButton(
          onPressed: () => Navigator.of(dialogContext).pop(true),
          child: const Text('Lancer les travaux'),
        ),
      ],
    ),
  );
  if (confirmed != true) return;
  final error = ref.read(gameProvider.notifier).startUpgrade(kind);
  if (!context.mounted) return;
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(error ?? 'Les travaux commencent.')),
  );
}

// ---------------------------------------------------------------------------
// Chantiers
// ---------------------------------------------------------------------------

class _WorksTab extends StatelessWidget {
  const _WorksTab({required this.game, required this.onPick});

  final GameState game;
  final ValueChanged<InfraKind> onPick;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final owner = game.owner;
    final works = owner.works;
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Chantiers en cours : ${works.length}/${maxConcurrentWorks(owner)}',
            style: theme.textTheme.titleSmall,
          ),
          const SizedBox(height: 4),
          Text(
            maxConcurrentWorks(owner) == 1
                ? 'Le centre des opérations (niveau 2 puis 4) permet de '
                    'mener plusieurs chantiers en parallèle et accélère les '
                    'travaux.'
                : 'Le centre des opérations accélère les travaux de '
                    '${(0.06 * owner.levelOf(InfraKind.operations) * 100).round()} %.',
            style: theme.textTheme.bodySmall,
          ),
          const SizedBox(height: 10),
          if (works.isEmpty)
            const Text('Aucun chantier. Touchez un bâtiment pour en lancer un.'),
          for (final w in works)
            Card(
              child: InkWell(
                onTap: () => onPick(w.kind),
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(infraIcon(w.kind), size: 18),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              '${infraLabel(w.kind)} → niveau ${w.targetLevel}',
                              style: theme.textTheme.bodyMedium,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      LinearProgressIndicator(
                        value: (1 -
                                w.roundsLeft /
                                    effectiveRounds(owner, w.kind, w.targetLevel))
                            .clamp(0.0, 1.0)
                            .toDouble(),
                        minHeight: 8,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Encore ${w.roundsLeft} journées · '
                        '${infraLevelName(w.kind, w.targetLevel)}',
                        style: theme.textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          const SizedBox(height: 10),
          Text('Personnel', style: theme.textTheme.titleSmall),
          Text(
            '${infraEmployees(owner)} employés pour une capacité de '
            '${staffCapacity(owner)}. Le siège et le centre de recrutement du '
            'personnel augmentent cette capacité.',
            style: theme.textTheme.bodySmall,
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Revenus et dépenses
// ---------------------------------------------------------------------------

class _AccountsTab extends StatelessWidget {
  const _AccountsTab({required this.game});

  final GameState game;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final owner = game.owner;
    final rounds = game.season.totalRounds;
    final home = rounds ~/ 2;
    final attendance = attendanceFor(
      populationThousands: game.city.population,
      rank: game.season.userRank < 1 ? 10 : game.season.userRank,
      clubCount: game.season.clubs.length,
      prestige: owner.reputation,
      fanMood: owner.fanMood,
      capacity: stadiumCapacity(owner.stadium),
    );

    final income = <MapEntry<String, int>>[];
    for (final kind in InfraKind.values) {
      final v = infraAnnualIncome(
        kind,
        owner,
        division: game.division,
        homeMatches: home,
        rounds: rounds,
        averageAttendance: attendance,
      );
      if (v > 0) income.add(MapEntry(infraLabel(kind), v));
    }
    final totalIncome = income.fold<int>(0, (s, e) => s + e.value);

    final byCategory = <InfraCategory, int>{
      for (final c in InfraCategory.values) c: 0,
    };
    for (final kind in InfraKind.values) {
      final cat = infraCatalog[kind]!.category;
      byCategory[cat] = byCategory[cat]! +
          infraMaintenanceOf(kind, owner.levelOf(kind));
    }
    final staffCost = infraStaffCost(owner);
    final upkeep = infrastructureUpkeepPerSeason(owner);

    Widget line(String label, int value, {bool bold = false, Color? color}) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          children: [
            Expanded(
              child: Text(
                label,
                style: theme.textTheme.bodySmall?.copyWith(
                  fontWeight: bold ? FontWeight.w700 : null,
                ),
              ),
            ),
            Text(
              formatMoney(value),
              style: theme.textTheme.bodySmall?.copyWith(
                fontWeight: bold ? FontWeight.w700 : null,
                color: color,
              ),
            ),
          ],
        ),
      );
    }

    final bonuses = <String>[
      'Billetterie x${ticketMultiplier(owner).toStringAsFixed(2)}',
      'Sponsoring x${sponsorMultiplier(owner).toStringAsFixed(2)}',
      'Commerce x${commercialMultiplier(owner).toStringAsFixed(2)}',
    ];

    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Estimation par saison '
            '($home matchs à domicile, ${attendance} spectateurs)',
            style: theme.textTheme.bodySmall,
          ),
          const SizedBox(height: 8),
          Text('Revenus des bâtiments', style: theme.textTheme.titleSmall),
          if (income.isEmpty)
            const Text('Aucun bâtiment ne rapporte encore de revenus directs.'),
          for (final e in income) line(e.key, e.value),
          line('Total', totalIncome, bold: true, color: Colors.green),
          const SizedBox(height: 4),
          Text(bonuses.join(' · '), style: theme.textTheme.bodySmall),
          const SizedBox(height: 12),
          Text('Dépenses', style: theme.textTheme.titleSmall),
          for (final c in InfraCategory.values)
            line('Entretien ${infraCategoryLabel(c).toLowerCase()}', byCategory[c]!),
          line('Personnel (${infraEmployees(owner)} employés)', staffCost),
          line(
            'Total après remises administratives',
            upkeep,
            bold: true,
            color: theme.colorScheme.error,
          ),
          const SizedBox(height: 8),
          line(
            'Bilan estimé',
            totalIncome - upkeep,
            bold: true,
            color: totalIncome - upkeep >= 0
                ? Colors.green
                : theme.colorScheme.error,
          ),
          const SizedBox(height: 8),
          Text(
            'Déjà dépensé cette saison (travaux et entretien) : '
            '${formatMoney(game.finance.infrastructure)}',
            style: theme.textTheme.bodySmall,
          ),
          const SizedBox(height: 4),
          Text(
            'Ces montants sont intégrés à la trésorerie du club : '
            'ils sont encaissés ou payés à chaque journée.',
            style: theme.textTheme.bodySmall,
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Historique
// ---------------------------------------------------------------------------

class _HistoryTab extends StatelessWidget {
  const _HistoryTab({required this.game});

  final GameState game;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final log = game.owner.infraLog;
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Historique des constructions', style: theme.textTheme.titleSmall),
          const SizedBox(height: 8),
          if (log.isEmpty) const Text('Aucune construction pour le moment.'),
          for (final line in log)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(
                    line.contains('terminé')
                        ? Icons.check_circle_outline
                        : Icons.construction,
                    size: 16,
                  ),
                  const SizedBox(width: 6),
                  Expanded(child: Text(line, style: theme.textTheme.bodySmall)),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
