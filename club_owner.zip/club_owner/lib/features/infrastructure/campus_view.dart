import 'dart:math';

import 'package:flutter/material.dart';

import '../../domain/entities/owner.dart';
import '../../engine/owner/infrastructure.dart';

/// Ambiance du plan du complexe.
enum CampusMood { day, night, rain }

String campusMoodLabel(CampusMood m) {
  switch (m) {
    case CampusMood.day:
      return 'Jour';
    case CampusMood.night:
      return 'Nuit';
    case CampusMood.rain:
      return 'Pluie';
  }
}

/// Couleurs de sièges proposées pour le stade.
const List<Color> seatPalette = [
  Color(0xFFE53935),
  Color(0xFF1E88E5),
  Color(0xFF43A047),
  Color(0xFFFFB300),
  Color(0xFFECEFF1),
  Color(0xFF8E24AA),
];

const List<String> seatPaletteNames = [
  'Rouge',
  'Bleu',
  'Vert',
  'Jaune',
  'Blanc',
  'Violet',
];

// Projection isométrique : demi-largeur et demi-hauteur d'une tuile.
const double _tw = 30;
const double _th = 15;
const double _ox = 700;
const double _oy = 150;
const int _n = 23;

/// Taille de la scène (en pixels logiques avant zoom).
const Size campusSize = Size(1400, 860);

Offset _p(double gx, double gy, [double h = 0]) =>
    Offset(_ox + (gx - gy) * _tw, _oy + (gx + gy) * _th - h);

/// Emplacement d'un bâtiment sur la grille du complexe.
class Plot {
  const Plot(this.gx, this.gy, this.w, this.d);

  final double gx;
  final double gy;
  final double w;
  final double d;
}

Map<InfraKind, Plot> _buildPlots() {
  final m = <InfraKind, Plot>{};
  m[InfraKind.stadium] = const Plot(7, 7, 8, 8);

  const sport = [
    InfraKind.training,
    InfraKind.complex,
    InfraKind.academy,
    InfraKind.youth,
    InfraKind.medical,
    InfraKind.rehab,
    InfraKind.fitness,
    InfraKind.recruitment,
    InfraKind.analysis,
  ];
  for (var i = 0; i < sport.length; i++) {
    m[sport[i]] = Plot(0.3 + (i % 2) * 3.3, 7.2 + (i ~/ 2) * 3.1, 2.8, 2.8);
  }

  const commercial = [
    InfraKind.shop,
    InfraKind.restaurant,
    InfraKind.vip,
    InfraKind.boxes,
    InfraKind.ads,
    InfraKind.museum,
    InfraKind.mall,
    InfraKind.partners,
    InfraKind.fanZone,
    InfraKind.parking,
  ];
  for (var i = 0; i < commercial.length; i++) {
    m[commercial[i]] =
        Plot(16.4 + (i % 2) * 3.3, 0.3 + (i ~/ 2) * 3.1, 2.8, 2.8);
  }

  const admin = [
    InfraKind.hq,
    InfraKind.hrCenter,
    InfraKind.operations,
    InfraKind.conference,
    InfraKind.commercial,
  ];
  for (var i = 0; i < admin.length; i++) {
    m[admin[i]] = Plot(7.2 + (i % 3) * 3.0, 0.4 + (i ~/ 3) * 3.1, 2.6, 2.6);
  }
  return m;
}

final Map<InfraKind, Plot> campusPlots = _buildPlots();

/// Les parties du stade que l'on touche directement sur le plan.
const List<InfraKind> stadiumParts = [
  InfraKind.stadium,
  InfraKind.pitch,
  InfraKind.lighting,
  InfraKind.screens,
  InfraKind.roof,
];

/// Point de la scène sur lequel centrer la vue pour un bâtiment.
Offset campusAnchor(InfraKind kind) {
  switch (kind) {
    case InfraKind.pitch:
      return _p(11, 11);
    case InfraKind.lighting:
      return _p(6.7, 15.3, 30);
    case InfraKind.screens:
      return _p(11, 7.2, 30);
    case InfraKind.roof:
      return _p(11, 7, 40);
    default:
      final plot = campusPlots[kind];
      if (plot == null) return _p(11, 11);
      return _p(plot.gx + plot.w / 2, plot.gy + plot.d / 2, 12);
  }
}

Color _shade(Color c, double f) {
  int ch(int v) => (v * f).clamp(0, 255).round();
  return Color.fromARGB(c.alpha, ch(c.red), ch(c.green), ch(c.blue));
}

Color _categoryColor(InfraCategory c) {
  switch (c) {
    case InfraCategory.sport:
      return const Color(0xFF5C8DD6);
    case InfraCategory.stadium:
      return const Color(0xFFB0BEC5);
    case InfraCategory.commercial:
      return const Color(0xFFE08A3C);
    case InfraCategory.admin:
      return const Color(0xFF8E7CC3);
  }
}

enum _Style { pitch, lot, plaza, box, tower, dome }

_Style _styleOf(InfraKind k) {
  switch (k) {
    case InfraKind.training:
    case InfraKind.complex:
      return _Style.pitch;
    case InfraKind.parking:
      return _Style.lot;
    case InfraKind.fanZone:
      return _Style.plaza;
    case InfraKind.hq:
    case InfraKind.conference:
      return _Style.tower;
    case InfraKind.museum:
      return _Style.dome;
    default:
      return _Style.box;
  }
}

class _Hit {
  _Hit(this.kind, this.path);

  final InfraKind kind;
  final Path path;
}

/// Zones touchables relevées pendant le dessin.
class CampusHits {
  final List<_Hit> _list = [];

  void _clear() => _list.clear();

  /// Bâtiment (ou partie du stade) sous le doigt, le plus en avant d'abord.
  InfraKind? at(Offset point) {
    for (var i = _list.length - 1; i >= 0; i--) {
      if (_list[i].path.contains(point)) return _list[i].kind;
    }
    return null;
  }
}

class _Item {
  _Item(this.key, this.draw);

  final double key;
  final void Function() draw;
}

class CampusPainter extends CustomPainter {
  CampusPainter({
    required this.owner,
    required this.selected,
    required this.mood,
    required this.labels,
    required this.hits,
  }) : sig = [
         for (final k in InfraKind.values) owner.levelOf(k),
         for (final w in owner.works) '${w.kind.name}${w.roundsLeft}',
         selected?.name,
         mood.name,
         labels,
         owner.seatColor,
         owner.stadiumName,
       ].join(',');

  final OwnerState owner;
  final InfraKind? selected;
  final CampusMood mood;
  final bool labels;
  final CampusHits hits;
  final String sig;

  late Canvas _c;
  final List<void Function()> _top = [];
  final Map<InfraKind, Offset> _centers = {};
  final List<Offset> _lampHeads = [];

  Color get _seat => seatPalette[owner.seatColor.clamp(0, 5).toInt()];

  @override
  bool shouldRepaint(CampusPainter old) => old.sig != sig;

  // ---------- primitives ----------

  Path _poly(List<Offset> pts) => Path()..addPolygon(pts, true);

  Path _flat(double gx, double gy, double w, double d, double h, Color color,
      {bool stroke = false}) {
    final pts = [
      _p(gx, gy, h),
      _p(gx + w, gy, h),
      _p(gx + w, gy + d, h),
      _p(gx, gy + d, h),
    ];
    final path = _poly(pts);
    _c.drawPath(path, Paint()..color = color);
    if (stroke) {
      _c.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1
          ..color = _shade(color, 0.7),
      );
    }
    return path;
  }

  Path _box(double gx, double gy, double w, double d, double h0, double h1,
      Color top) {
    final topFace = [
      _p(gx, gy, h1),
      _p(gx + w, gy, h1),
      _p(gx + w, gy + d, h1),
      _p(gx, gy + d, h1),
    ];
    final f1 = [
      _p(gx, gy + d, h1),
      _p(gx + w, gy + d, h1),
      _p(gx + w, gy + d, h0),
      _p(gx, gy + d, h0),
    ];
    final f2 = [
      _p(gx + w, gy + d, h1),
      _p(gx + w, gy, h1),
      _p(gx + w, gy, h0),
      _p(gx + w, gy + d, h0),
    ];
    final line = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8
      ..color = _shade(top, 0.5);
    _c.drawPath(_poly(f1), Paint()..color = _shade(top, 0.82));
    _c.drawPath(_poly(f2), Paint()..color = _shade(top, 0.62));
    _c.drawPath(_poly(topFace), Paint()..color = top);
    _c.drawPath(_poly(f1), line);
    _c.drawPath(_poly(f2), line);
    _c.drawPath(_poly(topFace), line);
    return Path()
      ..addPolygon(topFace, true)
      ..addPolygon(f1, true)
      ..addPolygon(f2, true);
  }

  void _hit(InfraKind kind, Path path) => hits._list.add(_Hit(kind, path));

  void _text(
    String s,
    Offset center, {
    double size = 12,
    Color color = Colors.white,
    bool bold = false,
    Color? bg,
  }) {
    final tp = TextPainter(
      text: TextSpan(
        text: s,
        style: TextStyle(
          fontSize: size,
          color: color,
          fontWeight: bold ? FontWeight.w700 : FontWeight.w500,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    if (bg != null) {
      final r = Rect.fromCenter(
        center: center,
        width: tp.width + 12,
        height: tp.height + 5,
      );
      _c.drawRRect(
        RRect.fromRectAndRadius(r, const Radius.circular(7)),
        Paint()..color = bg,
      );
    }
    tp.paint(_c, center - Offset(tp.width / 2, tp.height / 2));
  }

  void _iconText(IconData icon, Offset center, double size, Color color) {
    final tp = TextPainter(
      text: TextSpan(
        text: String.fromCharCode(icon.codePoint),
        style: TextStyle(
          fontSize: size,
          color: color,
          fontFamily: icon.fontFamily,
          package: icon.fontPackage,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(_c, center - Offset(tp.width / 2, tp.height / 2));
  }

  void _dashed(Offset a, Offset b, Paint paint) {
    final total = (b - a).distance;
    if (total == 0) return;
    final dir = (b - a) / total;
    var t = 0.0;
    while (t < total) {
      final e = min(t + 6, total);
      _c.drawLine(a + dir * t, a + dir * e, paint);
      t += 11;
    }
  }

  void _badge(InfraKind kind, Offset at, {bool small = false}) {
    final level = owner.levelOf(kind);
    final spec = infraCatalog[kind]!;
    final color = level == 0
        ? const Color(0xFF546E7A)
        : _shade(_categoryColor(spec.category), 0.75);
    final r = small ? 10.0 : 13.0;
    _c.drawCircle(at, r + 2, Paint()..color = Colors.white);
    _c.drawCircle(at, r, Paint()..color = color);
    if (level == 0) {
      final locked = infraBlockers(owner, kind).isNotEmpty;
      _iconText(
        locked ? Icons.lock : Icons.add,
        at,
        small ? 12 : 16,
        Colors.white,
      );
    } else {
      _text('$level', at, size: small ? 12 : 15, bold: true);
    }
  }

  InfraWork? _workOf(InfraKind kind) {
    for (final w in owner.works) {
      if (w.kind == kind) return w;
    }
    return null;
  }

  // ---------- peinture ----------

  @override
  void paint(Canvas canvas, Size size) {
    _c = canvas;
    hits._clear();
    _top.clear();
    _centers.clear();
    _lampHeads.clear();

    // Le décor déborde largement de la scène pour remplir tout l'écran.
    canvas.drawRect(
      const Rect.fromLTWH(-2400, -2400, 6200, 5700),
      Paint()..color = const Color(0xFF2F6B45),
    );
    _surroundings();
    _ground();

    final items = <_Item>[];
    campusPlots.forEach((kind, plot) {
      if (kind == InfraKind.stadium) return;
      items.add(
        _Item(plot.gx + plot.gy + (plot.w + plot.d) / 2, () => _building(kind)),
      );
    });
    items.add(_Item(21.5, _stadium));
    items.sort((a, b) => a.key.compareTo(b.key));
    for (final it in items) {
      it.draw();
    }
    _foreground();

    if (mood != CampusMood.day) _atmosphere();
    _selection();
    for (final f in _top) {
      f();
    }
  }

  void _ground() {
    final n = _n.toDouble();
    for (var i = 0; i < _n; i++) {
      for (var j = 0; j < _n; j++) {
        _flat(
          i.toDouble(),
          j.toDouble(),
          1,
          1,
          0,
          (i + j).isEven ? const Color(0xFF5E9F58) : const Color(0xFF68A962),
        );
      }
    }
    // Voirie et esplanades.
    const road = Color(0xFFB0BEC5);
    _flat(0, 6.9, 6.9, n - 6.9, 0.3, road);
    _flat(16.1, 0, n - 16.1, 19.2, 0.3, road);
    _flat(6.9, 0, 9.2, 6.9, 0.3, road);
    _flat(6.9, 15.4, 9.2, n - 15.4, 0.3, const Color(0xFFCFD8DC));
    _flat(6.5, 6.5, 9.0, 9.0, 0.6, const Color(0xFF90A4AE));

    // Quelques arbres sur l'esplanade avant.
    final r = Random(4);
    for (var i = 0; i < 16; i++) {
      final gx = 7.2 + r.nextDouble() * 8.6;
      final gy = 15.8 + r.nextDouble() * 6.6;
      _tree(gx, gy);
    }
  }

  /// Quartier autour du complexe : prairies, arbres et immeubles.
  void _surroundings() {
    final r = Random(21);
    // Une large prairie autour de la grille.
    _flat(-8, -8, _n + 16.0, _n + 16.0, 0, const Color(0xFF3E7D4F));
    // Rues extérieures.
    const street = Color(0xFF78909C);
    _flat(-3, -8, 1.4, _n + 16.0, 0.1, street);
    _flat(_n + 1.6, -8, 1.4, _n + 16.0, 0.1, street);
    _flat(-8, -3, _n + 16.0, 1.4, 0.1, street);
    _flat(-8, _n + 1.6, _n + 16.0, 1.4, 0.1, street);
    // Immeubles au loin (derrière la grille, dessinés avant).
    final palette = [
      const Color(0xFFB0BEC5),
      const Color(0xFF90A4AE),
      const Color(0xFFCFD8DC),
      const Color(0xFFBCAAA4),
    ];
    for (var i = 0; i < 14; i++) {
      final gx = -7.5 + i * 2.2;
      _box(gx, -7.5, 1.6, 1.6, 0, 18.0 + r.nextInt(5) * 9.0,
          palette[i % palette.length]);
      _box(-7.5, gx, 1.6, 1.6, 0, 14.0 + r.nextInt(5) * 8.0,
          palette[(i + 1) % palette.length]);
    }
    // Haies d'arbres le long des rues.
    for (var i = 0; i < 26; i++) {
      final t = -6.0 + i * 1.3;
      _tree(-1.0, t);
      _tree(t, -1.0);
    }
  }

  void _foreground() {
    final r = Random(33);
    final palette = [
      const Color(0xFFECEFF1),
      const Color(0xFFB0BEC5),
      const Color(0xFFD7CCC8),
    ];
    for (var i = 0; i < 12; i++) {
      final t = -4.0 + i * 2.6;
      _tree(_n + 0.8, t);
      _tree(t, _n + 0.8);
      _box(_n + 3.4, t, 1.6, 1.6, 0, 12.0 + r.nextInt(4) * 7.0,
          palette[i % palette.length]);
      _box(t, _n + 3.4, 1.6, 1.6, 0, 12.0 + r.nextInt(4) * 7.0,
          palette[(i + 1) % palette.length]);
    }
  }

  void _tree(double gx, double gy) {
    final base = _p(gx, gy, 0.3);
    _c.drawLine(
      base,
      base + const Offset(0, -9),
      Paint()
        ..color = const Color(0xFF6D4C41)
        ..strokeWidth = 3,
    );
    _c.drawCircle(base + const Offset(0, -15), 8, Paint()..color = const Color(0xFF2E7D32));
    _c.drawCircle(base + const Offset(-2, -17), 5, Paint()..color = const Color(0xFF43A047));
  }

  void _atmosphere() {
    final size = campusSize;
    if (mood == CampusMood.night) {
      _c.drawRect(
        Offset.zero & size,
        Paint()..color = const Color(0xB0061226),
      );
      for (final head in _lampHeads) {
        _c.drawCircle(
          head,
          70,
          Paint()
            ..blendMode = BlendMode.plus
            ..shader = const RadialGradient(
              colors: [Color(0xCCFFF1A8), Color(0x00FFF1A8)],
            ).createShader(Rect.fromCircle(center: head, radius: 70)),
        );
      }
      for (final e in _centers.entries) {
        if (owner.levelOf(e.key) == 0) continue;
        _c.drawCircle(
          e.value,
          26,
          Paint()
            ..blendMode = BlendMode.plus
            ..shader = const RadialGradient(
              colors: [Color(0x55FFD180), Color(0x00FFD180)],
            ).createShader(Rect.fromCircle(center: e.value, radius: 26)),
        );
      }
    } else {
      _c.drawRect(
        Offset.zero & size,
        Paint()..color = const Color(0x40455A64),
      );
      final r = Random(9);
      final paint = Paint()
        ..color = const Color(0x99E3F2FD)
        ..strokeWidth = 1.2;
      for (var i = 0; i < 260; i++) {
        final x = r.nextDouble() * size.width;
        final y = r.nextDouble() * size.height;
        _c.drawLine(Offset(x, y), Offset(x - 5, y + 14), paint);
      }
    }
  }

  void _selection() {
    final sel = selected;
    if (sel == null) return;
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..color = const Color(0xFFFFEB3B);
    for (final h in hits._list) {
      if (h.kind == sel) _c.drawPath(h.path, paint);
    }
  }

  // ---------- bâtiments ordinaires ----------

  void _building(InfraKind kind) {
    final plot = campusPlots[kind]!;
    final spec = infraCatalog[kind]!;
    final level = owner.levelOf(kind);
    final style = _styleOf(kind);
    final base = _categoryColor(spec.category);
    final gx = plot.gx + 0.15;
    final gy = plot.gy + 0.15;
    final w = plot.w - 0.3;
    final d = plot.d - 0.3;
    var topH = 0.0;
    Path footprint = _poly([
      _p(gx, gy),
      _p(gx + w, gy),
      _p(gx + w, gy + d),
      _p(gx, gy + d),
    ]);

    if (level == 0) {
      _flat(gx, gy, w, d, 0.5, const Color(0x66CFD8DC));
      final dash = Paint()
        ..strokeWidth = 1.6
        ..color = const Color(0xFFECEFF1);
      final pts = [
        _p(gx, gy, 0.5),
        _p(gx + w, gy, 0.5),
        _p(gx + w, gy + d, 0.5),
        _p(gx, gy + d, 0.5),
      ];
      for (var i = 0; i < 4; i++) {
        _dashed(pts[i], pts[(i + 1) % 4], dash);
      }
    } else {
      switch (style) {
        case _Style.pitch:
          footprint = _flat(gx, gy, w, d, 0.6, const Color(0xFF4CAF50),
              stroke: true);
          final line = Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1
            ..color = const Color(0xCCFFFFFF);
          final inner = [
            _p(gx + 0.2, gy + 0.2, 0.7),
            _p(gx + w - 0.2, gy + 0.2, 0.7),
            _p(gx + w - 0.2, gy + d - 0.2, 0.7),
            _p(gx + 0.2, gy + d - 0.2, 0.7),
          ];
          _c.drawPath(_poly(inner), line);
          _c.drawLine(
            _p(gx + w / 2, gy + 0.2, 0.7),
            _p(gx + w / 2, gy + d - 0.2, 0.7),
            line,
          );
          _c.drawCircle(_p(gx + w / 2, gy + d / 2, 0.7), 7, line);
          final hut = 8.0 + 3.0 * level;
          footprint = Path.combine(
            PathOperation.union,
            footprint,
            _box(gx + w - 0.9, gy, 0.9, 0.9, 0.6, hut, base),
          );
          topH = hut;
        case _Style.lot:
          footprint = _flat(gx, gy, w, d, 0.6, const Color(0xFF78909C),
              stroke: true);
          final rnd = Random(level);
          final cars = 3 + level * 3;
          for (var i = 0; i < cars; i++) {
            final cx = gx + 0.3 + rnd.nextDouble() * (w - 0.8);
            final cy = gy + 0.3 + rnd.nextDouble() * (d - 0.8);
            _box(cx, cy, 0.4, 0.22, 0.6, 3,
                <Color>[Colors.red, Colors.white, Colors.blue, Colors.amber][i % 4]);
          }
          topH = 4;
        case _Style.plaza:
          footprint = _flat(gx, gy, w, d, 0.6, const Color(0xFFD7B98E),
              stroke: true);
          final tents = 1 + level;
          for (var i = 0; i < tents; i++) {
            final tx = gx + 0.3 + (i % 3) * 0.85;
            final ty = gy + 0.3 + (i ~/ 3) * 0.85;
            _box(tx, ty, 0.6, 0.6, 0.6, 7,
                i.isEven ? const Color(0xFFE53935) : const Color(0xFFFFFFFF));
          }
          topH = 8;
        case _Style.tower:
          final ht = 24.0 + 13.0 * level;
          footprint = _box(gx + 0.3, gy + 0.3, w - 0.6, d - 0.6, 0, ht, base);
          _floors(gx + 0.3, gy + 0.3, w - 0.6, d - 0.6, ht, base);
          topH = ht;
        case _Style.dome:
          final hd = 10.0 + 6.0 * level;
          footprint = _box(gx, gy, w, d, 0, hd, base);
          final dc = _p(gx + w / 2, gy + d / 2, hd);
          _c.drawOval(
            Rect.fromCenter(center: dc, width: w * 38, height: w * 19),
            Paint()..color = _shade(base, 1.2),
          );
          topH = hd + 8;
        case _Style.box:
          final hb = 14.0 + 8.0 * level;
          footprint = _box(gx, gy, w, d, 0, hb, base);
          _floors(gx, gy, w, d, hb, base);
          topH = hb;
      }
    }
    _hit(kind, footprint);

    final center = _p(gx + w / 2, gy + d / 2, topH * 0.6);
    _centers[kind] = center;

    final work = _workOf(kind);
    if (work != null) _scaffold(kind, work, gx, gy, w, d, topH);

    final badgeAt = _p(gx + w / 2, gy + d / 2, max(topH, 6.0) + 20);
    final isSel = selected == kind;
    _top.add(() {
      _badge(kind, badgeAt);
      if (labels || isSel) {
        _text(
          spec.label,
          _p(gx + w / 2, gy + d, 0) + const Offset(0, 16),
          size: 12,
          bg: const Color(0xCC102027),
        );
      }
    });
  }

  void _floors(double gx, double gy, double w, double d, double h, Color base) {
    final line = Paint()
      ..strokeWidth = 0.8
      ..color = _shade(base, 0.45);
    final floors = max(1, (h / 9).floor());
    for (var i = 1; i < floors; i++) {
      final hh = h * i / floors;
      _c.drawLine(_p(gx, gy + d, hh), _p(gx + w, gy + d, hh), line);
      _c.drawLine(_p(gx + w, gy + d, hh), _p(gx + w, gy, hh), line);
    }
  }

  void _scaffold(InfraKind kind, InfraWork work, double gx, double gy,
      double w, double d, double topH) {
    final total = effectiveRounds(owner, kind, work.targetLevel);
    final progress = (1 - work.roundsLeft / total).clamp(0.0, 1.0).toDouble();
    final h = max(topH + 14, 26.0);
    final orange = Paint()
      ..strokeWidth = 2
      ..color = const Color(0xFFFF9800);
    final corners = [
      [gx, gy],
      [gx + w, gy],
      [gx + w, gy + d],
      [gx, gy + d],
    ];
    for (final c in corners) {
      _c.drawLine(_p(c[0], c[1]), _p(c[0], c[1], h), orange);
    }
    final topPts = [for (final c in corners) _p(c[0], c[1], h)];
    for (var i = 0; i < 4; i++) {
      _c.drawLine(topPts[i], topPts[(i + 1) % 4], orange);
    }
    _c.drawPath(_poly(topPts), Paint()..color = const Color(0x33FF9800));
    final mast = _p(gx + w, gy, 0);
    _c.drawLine(mast, mast + Offset(0, -h - 20), orange);
    _c.drawLine(
      mast + Offset(0, -h - 20),
      mast + Offset(-34, -h - 14),
      orange,
    );
    final bar = _p(gx + w / 2, gy + d / 2, h + 34);
    _top.add(() {
      _c.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(center: bar, width: 62, height: 8),
          const Radius.circular(4),
        ),
        Paint()..color = const Color(0xFF263238),
      );
      _c.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(bar.dx - 30, bar.dy - 3, 60 * progress, 6),
          const Radius.circular(3),
        ),
        Paint()..color = const Color(0xFFFFB300),
      );
    });
  }

  // ---------- le stade et ses parties ----------

  void _stadium() {
    final level = owner.stadium.clamp(1, 5).toInt();
    final seat = _seat;
    final concrete = const Color(0xFFB0BEC5);
    final mainH = 10.0 + 5.0 * level;
    final tiers = level <= 1 ? 1 : (level <= 3 ? 2 : 3);

    // Gradins : le nord et l'ouest derrière le terrain, l'est et le sud devant.
    _hit(
      InfraKind.stadium,
      _flat(6.6, 6.6, 8.8, 8.8, 0.8, const Color(0xFF90A4AE)),
    );

    // Nord (gy 7 -> 9.6) : les gradins les plus hauts sont au fond.
    _stand(
      gx: 7,
      gy: 7,
      w: 8,
      d: 2.6,
      alongX: true,
      innerAtEnd: true,
      tiers: tiers,
      height: mainH,
      seat: seat,
      concrete: concrete,
      seed: 1,
    );
    // Panneau d'affichage au-dessus de la tribune nord.
    _boardAndBanners(level, mainH);
    if (level >= 2) {
      _stand(
        gx: 7,
        gy: 9.6,
        w: 1.9,
        d: 2.8,
        alongX: false,
        innerAtEnd: true,
        tiers: max(1, tiers - 1),
        height: mainH * 0.7,
        seat: seat,
        concrete: concrete,
        seed: 2,
      );
    }

    _pitch();

    if (level >= 3) {
      _stand(
        gx: 13.1,
        gy: 9.6,
        w: 1.9,
        d: 2.8,
        alongX: false,
        innerAtEnd: false,
        tiers: max(1, tiers - 1),
        height: mainH * 0.7,
        seat: seat,
        concrete: concrete,
        seed: 3,
      );
    }
    _stand(
      gx: 7,
      gy: 12.4,
      w: 8,
      d: 2.6,
      alongX: true,
      innerAtEnd: false,
      tiers: tiers,
      height: mainH * (level >= 2 ? 0.9 : 0.6),
      seat: seat,
      concrete: concrete,
      seed: 4,
    );

    _roof(mainH);
    _masts(mainH);
    _flags(level, mainH);

    final c = _p(11, 11, mainH + 8);
    _centers[InfraKind.stadium] = c;
    final name = owner.stadiumName.isEmpty ? 'Stade du club' : owner.stadiumName;
    _top.add(() {
      _badge(InfraKind.stadium, _p(8, 15, mainH + 22));
      _badge(InfraKind.pitch, _p(11, 11, 4), small: true);
      if (labels || selected == InfraKind.stadium) {
        _text(name, _p(11, 15.6), size: 13, bold: true, bg: const Color(0xCC102027));
      }
    });
  }

  void _stand({
    required double gx,
    required double gy,
    required double w,
    required double d,
    required bool alongX,
    required bool innerAtEnd,
    required int tiers,
    required double height,
    required Color seat,
    required Color concrete,
    required int seed,
  }) {
    // La profondeur de la tribune est découpée en [tiers] marches.
    final depth = alongX ? d : w;
    final slice = depth / tiers;
    final order = <int>[
      for (var i = 0; i < tiers; i++) i,
    ];
    // i = 0 est la marche la plus proche du terrain (la plus basse).
    // On dessine de l'arrière vers l'avant.
    final backFirst = innerAtEnd ? order.reversed.toList() : order;
    final r = Random(seed * 17 + owner.stadium);
    for (final i in backFirst) {
      final h1 = height * (i + 1) / tiers;
      final double ax;
      final double ay;
      final double aw;
      final double ad;
      if (alongX) {
        ax = gx;
        aw = w;
        ad = slice;
        ay = innerAtEnd ? gy + depth - slice * (i + 1) : gy + slice * i;
      } else {
        ay = gy;
        ad = d;
        aw = slice;
        ax = innerAtEnd ? gx + depth - slice * (i + 1) : gx + slice * i;
      }
      final path = _box(ax, ay, aw, ad, 0, h1, seat);
      _hit(InfraKind.stadium, path);
      final dots = (aw * ad * (2.5 + owner.stadium * 1.6)).round();
      final colors = [
        const Color(0xFFFFFFFF),
        const Color(0xFF263238),
        seat,
        const Color(0xFFFFD54F),
      ];
      for (var k = 0; k < dots; k++) {
        final x = ax + 0.1 + r.nextDouble() * (aw - 0.2);
        final y = ay + 0.1 + r.nextDouble() * (ad - 0.2);
        _c.drawCircle(
          _p(x, y, h1),
          1.5,
          Paint()..color = colors[r.nextInt(colors.length)],
        );
      }
    }
  }

  void _boardAndBanners(int level, double mainH) {
    final s = owner.levelOf(InfraKind.screens);
    // Tunnel des joueurs sur la face visible de la tribune nord.
    final tunnel = [
      _p(11, 9.6, 0),
      _p(11.9, 9.6, 0),
      _p(11.9, 9.6, 5),
      _p(11, 9.6, 5),
    ];
    _c.drawPath(_poly(tunnel), Paint()..color = const Color(0xFF212121));
    // Banderoles du club sur la tribune.
    if (level >= 2) {
      final seat = _seat;
      for (var i = 0; i < 6; i++) {
        final x = 7.6 + i * 1.2;
        if (x > 10.6 && x < 12.2) continue;
        final q = [
          _p(x, 9.6, 1),
          _p(x + 0.8, 9.6, 1),
          _p(x + 0.8, 9.6, 3.2),
          _p(x, 9.6, 3.2),
        ];
        _c.drawPath(
          _poly(q),
          Paint()..color = i.isEven ? seat : const Color(0xFFFFFFFF),
        );
      }
    }
    if (s == 0) return;
    final bw = 1.0 + 0.45 * s;
    final bh = 4.0 + 1.6 * s;
    final gx = 11 - bw / 2;
    final path = _box(gx, 7.2, bw, 0.25, mainH + 1, mainH + 1 + bh,
        const Color(0xFF0D1B2A));
    final lit = [
      _p(gx + 0.1, 7.45, mainH + 2),
      _p(gx + bw - 0.1, 7.45, mainH + 2),
      _p(gx + bw - 0.1, 7.45, mainH + bh),
      _p(gx + 0.1, 7.45, mainH + bh),
    ];
    _c.drawPath(_poly(lit), Paint()..color = const Color(0xFF26C6DA));
    _c.drawPath(
      _poly(lit),
      Paint()
        ..style = PaintingStyle.stroke
        ..color = const Color(0xFFB2EBF2),
    );
    _hit(InfraKind.screens, path);
    _centers[InfraKind.screens] = _p(11, 7.3, mainH + bh / 2);
    final at = _p(11, 7.3, mainH + bh + 14);
    _top.add(() => _badge(InfraKind.screens, at, small: true));
  }

  void _pitch() {
    final q = owner.levelOf(InfraKind.pitch);
    final green1 = Color.lerp(
      const Color(0xFF7CB342),
      const Color(0xFF2E7D32),
      q / 5,
    )!;
    final green2 = _shade(green1, 0.9);
    const x0 = 8.9;
    const x1 = 13.1;
    const y0 = 9.6;
    const y1 = 12.4;
    final border = _flat(x0 - 0.3, y0 - 0.3, x1 - x0 + 0.6, y1 - y0 + 0.6, 0.9,
        const Color(0xFF455A64));
    _hit(InfraKind.pitch, border);
    final stripes = 10;
    final sw = (x1 - x0) / stripes;
    for (var i = 0; i < stripes; i++) {
      _flat(x0 + i * sw, y0, sw, y1 - y0, 1, i.isEven ? green1 : green2);
    }
    if (q <= 1) {
      final r = Random(3);
      for (var i = 0; i < 6 - q * 2; i++) {
        _flat(x0 + r.nextDouble() * 3.6, y0 + r.nextDouble() * 2.2, 0.5, 0.35,
            1.1, const Color(0xFF8D6E63));
      }
    }
    final line = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.1
      ..color = const Color(0xE6FFFFFF);
    _c.drawPath(
      _poly([
        _p(x0, y0, 1.2),
        _p(x1, y0, 1.2),
        _p(x1, y1, 1.2),
        _p(x0, y1, 1.2),
      ]),
      line,
    );
    _c.drawLine(_p(11, y0, 1.2), _p(11, y1, 1.2), line);
    final circle = Path();
    for (var i = 0; i <= 24; i++) {
      final a = i / 24 * 2 * pi;
      final pt = _p(11 + 0.55 * cos(a), 11 + 0.4 * sin(a), 1.2);
      if (i == 0) {
        circle.moveTo(pt.dx, pt.dy);
      } else {
        circle.lineTo(pt.dx, pt.dy);
      }
    }
    _c.drawPath(circle, line);
    for (final side in [x0, x1 - 0.8]) {
      _c.drawPath(
        _poly([
          _p(side, 10.3, 1.2),
          _p(side + 0.8, 10.3, 1.2),
          _p(side + 0.8, 11.7, 1.2),
          _p(side, 11.7, 1.2),
        ]),
        line,
      );
    }
    // Bancs de touche.
    _box(10.2, 12.0, 0.8, 0.3, 1, 3.2, const Color(0xFFFFFFFF));
    _box(11.4, 12.0, 0.8, 0.3, 1, 3.2, const Color(0xFFFFFFFF));
    // Buts.
    _box(x0 - 0.15, 10.8, 0.15, 0.4, 1, 3.5, const Color(0xFFFFFFFF));
    _box(x1, 10.8, 0.15, 0.4, 1, 3.5, const Color(0xFFFFFFFF));
  }

  void _roof(double mainH) {
    final r = owner.levelOf(InfraKind.roof);
    if (r == 0) return;
    final h = mainH + 14;
    final color = r >= 4 ? const Color(0x99B3E5FC) : const Color(0xB0CFD8DC);
    final slabs = <List<double>>[
      [6.7, 6.7, 8.6, 3.2],
      if (r >= 2) [6.7, 12.1, 8.6, 3.2],
      if (r >= 3) [6.7, 9.9, 2.4, 2.2],
      if (r >= 3) [12.9, 9.9, 2.4, 2.2],
    ];
    for (final s in slabs) {
      final pts = [
        _p(s[0], s[1], h),
        _p(s[0] + s[2], s[1], h),
        _p(s[0] + s[2], s[1] + s[3], h),
        _p(s[0], s[1] + s[3], h),
      ];
      _c.drawPath(_poly(pts), Paint()..color = color);
      final edge = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0xFF607D8B);
      _c.drawPath(_poly(pts), edge);
      for (var i = 1; i < 6; i++) {
        final t = i / 6;
        _c.drawLine(
          _p(s[0] + s[2] * t, s[1], h),
          _p(s[0] + s[2] * t, s[1] + s[3], h),
          Paint()
            ..strokeWidth = 0.8
            ..color = const Color(0x99546E7A),
        );
      }
      if (r >= 5) {
        _c.drawLine(
          _p(s[0], s[1] + s[3] / 2, h + 1),
          _p(s[0] + s[2], s[1] + s[3] / 2, h + 1),
          Paint()
            ..strokeWidth = 3
            ..color = const Color(0xFFFFD54F),
        );
      }
      // Seule la bordure du toit se touche, pour ne pas masquer les gradins.
      final front = [
        _p(s[0], s[1] + s[3], h),
        _p(s[0] + s[2], s[1] + s[3], h),
        _p(s[0] + s[2], s[1] + s[3], h - 6),
        _p(s[0], s[1] + s[3], h - 6),
      ];
      _hit(InfraKind.roof, _poly(front));
    }
    _centers[InfraKind.roof] = _p(11, 7, h);
    final at = _p(7.2, 7.2, h + 14);
    _top.add(() => _badge(InfraKind.roof, at, small: true));
  }

  void _masts(double mainH) {
    final l = owner.levelOf(InfraKind.lighting);
    final spots = <List<double>>[
      if (l >= 1) [6.6, 15.4],
      if (l >= 1) [15.4, 6.6],
      if (l >= 2) [6.6, 6.6],
      if (l >= 2) [15.4, 15.4],
    ];
    final h = 38.0 + 3.0 * l;
    for (final s in spots) {
      final path = _box(s[0] - 0.12, s[1] - 0.12, 0.24, 0.24, 0, h,
          const Color(0xFF78909C));
      final head = _p(s[0], s[1], h + 4);
      final bar = Path()
        ..addRect(Rect.fromCenter(center: head, width: 26, height: 10));
      _c.drawPath(bar, Paint()..color = const Color(0xFF37474F));
      final lamps = 1 + min(l, 4);
      for (var i = 0; i < lamps; i++) {
        _c.drawCircle(
          head + Offset(-10.0 + i * (20.0 / max(1, lamps - 1)), 0),
          2.2,
          Paint()..color = const Color(0xFFFFF59D),
        );
      }
      _hit(
        InfraKind.lighting,
        Path.combine(
          PathOperation.union,
          path,
          Path()..addOval(Rect.fromCircle(center: head, radius: 16)),
        ),
      );
      _lampHeads.add(head);
    }
    if (l == 0) return;
    if (l >= 4) {
      // Bandeau lumineux sur le pourtour du stade.
      final strip = Paint()
        ..strokeWidth = 2.5
        ..color = const Color(0xFF80DEEA);
      final y = mainH + 2;
      _c.drawLine(_p(7, 15, y), _p(15, 15, y), strip);
      _c.drawLine(_p(15, 15, y), _p(15, 7, y), strip);
    }
    _centers[InfraKind.lighting] = _lampHeads.isEmpty
        ? _p(6.6, 15.4, h)
        : _lampHeads.first;
    final at = _p(6.6, 15.4, h + 24);
    _top.add(() => _badge(InfraKind.lighting, at, small: true));
  }

  void _flags(int level, double mainH) {
    if (level < 3) return;
    final seat = _seat;
    for (final s in [
      [7.3, 7.3],
      [14.7, 7.3],
      [14.7, 14.7],
      [7.3, 14.7],
    ]) {
      final base = _p(s[0], s[1], mainH);
      _c.drawLine(
        base,
        base + const Offset(0, -16),
        Paint()
          ..strokeWidth = 1.5
          ..color = const Color(0xFFECEFF1),
      );
      _c.drawPath(
        Path()
          ..moveTo(base.dx, base.dy - 16)
          ..lineTo(base.dx + 11, base.dy - 12)
          ..lineTo(base.dx, base.dy - 8)
          ..close(),
        Paint()..color = seat,
      );
    }
  }
}

/// Plan interactif du complexe : zoom, déplacement, bâtiments à toucher.
class CampusView extends StatefulWidget {
  const CampusView({
    required this.owner,
    required this.selected,
    required this.mood,
    required this.controller,
    required this.onSelect,
    super.key,
  });

  final OwnerState owner;
  final InfraKind? selected;
  final CampusMood mood;
  final TransformationController controller;
  final ValueChanged<InfraKind?> onSelect;

  @override
  State<CampusView> createState() => _CampusViewState();
}

class _CampusViewState extends State<CampusView> {
  final CampusHits _hits = CampusHits();
  bool _labels = false;

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_onTransform);
  }

  @override
  void didUpdateWidget(CampusView old) {
    super.didUpdateWidget(old);
    if (old.controller != widget.controller) {
      old.controller.removeListener(_onTransform);
      widget.controller.addListener(_onTransform);
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onTransform);
    super.dispose();
  }

  void _onTransform() {
    final show = widget.controller.value.getMaxScaleOnAxis() > 0.9;
    if (show != _labels) setState(() => _labels = show);
  }

  @override
  Widget build(BuildContext context) {
    return InteractiveViewer(
      transformationController: widget.controller,
      constrained: false,
      minScale: 0.3,
      maxScale: 3.5,
      boundaryMargin: const EdgeInsets.all(420),
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: (d) => widget.onSelect(_hits.at(d.localPosition)),
        child: CustomPaint(
          size: campusSize,
          painter: CampusPainter(
            owner: widget.owner,
            selected: widget.selected,
            mood: widget.mood,
            labels: _labels,
            hits: _hits,
          ),
        ),
      ),
    );
  }
}
