import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:share_plus/share_plus.dart';

import '../common/crest.dart';

/// Lien d'installation partagé avec chaque carte.
const String kStoreLink =
    'https://play.google.com/store/apps/details?id=com.clubowner.club_owner';

/// Contenu d'une carte à partager (résultat, trophée, recrue, classement).
class ShareContent {
  const ShareContent({
    required this.kicker,
    required this.headline,
    required this.detail,
    required this.message,
    this.club,
    this.opponent,
    this.color = const Color(0xFFF5C04A),
    this.icon = Icons.emoji_events,
  });

  /// Petit titre (« RÉSULTAT », « CHAMPION »...).
  final String kicker;

  /// Grande ligne (« 2 - 1 », « Ligue 1 »...).
  final String headline;
  final String detail;

  /// Texte qui accompagne l'image dans WhatsApp, TikTok, Facebook...
  final String message;
  final String? club;
  final String? opponent;
  final Color color;
  final IconData icon;
}

/// Aperçu de la carte, puis partage de l'image avec le lien du jeu.
Future<void> showShareCard(BuildContext context, ShareContent content) {
  return showDialog<void>(
    context: context,
    builder: (_) => _ShareDialog(content: content),
  );
}

class _ShareDialog extends StatefulWidget {
  const _ShareDialog({required this.content});

  final ShareContent content;

  @override
  State<_ShareDialog> createState() => _ShareDialogState();
}

class _ShareDialogState extends State<_ShareDialog> {
  final GlobalKey _key = GlobalKey();
  bool _busy = false;

  Future<void> _share() async {
    setState(() => _busy = true);
    final c = widget.content;
    final text = '${c.message}\n\nJoue toi aussi à Club Owner : $kStoreLink';
    try {
      final boundary =
          _key.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null) throw StateError('carte absente');
      final image = await boundary.toImage(pixelRatio: 3);
      final data = await image.toByteData(format: ui.ImageByteFormat.png);
      if (data == null) throw StateError('image vide');
      await SharePlus.instance.share(
        ShareParams(
          text: text,
          files: [
            XFile.fromData(
              data.buffer.asUint8List(),
              mimeType: 'image/png',
              name: 'club_owner.png',
            ),
          ],
        ),
      );
    } catch (_) {
      // Repli : le texte seul.
      try {
        await SharePlus.instance.share(ShareParams(text: text));
      } catch (_) {}
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF0B1A12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            RepaintBoundary(
              key: _key,
              child: ShareCardView(content: widget.content),
            ),
            const SizedBox(width: 14),
            Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                FilledButton.icon(
                  onPressed: _busy ? null : _share,
                  icon: _busy
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.share),
                  label: const Text('Partager'),
                ),
                const SizedBox(height: 6),
                const Text(
                  'WhatsApp, TikTok,\nFacebook, Instagram…',
                  style: TextStyle(color: Colors.white54, fontSize: 11),
                ),
                const SizedBox(height: 10),
                TextButton(
                  onPressed: () => Navigator.of(context).maybePop(),
                  child: const Text('Fermer'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// La carte elle-même (format carré, lisible en story).
class ShareCardView extends StatelessWidget {
  const ShareCardView({required this.content, super.key});

  final ShareContent content;

  @override
  Widget build(BuildContext context) {
    final c = content;
    return Container(
      width: 260,
      height: 260,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color.lerp(c.color, Colors.black, 0.45)!,
            const Color(0xFF07140D),
          ],
        ),
        border: Border.all(color: c.color, width: 2),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            children: [
              Icon(c.icon, color: c.color, size: 22),
              const SizedBox(width: 8),
              Text(
                c.kicker,
                style: TextStyle(
                  color: c.color,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
          const Spacer(),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (c.club != null) ClubCrest(name: c.club!, size: 46),
              if (c.opponent != null) ...[
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Text(
                    c.headline,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 34,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                ClubCrest(name: c.opponent!, size: 46),
              ],
            ],
          ),
          if (c.opponent == null) ...[
            const SizedBox(height: 10),
            Text(
              c.headline,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 28,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
          const SizedBox(height: 10),
          Text(
            c.detail,
            textAlign: TextAlign.center,
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.white70, fontSize: 13),
          ),
          const Spacer(),
          Row(
            children: [
              Image.asset('assets/branding/logo.png', width: 26, height: 26,
                  errorBuilder: (context, e, s) => const SizedBox(width: 26)),
              const SizedBox(width: 8),
              const Expanded(
                child: Text(
                  'CLUB OWNER · Deviens président',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
