import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/cloud/cloud_save.dart';
import '../../core/cloud/online_league.dart';
import '../../domain/entities/division.dart';
import '../../engine/game/game_state.dart';
import '../cloud/google_account_card.dart';
import '../common/crest.dart';
import '../common/pro_page.dart';
import '../game/game_state.dart';
import '../share/share_card.dart';

/// Ligue des présidents : classement mondial et ligues privées entre amis.
class OnlinePage extends ConsumerStatefulWidget {
  const OnlinePage({super.key});

  @override
  ConsumerState<OnlinePage> createState() => _OnlinePageState();
}

class _OnlinePageState extends ConsumerState<OnlinePage> {
  int _tab = 0;
  final _code = TextEditingController();
  final _name = TextEditingController();
  bool _loaded = false;

  @override
  void dispose() {
    _code.dispose();
    _name.dispose();
    super.dispose();
  }

  void _load() {
    final game = ref.read(gameProvider);
    if (game == null) return;
    ref.read(onlineProvider.notifier).refresh(game);
  }

  @override
  Widget build(BuildContext context) {
    final cloud = ref.watch(cloudProvider);
    final online = ref.watch(onlineProvider);
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();
    if (cloud.signedIn && !_loaded) {
      _loaded = true;
      WidgetsBinding.instance.addPostFrameCallback((_) => _load());
    }
    ref.listen(onlineProvider, (prev, next) {
      final m = next.message;
      if (m != null && m != prev?.message) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
      }
    });
    final myUid = online.me?.uid;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ligue des présidents'),
        actions: [
          if (cloud.signedIn)
            IconButton(
              tooltip: 'Actualiser',
              onPressed: online.busy ? null : _load,
              icon: const Icon(Icons.refresh),
            ),
        ],
      ),
      body: !cloud.signedIn
          ? Center(
              child: SizedBox(
                width: 520,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.public, size: 54, color: Color(0xFFF5C04A)),
                    const SizedBox(height: 10),
                    const Text(
                      'Affrontez les présidents du monde entier et défiez vos '
                      'amis dans des ligues privées. Connectez-vous avec Google '
                      'pour entrer dans le classement.',
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    const GoogleAccountCard(),
                  ],
                ),
              ),
            )
          : ProColumns(
              flex: const [2, 3],
              columns: [[
                _MyCard(game: game, online: online),
                const SizedBox(height: 12),
                ProCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text('Rejoindre une ligue',
                          style: TextStyle(fontWeight: FontWeight.w800)),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: _code,
                              textCapitalization: TextCapitalization.characters,
                              maxLength: 6,
                              decoration: const InputDecoration(
                                hintText: 'Code à 6 caractères',
                                counterText: '',
                                isDense: true,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          FilledButton(
                            onPressed: online.busy
                                ? null
                                : () => ref
                                    .read(onlineProvider.notifier)
                                    .joinLeague(_code.text, game),
                            child: const Text('Rejoindre'),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      const Text('Créer une ligue entre amis',
                          style: TextStyle(fontWeight: FontWeight.w800)),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: _name,
                              maxLength: 30,
                              decoration: const InputDecoration(
                                hintText: 'Nom de la ligue',
                                counterText: '',
                                isDense: true,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          FilledButton.tonal(
                            onPressed: online.busy
                                ? null
                                : () async {
                                    final code = await ref
                                        .read(onlineProvider.notifier)
                                        .createLeague(_name.text, game);
                                    if (code != null && context.mounted) {
                                      _invite(context, code, game.userClub.name);
                                    }
                                  },
                            child: const Text('Créer'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
              [
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                  children: [
                    ChoiceChip(
                      label: const Text('Mondial'),
                      selected: _tab == 0,
                      onSelected: (_) => setState(() => _tab = 0),
                    ),
                    const SizedBox(width: 6),
                    for (var i = 0; i < online.leagues.length; i++)
                      Padding(
                        padding: const EdgeInsets.only(right: 6),
                        child: ChoiceChip(
                          label: Text(online.leagues[i].name),
                          selected: _tab == i + 1,
                          onSelected: (_) => setState(() => _tab = i + 1),
                        ),
                      ),
                  ],
                ),
                ),
                const SizedBox(height: 8),
                if (online.busy) const LinearProgressIndicator(),
                if (_tab > 0 && _tab <= online.leagues.length) ...[
                  _LeagueHeader(
                    league: online.leagues[_tab - 1],
                    onInvite: () => _invite(
                      context,
                      online.leagues[_tab - 1].code,
                      game.userClub.name,
                    ),
                    onLeave: () {
                      final code = online.leagues[_tab - 1].code;
                      setState(() => _tab = 0);
                      ref.read(onlineProvider.notifier).leaveLeague(code, game);
                    },
                  ),
                  _Table(
                    rows: online.standings[online.leagues[_tab - 1].code] ??
                        const [],
                    myUid: myUid,
                  ),
                ] else
                  _Table(rows: online.global, myUid: myUid),
              ]],
            ),
    );
  }

  void _invite(BuildContext context, String code, String club) {
    Clipboard.setData(ClipboardData(text: code));
    showShareCard(
      context,
      ShareContent(
        kicker: 'LIGUE PRIVÉE',
        headline: code,
        detail: 'Rejoins ma ligue de présidents sur Club Owner avec ce code.',
        message: 'Je te défie dans ma ligue de présidents sur Club Owner ! '
            'Code de la ligue : $code',
        club: club,
        icon: Icons.groups,
      ),
    );
  }
}

class _MyCard extends StatelessWidget {
  const _MyCard({required this.game, required this.online});

  final GameState game;
  final OnlineState online;

  @override
  Widget build(BuildContext context) {
    final score = presidentScore(game);
    final globalRank = online.me == null
        ? null
        : online.global.indexWhere((e) => e.uid == online.me!.uid);
    return ProCard(
      child: Row(
        children: [
          ClubCrest(name: game.userClub.name, size: 44),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(game.userClub.name,
                    style: const TextStyle(fontWeight: FontWeight.w900)),
                Text('Indice Président : $score',
                    style: const TextStyle(color: Color(0xFFF5C04A))),
                Text(
                  globalRank == null || globalRank < 0
                      ? 'Hors du top 50 mondial'
                      : '${globalRank + 1}e au classement mondial',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
          IconButton(
            tooltip: 'Partager',
            icon: const Icon(Icons.share),
            onPressed: () => showShareCard(
              context,
              ShareContent(
                kicker: 'INDICE PRÉSIDENT',
                headline: '$score',
                detail: '${game.userClub.name} · '
                    '${divisionName(game.division)} · saison ${game.seasonNumber}',
                message: 'Mon Indice Président sur Club Owner : $score. '
                    'Tu fais mieux ?',
                club: game.userClub.name,
                icon: Icons.workspace_premium,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _LeagueHeader extends StatelessWidget {
  const _LeagueHeader({
    required this.league,
    required this.onInvite,
    required this.onLeave,
  });

  final LeagueInfo league;
  final VoidCallback onInvite;
  final VoidCallback onLeave;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          Text('Code : ${league.code}',
              style: const TextStyle(fontWeight: FontWeight.w800)),
          const Spacer(),
          TextButton.icon(
            onPressed: onInvite,
            icon: const Icon(Icons.person_add, size: 18),
            label: const Text('Inviter'),
          ),
          TextButton(onPressed: onLeave, child: const Text('Quitter')),
        ],
      ),
    );
  }
}

class _Table extends StatelessWidget {
  const _Table({required this.rows, required this.myUid});

  final List<PresidentEntry> rows;
  final String? myUid;

  @override
  Widget build(BuildContext context) {
    if (rows.isEmpty) {
      return const ProEmpty(
        icon: Icons.leaderboard,
        title: 'Classement vide',
        message: 'Actualisez dans un instant.',
      );
    }
    return ProCard(
      padding: EdgeInsets.zero,
      child: Column(
        children: [
          for (var i = 0; i < rows.length; i++)
            ListTile(
              dense: true,
              tileColor: rows[i].uid == myUid
                  ? const Color(0x33F5C04A)
                  : null,
              leading: SizedBox(
                width: 64,
                child: Row(
                  children: [
                    SizedBox(
                      width: 24,
                      child: Text('${i + 1}',
                          style: const TextStyle(fontWeight: FontWeight.w900)),
                    ),
                    ClubCrest(name: rows[i].club, size: 26),
                  ],
                ),
              ),
              title: Text('${rows[i].club} · ${rows[i].name}',
                  maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: Text(
                '${divisionName(rows[i].division)} · saison ${rows[i].season}'
                '${rows[i].titles > 0 ? ' · ${rows[i].titles} titre(s)' : ''}',
              ),
              trailing: Text(
                '${rows[i].score}',
                style: const TextStyle(
                  fontWeight: FontWeight.w900,
                  color: Color(0xFFF5C04A),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
