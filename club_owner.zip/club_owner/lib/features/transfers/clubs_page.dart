import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../domain/entities/club.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/tactic.dart';
import '../../engine/world/facilities.dart';
import '../common/crest.dart';
import '../common/stadium_view.dart';
import '../common/widgets.dart';
import '../common/pro_page.dart';
import '../game/game_state.dart';
import '../squad/player_sheet.dart';
import 'recruit_dialog.dart';

double _overall(Club club) {
  final s = club.matchStrength;
  return (s.attack + s.midfield + s.defense + s.goalkeeper) / 4;
}

/// Liste des clubs du championnat.
class ClubsPage extends ConsumerWidget {
  const ClubsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();

    final standings = game.season.standings;
    final rankOf = {
      for (var i = 0; i < standings.length; i++) standings[i].clubId: i + 1,
    };
    final clubs = [...game.season.clubs]
      ..sort((a, b) => (rankOf[a.id] ?? 99).compareTo(rankOf[b.id] ?? 99));

    return Scaffold(
      appBar: AppBar(title: const Text('Clubs du championnat')),
      body: ProColumns(
        columns: ProColumns.split([
          for (final club in clubs)
            ListTile(
              leading: ClubCrest(name: club.name, size: 36),
              title: Text(club.name),
              subtitle: Text(
                '${rankOf[club.id]}e au classement, '
                'prestige ${club.prestige}, force ${_overall(club).round()}',
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                if (club.isUser) {
                  context.go('/squad');
                } else {
                  context.push('/clubs/${club.id}');
                }
              },
            ),
        ], 2),
      ),
    );
  }
}

/// Effectif complet d'un club adverse, avec possibilité d'offre.
class ClubDetailPage extends ConsumerWidget {
  const ClubDetailPage({required this.clubId, super.key});

  final String clubId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();
    final matches = game.everyClub.where((c) => c.id == clubId);
    if (matches.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('Club')),
        body: const Center(child: Text('Club introuvable.')),
      );
    }
    final club = matches.first;
    final theme = Theme.of(context);

    List<Widget> section(String title, List<Player> players) {
      if (players.isEmpty) return const [];
      final sorted = [...players]..sort((a, b) => b.skill.compareTo(a.skill));
      return [
        SectionTitle('$title (${sorted.length})'),
        for (final player in sorted)
          PlayerRow(
            player: player,
            showPotential: game.scouts.isNotEmpty,
            trailing: const Icon(Icons.local_offer_outlined),
            onTap: () => _open(context, ref, player),
          ),
      ];
    }

    return Scaffold(
      appBar: AppBar(title: Text(club.name)),
      body: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                ClubCrest(name: club.name, size: 56),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(club.name, style: theme.textTheme.titleLarge),
                      Text('Prestige : ${club.prestige} sur 100'),
                      Text('Formation : ${club.tactic.formation.label}'),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: _StadiumCard(club: club),
          ),
          const SizedBox(height: 8),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              'Touchez un joueur pour voir sa fiche et faire une offre. '
              'Votre directeur sportif mène la négociation.',
            ),
          ),
          ...section('Équipe première', club.squad),
          ...section('Équipe réserve', club.reserve),
          ...section('Centre de formation', club.academy),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  void _open(BuildContext context, WidgetRef ref, Player player) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (sheetContext) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(player.name, style: Theme.of(sheetContext).textTheme.titleLarge),
              const SizedBox(height: 8),
              playerStatsBlock(sheetContext, player),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: () {
                  Navigator.of(sheetContext).pop();
                  showRecruitDialog(context, ref, player);
                },
                icon: const Icon(Icons.person_search),
                label: const Text('Signaler au directeur sportif'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StadiumCard extends StatelessWidget {
  const _StadiumCard({required this.club});

  final Club club;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final facilities = facilitiesOf(club);
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            StadiumView(owner: facilities.toOwnerState()),
            const SizedBox(height: 8),
            Text(facilities.stadiumName, style: theme.textTheme.titleMedium),
            Text(
              '${facilities.capacity} places · '
              '${facilities.supporters ~/ 1000} k supporters · '
              'fan zone ${facilities.fanZone}, parking ${facilities.parking}, '
              'boutique ${facilities.shop}',
              style: theme.textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}
