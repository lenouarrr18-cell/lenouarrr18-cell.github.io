import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/utils/format.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/transfer.dart';
import '../../engine/finance/finance.dart';
import '../../engine/transfers/negotiation.dart';
import '../common/labels.dart';
import '../game/game_state.dart';

/// Boîte de dialogue pour envoyer une offre à un autre club. Le directeur
/// sportif mène la négociation ; le club vendeur répond tout de suite.
Future<void> showOfferDialog(
  BuildContext context,
  WidgetRef ref,
  Player player,
) async {
  await showDialog<void>(
    context: context,
    builder: (_) => _OfferDialog(player: player, parentContext: context),
  );
}

class _OfferDialog extends ConsumerStatefulWidget {
  const _OfferDialog({required this.player, required this.parentContext});

  final Player player;
  final BuildContext parentContext;

  @override
  ConsumerState<_OfferDialog> createState() => _OfferDialogState();
}

class _OfferDialogState extends ConsumerState<_OfferDialog> {
  late OfferKind _kind;
  late final TextEditingController _fee;
  late final TextEditingController _option;

  @override
  void initState() {
    super.initState();
    _kind = OfferKind.transfer;
    _fee = TextEditingController(
      text: '${roundThousand(playerValue(widget.player) * 1.05)}',
    );
    _option = TextEditingController(
      text: '${roundThousand(playerValue(widget.player) * 1.1)}',
    );
  }

  @override
  void dispose() {
    _fee.dispose();
    _option.dispose();
    super.dispose();
  }

  void _setKind(OfferKind kind) {
    setState(() {
      _kind = kind;
      final value = playerValue(widget.player);
      _fee.text = kind == OfferKind.transfer
          ? '${roundThousand(value * 1.05)}'
          : '${roundThousand(value * 0.15)}';
    });
  }

  void _send() {
    final fee = int.tryParse(_fee.text.replaceAll(' ', '')) ?? 0;
    final option = int.tryParse(_option.text.replaceAll(' ', '')) ?? 0;
    final notifier = ref.read(gameProvider.notifier);
    final error = notifier.makeOffer(
      playerId: widget.player.id,
      kind: _kind,
      fee: fee,
      optionFee: _kind == OfferKind.loanOption ? option : 0,
    );
    final messenger = ScaffoldMessenger.of(widget.parentContext);
    Navigator.of(context).pop();
    if (error != null) {
      messenger.showSnackBar(SnackBar(content: Text(error)));
      return;
    }
    final game = ref.read(gameProvider);
    final offer = game?.offers
        .where((o) => !o.incoming && o.playerId == widget.player.id)
        .lastOrNull;
    String text;
    if (offer == null) {
      text = 'Offre envoyée.';
    } else if (offer.status == OfferStatus.accepted) {
      text = '${widget.player.name} rejoint le club !';
    } else if (offer.status == OfferStatus.countered) {
      text = 'Le club demande ${formatMoney(offer.counterFee)}. '
          'Répondez dans Transferts, onglet Offres.';
    } else {
      text = offer.reason.isEmpty ? 'Offre refusée.' : offer.reason;
    }
    messenger.showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    final player = widget.player;
    final isOption = _kind == OfferKind.loanOption;
    return AlertDialog(
      title: Text('Offre pour ${player.name}'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Valeur estimée : ${formatMoney(playerValue(player))}. '
              'Plus l\'offre est haute, plus le club et le joueur sont '
              'enclins à accepter.',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: [
                for (final kind in OfferKind.values)
                  ChoiceChip(
                    label: Text(offerKindLabel(kind)),
                    selected: _kind == kind,
                    onSelected: (_) => _setKind(kind),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _fee,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: _kind == OfferKind.transfer
                    ? 'Montant du transfert (€)'
                    : 'Indemnité de prêt (€)',
              ),
            ),
            if (isOption) ...[
              const SizedBox(height: 8),
              TextField(
                controller: _option,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: "Prix de l'option d'achat (€)",
                ),
              ),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Annuler'),
        ),
        FilledButton(onPressed: _send, child: const Text('Envoyer')),
      ],
    );
  }
}
