import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/utils/format.dart';
import '../../domain/entities/player.dart';
import '../game/game_state.dart';

/// Le président signale un joueur : il fixe un budget, le directeur sportif
/// négocie et le manager donne son avis.
Future<void> showRecruitDialog(
  BuildContext context,
  WidgetRef ref,
  Player player,
) async {
  await showDialog<void>(
    context: context,
    builder: (_) => _RecruitDialog(player: player, parentContext: context),
  );
}

class _RecruitDialog extends ConsumerStatefulWidget {
  const _RecruitDialog({required this.player, required this.parentContext});

  final Player player;
  final BuildContext parentContext;

  @override
  ConsumerState<_RecruitDialog> createState() => _RecruitDialogState();
}

class _RecruitDialogState extends ConsumerState<_RecruitDialog> {
  bool _loan = false;
  double? _budget;

  @override
  Widget build(BuildContext context) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();
    final theme = Theme.of(context);
    final p = widget.player;
    final free = game.isFreeAgent(p.id);
    final expected = game.expectedFee(p.id, loan: _loan);
    final view = game.coachOpinion(p);
    final treasury = game.finance.treasury;
    final maxSlider = (treasury < 1000 ? 1000 : treasury).toDouble();
    final minSlider = (expected * 0.6).clamp(1000, maxSlider).toDouble();
    final budget = (_budget ?? (expected * 1.1)).clamp(minSlider, maxSlider).toDouble();
    final ds = game.sportingDirector;
    final verdictColor = view.verdict == 2
        ? const Color(0xFF66BB6A)
        : (view.verdict == 1 ? const Color(0xFFFFB74D) : const Color(0xFFEF5350));

    return AlertDialog(
      title: Text('Signaler ${p.name}'),
      content: SizedBox(
        width: 420,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                ds == null
                    ? 'Vous n\'avez pas de directeur sportif : engagez-en un, '
                        'c\'est lui qui négocie les transferts.'
                    : 'Vous ne négociez pas vous-même : ${ds.name} mènera les '
                        'discussions dans la limite de votre budget.',
                style: theme.textTheme.bodySmall,
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: verdictColor.withAlpha(30),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: verdictColor.withAlpha(120)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.sports, color: verdictColor),
                    const SizedBox(width: 8),
                    Expanded(child: Text(view.note)),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              if (!free)
                SegmentedButton<bool>(
                  segments: const [
                    ButtonSegment(value: false, label: Text('Transfert')),
                    ButtonSegment(value: true, label: Text('Prêt')),
                  ],
                  selected: {_loan},
                  onSelectionChanged: (s) => setState(() {
                    _loan = s.first;
                    _budget = null;
                  }),
                ),
              const SizedBox(height: 10),
              Text(
                free
                    ? 'Agent libre : il demande environ ${formatMoney(expected)}.'
                    : 'Estimation du directeur sportif : ${formatMoney(expected)}.',
              ),
              const SizedBox(height: 6),
              Text(
                'Budget maximum : ${formatMoney(budget.round())}',
                style: theme.textTheme.titleMedium,
              ),
              Slider(
                value: budget,
                min: minSlider,
                max: maxSlider,
                onChanged: maxSlider > minSlider
                    ? (v) => setState(() => _budget = v)
                    : null,
              ),
              Text(
                'Trésorerie : ${formatMoney(treasury)}',
                style: theme.textTheme.bodySmall,
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Annuler'),
        ),
        FilledButton.icon(
          onPressed: ds == null
              ? null
              : () {
                  final rounded = (budget / 1000).round() * 1000;
                  final error = ref
                      .read(gameProvider.notifier)
                      .requestRecruit(p.id, rounded, loan: _loan);
                  Navigator.of(context).pop();
                  ScaffoldMessenger.of(widget.parentContext).showSnackBar(
                    SnackBar(
                      content: Text(
                        error ??
                            (view.verdict == 0
                                ? 'Le manager s\'y oppose : dossier suspendu.'
                                : 'Dossier transmis au directeur sportif.'),
                      ),
                    ),
                  );
                },
          icon: const Icon(Icons.send),
          label: const Text('Transmettre'),
        ),
      ],
    );
  }
}
