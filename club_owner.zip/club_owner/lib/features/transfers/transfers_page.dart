import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/utils/format.dart';
import '../../domain/entities/owner.dart';
import '../../domain/entities/player.dart';
import '../../domain/entities/transfer.dart';
import '../../engine/finance/finance.dart';
import '../common/crest.dart';
import '../common/labels.dart';
import '../common/pro_page.dart';
import 'recruit_dialog.dart';
import '../common/widgets.dart';
import '../game/game_state.dart';
import '../squad/player_sheet.dart';

/// Centre des transferts : agents libres, clubs, offres et prêts.
class TransfersPage extends ConsumerWidget {
  const TransfersPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();

    final waiting = game.offers
        .where((o) => o.incoming || o.status == OfferStatus.countered)
        .length;

    final open = game.transferWindowOpen;
    return ProPage(
      title: 'Mercato',
      subtitle: game.transferWindowMessage,
      icon: Icons.swap_horiz,
      accent: const Color(0xFF1E88E5),
      stats: [
        ProStat('Trésorerie', formatMoney(game.finance.treasury),
            icon: Icons.account_balance_wallet_outlined),
        ProStat('Fenêtre', open ? 'Ouverte' : 'Fermée',
            icon: open ? Icons.lock_open : Icons.lock_outline,
            color: open ? const Color(0xFF66BB6A) : const Color(0xFFEF5350)),
        ProStat('Offres', '$waiting', icon: Icons.mail_outline),
        ProStat('Agents libres', '${game.market.length}',
            icon: Icons.person_search_outlined),
        ProStat('Effectif', '${game.userClub.squad.length}',
            icon: Icons.groups_outlined),
        ProStat('Recruteurs', '${game.scouts.length}',
            icon: Icons.travel_explore),
      ],
      banner: Container(
        width: double.infinity,
        color: open ? const Color(0xFF1B5E20) : const Color(0xFF8E2A1E),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Row(
          children: [
            Icon(open ? Icons.lock_open : Icons.lock_outline,
                size: 16, color: Colors.white),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                game.transferWindowMessage,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
      tabs: [
        ProTab('Agents libres', _FreeAgents(game: game),
            icon: Icons.person_search_outlined),
        ProTab('Clubs', _ClubsTab(game: game), icon: Icons.shield_outlined),
        ProTab(waiting > 0 ? 'Offres ($waiting)' : 'Offres',
            _OffersTab(game: game),
            icon: Icons.mail_outline),
        ProTab('Prêts', _LoansTab(game: game), icon: Icons.sync_alt),
      ],
    );
  }
}

class _FreeAgents extends ConsumerWidget {
  const _FreeAgents({required this.game});

  final GameState game;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final players = [...game.market]
      ..sort((a, b) => b.maxSkill.compareTo(a.maxSkill));
    final scouting = game.scouts.isNotEmpty;

    return ListView(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Trésorerie : ${formatMoney(game.finance.treasury)}',
                style: theme.textTheme.titleMedium,
              ),
              const SizedBox(height: 4),
              Text(
                scouting
                    ? 'Vos recruteurs révèlent le potentiel des joueurs. '
                        'Lancez une prospection depuis le Staff.'
                    : 'Sans recruteur, le potentiel des joueurs reste '
                        'inconnu. Engagez des recruteurs depuis le Staff.',
                style: theme.textTheme.bodySmall,
              ),
            ],
          ),
        ),
        if (players.isEmpty)
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('Aucun agent libre pour le moment.'),
          ),
        for (final player in players)
          PlayerRow(
            player: player,
            showPotential: scouting,
            trailing: const Icon(Icons.add_circle_outline),
            onTap: () => _openFreeAgent(context, ref, player.id),
          ),
      ],
    );
  }

  void _openFreeAgent(BuildContext context, WidgetRef ref, String playerId) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (_) => _FreeAgentSheet(playerId: playerId),
    );
  }
}

class _FreeAgentSheet extends ConsumerWidget {
  const _FreeAgentSheet({required this.playerId});

  final String playerId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();
    final matches = game.market.where((p) => p.id == playerId);
    if (matches.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(24),
        child: Text("Ce joueur n'est plus disponible."),
      );
    }
    final player = matches.first;
    final theme = Theme.of(context);
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(player.name, style: theme.textTheme.titleLarge),
            Text(
              '${positionLabel(player.position)}, ${player.age} ans, '
              '${player.nation}',
            ),
            const SizedBox(height: 12),
            playerStatsBlock(
              context,
              game.scouts.isEmpty ? player.copyWith(potential: player.skill) : player,
              full: false,
            ),
            const SizedBox(height: 4),
            Text(
              'Prix : ${formatMoney(playerValue(player))}',
              style: theme.textTheme.titleMedium,
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: () => showRecruitDialog(context, ref, player),
              icon: const Icon(Icons.person_search),
              label: const Text('Signaler au directeur sportif'),
            ),
          ],
        ),
      ),
    );
  }
}

class _ClubsTab extends StatelessWidget {
  const _ClubsTab({required this.game});

  final GameState game;

  @override
  Widget build(BuildContext context) {
    final clubs = game.otherClubs..sort((a, b) => b.prestige.compareTo(a.prestige));
    return ListView(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Text(
            game.sportingDirector == null
                ? 'Engagez un directeur sportif pour négocier avec les '
                    'autres clubs.'
                : 'Choisissez un club, puis un joueur pour faire une offre : '
                    'transfert, prêt ou prêt avec option d\'achat.',
          ),
        ),
        ListTile(
          leading: const Icon(Icons.public),
          title: const Text('Championnats du monde'),
          subtitle: const Text(
            'Autres divisions et autres pays : cherchez des joueurs partout.',
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => context.push('/leagues'),
        ),
        for (final club in clubs)
          ListTile(
            leading: ClubCrest(name: club.name, size: 36),
            title: Text(club.name),
            subtitle: Text(
              'Prestige ${club.prestige}, '
              '${club.squad.length + club.reserve.length + club.academy.length} '
              'joueurs',
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => context.push('/clubs/${club.id}'),
          ),
      ],
    );
  }
}

class _OffersTab extends ConsumerWidget {
  const _OffersTab({required this.game});

  final GameState game;

  String _clubName(String id) {
    for (final c in game.season.clubs) {
      if (c.id == id) return c.name;
    }
    return 'Club';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final offers = [...game.offers]..sort((a, b) => b.round.compareTo(a.round));
    final recruits = game.owner.recruits;
    if (offers.isEmpty && recruits.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'Aucun dossier en cours. Signalez un joueur à votre directeur '
            'sportif depuis la liste des agents libres ou la fiche d\'un club.',
            textAlign: TextAlign.center,
          ),
        ),
      );
    }
    final notifier = ref.read(gameProvider.notifier);

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        if (recruits.isNotEmpty) ...[
          const ProSection('Dossiers confiés au directeur sportif'),
          ProGrid(
            minWidth: 320,
            children: [
              for (final r in recruits.take(8)) _RecruitCard(request: r),
            ],
          ),
          const ProSection('Offres'),
        ],
        for (final offer in offers)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${offer.playerName} : ${offerKindLabel(offer.kind)}',
                    style: theme.textTheme.titleSmall,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    offer.incoming
                        ? '${_clubName(offer.buyerClubId)} propose '
                            '${formatMoney(offer.fee)}'
                        : 'Offre à ${_clubName(offer.sellerClubId)} : '
                            '${formatMoney(offer.fee)}',
                  ),
                  if (offer.kind == OfferKind.loanOption)
                    Text("Option d'achat : ${formatMoney(offer.optionFee)}"),
                  Text(
                    'Statut : ${offerStatusLabel(offer.status)}',
                    style: theme.textTheme.bodySmall,
                  ),
                  if (offer.reason.isNotEmpty)
                    Text(offer.reason, style: theme.textTheme.bodySmall),
                  if (offer.status == OfferStatus.countered)
                    Text(
                      'Le club demande ${formatMoney(offer.counterFee)}',
                      style: theme.textTheme.bodyMedium,
                    ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      if (offer.incoming && offer.status == OfferStatus.pending) ...[
                        FilledButton(
                          onPressed: () => _toast(
                            context,
                            notifier.respondIncoming(offer.id, accept: true),
                            'Offre acceptée.',
                          ),
                          child: const Text('Accepter'),
                        ),
                        OutlinedButton(
                          onPressed: () => _toast(
                            context,
                            notifier.respondIncoming(offer.id, accept: false),
                            'Offre refusée.',
                          ),
                          child: const Text('Refuser'),
                        ),
                      ],
                      if (!offer.incoming &&
                          offer.status == OfferStatus.countered)
                        const ProTag(
                          'Le directeur sportif négocie',
                          icon: Icons.handshake_outlined,
                          color: Color(0xFFFFB74D),
                        ),
                      if (!offer.incoming &&
                          (offer.status == OfferStatus.rejected ||
                              offer.status == OfferStatus.accepted))
                        TextButton(
                          onPressed: () => notifier.withdrawOffer(offer.id),
                          child: const Text('Effacer'),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }

  void _toast(BuildContext context, String? error, String done) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(error ?? done)),
    );
  }

  Future<void> _raise(BuildContext context, WidgetRef ref, Offer offer) async {
    final controller = TextEditingController(text: '${offer.counterFee}');
    final value = await showDialog<int>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text('Relancer pour ${offer.playerName}'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Nouveau montant (€)'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Annuler'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(
              int.tryParse(controller.text.replaceAll(' ', '')) ?? 0,
            ),
            child: const Text('Envoyer'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (value == null) return;
    final error = ref.read(gameProvider.notifier).raiseOffer(offer.id, value);
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(error ?? 'Nouvelle offre envoyée.')),
    );
  }
}

class _LoansTab extends ConsumerWidget {
  const _LoansTab({required this.game});

  final GameState game;

  String _clubName(String id) {
    for (final c in game.season.clubs) {
      if (c.id == id) return c.name;
    }
    return 'Club';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (game.loans.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'Aucun prêt en cours. Les prêts se terminent à la fin de la '
            'saison.',
            textAlign: TextAlign.center,
          ),
        ),
      );
    }
    return ListView(
      children: [
        for (final loan in game.loans)
          ListTile(
            leading: const Icon(Icons.swap_horiz),
            title: Text(loan.playerName),
            subtitle: Text(
              loan.ownerClubId == 'user'
                  ? 'Prêté à ${_clubName(loan.borrowerClubId)}'
                  : 'Prêté par ${_clubName(loan.ownerClubId)}',
            ),
            trailing: loan.borrowerClubId == 'user' && loan.optionFee > 0
                ? FilledButton.tonal(
                    onPressed: () {
                      final error = ref
                          .read(gameProvider.notifier)
                          .exerciseOption(loan.playerId);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(error ?? 'Option d\'achat levée.'),
                        ),
                      );
                    },
                    child: Text('Acheter ${formatMoney(loan.optionFee)}'),
                  )
                : (loan.optionFee > 0
                    ? Text('Option ${formatMoney(loan.optionFee)}')
                    : null),
          ),
      ],
    );
  }
}

class _RecruitCard extends ConsumerWidget {
  const _RecruitCard({required this.request});

  final RecruitRequest request;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final r = request;
    final (label, color) = switch (r.status) {
      RecruitStatus.pending => ('En négociation', const Color(0xFFFFB74D)),
      RecruitStatus.done => ('Signé', const Color(0xFF66BB6A)),
      RecruitStatus.failed => ('Échec', const Color(0xFFEF5350)),
      RecruitStatus.refusedByCoach => ('Refus du manager', const Color(0xFFEF5350)),
      RecruitStatus.cancelled => ('Abandonné', const Color(0xFF90A4AE)),
    };
    final notifier = ref.read(gameProvider.notifier);
    return ProCard(
      highlight: r.open,
      accent: color,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  r.playerName,
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              ProTag(label, color: color),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            '${r.loan ? 'Prêt' : 'Transfert'} · budget ${formatMoney(r.maxFee)}',
            style: theme.textTheme.bodySmall,
          ),
          if (r.coachNote.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(r.coachNote, style: theme.textTheme.bodySmall),
            ),
          if (r.report.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                r.report,
                style: theme.textTheme.bodySmall?.copyWith(
                  fontStyle: FontStyle.italic,
                ),
              ),
            ),
          if (r.open || r.status == RecruitStatus.refusedByCoach)
            Wrap(
              spacing: 8,
              children: [
                if (r.status == RecruitStatus.refusedByCoach)
                  TextButton(
                    onPressed: () => notifier.insistRecruit(r.id),
                    child: const Text('Insister'),
                  ),
                TextButton(
                  onPressed: () => notifier.cancelRecruit(r.id),
                  child: const Text('Abandonner'),
                ),
              ],
            ),
        ],
      ),
    );
  }
}
