import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/utils/format.dart';
import '../../domain/entities/staff.dart';
import '../../engine/game/game_state.dart';
import '../../engine/game/owner_actions.dart';
import '../../engine/owner/infrastructure.dart';
import '../game/game_state.dart';

/// Introduction narrative de début de carrière, adaptée au vrai club.
class IntroPage extends ConsumerStatefulWidget {
  const IntroPage({super.key});

  @override
  ConsumerState<IntroPage> createState() => _IntroPageState();
}

class _IntroPageState extends ConsumerState<IntroPage> {
  int _index = 0;

  List<_Slide> _slides(GameState g) {
    final name = g.userClub.name;
    final o = g.owner;
    final sd = g.sportingDirector;
    final manager = g.staffOf(StaffRole.manager);
    final scout = g.staffOf(StaffRole.scout);
    final stadium = o.stadiumName.isEmpty ? 'le stade' : o.stadiumName;
    return [
      _Slide(
        Icons.flag_outlined,
        'Bienvenue à la présidence',
        'Vous êtes désormais propriétaire et président de $name, à '
            '${g.city.name} (${g.country.name}). Vous n\'êtes pas '
            'l\'entraîneur : votre rôle est de développer le club, d\'assurer '
            'sa stabilité financière, de construire une équipe compétitive '
            'et de faire grandir ses infrastructures.',
      ),
      _Slide(
        Icons.account_balance_wallet_outlined,
        'La situation du club',
        'Division ${g.division}. Trésorerie : ${formatMoney(g.finance.treasury)}. '
            'Effectif : ${g.userClub.squad.length} joueurs. '
            'Réputation : ${o.reputation}/100. '
            'Le conseil attend au minimum une ${g.boardObjective}e place.\n\n'
            'Votre stade, $stadium, accueille ${stadiumCapacity(o.stadium)} '
            'spectateurs.',
      ),
      _Slide(
        Icons.groups_2_outlined,
        'Première réunion de direction',
        'Votre équipe dirigeante se présente :\n\n'
            '• Directeur sportif : ${sd == null ? "à recruter. Il gérera les transferts" : "${sd.name}. Il gère transferts, ventes et prêts"} '
            'et vous soumet ses décisions : vous pouvez les bloquer.\n'
            '• Entraîneur : ${manager == null ? "à recruter" : manager.name}. '
            'Il choisit la composition et les tactiques.\n'
            '• Directeur financier : surveille la trésorerie '
            '(${formatMoney(g.finance.treasury)}) et la dette.\n'
            '• Responsable du recrutement : ${scout == null ? "à recruter" : scout.name}. '
            'Il détecte les talents.\n'
            '• Responsable commercial : ${g.sponsorOffers.length} offre(s) de '
            'sponsor vous attendent.',
      ),
      _Slide(
        Icons.balance_outlined,
        'Autonomie et pouvoir',
        'Vos dirigeants agissent seuls dans leurs domaines. Vous recevez '
            'des notifications et pouvez intervenir : bloquer une vente, '
            'une libération, demander une autre solution. Mais trop de '
            'vetos fragilisent leur confiance.',
      ),
      _Slide(
        Icons.checklist_rtl,
        'Vos premières missions',
        'Dans le Bureau du président, six missions facultatives vous '
            'font découvrir les finances, l\'effectif, le staff, les '
            'installations, le calendrier et les objectifs. Des conseils '
            'apparaissent aussi à la première visite de chaque page.',
      ),
    ];
  }

  void _finish() {
    ref.read(gameProvider.notifier).finishIntro();
    context.go('/guide');
  }

  @override
  Widget build(BuildContext context) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();
    final slides = _slides(game);
    final slide = slides[_index];
    final last = _index == slides.length - 1;
    final theme = Theme.of(context);

    return Scaffold(
      body: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            flex: 2,
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF0F5C3C), Color(0xFF051A11)],
                ),
              ),
              child: Center(
                child: Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withAlpha(18),
                    border: Border.all(color: const Color(0xFFF5C04A), width: 2),
                  ),
                  child: Icon(slide.icon, size: 60, color: const Color(0xFFF5C04A)),
                ),
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: SafeArea(
        left: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 12, 24, 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: _finish,
                  child: const Text('Passer'),
                ),
              ),
              Text(slide.title, style: theme.textTheme.headlineSmall),
              const SizedBox(height: 12),
              Flexible(
                flex: 6,
                child: SingleChildScrollView(child: Text(slide.body)),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  for (var i = 0; i < slides.length; i++)
                    Container(
                      width: 8,
                      height: 8,
                      margin: const EdgeInsets.only(right: 6),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: i == _index
                            ? theme.colorScheme.primary
                            : theme.colorScheme.outlineVariant,
                      ),
                    ),
                  const Spacer(),
                  if (_index > 0)
                    TextButton(
                      onPressed: () => setState(() => _index--),
                      child: const Text('Précédent'),
                    ),
                  FilledButton(
                    onPressed: last ? _finish : () => setState(() => _index++),
                    child: Text(last ? 'Commencer' : 'Continuer'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
          ),
        ],
      ),
    );
  }
}

class _Slide {
  const _Slide(this.icon, this.title, this.body);

  final IconData icon;
  final String title;
  final String body;
}
