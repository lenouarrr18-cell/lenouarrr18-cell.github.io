import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../engine/owner/advisor.dart';
import '../common/pro_page.dart';
import '../game/game_state.dart';

class AdvisorPage extends ConsumerWidget {
  const AdvisorPage({super.key});

  static const _tabRoutes = ['/finance', '/squad', '/calendar'];

  Color _color(AdviceLevel level) {
    switch (level) {
      case AdviceLevel.info:
        return Colors.blueGrey;
      case AdviceLevel.recommendation:
        return Colors.teal;
      case AdviceLevel.warning:
        return Colors.orange;
      case AdviceLevel.urgent:
        return Colors.deepOrange;
      case AdviceLevel.critical:
        return Colors.red;
    }
  }

  String _historyLine(String key) {
    final i = key.indexOf('-');
    if (i < 0) return key;
    return 'Saison ${key.substring(0, i)} : '
        '${key.substring(i + 1).replaceAll('_', ' ')}';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();
    final theme = Theme.of(context);
    final advices = adviseClub(game);
    final history = game.owner.adviceSeen.reversed.toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Conseiller du président')),
      body: ProColumns(
        columns: ProColumns.split([
          if (advices.isEmpty)
            const Text(
              'Rien à signaler : votre club est bien géré pour le moment.',
            ),
          for (final a in advices)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Chip(
                      label: Text(adviceLevelLabel(a.level)),
                      backgroundColor: _color(a.level).withAlpha(50),
                      side: BorderSide(color: _color(a.level)),
                      visualDensity: VisualDensity.compact,
                    ),
                    Text(a.situation, style: theme.textTheme.titleMedium),
                    const SizedBox(height: 4),
                    Text(a.explanation),
                    const SizedBox(height: 4),
                    Text('Conséquence : ${a.consequence}'),
                    Text('Solution : ${a.solution}'),
                    if (a.route != null)
                      Align(
                        alignment: Alignment.centerRight,
                        child: FilledButton(
                          onPressed: () {
                            final route = a.route!;
                            if (_tabRoutes.contains(route)) {
                              context.go(route);
                            } else {
                              context.push(route);
                            }
                          },
                          child: Text(a.actionLabel),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          if (history.isNotEmpty) ...[
            const SizedBox(height: 16),
            Text('Historique des alertes', style: theme.textTheme.titleLarge),
            const SizedBox(height: 8),
            for (final h in history.take(20))
              Text(_historyLine(h)),
          ],
        ], 2),
      ),
    );
  }
}
