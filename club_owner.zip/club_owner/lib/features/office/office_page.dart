import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../engine/game/governance.dart';
import '../../engine/owner/goals.dart';
import '../common/tip_banner.dart';
import '../common/pro_page.dart';
import '../game/game_state.dart';

/// Bureau du président : décisions à valider, confiance des dirigeants
/// et missions de bienvenue.
class OfficePage extends ConsumerWidget {
  const OfficePage({super.key});

  static const _tabRoutes = ['/finance', '/squad', '/calendar'];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();
    final notifier = ref.read(gameProvider.notifier);
    final owner = game.owner;
    final theme = Theme.of(context);
    final done = owner.missionsDone;

    return Scaffold(
      appBar: AppBar(title: const Text('Bureau du président')),
      body: ProColumns(
        columns: ProColumns.split([
          const TipBanner(
            id: 'office',
            text: 'Votre directeur sportif et votre manager agissent seuls. '
                "Vous n'intervenez que si une décision ne vous convient pas : "
                'bloquer trop souvent fragilise pourtant leur confiance.',
          ),
          Text('Décisions à valider', style: theme.textTheme.titleLarge),
          const SizedBox(height: 8),
          if (owner.decisions.isEmpty)
            const Text(
              'Aucune décision en attente. La direction gère les affaires '
              'courantes en toute autonomie.',
            ),
          for (final d in owner.decisions)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      d.kind == 'sell'
                          ? 'Vente proposée'
                          : (d.kind == 'release'
                              ? 'Libération proposée'
                              : d.playerName),
                      style: theme.textTheme.titleMedium,
                    ),
                    const SizedBox(height: 4),
                    Text(d.text),
                    const SizedBox(height: 4),
                    Text(
                      'Exécution automatique à la journée ${d.executeRound}.',
                      style: theme.textTheme.bodySmall,
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 4,
                      children: [
                        FilledButton(
                          onPressed: () => notifier.approveDecision(d.id),
                          child: Text(
                            d.kind == 'invest' || d.kind == 'buyout'
                                ? 'Accepter'
                                : 'Valider',
                          ),
                        ),
                        OutlinedButton(
                          onPressed: () => notifier.blockDecision(d.id),
                          child: Text(
                            d.kind == 'invest' || d.kind == 'buyout'
                                ? 'Refuser'
                                : 'Bloquer',
                          ),
                        ),
                        if (d.kind == 'sell' || d.kind == 'release')
                          OutlinedButton(
                            onPressed: () =>
                                notifier.alternativeDecision(d.id),
                            child: const Text('Autre solution'),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 16),
          if (owner.confidenceHistory.isNotEmpty) ...[
            Text(
              'Confiance du conseil par saison',
              style: theme.textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            SizedBox(
              height: 80,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  for (final v in owner.confidenceHistory)
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 2),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text('$v', style: theme.textTheme.labelSmall),
                            Container(
                              height: 60 * v / 100,
                              color: v >= 50 ? Colors.green : Colors.orange,
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 16),
          ],
          Text('Direction', style: theme.textTheme.titleLarge),
          const SizedBox(height: 8),
          _TrustBar(label: 'Confiance du directeur sportif', value: owner.dsTrust),
          _TrustBar(label: 'Confiance du manager', value: owner.managerTrust),
          _TrustBar(
            label: 'Tensions internes',
            value: owner.tension,
            invert: true,
          ),
          Text(
            'Vetos exercés : ${owner.vetoCount}',
            style: theme.textTheme.bodySmall,
          ),
          const SizedBox(height: 16),
          Text('Objectifs à long terme', style: theme.textTheme.titleLarge),
          const SizedBox(height: 8),
          for (final goal in longGoals)
            ListTile(
              contentPadding: EdgeInsets.zero,
              dense: true,
              leading: Icon(
                goalStatus(game, goal) == GoalStatus.done
                    ? Icons.check_circle
                    : (goalStatus(game, goal) == GoalStatus.failed
                        ? Icons.cancel_outlined
                        : Icons.flag_outlined),
                color: goalStatus(game, goal) == GoalStatus.done
                    ? Colors.green
                    : (goalStatus(game, goal) == GoalStatus.failed
                        ? Colors.red
                        : null),
              ),
              title: Text(goal.title),
              subtitle: Text(
                'Horizon : ${goal.years} ans (saison ${game.seasonNumber})',
              ),
            ),
          const SizedBox(height: 16),
          Text('Missions de bienvenue', style: theme.textTheme.titleLarge),
          const Text('Facultatives : elles vous font découvrir votre club.'),
          const SizedBox(height: 8),
          for (final m in startMissions)
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(
                done.contains(m[0])
                    ? Icons.check_circle
                    : Icons.radio_button_unchecked,
                color: done.contains(m[0]) ? Colors.green : null,
              ),
              title: Text(m[1]),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                notifier.completeMission(m[0]);
                if (m[2] == '/office') return;
                if (_tabRoutes.contains(m[2])) {
                  context.go(m[2]);
                } else {
                  context.push(m[2]);
                }
              },
            ),
          const Divider(),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Conseils du président'),
            subtitle: const Text('Aides contextuelles à la première visite'),
            value: owner.tipsEnabled,
            onChanged: notifier.setTipsEnabled,
          ),
        ], 2),
      ),
    );
  }
}

class _TrustBar extends StatelessWidget {
  const _TrustBar({
    required this.label,
    required this.value,
    this.invert = false,
  });

  final String label;
  final int value;
  final bool invert;

  @override
  Widget build(BuildContext context) {
    final good = invert ? value < 40 : value >= 50;
    final color = good ? Colors.green : (value > 25 && value < 75 ? Colors.orange : Colors.red);
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('$label : $value/100'),
          const SizedBox(height: 4),
          LinearProgressIndicator(
            value: value / 100,
            color: color,
            minHeight: 8,
          ),
        ],
      ),
    );
  }
}
