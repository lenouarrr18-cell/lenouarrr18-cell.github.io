import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/utils/format.dart';
import '../../engine/finance/finance.dart';
import '../../engine/owner/infrastructure.dart';
import '../../engine/staff/staff_factory.dart';
import '../common/pro_page.dart';
import '../common/tip_banner.dart';
import '../game/game_state.dart';

/// Courbe simple de la trésorerie.
class _Spark extends CustomPainter {
  _Spark(this.values, this.color);

  final List<int> values;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    if (values.length < 2) return;
    var lo = values.first;
    var hi = values.first;
    for (final v in values) {
      if (v < lo) lo = v;
      if (v > hi) hi = v;
    }
    final span = (hi - lo) == 0 ? 1 : (hi - lo);
    final path = Path();
    for (var i = 0; i < values.length; i++) {
      final x = size.width * i / (values.length - 1);
      final y = size.height - size.height * (values[i] - lo) / span;
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    canvas.drawPath(
      path,
      Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5,
    );
  }

  @override
  bool shouldRepaint(covariant _Spark old) => old.values != values;
}

class FinancePage extends ConsumerWidget {
  const FinancePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();

    final theme = Theme.of(context);
    final book = game.finance;
    final season = game.season;
    final rounds = season.totalRounds;
    final club = game.userClub;

    final deal = game.owner.deal;
    final sponsorsPerRound =
        sponsorIncomePerSeason(
              wealth: game.city.wealth,
              division: game.division,
            ) ~/
            rounds +
        (deal == null ? 0 : deal.perSeason ~/ rounds);
    final wagesPerRound =
        (squadAnnualWages(club.squad) + staffAnnualWages(game.staff)) ~/ rounds;
    final ticketPerHome = ticketRevenue(
      populationThousands: game.city.population,
      division: game.division,
      rank: season.userRank,
      clubCount: season.clubs.length,
      stadiumLevel: game.owner.stadium,
    );
    final merchPerHome = merchRevenue(
      populationThousands: game.city.population,
      division: game.division,
      reputation: game.owner.reputation,
    );
    final extrasPerRound =
        tvIncomePerSeason(game.division) ~/ rounds + merchPerHome ~/ 2;
    final upkeepPerRound =
        infrastructureUpkeepPerSeason(game.owner) ~/ rounds;
    final expectedPerRound =
        sponsorsPerRound +
        ticketPerHome ~/ 2 +
        extrasPerRound -
        wagesPerRound -
        upkeepPerRound;
    final negative = book.treasury < 0;

    return Scaffold(
      appBar: AppBar(title: const Text('Finances')),
      body: ProColumns(
        flex: const [4, 4, 4],
        columns: [
          [
          const TipBanner(
            id: 'finance',
            text: 'Revenus : billetterie, sponsors, droits TV, boutique. '
                'Dépenses : salaires, entretien des installations, dette. '
                'Gardez une trésorerie positive pour pouvoir recruter.',
          ),
          Text('Budget', style: theme.textTheme.titleMedium),
          const SizedBox(height: 4),
          Text(
            formatMoney(book.treasury),
            style: theme.textTheme.headlineMedium?.copyWith(
              color: negative ? theme.colorScheme.error : null,
            ),
          ),
          if (game.owner.financeHistory.length >= 2) ...[
            const SizedBox(height: 12),
            SizedBox(
              height: 90,
              width: double.infinity,
              child: CustomPaint(
                painter: _Spark(
                  game.owner.financeHistory,
                  theme.colorScheme.primary,
                ),
              ),
            ),
            Text(
              'Évolution de la trésorerie (dernières journées)',
              style: theme.textTheme.bodySmall,
            ),
          ],
          if (negative)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                'Trésorerie négative : les achats sont bloqués. '
                'Vendez des joueurs bien payés pour la rétablir.',
                style: theme.textTheme.bodySmall,
              ),
            ),
          const SizedBox(height: 12),
          const _BudgetCard(),
          ],
          [
          _FinanceCard(
            title: 'Cette saison',
            lines: [
              'Billetterie : ${formatMoney(book.tickets)}',
              'Sponsors : ${formatMoney(book.sponsors)}',
              'TV, merchandising et primes : ${formatMoney(book.extras)}',
              'Salaires et staff : ${formatMoney(-book.wages)}',
              'Infrastructures : ${formatMoney(-book.infrastructure)}',
              'Intérêts : ${formatMoney(-book.debtService)}',
              'Transferts : ${formatMoney(book.transfers)}',
              'Résultat : ${formatMoney(book.seasonResult)}',
            ],
          ),
          ],
          [
          _FinanceCard(
            title: 'Par journée (estimation)',
            lines: [
              'Sponsors : ${formatMoney(sponsorsPerRound)}',
              'Billetterie, un match à domicile : '
                  '${formatMoney(ticketPerHome)}',
              'TV et merchandising : ${formatMoney(extrasPerRound)}',
              'Salaires et staff : ${formatMoney(-wagesPerRound)}',
              'Entretien des infrastructures : '
                  '${formatMoney(-upkeepPerRound)}',
              'Bilan moyen : ${formatMoney(expectedPerRound)}',
            ],
          ),
          Text(
            'La billetterie dépend de la taille de la ville, de la division '
            'et de votre classement. Monter de division multiplie vos '
            'revenus, mais les bons joueurs coûtent plus cher.',
            style: theme.textTheme.bodySmall,
          ),
          ],
        ],
      ),
    );
  }
}

class _FinanceCard extends StatelessWidget {
  const _FinanceCard({required this.title, required this.lines});

  final String title;
  final List<String> lines;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: theme.textTheme.titleMedium),
            const SizedBox(height: 8),
            for (final line in lines)
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text(line),
              ),
          ],
        ),
      ),
    );
  }
}


/// Budgets fixés par le président : le staff renouvelle l'effectif avec.
class _BudgetCard extends ConsumerWidget {
  const _BudgetCard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();
    final theme = Theme.of(context);
    final notifier = ref.read(gameProvider.notifier);
    final treasury = game.finance.treasury < 0 ? 0 : game.finance.treasury;
    final tMax = (treasury < 100000 ? 100000 : treasury).toDouble();
    final tValue = game.transferBudgetTotal.clamp(0, tMax.toInt()).toDouble();
    final bill = game.wageBill;
    final wMin = (bill * 0.8).roundToDouble();
    final wMax = (bill * 2.0 + 100000).roundToDouble();
    final wValue = game.wageBudget.clamp(wMin.toInt(), wMax.toInt()).toDouble();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Budgets du staff', style: theme.textTheme.titleMedium),
            const SizedBox(height: 4),
            Text(
              'Votre rôle : fixer les moyens. Le directeur sportif recrute et '
              'prolonge les contrats sans dépasser ces montants.',
              style: theme.textTheme.bodySmall,
            ),
            const SizedBox(height: 10),
            Text(
              'Transferts de la saison : ${formatMoney(tValue.round())}'
              '${game.owner.transferBudget == 0 ? ' (automatique)' : ''}',
            ),
            Slider(
              value: tValue,
              max: tMax,
              divisions: 40,
              onChanged: (v) =>
                  notifier.setBudgets(transfer: (v / 10000).round() * 10000),
            ),
            Text(
              'Déjà dépensé : ${formatMoney(game.transferSpentThisSeason)} · '
              'reste ${formatMoney(game.transferBudgetLeft)}',
              style: theme.textTheme.bodySmall,
            ),
            const SizedBox(height: 10),
            Text(
              'Plafond salarial annuel : ${formatMoney(wValue.round())}'
              '${game.owner.wageBudget == 0 ? ' (automatique)' : ''}',
            ),
            Slider(
              value: wValue,
              min: wMin,
              max: wMax,
              divisions: 40,
              onChanged: (v) =>
                  notifier.setBudgets(wage: (v / 10000).round() * 10000),
            ),
            Text(
              'Masse salariale actuelle : ${formatMoney(bill)}',
              style: theme.textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}
