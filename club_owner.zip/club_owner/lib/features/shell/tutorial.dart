import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../game/game_repository.dart';

const String _tutorialKey = 'tutorial_v1';
bool _shownThisSession = false;

class _Step {
  const _Step(this.icon, this.title, this.text);

  final IconData icon;
  final String title;
  final String text;
}

const List<_Step> _steps = [
  _Step(Icons.workspace_premium, 'Bienvenue, Président',
      'Vous dirigez le club : argent, stade, staff, image. Le coach gère le '
          'terrain, le directeur sportif gère les transferts et les contrats. '
          'Vous fixez le cap et les budgets.'),
  _Step(Icons.home, 'Accueil : votre tableau de bord',
      'Le prochain match, votre classement, la trésorerie et le contrat '
          "d'objectifs du conseil. Touchez « Jouer » pour lancer la journée."),
  _Step(Icons.sports_soccer, 'Le match en 2D',
      'Regardez vos matchs en direct : corners, coups francs, penalties, '
          'cartons, remplacements. Le score se décide sur le terrain, selon '
          'la qualité de votre effectif.'),
  _Step(Icons.stadium, 'Club : installations et staff',
      "Agrandissez le stade, construisez le centre d'entraînement, "
          "l'académie, la boutique. Recrutez un directeur sportif et un "
          'manager compétents : ce sont eux qui exécutent.'),
  _Step(Icons.account_balance_wallet, 'Finances : les budgets',
      'Fixez le budget transferts et la masse salariale. Signalez au '
          'directeur sportif les joueurs qui vous intéressent : il négocie '
          'dans vos budgets.'),
  _Step(Icons.mail, 'Messages',
      "Votre staff, le conseil, les supporters et la presse vous écrivent. "
          'Un message est marqué lu quand vous l\'ouvrez ; archivez ou '
          'supprimez ce que vous voulez.'),
  _Step(Icons.flag_circle, 'Votre mission',
      "Tenez le contrat d'objectifs du conseil, gardez des comptes sains et "
          'des supporters heureux, puis montez jusqu\'à la première division. '
          'Bonne chance, Président !'),
];

/// Visite guidée des premières minutes (une seule fois).
void showTutorialIfNeeded(BuildContext context, WidgetRef ref) {
  if (_shownThisSession) return;
  _shownThisSession = true;
  final prefs = ref.read(sharedPreferencesProvider);
  if (prefs.getBool(_tutorialKey) ?? false) return;
  showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (_) => const _TutorialDialog(),
  ).then((_) => prefs.setBool(_tutorialKey, true));
}

class _TutorialDialog extends StatefulWidget {
  const _TutorialDialog();

  @override
  State<_TutorialDialog> createState() => _TutorialDialogState();
}

class _TutorialDialogState extends State<_TutorialDialog> {
  int _i = 0;

  @override
  Widget build(BuildContext context) {
    final step = _steps[_i];
    final last = _i == _steps.length - 1;
    final theme = Theme.of(context);
    return Dialog(
      backgroundColor: const Color(0xFF0F2419),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: Color(0xFFF5C04A), width: 1.2),
      ),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 520),
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 26,
                    backgroundColor: const Color(0xFFF5C04A),
                    child: Icon(step.icon, color: const Color(0xFF0F2419), size: 28),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Text(
                      step.title,
                      style: theme.textTheme.titleLarge?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Text(
                step.text,
                style: const TextStyle(color: Colors.white70, fontSize: 15, height: 1.35),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  for (var k = 0; k < _steps.length; k++)
                    Container(
                      width: k == _i ? 18 : 7,
                      height: 7,
                      margin: const EdgeInsets.only(right: 5),
                      decoration: BoxDecoration(
                        color: k == _i ? const Color(0xFFF5C04A) : Colors.white24,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  const Spacer(),
                  if (!last)
                    TextButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('Passer'),
                    ),
                  const SizedBox(width: 6),
                  FilledButton(
                    onPressed: () {
                      if (last) {
                        Navigator.of(context).pop();
                      } else {
                        setState(() => _i++);
                      }
                    },
                    child: Text(last ? "C'est parti !" : 'Suivant'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
