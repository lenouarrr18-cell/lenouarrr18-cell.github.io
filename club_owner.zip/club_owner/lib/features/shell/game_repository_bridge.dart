import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../engine/achievements/achievements.dart';
import '../../engine/game/game_state.dart';
import '../game/game_repository.dart';

const String _seenKey = 'achievements_seen';

/// Succès nouvellement débloqués depuis la dernière vérification. Au tout
/// premier appel, l'état actuel est enregistré sans notification.
List<Achievement> newAchievements(WidgetRef ref, GameState game) {
  final prefs = ref.read(sharedPreferencesProvider);
  final now = unlockedAchievements(game);
  final stored = prefs.getStringList(_seenKey);
  if (stored == null) {
    prefs.setStringList(_seenKey, now.toList());
    return const [];
  }
  final seen = stored.toSet();
  final fresh = [
    for (final a in achievements)
      if (now.contains(a.id) && !seen.contains(a.id)) a,
  ];
  if (fresh.isNotEmpty) prefs.setStringList(_seenKey, {...seen, ...now}.toList());
  return fresh;
}
