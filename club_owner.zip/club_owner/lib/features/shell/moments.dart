import 'dart:math';

import 'package:flutter/material.dart';

import '../../domain/entities/division.dart';
import '../../engine/game/game_state.dart';
import '../common/crest.dart';
import '../share/share_card.dart';

/// Un grand moment de la carrière, mis en scène en plein écran.
class Moment {
  const Moment({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    this.club,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final String? club;
}

/// Compare deux états du jeu : titre, montée, arrivée d'une star.
Moment? detectMoment(GameState prev, GameState next) {
  final club = next.userClub;
  if (!prev.season.isFinished && next.season.isFinished) {
    final rank = next.season.userRank;
    if (rank == 1) {
      return Moment(
        title: 'CHAMPION !',
        subtitle: '${club.name} remporte le championnat. Le trophée est '
            'soulevé devant des tribunes en fusion.',
        icon: Icons.emoji_events,
        color: const Color(0xFFF5C04A),
        club: club.name,
      );
    }
    final outcome = seasonOutcome(
      rank: rank,
      division: next.division,
      clubCount: next.season.clubs.length,
    );
    if (outcome == SeasonOutcome.promoted) {
      return Moment(
        title: 'MONTÉE !',
        subtitle: '${club.name} termine ${rank}e et monte en '
            '${divisionName(next.division - 1)}. La ville fait la fête.',
        icon: Icons.trending_up,
        color: const Color(0xFF43A047),
        club: club.name,
      );
    }
  }
  // Signature d'un joueur parmi les meilleurs de l'effectif.
  final before = {for (final p in prev.userClub.squad) p.id};
  final arrivals = [
    for (final p in club.squad)
      if (!before.contains(p.id)) p,
  ];
  if (arrivals.isNotEmpty && prev.userClub.squad.isNotEmpty) {
    final skills = [for (final p in prev.userClub.squad) p.skill]
      ..sort((a, b) => b.compareTo(a));
    final bar = skills[min(2, skills.length - 1)];
    arrivals.sort((a, b) => b.skill.compareTo(a.skill));
    final star = arrivals.first;
    if (star.skill >= bar && star.skill >= 60) {
      return Moment(
        title: 'NOUVELLE STAR',
        subtitle: '${star.name} (${star.age} ans, ${star.nation.isEmpty ? 'international' : star.nation}) '
            'rejoint ${club.name}. Présentation officielle au stade, niveau ${star.skill}.',
        icon: Icons.star,
        color: const Color(0xFF42A5F5),
        club: club.name,
      );
    }
  }
  return null;
}

Future<void> showMoment(BuildContext context, Moment m) {
  return showGeneralDialog<void>(
    context: context,
    barrierDismissible: true,
    barrierLabel: m.title,
    barrierColor: Colors.black.withAlpha(200),
    transitionDuration: const Duration(milliseconds: 380),
    pageBuilder: (context, a, b) => _MomentView(moment: m),
    transitionBuilder: (context, anim, b, child) => FadeTransition(
      opacity: anim,
      child: ScaleTransition(
        scale: Tween(begin: 0.85, end: 1.0).animate(
          CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        ),
        child: child,
      ),
    ),
  );
}

class _MomentView extends StatefulWidget {
  const _MomentView({required this.moment});

  final Moment moment;

  @override
  State<_MomentView> createState() => _MomentViewState();
}

class _MomentViewState extends State<_MomentView>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 4),
  )..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final m = widget.moment;
    return Material(
      color: Colors.transparent,
      child: Stack(
        children: [
          Positioned.fill(
            child: IgnorePointer(
              child: AnimatedBuilder(
                animation: _c,
                builder: (context, _) => CustomPaint(
                  painter: _Confetti(_c.value, m.color),
                ),
              ),
            ),
          ),
          Center(
            child: Container(
              width: 460,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color.lerp(m.color, Colors.black, 0.55)!,
                    const Color(0xFF07140D),
                  ],
                ),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: m.color, width: 2),
                boxShadow: [BoxShadow(color: m.color.withAlpha(90), blurRadius: 40)],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (m.club != null) ClubCrest(name: m.club!, size: 46),
                      const SizedBox(width: 14),
                      Icon(m.icon, size: 64, color: m.color),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    m.title,
                    style: TextStyle(
                      color: m.color,
                      fontSize: 40,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 3,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    m.subtitle,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white, fontSize: 15),
                  ),
                  const SizedBox(height: 18),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      OutlinedButton.icon(
                        onPressed: () => showShareCard(
                          context,
                          ShareContent(
                            kicker: m.title,
                            headline: m.club ?? 'Club Owner',
                            detail: m.subtitle,
                            message: '${m.title} ${m.subtitle}',
                            club: m.club,
                            color: m.color,
                            icon: m.icon,
                          ),
                        ),
                        icon: const Icon(Icons.share),
                        label: const Text('Partager'),
                      ),
                      const SizedBox(width: 10),
                      FilledButton(
                        onPressed: () => Navigator.of(context).maybePop(),
                        child: const Text('Savourer et continuer'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Confetti extends CustomPainter {
  _Confetti(this.t, this.color);

  final double t;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final r = Random(7);
    const colors = [
      Color(0xFFF5C04A),
      Color(0xFFFFFFFF),
      Color(0xFF43A047),
      Color(0xFF42A5F5),
      Color(0xFFE53935),
    ];
    for (var i = 0; i < 140; i++) {
      final x0 = r.nextDouble() * size.width;
      final speed = 0.5 + r.nextDouble();
      final y = ((r.nextDouble() + t * speed) % 1.0) * (size.height + 40) - 20;
      final x = x0 + sin((t * 6 + i) * speed) * 18;
      final paint = Paint()
        ..color = (i % 6 == 0 ? color : colors[i % colors.length])
            .withAlpha(220);
      canvas.save();
      canvas.translate(x, y);
      canvas.rotate(t * 12 * speed + i);
      canvas.drawRect(const Rect.fromLTWH(-4, -2, 8, 4), paint);
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant _Confetti old) => old.t != t;
}
