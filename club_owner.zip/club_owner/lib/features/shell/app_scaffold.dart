import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/audio/audio_service.dart';
import '../../core/l10n/l10n.dart';
import '../../engine/achievements/achievements.dart';
import 'game_repository_bridge.dart';
import '../../core/cloud/online_league.dart';
import '../events/daily.dart';
import 'moments.dart';
import 'tutorial.dart';
import '../common/crest.dart';
import '../game/game_state.dart';

class _Dest {
  const _Dest(this.icon, this.selected, this.key);

  final IconData icon;
  final IconData selected;
  final String key;
}

const List<_Dest> _dests = [
  _Dest(Icons.home_outlined, Icons.home, 'nav.home'),
  _Dest(Icons.groups_outlined, Icons.groups, 'nav.squad'),
  _Dest(Icons.stadium_outlined, Icons.stadium, 'nav.club'),
  _Dest(Icons.account_balance_wallet_outlined, Icons.account_balance_wallet,
      'nav.finance'),
  _Dest(Icons.calendar_month_outlined, Icons.calendar_month, 'nav.calendar'),
];

/// Coquille du jeu en paysage : barre latérale à gauche, contenu à droite.
/// Prime de fidélité vérifiée une fois par lancement.
bool _loginChecked = false;

class AppScaffold extends ConsumerWidget {
  const AppScaffold({required this.navigationShell, super.key});

  final StatefulNavigationShell navigationShell;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    // La musique démarre ici : la partie a vraiment commencé.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(audioProvider.notifier).startGameMusic();
      if (context.mounted) showTutorialIfNeeded(context, ref);
      if (!_loginChecked) {
        _loginChecked = true;
        ref.read(dailyProvider.notifier).checkLogin();
      }
    });
    ref.listen(dailyProvider, (previous, next) {
      final toast = next.toast;
      if (toast != null && toast != previous?.toast) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(toast),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    });
    ref.listen(gameProvider, (previous, next) {
      if (next == null) return;
      if (previous != null &&
          previous.season.currentRound != next.season.currentRound) {
        // Classement en ligne à jour après chaque journée (si connecté).
        ref.read(onlineProvider.notifier).publish(next);
        ref.read(dailyProvider.notifier).evaluate(next);
      }
      if (previous != null) {
        final moment = detectMoment(previous, next);
        if (moment != null) {
          ref.read(audioProvider.notifier).playCelebration();
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (context.mounted) showMoment(context, moment);
          });
        }
      }
      final fresh = newAchievements(ref, next);
      if (fresh.isEmpty) return;
      ref.read(audioProvider.notifier).sfx(Sfx.goalCheer, volume: 0.5);
      for (final a in fresh) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: const Color(0xFF14432D),
            content: Row(
              children: [
                const Icon(Icons.emoji_events, color: Color(0xFFF5C04A)),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Succès débloqué : ${a.title}',
                    style: const TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
            action: SnackBarAction(
              label: 'Voir',
              onPressed: () => context.push('/achievements'),
            ),
          ),
        );
      }
    });
    final width = MediaQuery.sizeOf(context).width;
    final extended = width >= 900;
    final railW = extended ? 176.0 : 78.0;
    final unread = game?.owner.unreadCount ?? 0;

    return Scaffold(
      body: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            width: railW,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF0C2A1C), Color(0xFF06150E)],
              ),
              border: Border(right: BorderSide(color: Colors.white10)),
            ),
            child: SafeArea(
              right: false,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 8),
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Row(
                      mainAxisAlignment: extended
                          ? MainAxisAlignment.start
                          : MainAxisAlignment.center,
                      children: [
                        const AppLogo(size: 38),
                        if (extended) ...[
                          const SizedBox(width: 8),
                          const Expanded(
                            child: Text(
                              'CLUB\nOWNER',
                              style: TextStyle(
                                color: Color(0xFFF5C04A),
                                fontWeight: FontWeight.w900,
                                fontSize: 13,
                                height: 1.05,
                                letterSpacing: 1.2,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 6),
                  for (var i = 0; i < _dests.length; i++)
                    _RailItem(
                      icon: _dests[i].icon,
                      selectedIcon: _dests[i].selected,
                      label: ref.t(_dests[i].key),
                      selected: navigationShell.currentIndex == i,
                      extended: extended,
                      onTap: () => navigationShell.goBranch(
                        i,
                        initialLocation: i == navigationShell.currentIndex,
                      ),
                    ),
                  const Divider(color: Colors.white10, height: 16),
                  _RailItem(
                    icon: Icons.mail_outline,
                    selectedIcon: Icons.mail,
                    label: extended ? 'Messages' : 'Mess.',
                    badge: unread,
                    extended: extended,
                    onTap: () => context.push('/inbox'),
                  ),
                  _RailItem(
                    icon: Icons.settings_outlined,
                    selectedIcon: Icons.settings,
                    label: ref.t('settings.title'),
                    extended: extended,
                    onTap: () => context.push('/settings'),
                  ),
                ],
              ),
            ),
          ),
          Expanded(child: navigationShell),
        ],
      ),
    );
  }
}

class _RailItem extends StatelessWidget {
  const _RailItem({
    required this.icon,
    required this.selectedIcon,
    required this.label,
    required this.extended,
    required this.onTap,
    this.selected = false,
    this.badge = 0,
  });

  final IconData icon;
  final IconData selectedIcon;
  final String label;
  final bool extended;
  final bool selected;
  final int badge;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    const gold = Color(0xFFF5C04A);
    final color = selected ? gold : Colors.white70;
    Widget iconW = Icon(selected ? selectedIcon : icon, color: color, size: 22);
    if (badge > 0) {
      iconW = Badge(label: Text('$badge'), child: iconW);
    }
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      child: Material(
        color: selected ? const Color(0xFF1E4D34) : Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: Container(
            padding: EdgeInsets.symmetric(
              horizontal: extended ? 12 : 4,
              vertical: extended ? 10 : 6,
            ),
            decoration: selected
                ? BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: gold.withAlpha(120)),
                  )
                : null,
            child: extended
                ? Row(
                    children: [
                      iconW,
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          label,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: color,
                            fontWeight:
                                selected ? FontWeight.w800 : FontWeight.w600,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  )
                : Column(
                    children: [
                      iconW,
                      const SizedBox(height: 2),
                      Text(
                        label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: color,
                          fontSize: 10,
                          fontWeight:
                              selected ? FontWeight.w800 : FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}
