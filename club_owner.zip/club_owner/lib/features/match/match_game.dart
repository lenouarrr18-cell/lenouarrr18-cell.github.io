import 'dart:math';
import 'dart:typed_data';
import 'dart:ui' hide Gradient, TextStyle;

import 'package:flame/components.dart';
import 'package:flame/game.dart';
import 'package:flutter/painting.dart';

import 'match_log.dart';

/// Rendu 2D du match avec le moteur de jeu Flame, vue fixe sur tout le
/// terrain (façon Soccer Manager) : 22 joueurs, ballon avec sa hauteur,
/// arbitre, assistants avec leur drapeau, quatrième arbitre et bancs.
/// Les positions viennent des trajectoires réelles du moteur (une image par
/// seconde, lissées) ; les cartons, panneaux de remplacement, soigneurs,
/// murs et filets viennent du journal du match.
class MatchGame extends FlameGame {
  MatchGame({
    required this.track,
    required this.frameBytes,
    required this.frameSeconds,
    required this.homeColor,
    required this.awayColor,
    required this.names,
    required this.events,
  }) : numbers = shirtNumbers(names, events);

  final Uint8List track;
  final int frameBytes;
  final double frameSeconds;
  final Color homeColor;
  final Color awayColor;

  /// Les 22 titulaires (ordre des trajectoires).
  final List<String> names;
  final List<LogEvent> events;
  final Map<String, int> numbers;

  /// Seconde de jeu affichée (pilotée par l'écran de match).
  double t = 0;

  /// Joueurs mis en avant (tireur, buteur, fautif...).
  Set<String> focus = const {};

  /// Affiche le bloc de chaque équipe (lignes de la formation).
  bool showShape = false;

  /// Match en nocturne (projecteurs), sous la pluie, et usure de la pelouse
  /// au fil de la saison (0 à 1).
  bool night = false;
  bool rain = false;
  double wear = 0;

  /// Joueurs par ligne (défense, milieu, attaque), ex. 4-3-3 → [4, 3, 3].
  List<int> homeLines = const [];
  List<int> awayLines = const [];

  static const double pitchW = kPitchW;
  static const double pitchH = kPitchH;

  bool get hasOfficials => frameBytes >= 54;

  @override
  Color backgroundColor() => const Color(0x00000000);

  @override
  Future<void> onLoad() async {
    camera.viewfinder.anchor = Anchor.center;
    world.add(_PitchLayer(this));
  }

  int get frames => track.length ~/ frameBytes;

  /// Durée couverte par la trajectoire (secondes).
  double get duration => max(0, frames - 1) * frameSeconds;

  Offset? _raw(int f, int slot) {
    final o = f * frameBytes + slot * 2;
    if (o + 1 >= track.length) return null;
    final x = track[o];
    final y = track[o + 1];
    if (slot < 22 && x == 0 && y == 0) return null;
    return Offset(x / 255 * pitchW, y / 255 * pitchH);
  }

  /// Position (mètres) : 0-21 joueurs, 22 ballon, 23 arbitre, 24-25
  /// assistants. Les joueurs sont lissés (spline de Catmull-Rom).
  Offset? pos(int slot, double time) {
    final n = frames;
    if (n < 2) return null;
    if (slot > 22 && !hasOfficials) return null;
    final f = (time / frameSeconds).clamp(0.0, n - 1.0);
    final i1 = f.floor();
    final i2 = min(i1 + 1, n - 1);
    final k = f - i1;
    final p1 = _raw(i1, slot);
    final p2 = _raw(i2, slot);
    if (p1 == null) return null;
    if (p2 == null) return p1;
    final jump = (p2 - p1).distance;
    if (jump > 14) return k < 0.5 ? p1 : p2;
    // Le ballon file en ligne droite entre deux images.
    if (slot == 22) return Offset.lerp(p1, p2, k);
    final p0 = _raw(max(0, i1 - 1), slot) ?? p1;
    final p3 = _raw(min(n - 1, i2 + 1), slot) ?? p2;
    final k2 = k * k;
    final k3 = k2 * k;
    double cr(double a, double b, double c, double d) =>
        0.5 *
        (2 * b +
            (-a + c) * k +
            (2 * a - 5 * b + 4 * c - d) * k2 +
            (-a + 3 * b - 3 * c + d) * k3);
    return Offset(
      cr(p0.dx, p1.dx, p2.dx, p3.dx).clamp(-2.0, pitchW + 2).toDouble(),
      cr(p0.dy, p1.dy, p2.dy, p3.dy).clamp(-2.0, pitchH + 2).toDouble(),
    );
  }

  /// Hauteur du ballon (mètres).
  double ballHeight(double time) {
    if (frameBytes < 54) return 0;
    final n = frames;
    if (n < 2) return 0;
    final f = (time / frameSeconds).clamp(0.0, n - 1.0);
    final i1 = f.floor();
    final i2 = min(i1 + 1, n - 1);
    final k = f - i1;
    final a = track[i1 * frameBytes + 52] / 255 * 16;
    final b = track[i2 * frameBytes + 52] / 255 * 16;
    return a + (b - a) * k;
  }

  /// Le ballon est-il arrêté (coup de pied arrêté, célébration...) ?
  bool deadBall(double time) {
    if (frameBytes < 54) return false;
    final n = frames;
    if (n < 1) return false;
    final i = (time / frameSeconds).clamp(0.0, n - 1.0).floor();
    return track[i * frameBytes + 53] == 1;
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (size.x <= 0 || size.y <= 0) return;
    // Vue fixe : tout le terrain, les bancs et les assistants.
    final zoom = min(size.x / (pitchW + 9), size.y / (pitchH + 13));
    camera.viewfinder.zoom = zoom;
    camera.viewfinder.position = Vector2(pitchW / 2, pitchH / 2 + 2.2);
  }
}

class _PitchLayer extends Component {
  _PitchLayer(this.game);

  final MatchGame game;
  final Map<String, TextPainter> _text = {};

  static const Color _white = Color(0xE6FFFFFF);
  static const Color _gold = Color(0xFFF5C04A);
  static const Color _refColor = Color(0xFF151515);
  static const Color _refTrim = Color(0xFFE4FF1A);

  final Paint _line = Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = 0.16
    ..color = _white;

  TextPainter _label(String text, double size, Color color) {
    final key = '$text|$size|${color.toARGB32()}';
    final cached = _text[key];
    if (cached != null) return cached;
    if (_text.length > 400) _text.clear();
    final tp = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          color: color,
          fontSize: size,
          fontWeight: FontWeight.w900,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    _text[key] = tp;
    return tp;
  }

  void _centered(Canvas c, TextPainter tp, Offset at) {
    tp.paint(c, at - Offset(tp.width / 2, tp.height / 2));
  }

  @override
  void render(Canvas canvas) {
    const w = MatchGame.pitchW;
    const h = MatchGame.pitchH;
    final t = game.t;

    _drawGround(canvas, w, h);
    _drawConditions(canvas, w, h);

    // ---- état du moment, tiré du journal ----
    final names = namesAt(game.names, game.events, t);
    int? slotOf(String name) {
      final i = names.indexOf(name);
      return i < 0 ? null : i;
    }

    final recent = <LogEvent>[];
    for (final e in game.events) {
      if (e.t > t) break;
      if (t - e.t <= 45) recent.add(e);
    }
    LogEvent? last(String code, double within) {
      for (final e in recent.reversed) {
        if (e.code == code && t - e.t <= within) return e;
      }
      return null;
    }

    // Remplacement annoncé mais pas encore effectué : panneau levé.
    LogEvent? board;
    for (final e in recent.reversed) {
      if (e.code == 'SBA') {
        final done = recent.any(
          (x) => x.code == 'SB' && x.t >= e.t && x.a == e.a,
        );
        if (!done) board = e;
        break;
      }
    }
    final injury = last('IN', 34);
    final injuryOver = injury != null &&
        recent.any(
          (x) =>
              x.t > injury.t + 1 &&
              (x.code == 'KO' ||
                  x.code == 'FK' ||
                  x.code == 'PK' ||
                  (x.code == 'SB' && x.a == injury.a)),
        );
    final String? lying =
        injury != null && !injuryOver && t - injury.t < 30 ? injury.a : null;

    // Coup franc dangereux : bombe de l'arbitre (ligne du mur à 9,15 m).
    final fk = last('FK', 17);
    if (fk != null && fk.b == 'D' && game.deadBall(t)) {
      final goalX = (fk.home == (t < 2700)) ? w : 0.0;
      _drawWallSpray(canvas, Offset(fk.x, fk.y), Offset(goalX, h / 2));
    }
    // Penalty : le point s'illumine.
    final pk = last('PK', 27);
    if (pk != null) {
      final pulse = 0.6 + 0.4 * sin(t * 6);
      canvas.drawCircle(
        Offset(pk.x, pk.y),
        1.4 + pulse * 0.4,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.18
          ..color = _gold.withValues(alpha: 0.8),
      );
    }
    // Hors-jeu : ligne pointillée sur la position du joueur signalé.
    final off = last('OF', 3.5);
    if (off != null) {
      final p = Paint()
        ..color = const Color(0xCCFFEB3B)
        ..strokeWidth = 0.2;
      for (var y = 0.0; y < h; y += 2.2) {
        canvas.drawLine(Offset(off.x, y), Offset(off.x, min(h, y + 1.2)), p);
      }
    }
    // But : le filet tremble.
    final goal = last('GL', 4);
    if (goal != null) {
      final right = goal.x > w / 2;
      final k = (t - goal.t) / 4;
      final ripple = sin(k * pi * 8) * (1 - k) * 0.8;
      final x0 = right ? w : 0.0;
      final dir = right ? 1.0 : -1.0;
      canvas.drawRect(
        Rect.fromLTRB(
          min(x0, x0 + dir * (2.2 + ripple)),
          h / 2 - 3.66,
          max(x0, x0 + dir * (2.2 + ripple)),
          h / 2 + 3.66,
        ),
        Paint()..color = _gold.withValues(alpha: 0.45 * (1 - k)),
      );
    }
    // Trajectoire d'une frappe.
    final shot = last('SH', 1.2);
    if (shot != null) {
      final ball = game.pos(22, t);
      if (ball != null) {
        final k = ((t - shot.t) / 1.2).clamp(0.0, 1.0);
        canvas.drawLine(
          Offset(shot.x, shot.y),
          ball,
          Paint()
            ..color = Color.fromARGB((160 * (1 - k)).round(), 255, 255, 255)
            ..strokeWidth = 0.35
            ..strokeCap = StrokeCap.round,
        );
      }
    }

    // ---- bloc tactique (optionnel) ----
    if (game.showShape) {
      for (final home in [true, false]) {
        _drawShape(
          canvas,
          [for (var i = 0; i < 11; i++) game.pos((home ? 0 : 11) + i, t)],
          home ? game.homeLines : game.awayLines,
          home ? game.homeColor : game.awayColor,
        );
      }
    }

    // ---- joueurs ----
    final ballNow = game.pos(22, t);
    final z = game.ballHeight(t);
    final positions = List<Offset?>.generate(22, (i) => game.pos(i, t));
    var carrier = -1;
    if (ballNow != null && z < 2.2) {
      var best = 2.6;
      for (var i = 0; i < 22; i++) {
        final p = positions[i];
        if (p == null) continue;
        final d = (p - ballNow).distance;
        if (d < best) {
          best = d;
          carrier = i;
        }
      }
    }
    for (var i = 0; i < 22; i++) {
      final p = positions[i];
      if (p == null) continue;
      final name = names[i];
      // Direction et vitesse : le joueur court dans le bon sens, ou regarde
      // le ballon quand il est arrêté.
      final before = game.pos(i, t - 0.3);
      var vel = before == null ? Offset.zero : (p - before) / 0.3;
      final speed = vel.distance;
      double angle;
      if (speed > 0.6) {
        angle = atan2(vel.dy, vel.dx);
      } else if (ballNow != null) {
        final d = ballNow - p;
        angle = atan2(d.dy, d.dx);
        vel = Offset.zero;
      } else {
        angle = i < 11 ? 0.0 : pi;
      }
      _drawPlayer(
        canvas,
        p,
        home: i < 11,
        keeper: i == 0 || i == 11,
        number: game.numbers[name] ?? (i % 11) + 1,
        down: name == lying,
        angle: angle,
        speed: min(8.0, speed),
        phase: t * (2.2 + min(8.0, speed) * 0.55) + i * 0.7,
      );
    }

    // Soigneurs auprès du joueur blessé (ils arrivent du banc).
    if (lying != null && injury != null) {
      final slot = slotOf(lying);
      final p = slot == null ? null : positions[slot];
      if (p != null) {
        final k = ((t - injury.t) / 6).clamp(0.0, 1.0);
        const bench = Offset(w / 2, h + 3);
        for (final side in [-1.0, 1.0]) {
          final target = p + Offset(side * 1.6, 1.2);
          _drawMedic(canvas, Offset.lerp(bench, target, k)!);
        }
        if (injury.b == 'S' && k >= 1) {
          // Civière.
          canvas.drawRRect(
            RRect.fromRectAndRadius(
              Rect.fromCenter(
                center: p + const Offset(0, 2.4),
                width: 4.2,
                height: 1.1,
              ),
              const Radius.circular(0.3),
            ),
            Paint()..color = const Color(0xFFECEFF1),
          );
        }
        _drawCross(canvas, p + const Offset(0, -2.6));
      }
    }

    // Noms : porteur du ballon et joueurs au cœur de l'action.
    final shownNames = <int>{};
    if (carrier >= 0) shownNames.add(carrier);
    for (var i = 0; i < 22; i++) {
      if (game.focus.contains(names[i])) shownNames.add(i);
    }
    for (final e in recent) {
      if (t - e.t > 4) continue;
      if (e.code == 'YC' ||
          e.code == 'RC' ||
          e.code == 'FL' ||
          e.code == 'SB') {
        final s = slotOf(e.code == 'SB' ? e.b : e.a);
        if (s != null) shownNames.add(s);
      }
    }
    for (final i in shownNames) {
      final p = positions[i];
      if (p == null) continue;
      final focused = game.focus.contains(names[i]);
      if (focused) {
        canvas.drawCircle(
          p,
          2.0,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 0.28
            ..color = _gold,
        );
      }
      final short = names[i].split(' ').last;
      final tp = _label(
        short,
        1.25,
        focused ? const Color(0xFF1A1300) : const Color(0xFFFFFFFF),
      );
      final box = Rect.fromCenter(
        center: p + const Offset(0, -2.7),
        width: tp.width + 1.2,
        height: tp.height + 0.4,
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(box, const Radius.circular(0.5)),
        Paint()..color = focused ? _gold : const Color(0xCC0B1A12),
      );
      _centered(canvas, tp, box.center);
    }

    // Flèches de remplacement : rouge pour la sortie, vert pour l'entrée.
    if (board != null) {
      final s = slotOf(board.a);
      final p = s == null ? null : positions[s];
      if (p != null) _drawArrow(canvas, p + const Offset(1.9, -0.6), false);
    }
    final sb = last('SB', 4);
    if (sb != null) {
      final s = slotOf(sb.b);
      final p = s == null ? null : positions[s];
      if (p != null) _drawArrow(canvas, p + const Offset(1.9, -0.6), true);
    }

    // ---- arbitres ----
    final ref = game.pos(23, t);
    if (ref != null) {
      _drawOfficial(canvas, ref);
      final card = last('YC', 5) ?? last('RC', 5);
      if (card != null) {
        final red = card.code == 'RC';
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            Rect.fromCenter(
              center: ref + const Offset(0.4, -2.6),
              width: 1.3,
              height: 1.8,
            ),
            const Radius.circular(0.15),
          ),
          Paint()
            ..color = red ? const Color(0xFFE53935) : const Color(0xFFFFD600),
        );
        final s = slotOf(card.a);
        final p = s == null ? null : positions[s];
        if (p != null) {
          canvas.drawLine(
            ref,
            p,
            Paint()
              ..color = const Color(0x55FFFFFF)
              ..strokeWidth = 0.12,
          );
        }
      }
      final whistle = last('FL', 1.6) ?? last('OF', 1.6);
      if (whistle != null) {
        final k = (t - whistle.t) / 1.6;
        canvas.drawCircle(
          ref,
          1.2 + k * 2.4,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 0.2
            ..color = Color.fromARGB((200 * (1 - k)).round(), 255, 255, 255),
        );
      }
    }
    if (game.hasOfficials) {
      final l1 = game.pos(24, t);
      final l2 = game.pos(25, t);
      if (l1 != null) {
        final p = Offset(l1.dx, -1.7);
        _drawOfficial(canvas, p);
        _drawFlag(canvas, p, off != null && off.x > w / 2, top: true);
      }
      if (l2 != null) {
        final p = Offset(l2.dx, h + 1.7);
        _drawOfficial(canvas, p);
        _drawFlag(canvas, p, off != null && off.x <= w / 2, top: false);
      }
    }
    // Quatrième arbitre et son panneau lumineux.
    const fourth = Offset(w / 2, h + 3.2);
    _drawOfficial(canvas, fourth);
    if (board != null) {
      final outNo = game.numbers[board.a] ?? 0;
      final inNo = game.numbers[board.b] ?? 0;
      final r = Rect.fromCenter(
        center: fourth + const Offset(0, -3.6),
        width: 6.2,
        height: 2.6,
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(r, const Radius.circular(0.3)),
        Paint()..color = const Color(0xFF0B0B0B),
      );
      _centered(canvas, _label('$outNo', 1.6, const Color(0xFFFF5252)),
          r.center - const Offset(1.5, 0));
      _centered(canvas, _label('$inNo', 1.6, const Color(0xFF69F0AE)),
          r.center + const Offset(1.5, 0));
    }

    // ---- ballon (ombre au sol, ballon en l'air selon sa hauteur) ----
    if (ballNow != null) {
      final lift = Offset(0, -z * 0.45);
      final r = 0.55 + z * 0.035;
      canvas.drawOval(
        Rect.fromCenter(
          center: ballNow + const Offset(0.2, 0.3),
          width: 1.3 - min(0.7, z * 0.06),
          height: 0.7 - min(0.35, z * 0.03),
        ),
        Paint()
          ..color =
              Color.fromARGB((110 - min(80.0, z * 8)).round(), 0, 0, 0),
      );
      for (var k = 3; k >= 1; k--) {
        final tr = game.pos(22, t - k * 0.06);
        if (tr == null) continue;
        canvas.drawCircle(
          tr + lift,
          r * (1 - k * 0.18),
          Paint()..color = Color.fromARGB(90 - k * 25, 255, 255, 255),
        );
      }
      canvas.drawCircle(
        ballNow + lift,
        r,
        Paint()..color = const Color(0xFFFFFFFF),
      );
      canvas.drawCircle(
        ballNow + lift,
        r,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.12
          ..color = const Color(0xFF000000),
      );
      canvas.drawCircle(
        ballNow + lift + Offset(r * 0.25, -r * 0.2),
        r * 0.32,
        Paint()..color = const Color(0xFF263238),
      );
    }
    if (game.rain) _drawRain(canvas, w, h);
  }

  /// Projecteurs de nuit, pelouse mouillée, usure du gazon.
  void _drawConditions(Canvas canvas, double w, double h) {
    final wear = game.wear.clamp(0.0, 1.0);
    if (wear > 0.05) {
      final mud = Paint()
        ..color = Color.fromARGB((70 * wear).round(), 121, 85, 52);
      canvas.drawOval(
        Rect.fromCenter(center: Offset(w / 2, h / 2), width: 10, height: 6),
        mud,
      );
      for (final x in [5.5, w - 5.5]) {
        canvas.drawOval(
          Rect.fromCenter(center: Offset(x, h / 2), width: 7, height: 12),
          mud,
        );
      }
    }
    if (game.rain) {
      canvas.drawRect(
        Rect.fromLTWH(0, 0, w, h),
        Paint()..color = const Color(0x22001020),
      );
    }
    if (game.night) {
      canvas.drawRect(
        Rect.fromLTWH(-8, -6, w + 16, h + 14),
        Paint()..color = const Color(0x55000814),
      );
      for (final c in [
        const Offset(-4, -4),
        Offset(w + 4, -4),
        Offset(-4, h + 4),
        Offset(w + 4, h + 4),
      ]) {
        canvas.drawCircle(
          c,
          55,
          Paint()
            ..shader = RadialGradient(
              colors: const [Color(0x33FFF8E1), Color(0x00FFF8E1)],
            ).createShader(Rect.fromCircle(center: c, radius: 55)),
        );
        canvas.drawCircle(c, 1.2, Paint()..color = const Color(0xFFFFFDE7));
      }
    }
  }

  /// Pluie qui tombe (au-dessus de tout).
  void _drawRain(Canvas canvas, double w, double h) {
    final paint = Paint()
      ..color = const Color(0x66CFE8FF)
      ..strokeWidth = 0.12;
    final r = Random(11);
    final t = game.t;
    for (var i = 0; i < 160; i++) {
      final x = r.nextDouble() * (w + 16) - 8;
      final speed = 14 + r.nextDouble() * 8;
      final y = ((r.nextDouble() * (h + 14)) + t * speed) % (h + 14) - 6;
      canvas.drawLine(Offset(x, y), Offset(x - 0.4, y + 1.6), paint);
    }
  }

  // ---------- décor ----------

  void _drawGround(Canvas canvas, double w, double h) {
    // Abords et pelouse rayée (bandes tondues).
    canvas.drawRect(
      Rect.fromLTWH(-8, -6, w + 16, h + 14),
      Paint()..color = const Color(0xFF1C5230),
    );
    for (var i = 0; i < 18; i++) {
      canvas.drawRect(
        Rect.fromLTWH(i * w / 18, 0, w / 18, h),
        Paint()
          ..color =
              i.isEven ? const Color(0xFF2F8048) : const Color(0xFF379052),
      );
    }
    // Bancs de touche.
    for (final side in [-1.0, 1.0]) {
      final r = Rect.fromCenter(
        center: Offset(w / 2 + side * 12, h + 4.4),
        width: 13,
        height: 2.6,
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(r, const Radius.circular(0.8)),
        Paint()..color = const Color(0xFF0E2A1A),
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(r, const Radius.circular(0.8)),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.15
          ..color = const Color(0x66FFFFFF),
      );
      final dots = side < 0 ? game.homeColor : game.awayColor;
      for (var k = 0; k < 6; k++) {
        canvas.drawCircle(
          Offset(r.left + 1.4 + k * 2.0, r.center.dy),
          0.55,
          Paint()..color = dots.withValues(alpha: 0.85),
        );
      }
    }
    // Lignes.
    canvas.drawRect(Rect.fromLTWH(0, 0, w, h), _line);
    canvas.drawLine(Offset(w / 2, 0), Offset(w / 2, h), _line);
    canvas.drawCircle(Offset(w / 2, h / 2), 9.15, _line);
    canvas.drawCircle(Offset(w / 2, h / 2), 0.3, Paint()..color = _white);
    for (final left in [true, false]) {
      final x0 = left ? 0.0 : w;
      final dir = left ? 1.0 : -1.0;
      canvas.drawRect(
        Rect.fromLTRB(min(x0, x0 + dir * 16.5), h / 2 - 20.16,
            max(x0, x0 + dir * 16.5), h / 2 + 20.16),
        _line,
      );
      canvas.drawRect(
        Rect.fromLTRB(min(x0, x0 + dir * 5.5), h / 2 - 9.16,
            max(x0, x0 + dir * 5.5), h / 2 + 9.16),
        _line,
      );
      canvas.drawCircle(
        Offset(x0 + dir * 11, h / 2),
        0.3,
        Paint()..color = _white,
      );
      // Arc de la surface.
      canvas.drawArc(
        Rect.fromCircle(center: Offset(x0 + dir * 11, h / 2), radius: 9.15),
        left ? -0.93 : pi - 0.93,
        1.86,
        false,
        _line,
      );
      // But et filet.
      final net = Rect.fromLTRB(
        min(x0, x0 - dir * 2.2),
        h / 2 - 3.66,
        max(x0, x0 - dir * 2.2),
        h / 2 + 3.66,
      );
      canvas.drawRect(net, Paint()..color = const Color(0x55FFFFFF));
      final mesh = Paint()
        ..color = const Color(0x40FFFFFF)
        ..strokeWidth = 0.06;
      for (var y = net.top; y <= net.bottom; y += 0.8) {
        canvas.drawLine(Offset(net.left, y), Offset(net.right, y), mesh);
      }
      for (var x = net.left; x <= net.right; x += 0.8) {
        canvas.drawLine(Offset(x, net.top), Offset(x, net.bottom), mesh);
      }
      canvas.drawLine(
        Offset(x0, h / 2 - 3.66),
        Offset(x0, h / 2 + 3.66),
        Paint()
          ..color = const Color(0xFFFFFFFF)
          ..strokeWidth = 0.35,
      );
      // Arcs et drapeaux de corner.
      for (final top in [true, false]) {
        final cy = top ? 0.0 : h;
        canvas.drawArc(
          Rect.fromCircle(center: Offset(x0, cy), radius: 1),
          left ? (top ? 0.0 : -pi / 2) : (top ? pi / 2 : pi),
          pi / 2,
          false,
          _line,
        );
        canvas.drawLine(
          Offset(x0, cy),
          Offset(x0, cy - 1.6),
          Paint()
            ..color = const Color(0xFFFFFFFF)
            ..strokeWidth = 0.12,
        );
        canvas.drawPath(
          Path()
            ..moveTo(x0, cy - 1.6)
            ..lineTo(x0 + dir * 1.0, cy - 1.3)
            ..lineTo(x0, cy - 1.0)
            ..close(),
          Paint()..color = const Color(0xFFFF7043),
        );
      }
    }
  }

  void _drawPlayer(
    Canvas canvas,
    Offset p, {
    required bool home,
    required bool keeper,
    required int number,
    required bool down,
    double angle = 0,
    double speed = 0,
    double phase = 0,
  }) {
    final shirt = keeper
        ? (home ? const Color(0xFFFFC107) : const Color(0xFF26C6DA))
        : (home ? game.homeColor : game.awayColor);
    final light = shirt.computeLuminance() > 0.5;
    final rim = light ? const Color(0xFF1B1B1F) : const Color(0xFFFFFFFF);
    final shorts = Color.lerp(shirt, const Color(0xFF000000), 0.55)!;
    if (down) {
      // Joueur au sol.
      final body = Rect.fromCenter(center: p, width: 3.0, height: 1.2);
      canvas.drawOval(body, Paint()..color = shirt);
      canvas.drawOval(
        body,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.2
          ..color = rim,
      );
      canvas.drawCircle(
        p + const Offset(1.5, 0),
        0.45,
        Paint()..color = const Color(0xFF3E2723),
      );
      return;
    }
    canvas.drawOval(
      Rect.fromCenter(
        center: p + const Offset(0.35, 0.6),
        width: 2.3,
        height: 1.15,
      ),
      Paint()..color = const Color(0x55000000),
    );
    canvas.save();
    canvas.translate(p.dx, p.dy);
    canvas.rotate(angle);
    // Jambes : elles balancent plus vite et plus loin quand il court.
    final swing = sin(phase) * min(0.9, 0.12 + speed * 0.11);
    final leg = Paint()..color = shorts;
    canvas.drawOval(
      Rect.fromCenter(center: Offset(swing, -0.42), width: 0.95, height: 0.5),
      leg,
    );
    canvas.drawOval(
      Rect.fromCenter(center: Offset(-swing, 0.42), width: 0.95, height: 0.5),
      leg,
    );
    // Bras, en opposition des jambes.
    final arm = Paint()..color = shirt;
    canvas.drawCircle(Offset(-swing * 0.7, -1.0), 0.32, arm);
    canvas.drawCircle(Offset(swing * 0.7, 1.0), 0.32, arm);
    // Buste (épaules larges, vu de dessus).
    final torso = Rect.fromCenter(center: Offset.zero, width: 1.35, height: 2.2);
    canvas.drawOval(torso, Paint()..color = shirt);
    canvas.drawOval(
      torso,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.18
        ..color = rim,
    );
    // Tête.
    canvas.drawCircle(
      const Offset(0.15, 0),
      0.5,
      Paint()..color = const Color(0xFF3E2723),
    );
    canvas.restore();
    // Numéro, toujours lisible, sous le joueur.
    final tp = _label(
      '$number',
      0.95,
      light ? const Color(0xFF111111) : const Color(0xFFFFFFFF),
    );
    final tag = Rect.fromCenter(
      center: p + const Offset(0, 1.75),
      width: tp.width + 0.5,
      height: tp.height,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(tag, const Radius.circular(0.3)),
      Paint()..color = shirt.withValues(alpha: 0.9),
    );
    _centered(canvas, tp, tag.center);
  }

  /// Lignes de la formation et zone occupée par le bloc.
  void _drawShape(
    Canvas canvas,
    List<Offset?> team,
    List<int> lines,
    Color color,
  ) {
    final outfield = [
      for (var i = 1; i < team.length; i++)
        if (team[i] != null) team[i]!,
    ];
    if (outfield.length < 4) return;
    var minX = outfield.first.dx;
    var maxX = minX;
    var minY = outfield.first.dy;
    var maxY = minY;
    for (final p in outfield) {
      minX = min(minX, p.dx);
      maxX = max(maxX, p.dx);
      minY = min(minY, p.dy);
      maxY = max(maxY, p.dy);
    }
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTRB(minX - 1, minY - 1, maxX + 1, maxY + 1),
        const Radius.circular(2),
      ),
      Paint()..color = color.withValues(alpha: 0.08),
    );
    final paint = Paint()
      ..color = color.withValues(alpha: 0.75)
      ..strokeWidth = 0.28
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    var k = 1;
    for (final count in lines) {
      final pts = <Offset>[
        for (var i = k; i < k + count && i < team.length; i++)
          if (team[i] != null) team[i]!,
      ]..sort((a, b) => a.dy.compareTo(b.dy));
      k += count;
      if (pts.length < 2) continue;
      final path = Path()..moveTo(pts.first.dx, pts.first.dy);
      for (final q in pts.skip(1)) {
        path.lineTo(q.dx, q.dy);
      }
      canvas.drawPath(path, paint);
    }
  }

  void _drawOfficial(Canvas canvas, Offset p) {
    canvas.drawOval(
      Rect.fromCenter(
        center: p + const Offset(0.3, 0.5),
        width: 2.0,
        height: 1.0,
      ),
      Paint()..color = const Color(0x44000000),
    );
    canvas.drawCircle(p, 0.95, Paint()..color = _refColor);
    canvas.drawCircle(
      p,
      0.95,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.25
        ..color = _refTrim,
    );
  }

  void _drawFlag(Canvas canvas, Offset p, bool up, {required bool top}) {
    final stick = Paint()
      ..color = const Color(0xFFEEEEEE)
      ..strokeWidth = 0.14;
    final base = p + const Offset(0.7, 0);
    final tip = up
        ? base + const Offset(0, -2.6)
        : base + Offset(0.9, top ? 0.9 : -0.9);
    canvas.drawLine(base, tip, stick);
    canvas.drawRect(
      Rect.fromLTWH(tip.dx, tip.dy, 1.0, 0.75),
      Paint()..color = const Color(0xFFFFEB3B),
    );
    final red = Paint()..color = const Color(0xFFE53935);
    canvas.drawRect(Rect.fromLTWH(tip.dx, tip.dy, 0.5, 0.375), red);
    canvas.drawRect(
      Rect.fromLTWH(tip.dx + 0.5, tip.dy + 0.375, 0.5, 0.375),
      red,
    );
  }

  void _drawMedic(Canvas canvas, Offset p) {
    canvas.drawCircle(p, 0.85, Paint()..color = const Color(0xFFF5F5F5));
    canvas.drawCircle(
      p,
      0.85,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.15
        ..color = const Color(0xFF2E7D32),
    );
    _drawCross(canvas, p, size: 0.9);
  }

  void _drawCross(Canvas canvas, Offset p, {double size = 1.4}) {
    final paint = Paint()..color = const Color(0xFFE53935);
    canvas.drawRect(
      Rect.fromCenter(center: p, width: size, height: size * 0.34),
      paint,
    );
    canvas.drawRect(
      Rect.fromCenter(center: p, width: size * 0.34, height: size),
      paint,
    );
  }

  void _drawArrow(Canvas canvas, Offset p, bool entering) {
    final color = entering ? const Color(0xFF69F0AE) : const Color(0xFFFF5252);
    final s = entering ? -1.0 : 1.0;
    final path = Path()
      ..moveTo(p.dx, p.dy + 0.9 * s)
      ..lineTo(p.dx + 0.8, p.dy - 0.2 * s)
      ..lineTo(p.dx - 0.8, p.dy - 0.2 * s)
      ..close();
    canvas.drawPath(path, Paint()..color = color);
  }

  /// Ligne de bombe : le mur se place à 9,15 m du ballon.
  void _drawWallSpray(Canvas canvas, Offset ball, Offset goal) {
    final d = goal - ball;
    final len = max(1.0, d.distance);
    final u = d / len;
    final c = ball + u * 9.15;
    final n = Offset(-u.dy, u.dx);
    final paint = Paint()
      ..color = const Color(0xDDFFFFFF)
      ..strokeWidth = 0.25
      ..strokeCap = StrokeCap.round;
    for (var k = -2.5; k <= 2.5; k += 0.9) {
      canvas.drawLine(c + n * k, c + n * (k + 0.5), paint);
    }
    canvas.drawCircle(ball, 0.45, Paint()..color = const Color(0xBBFFFFFF));
  }
}
