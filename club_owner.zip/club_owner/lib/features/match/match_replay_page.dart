import 'dart:math';

import 'package:flame/game.dart' show GameWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/audio/audio_service.dart';
import '../../core/l10n/l10n.dart';
import '../../domain/entities/match_summary.dart';
import '../../engine/match/match_models.dart' show matchConditions, unpackTrack;
import '../common/crest.dart';
import '../common/landscape_scope.dart';
import '../game/game_state.dart';
import '../share/share_card.dart';
import 'match_game.dart';
import 'match_log.dart';

class _Goal {
  const _Goal(this.minute, this.home, this.scorer, this.assist);

  final int minute;
  final bool home;
  final String scorer;
  final String assist;
}

String _goalSub(_Goal goal, String team) {
  if (goal.assist.isEmpty) return team;
  return '$team · passe de ${goal.assist}';
}

/// Fenêtre d'une action à montrer en entier (mode « Temps forts »).
class _Window {
  _Window(this.from, this.to);

  double from;
  double to;
}

/// Bandeau d'information en bas de l'écran (carton, remplacement...).
class _Banner {
  const _Banner(this.title, this.text, this.color, this.icon);

  final String title;
  final String text;
  final Color color;
  final IconData icon;
}

/// Match en 2D du président : moteur v2 (une image par seconde, arbitres,
/// coups de pied arrêtés, remplacements, blessures), vue fixe.
class MatchReplayPage extends ConsumerStatefulWidget {
  const MatchReplayPage({this.initialSpeed = 1, super.key});

  final double initialSpeed;

  @override
  ConsumerState<MatchReplayPage> createState() => _MatchReplayPageState();
}

class _MatchReplayPageState extends ConsumerState<MatchReplayPage>
    with SingleTickerProviderStateMixin {
  late final Ticker _ticker;
  Duration _last = Duration.zero;

  /// Seconde de jeu affichée.
  double _t = 0;
  double _speed = 1;
  bool _playing = true;
  bool _highlights = true;
  bool _panel = false;
  bool _shape = false;
  AppLang _lang = AppLang.fr;
  double _fill = 0.75;
  bool _night = false;
  int _panelTab = 0;
  bool _intro = true;
  bool _started = false;
  bool _showHalf = false;
  bool _halfDone = false;
  bool _ended = false;
  bool _celebrated = false;
  double _crowdTimer = 0;

  MatchSummary? _summary;
  String _src = '';
  MatchGame? _game;
  List<LogEvent> _log = const [];
  List<_Window> _windows = const [];
  double _end = 5400;
  bool _userHome = true;
  Color _homeColor = const Color(0xFF1E5BD8);
  Color _awayColor = const Color(0xFFD32F2F);

  /// Prochain événement du journal à traiter (sons, bandeaux).
  int _next = 0;

  // But : annonce, puis ralenti de l'action.
  _Goal? _flash;
  double _flashLeft = 0;
  double _goalT = 0;
  double? _replayTo;
  double _resumeAt = 0;
  bool _pendingReplay = false;

  _Banner? _banner;
  double _bannerLeft = 0;

  AudioController get _audio => ref.read(audioProvider.notifier);

  /// Texte dans la langue du joueur (français ou anglais).
  String _l(String fr, String en) => _lang == AppLang.fr ? fr : en;

  /// Secondes de jeu par seconde réelle pendant une action (x1) : on voit
  /// la construction, la passe, la frappe.
  static const double _actionRate = 1.4;

  /// Mode direct (sans « Temps forts ») à x1.
  static const double _directRate = 2.5;

  @override
  void initState() {
    super.initState();
    _speed = widget.initialSpeed.clamp(1, 4).toDouble();
    enforceLandscape();
    _ticker = createTicker(_tick)..start();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _audio.enterMatch();
      _audio.playIntro();
    });
  }

  @override
  void dispose() {
    _ticker.dispose();
    _audio.leaveMatch();
    enforceLandscape();
    super.dispose();
  }

  void _kickOff() {
    _audio.stopJingle();
    setState(() {
      _intro = false;
      _playing = true;
    });
  }

  // ---------- préparation ----------

  void _prepare(MatchSummary s, String userClubId) {
    if (s.track == _src && _game != null) return;
    _src = s.track;
    _userHome = s.homeId == userClubId;
    final kits = matchKits(s.homeName, s.awayName);
    _homeColor = kits.$1;
    _awayColor = kits.$2;
    _log = parseLog(s.log);
    final track = unpackTrack(s.track);
    if (track == null || s.trackVersion < 2 || s.names.length != 22) {
      _game = null;
      return;
    }
    final game = MatchGame(
      track: track,
      frameBytes: 54,
      frameSeconds: 1,
      homeColor: _homeColor,
      awayColor: _awayColor,
      names: s.names,
      events: _log,
    );
    List<int> lines(String label) => [
          for (final part in label.split('-'))
            if (int.tryParse(part) != null) int.parse(part),
        ];
    game.homeLines = lines(s.homeFormation);
    game.awayLines = lines(s.awayFormation);
    final cond = matchConditions(s.season, s.round);
    game.night = cond.night;
    game.rain = cond.rain;
    game.wear = (s.round / 38).clamp(0.0, 1.0).toDouble();
    _fill = s.capacity > 0
        ? (s.attendance / s.capacity).clamp(0.05, 1.0).toDouble()
        : 0.75;
    _night = cond.night;
    _game = game;
    _end = game.duration;
    for (final e in _log) {
      if (e.code == 'FT') _end = min(_end, e.t);
    }
    _windows = _buildWindows();
    _next = 0;
  }

  /// Les actions à montrer en entier, fusionnées.
  List<_Window> _buildWindows() {
    final raw = <_Window>[];
    for (final e in _log) {
      double? pre;
      double? post;
      switch (e.code) {
        case 'SH':
          pre = 14;
          post = 3.5;
        case 'GL':
          pre = 16;
          post = 14;
        case 'PK':
          pre = 6;
          post = 30;
        case 'CK':
          pre = 3;
          post = 19;
        case 'FK':
          if (e.b == 'D') {
            pre = 6;
            post = 21;
          }
        case 'YC':
        case 'RC':
          pre = 8;
          post = 9;
        case 'IN':
          pre = 6;
          post = 12;
        case 'SBA':
          pre = 2;
          post = 5;
        case 'SB':
          pre = 3;
          post = 5;
        case 'OF':
          pre = 10;
          post = 3;
        case 'KO':
          pre = 0;
          post = 7;
        case 'HT':
        case 'FT':
          pre = 4;
          post = 0.5;
      }
      if (pre == null || post == null) continue;
      raw.add(_Window(max(0.0, e.t - pre), e.t + post));
    }
    raw.sort((a, b) => a.from.compareTo(b.from));
    final merged = <_Window>[];
    for (final w in raw) {
      if (merged.isNotEmpty && w.from <= merged.last.to + 2) {
        merged.last.to = max(merged.last.to, w.to);
      } else {
        merged.add(_Window(w.from, w.to));
      }
    }
    return merged;
  }

  _Window? _windowAt(double t) {
    for (final w in _windows) {
      if (t >= w.from && t <= w.to) return w;
      if (w.from > t) break;
    }
    return null;
  }

  double? _nextWindowStart(double t) {
    for (final w in _windows) {
      if (w.from > t) return w.from;
    }
    return null;
  }

  bool get _fastForward =>
      _highlights && !_intro && _replayTo == null && _windowAt(_t) == null;

  /// Vitesse de lecture à l'instant [t] (secondes de jeu par seconde).
  double _rate(double t) {
    final game = _game;
    // Ballon arrêté et joueurs qui se replacent : on accélère, sauf dans
    // les 3 secondes qui précèdent la reprise du jeu.
    final idle = game != null && game.deadBall(t) && game.deadBall(t + 3);
    if (_highlights) {
      if (_windowAt(t) == null) return 50 * _speed;
      return (idle ? 4.5 : _actionRate) * _speed;
    }
    return (idle ? 3 : 1) * _directRate * _speed;
  }

  // ---------- horloge ----------

  void _tick(Duration elapsed) {
    final dt = (elapsed - _last).inMicroseconds / 1000000;
    _last = elapsed;
    if (dt <= 0 || dt > 0.5) return;
    final game = _game;
    if (game == null) return;
    var changed = false;

    if (_bannerLeft > 0) {
      _bannerLeft = max(0.0, _bannerLeft - dt);
      if (_bannerLeft == 0) _banner = null;
      changed = true;
    }

    if (_flashLeft > 0) {
      // Annonce du but : la célébration continue sur le terrain.
      _flashLeft = max(0.0, _flashLeft - dt);
      _t = min(_end, _t + dt * 1.2);
      if (_flashLeft == 0 && _pendingReplay) {
        _pendingReplay = false;
        _resumeAt = _t;
        _replayTo = _goalT + 0.6;
        _t = max(0.0, _goalT - 7);
        _flash = null;
      } else if (_flashLeft == 0) {
        _flash = null;
      }
      changed = true;
    } else if (_replayTo != null) {
      // Ralenti du but (sans relancer les événements).
      _t = min(_replayTo!, _t + dt * 0.55);
      if (_t >= _replayTo!) {
        _t = _resumeAt;
        _replayTo = null;
        _skipEventsTo(_t);
      }
      changed = true;
    } else if (_playing && !_intro && !_showHalf && !_ended) {
      if (!_started) {
        _started = true;
        _audio.sfx(Sfx.whistleShort);
      }
      final prev = _t;
      var next = _t + dt * _rate(_t);
      if (_highlights && _windowAt(_t) == null) {
        final start = _nextWindowStart(_t);
        if (start != null && next > start) next = start;
      }
      _t = min(_end, next);
      _process(prev, _t);
      if (_t >= _end && !_ended) _finish();
      changed = true;
    }

    _crowdTimer += dt;
    if (_crowdTimer > 0.35) {
      _crowdTimer = 0;
      _audio.crowdLevel(_crowdIntensity());
    }
    if (changed && mounted) setState(() {});
  }

  void _skipEventsTo(double t) {
    var i = 0;
    while (i < _log.length && _log[i].t <= t) {
      i++;
    }
    _next = i;
  }

  /// Événements franchis entre [from] et [to] : sons, bandeaux, but.
  void _process(double from, double to) {
    while (_next < _log.length && _log[_next].t <= to) {
      final e = _log[_next];
      _next++;
      if (e.t < from - 0.01) continue;
      _onEvent(e);
      if (_flash != null || _showHalf) break;
    }
  }

  String _team(bool home) {
    final s = _summary;
    if (s == null) return '';
    return home ? s.homeName : s.awayName;
  }

  void _showBanner(String title, String text, Color color, IconData icon,
      {double seconds = 3.2}) {
    _banner = _Banner(title, text, color, icon);
    _bannerLeft = seconds;
  }

  void _onEvent(LogEvent e) {
    switch (e.code) {
      case 'KO':
        if (e.t > 1) _audio.sfx(Sfx.whistleShort, volume: 0.7);
      case 'FL':
        _audio.sfx(Sfx.whistleShort, volume: 0.55);
      case 'OF':
        _audio.sfx(Sfx.whistleShort, volume: 0.55);
        _showBanner(_l('HORS-JEU', 'OFFSIDE'), '${e.a} (${_team(e.home)})',
            const Color(0xFFFFB300), Icons.flag);
      case 'YC':
        _showBanner(_l('CARTON JAUNE', 'YELLOW CARD'), '${e.a} · ${_team(e.home)}',
            const Color(0xFFFFD600), Icons.style);
      case 'RC':
        _showBanner(
          _l('CARTON ROUGE', 'RED CARD'),
          '${e.a}${e.b == '2' ? ' (second jaune)' : ''} · ${_team(e.home)}',
          const Color(0xFFE53935),
          Icons.style,
          seconds: 4,
        );
        _audio.sfx(Sfx.groan, volume: 0.6);
      case 'IN':
        _showBanner(
          _l('BLESSURE', 'INJURY'),
          '${e.a} reste au sol${e.b == 'S' ? ', il ne pourra pas continuer' : ''}',
          const Color(0xFFEF5350),
          Icons.healing,
          seconds: 4,
        );
      case 'SB':
        _showBanner('${_l('REMPLACEMENT', 'SUBSTITUTION')} · ${_team(e.home)}',
            '▲ ${e.b}   ▼ ${e.a}', const Color(0xFF43A047), Icons.swap_vert,
            seconds: 4);
      case 'PK':
        _audio.sfx(Sfx.whistleShort);
        _showBanner(_l('PENALTY !', 'PENALTY!'), _l('Pour ${_team(e.home)} · ${e.a} va tirer', '${_team(e.home)} · ${e.a} steps up'),
            const Color(0xFFF5C04A), Icons.sports_soccer,
            seconds: 4);
      case 'PKS':
        if (e.b == 'S') {
          _showBanner(_l('ARRÊTÉ !', 'SAVED!'), _l('Le gardien repousse le penalty de ${e.a}', 'The keeper saves ${e.a}\'s penalty'),
              const Color(0xFF42A5F5), Icons.back_hand);
        } else if (e.b == 'M') {
          _showBanner(_l('MANQUÉ !', 'MISSED!'), _l('${e.a} rate son penalty', '${e.a} misses the penalty'),
              const Color(0xFF90A4AE), Icons.close);
        }
      case 'CK':
        _showBanner('CORNER', _l('Pour ${_team(e.home)} · ${e.a} au point de corner', '${_team(e.home)} · ${e.a} takes it'),
            const Color(0xFF26A69A), Icons.flag_circle,
            seconds: 2.6);
      case 'FK':
        if (e.b == 'D') {
          _showBanner(_l('COUP FRANC DANGEREUX', 'DANGEROUS FREE KICK'),
              '${_team(e.home)} · ${e.a} face au mur',
              const Color(0xFF7E57C2), Icons.sports_soccer,
              seconds: 3);
        }
      case 'SV':
        if (e.b != 'C') {
          _showBanner(_l('ARRÊT', 'SAVE'), _l('Parade de ${e.a}', 'Great save by ${e.a}'), const Color(0xFF42A5F5),
              Icons.back_hand,
              seconds: 2.2);
        }
      case 'GL':
        _onGoal(e);
      case 'HT':
        _audio.sfx(Sfx.whistleHalf);
        _halfDone = true;
        _showHalf = true;
      case 'FT':
        _finish();
    }
  }

  void _onGoal(LogEvent e) {
    final s = _summary;
    var assist = e.b;
    var minute = minuteOf(e.t);
    if (s != null) {
      for (final g in s.goals) {
        if (g.home == e.home && g.scorer == e.a) {
          minute = g.minute;
          if (assist.isEmpty) assist = g.assist;
        }
      }
    }
    _flash = _Goal(minute, e.home, e.a, assist);
    _flashLeft = 3.6;
    _goalT = e.t;
    _pendingReplay = true;
    _audio.sfx(e.home == _userHome ? Sfx.goalCheer : Sfx.groan);
  }

  void _finish() {
    if (_ended) return;
    _ended = true;
    _t = _end;
    _audio.sfx(Sfx.whistleFinal);
    final s = _summary;
    if (s != null && !_celebrated) {
      _celebrated = true;
      final mine = _userHome ? s.homeGoals : s.awayGoals;
      final theirs = _userHome ? s.awayGoals : s.homeGoals;
      if (mine > theirs) _audio.playCelebration();
    }
  }

  void _seek(double t) {
    setState(() {
      _t = t.clamp(0.0, _end).toDouble();
      _intro = false;
      _showHalf = false;
      _ended = false;
      if (_t >= 2700) _halfDone = true;
      _flash = null;
      _flashLeft = 0;
      _replayTo = null;
      _pendingReplay = false;
      _banner = null;
      _bannerLeft = 0;
      _skipEventsTo(_t);
    });
  }

  double _crowdIntensity() {
    final ball = _game?.pos(22, _t);
    if (ball == null) return 0.35;
    final edge =
        (((ball.dx / kPitchW) - 0.5).abs() * 2 - 0.45).clamp(0.0, 0.55) / 0.55;
    return 0.28 + 0.5 * edge + (_flashLeft > 0 ? 0.3 : 0);
  }

  // ---------- lecture du journal ----------

  (int, int) _score() {
    final s = _summary;
    if (s != null && _ended) return (s.homeGoals, s.awayGoals);
    var h = 0;
    var a = 0;
    for (final e in _log) {
      if (e.t > _t + 0.01) break;
      if (e.code != 'GL') continue;
      if (e.home) {
        h++;
      } else {
        a++;
      }
    }
    return (h, a);
  }

  /// Part du temps passée par le ballon dans le camp adverse (domicile).
  int _territory(double upTo) {
    final g = _game;
    if (g == null) return 50;
    var home = 0;
    var n = 0;
    for (var t = 0.0; t <= upTo; t += 10) {
      final b = g.pos(22, t);
      if (b == null) continue;
      n++;
      final second = t >= 2700;
      if (second ? b.dx < kPitchW / 2 : b.dx > kPitchW / 2) home++;
    }
    return n == 0 ? 50 : (home * 100 / n).round();
  }

  Set<String> _focus() {
    final out = <String>{};
    final f = _flash;
    if (f != null) out.add(f.scorer);
    if (_replayTo != null) {
      for (final e in _log) {
        if (e.code == 'GL' && (e.t - _goalT).abs() < 0.5) out.add(e.a);
      }
    }
    for (final e in _log) {
      if (e.t > _t + 7) break;
      if (e.code == 'SH' && _t >= e.t - 6 && _t <= e.t + 1.5) out.add(e.a);
      if ((e.code == 'PK' && _t >= e.t && _t <= e.t + 30)) out.add(e.a);
      if ((e.code == 'YC' || e.code == 'RC') && _t >= e.t && _t <= e.t + 4) {
        out.add(e.a);
      }
    }
    return out;
  }

  String _commentary(MatchSummary m) {
    if (_lang != AppLang.fr) return _commentaryEn(m);
    if (_ended) return 'Coup de sifflet final.';
    if (_showHalf) return 'Mi-temps. Les équipes rentrent aux vestiaires.';
    final f = _flash;
    if (f != null) {
      return "BUT pour ${_team(f.home)} ! ${f.scorer} (${f.minute}')";
    }
    if (_replayTo != null) return 'Au ralenti : revivez l\'action du but.';
    LogEvent? recent;
    for (final e in _log) {
      if (e.t > _t) break;
      if (_t - e.t <= 6 && e.code != 'TI') recent = e;
    }
    // Annonce d'une frappe imminente.
    for (final e in _log) {
      if (e.t > _t + 4) break;
      if (e.code == 'SH' && e.t > _t && e.t - _t <= 4) {
        return 'Occasion pour ${_team(e.home)}, ${e.a} s\'approche du but…';
      }
    }
    final e = recent;
    if (e != null) {
      final team = _team(e.home);
      String pick(List<String> options) =>
          options[(e.t * 7.31).floor().abs() % options.length];
      switch (e.code) {
        case 'KO':
          return _t < 30
              ? pick([
                  "Coup d'envoi ! C'est parti.",
                  "L'arbitre siffle le début de la rencontre.",
                  'Les deux équipes sont prêtes : le match commence !',
                ])
              : pick(['Reprise du jeu.', 'Le ballon est remis en jeu au centre.']);
        case 'FL':
          return pick([
            'Faute de ${e.a} sur ${e.b}. L\'arbitre siffle.',
            '${e.b} est fauché par ${e.a}, coup de sifflet.',
            'Intervention en retard de ${e.a}. Faute.',
            '${e.a} accroche ${e.b}, l\'arbitre arrête le jeu.',
          ]);
        case 'YC':
          return pick([
            'Carton jaune pour ${e.a}.',
            '${e.a} est averti par l\'arbitre.',
            'L\'arbitre sort le jaune : ${e.a} devra faire attention.',
          ]);
        case 'RC':
          return pick([
            'Carton rouge ! ${e.a} doit quitter le terrain.',
            'Expulsion de ${e.a} ! $team va finir à dix.',
          ]);
        case 'IN':
          return pick([
            '${e.a} est touché, les soigneurs entrent sur la pelouse.',
            '${e.a} se tient la jambe, le staff médical accourt.',
          ]);
        case 'SBA':
          return 'Le quatrième arbitre lève le panneau pour $team.';
        case 'SB':
          return pick([
            '${e.b} entre à la place de ${e.a}.',
            'Changement pour $team : ${e.a} cède sa place à ${e.b}.',
          ]);
        case 'FK':
          return e.b == 'D'
              ? pick([
                  'Coup franc idéalement placé. ${e.a} pose le ballon, le mur se forme.',
                  'Coup franc dangereux pour $team ! ${e.a} s\'en charge.',
                  'Position de frappe pour ${e.a}, l\'arbitre recule le mur.',
                ])
              : pick(['Coup franc pour $team.', '$team relance sur coup franc.']);
        case 'CK':
          return pick([
            'Corner pour $team. Tout le monde monte dans la surface.',
            '${e.a} va tirer le corner, les grands sont dans la surface.',
            'Corner ! Bousculade dans la surface.',
          ]);
        case 'CR':
          return pick([
            'Centre de ${e.a} dans la surface…',
            '${e.a} envoie le ballon au second poteau…',
            'Ballon brossé par ${e.a}…',
          ]);
        case 'CL':
          return pick([
            'Dégagement de ${e.a} !',
            '${e.a} s\'impose de la tête et éloigne le danger.',
            'La défense tient bon, ${e.a} dégage.',
          ]);
        case 'PK':
          return pick([
            'Penalty ! ${e.a} prend le ballon.',
            'L\'arbitre désigne le point de penalty ! ${e.a} va tirer.',
          ]);
        case 'PKS':
          return e.b == 'G'
              ? pick([
                  'Penalty transformé par ${e.a} !',
                  '${e.a} prend le gardien à contre-pied !',
                ])
              : (e.b == 'S'
                  ? 'Le gardien arrête le penalty de ${e.a} !'
                  : '${e.a} manque le cadre sur penalty !');
        case 'OF':
          return pick([
            'Drapeau levé : ${e.a} est hors-jeu.',
            '${e.a} était parti trop tôt, hors-jeu signalé.',
            'L\'assistant signale le hors-jeu de ${e.a}.',
          ]);
        case 'GK':
          return pick(['Six mètres pour $team.', 'Le gardien va dégager.']);
        case 'SH':
          switch (e.b.isEmpty ? 'M' : e.b[0]) {
            case 'S':
              return e.b.endsWith('H')
                  ? pick([
                      'Tête de ${e.a}… arrêt du gardien !',
                      'Superbe tête de ${e.a}, le gardien s\'envole !',
                    ])
                  : pick([
                      'Frappe de ${e.a}… arrêt du gardien !',
                      '${e.a} déclenche, le gardien repousse !',
                      'Tir cadré de ${e.a}, parade du gardien !',
                    ]);
            case 'M':
              return e.b.endsWith('F')
                  ? 'Coup franc direct de ${e.a}… au-dessus !'
                  : pick([
                      '${e.a} tente sa chance… à côté !',
                      'La frappe de ${e.a} frôle le poteau !',
                      '${e.a} ne cadre pas, dommage.',
                      'Énorme occasion pour ${e.a}… au-dessus !',
                    ]);
            case 'B':
              return pick([
                'Frappe de ${e.a}, contrée par la défense !',
                'Le tir de ${e.a} est bloqué !',
              ]);
          }
        case 'SV':
          return e.b == 'C'
              ? 'Sortie autoritaire du gardien ${e.a}.'
              : pick([
                  'Belle parade de ${e.a} !',
                  '${e.a} sauve son équipe !',
                ]);
      }
    }
    final ball = _game?.pos(22, _t);
    if (ball != null) {
      final homeRight = _t < 2700;
      final x = ball.dx / kPitchW;
      if (x > 0.8 || x < 0.2) {
        final homeAttacking = (x > 0.8) == homeRight;
        return 'Situation chaude devant le but de '
            '${homeAttacking ? m.awayName : m.homeName}.';
      }
    }
    return 'Le ballon circule au milieu de terrain.';
  }

  String _commentaryEn(MatchSummary m) {
    if (_ended) return 'Full-time whistle.';
    if (_showHalf) return 'Half time. The players head to the dressing rooms.';
    final f = _flash;
    if (f != null) return "GOAL for ${_team(f.home)}! ${f.scorer} (${f.minute}')";
    if (_replayTo != null) return 'Slow motion: watch the goal again.';
    for (final e in _log) {
      if (e.t > _t + 4) break;
      if (e.code == 'SH' && e.t > _t && e.t - _t <= 4) {
        return 'Chance for ${_team(e.home)}, ${e.a} closes in on goal…';
      }
    }
    LogEvent? e;
    for (final x in _log) {
      if (x.t > _t) break;
      if (_t - x.t <= 6 && x.code != 'TI') e = x;
    }
    if (e != null) {
      final team = _team(e.home);
      switch (e.code) {
        case 'KO':
          return _t < 30 ? 'Kick-off! Here we go.' : 'Play restarts.';
        case 'FL':
          return 'Foul by ${e.a} on ${e.b}.';
        case 'YC':
          return 'Yellow card for ${e.a}.';
        case 'RC':
          return 'Red card! ${e.a} is sent off.';
        case 'IN':
          return '${e.a} is down, the medical staff come on.';
        case 'SBA':
          return 'The fourth official raises the board for $team.';
        case 'SB':
          return '${e.b} comes on for ${e.a}.';
        case 'FK':
          return e.b == 'D'
              ? 'Dangerous free kick. ${e.a} over the ball, the wall lines up.'
              : 'Free kick to $team.';
        case 'CK':
          return 'Corner for $team. Everyone up in the box.';
        case 'CR':
          return 'Cross from ${e.a} into the box…';
        case 'CL':
          return 'Cleared by ${e.a}!';
        case 'PK':
          return 'Penalty! ${e.a} picks up the ball.';
        case 'PKS':
          return e.b == 'G'
              ? '${e.a} scores the penalty!'
              : (e.b == 'S' ? 'Penalty saved!' : '${e.a} misses the target!');
        case 'OF':
          return 'Flag up: ${e.a} is offside.';
        case 'GK':
          return 'Goal kick for $team.';
        case 'SH':
          final o = e.b.isEmpty ? 'M' : e.b[0];
          if (o == 'S') return 'Shot by ${e.a}… saved!';
          if (o == 'B') return 'Shot by ${e.a}, blocked!';
          if (o == 'M') return '${e.a} tries his luck… wide!';
        case 'SV':
          return 'Great save by ${e.a}!';
      }
    }
    return 'The ball moves around midfield.';
  }

  /// Statistiques en direct, tirées du journal.
  Map<String, (int, int)> _liveStats() {
    final out = <String, (int, int)>{};
    void add(String k, bool home) {
      final v = out[k] ?? (0, 0);
      out[k] = home ? (v.$1 + 1, v.$2) : (v.$1, v.$2 + 1);
    }

    for (final e in _log) {
      if (e.t > _t) break;
      switch (e.code) {
        case 'SH':
          add('Tirs', e.home);
          if (e.b.startsWith('G') || e.b.startsWith('S')) add('Cadrés', e.home);
        case 'PKS':
          add('Tirs', e.home);
          if (e.b != 'M') add('Cadrés', e.home);
        case 'CK':
          add('Corners', e.home);
        case 'FL':
          add('Fautes', e.home);
        case 'OF':
          add('Hors-jeu', e.home);
        case 'YC':
          add('Cartons jaunes', e.home);
        case 'RC':
          add('Cartons rouges', e.home);
      }
    }
    return out;
  }

  /// Réaction du président dans sa loge, selon ce qui vient de se passer.
  (String, String) _presidentMood() {
    if (_ended) {
      final s = _summary;
      if (s != null) {
        final mine = _userHome ? s.homeGoals : s.awayGoals;
        final theirs = _userHome ? s.awayGoals : s.homeGoals;
        if (mine > theirs) return ('🥳', 'Le président applaudit ses joueurs');
        if (mine < theirs) return ('😞', 'Le président quitte sa loge, déçu');
      }
      return ('🤝', 'Le président salue un match accroché');
    }
    for (final e in _log.reversed) {
      if (e.t > _t) continue;
      if (_t - e.t > 9) break;
      final mine = e.home == _userHome;
      switch (e.code) {
        case 'GL':
          return mine
              ? ('🤩', 'Le président bondit de joie !')
              : ('🤦', 'Le président se prend la tête');
        case 'PK':
          return mine
              ? ('😬', 'Le président retient son souffle')
              : ('😠', 'Le président conteste le penalty');
        case 'RC':
          return mine
              ? ('😡', "Le président fulmine contre l'arbitre")
              : ('😏', 'Le président apprécie la décision');
        case 'SH':
          if (mine && e.b.isNotEmpty && e.b[0] != 'G') {
            return ('😫', 'Le président y a cru !');
          }
        case 'SV':
          if (mine) return ('👏', 'Le président salue son gardien');
        case 'IN':
          if (mine) return ('😟', 'Le président s\'inquiète pour son joueur');
      }
    }
    final (h, a) = _score();
    final diff = _userHome ? h - a : a - h;
    if (diff > 0) return ('😌', 'Le président savoure dans sa loge');
    if (diff < 0) return ('😰', 'Le président trépigne');
    return ('🧐', 'Le président suit le match, concentré');
  }

  /// Pouls des supporters (0 à 100) pendant le match.
  int _fanPulse() {
    final (h, a) = _score();
    final diff = _userHome ? h - a : a - h;
    var v = 55 + diff * 14;
    for (final e in _log) {
      if (e.t > _t) break;
      if (e.code == 'SH' && e.home == _userHome) v += 1;
      if (e.code == 'SH' && e.home != _userHome) v -= 1;
      if (e.code == 'RC' && e.home == _userHome) v -= 6;
    }
    return v.clamp(0, 100).toInt();
  }

  /// Carte du résultat à partager (WhatsApp, TikTok...).
  void _shareResult(MatchSummary s) {
    final mine = _userHome ? s.homeGoals : s.awayGoals;
    final theirs = _userHome ? s.awayGoals : s.homeGoals;
    final verdict = mine > theirs
        ? 'VICTOIRE'
        : (mine < theirs ? 'DÉFAITE' : 'MATCH NUL');
    final scorers = [
      for (final g in s.goals)
        if (g.home == _userHome) "${g.scorer} ${g.minute}'",
    ];
    showShareCard(
      context,
      ShareContent(
        kicker: verdict,
        headline: '${s.homeGoals} - ${s.awayGoals}',
        detail: scorers.isEmpty
            ? '${s.homeName} - ${s.awayName}'
            : 'Buteurs : ${scorers.join(', ')}',
        message: '$verdict ! ${s.homeName} ${s.homeGoals} - ${s.awayGoals} '
            '${s.awayName}. Je dirige mon club sur Club Owner.',
        club: s.homeName,
        opponent: s.awayName,
        color: mine >= theirs ? const Color(0xFFF5C04A) : const Color(0xFF90A4AE),
        icon: Icons.sports_soccer,
      ),
    );
  }

  // ---------- interface ----------

  @override
  Widget build(BuildContext context) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();
    final summary = game.lastMatch;
    if (summary == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Match en 2D')),
        body: const Center(
          child: Text('Aucun match à revoir : jouez une journée.'),
        ),
      );
    }
    _summary = summary;
    _lang = ref.watch(langProvider);
    _prepare(summary, game.userClub.id);
    final engine = _game;
    if (engine == null) return _LegacyMatch(summary: summary);

    engine.t = _t;
    engine.focus = _focus();
    engine.showShape = _shape;
    final (homeScore, awayScore) = _score();
    final clock = _ended ? 'FIN' : (_showHalf ? 'MT' : clockLabel(_t));
    final finished = _ended;

    return Scaffold(
      backgroundColor: const Color(0xFF07140D),
      body: LayoutBuilder(
        builder: (context, box) {
          final panelW = min(340.0, box.maxWidth * 0.42);
          final right = _panel ? panelW : 0.0;
          return Stack(
            children: [
              Positioned.fill(
                child: CustomPaint(
                  painter: _StandsPainter(
                    fill: _fill,
                    home: _homeColor,
                    away: _awayColor,
                    night: _night,
                  ),
                ),
              ),
              Positioned(
                left: 0,
                right: right,
                top: 58,
                bottom: 56,
                child: GameWidget(game: engine),
              ),
              Positioned(
                left: 8,
                top: 58,
                child: _PresidentBox(
                  mood: _presidentMood(),
                  fans: _fanPulse(),
                ),
              ),
              // Barre du haut : retour, tableau d'affichage, statistiques.
              Positioned(
                left: 8,
                right: 8,
                top: 6,
                child: Row(
                  children: [
                    _RoundButton(
                      icon: Icons.arrow_back,
                      onTap: () => Navigator.of(context).maybePop(),
                    ),
                    const Spacer(),
                    _ScoreBug(
                      home: summary.homeName,
                      away: summary.awayName,
                      homeScore: homeScore,
                      awayScore: awayScore,
                      clock: clock,
                      homeColor: _homeColor,
                      awayColor: _awayColor,
                    ),
                    const Spacer(),
                    _RoundButton(
                      icon: _shape ? Icons.grid_off : Icons.account_tree,
                      onTap: () => setState(() => _shape = !_shape),
                    ),
                    const SizedBox(width: 6),
                    _RoundButton(
                      icon: _panel ? Icons.close : Icons.bar_chart,
                      onTap: () => setState(() => _panel = !_panel),
                    ),
                  ],
                ),
              ),
              Positioned(
                left: 70,
                right: right + 70,
                top: 44,
                child: _Timeline(
                  t: _t,
                  end: _end,
                  log: _log,
                  onSeek: _seek,
                ),
              ),
              // Commandes et commentaire.
              Positioned(
                left: 8,
                right: right + 8,
                bottom: 6,
                child: Row(
                  children: [
                    _RoundButton(
                      icon: _playing && !finished ? Icons.pause : Icons.play_arrow,
                      onTap: () {
                        if (finished) {
                          _seek(0);
                          setState(() => _playing = true);
                          return;
                        }
                        setState(() {
                          _showHalf = false;
                          _playing = !_playing;
                        });
                      },
                    ),
                    const SizedBox(width: 6),
                    for (final sp in const [1.0, 2.0, 4.0])
                      _SpeedChip(
                        label: 'x${sp.toInt()}',
                        selected: _speed == sp,
                        onTap: () => setState(() => _speed = sp),
                      ),
                    _SpeedChip(
                      label: _l('Temps forts', 'Highlights'),
                      icon: Icons.auto_awesome,
                      selected: _highlights,
                      onTap: () => setState(() => _highlights = !_highlights),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Container(
                        height: 36,
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        alignment: Alignment.centerLeft,
                        decoration: BoxDecoration(
                          color: Colors.black.withAlpha(120),
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: Text(
                          _commentary(summary),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    _RoundButton(
                      icon: Icons.skip_next,
                      onTap: () {
                        _seek(_end);
                        _finish();
                      },
                    ),
                  ],
                ),
              ),
              if (_fastForward && _playing && !_showHalf && !finished)
                Positioned(
                  top: 64,
                  right: right + 16,
                  child: _Tag(
                    text: _l('ACCÉLÉRÉ', 'FAST-FORWARD'),
                    icon: Icons.fast_forward,
                    color: Color(0xCC263238),
                  ),
                ),
              if (_replayTo != null)
                Positioned(
                  top: 64,
                  left: 16,
                  child: _Tag(
                    text: _l('RALENTI', 'SLOW-MO'),
                    icon: Icons.slow_motion_video,
                    color: Color(0xFFD32F2F),
                  ),
                ),
              if (_banner != null)
                Positioned(
                  left: 16,
                  bottom: 60,
                  child: _LowerThird(banner: _banner!),
                ),
              if (_intro)
                Positioned.fill(
                  child: _IntroCard(summary: summary, onKickOff: _kickOff),
                ),
              if (_flash != null)
                Positioned.fill(
                  right: right,
                  child: IgnorePointer(
                    child: _GoalBanner(
                      goal: _flash!,
                      team: _team(_flash!.home),
                      progress: (_flashLeft / 3.6).clamp(0.0, 1.0).toDouble(),
                      color: _flash!.home ? _homeColor : _awayColor,
                    ),
                  ),
                ),
              if (_showHalf || finished)
                Positioned.fill(
                  right: right,
                  child: _BreakCard(
                    title: finished ? _l('Fin du match', 'Full time') : _l('Mi-temps', 'Half time'),
                    summary: summary,
                    homeScore: homeScore,
                    awayScore: awayScore,
                    territory: _territory(_t),
                    finished: finished,
                    userHome: _userHome,
                    fanRating: (_fanPulse() / 10).round().clamp(1, 10).toInt(),
                    onResume: finished
                        ? () => Navigator.of(context).maybePop()
                        : () => setState(() {
                              _showHalf = false;
                              _playing = true;
                            }),
                    onStats: () => setState(() => _panel = true),
                    onShare: () => _shareResult(summary),
                  ),
                ),
              AnimatedPositioned(
                duration: const Duration(milliseconds: 220),
                curve: Curves.easeOut,
                top: 0,
                bottom: 0,
                right: _panel ? 0 : -panelW,
                width: panelW,
                child: Material(
                  color: const Color(0xF20D1F16),
                  child: SafeArea(
                    left: false,
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.fromLTRB(8, 8, 8, 4),
                          child: Row(
                            children: [
                              for (final (i, label) in const [
                                (0, 'Stats'),
                                (1, 'Joueurs'),
                                (2, 'Faits'),
                              ])
                                Padding(
                                  padding: const EdgeInsets.only(right: 6),
                                  child: ChoiceChip(
                                    label: Text(label),
                                    selected: _panelTab == i,
                                    onSelected: (_) =>
                                        setState(() => _panelTab = i),
                                  ),
                                ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: ListView(
                            padding: const EdgeInsets.all(8),
                            children: [
                              if (_panelTab == 0) ...[
                                _LiveTerritory(
                                  home: summary.homeName,
                                  away: summary.awayName,
                                  value: _territory(_t),
                                ),
                                if (finished && summary.stats != null)
                                  _StatsCard(stats: summary.stats!)
                                else
                                  _LiveStatsCard(stats: _liveStats()),
                              ],
                              if (_panelTab == 1)
                                if (summary.perfs.isNotEmpty)
                                  _PerfCard(summary: summary)
                                else
                                  const Text('Notes indisponibles.'),
                              if (_panelTab == 2) ..._facts(summary),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  List<Widget> _facts(MatchSummary summary) {
    final theme = Theme.of(context);
    final items = <Widget>[];
    for (final e in _log) {
      if (e.t > _t) break;
      final team = _team(e.home);
      final minute = clockLabel(e.t);
      Widget tile(Widget leading, String title, String sub) => ListTile(
            dense: true,
            leading: leading,
            title: Text('$minute  $title'),
            subtitle: Text(sub),
          );
      Widget card(Color c) => Container(
            width: 12,
            height: 16,
            decoration: BoxDecoration(
              color: c,
              borderRadius: BorderRadius.circular(2),
            ),
          );
      switch (e.code) {
        case 'GL':
          items.add(tile(
            const Icon(Icons.sports_soccer, color: Color(0xFFF5C04A)),
            e.a,
            e.b.isEmpty ? team : '$team · passe de ${e.b}',
          ));
        case 'YC':
          items.add(tile(card(const Color(0xFFFFD600)), e.a, 'Carton jaune · $team'));
        case 'RC':
          items.add(tile(card(const Color(0xFFE53935)), e.a, 'Carton rouge · $team'));
        case 'SB':
          items.add(tile(
            const Icon(Icons.swap_vert, color: Colors.white60),
            e.b,
            'remplace ${e.a} · $team',
          ));
        case 'IN':
          items.add(tile(
            const Icon(Icons.healing, color: Color(0xFFEF5350)),
            e.a,
            e.b == 'S' ? 'Blessure, sort sur civière · $team' : 'Touché, reprend · $team',
          ));
        case 'PKS':
          items.add(tile(
            const Icon(Icons.adjust, color: Colors.white70),
            e.a,
            'Penalty ${e.b == 'G' ? 'transformé' : (e.b == 'S' ? 'arrêté' : 'manqué')} · $team',
          ));
      }
    }
    if (items.isEmpty) {
      return [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Text(
            'Rien à signaler pour le moment.',
            style: theme.textTheme.bodySmall,
          ),
        ),
      ];
    }
    return items.reversed.toList();
  }
}

/// Ancien match (moteur précédent) : résumé seulement.
class _LegacyMatch extends StatelessWidget {
  const _LegacyMatch({required this.summary});

  final MatchSummary summary;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      backgroundColor: const Color(0xFF07140D),
      body: Stack(
        children: [
          const Positioned.fill(child: CustomPaint(painter: _StandsPainter())),
          Positioned(
            left: 8,
            top: 8,
            child: SafeArea(
              child: _RoundButton(
                icon: Icons.arrow_back,
                onTap: () => Navigator.of(context).maybePop(),
              ),
            ),
          ),
          Center(
            child: Container(
              width: 460,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFF0F2419),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: const Color(0xFFF5C04A).withAlpha(140)),
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        ClubCrest(name: summary.homeName, size: 30),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: Text(
                            '${summary.homeGoals} - ${summary.awayGoals}',
                            style: theme.textTheme.headlineMedium?.copyWith(
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                        ClubCrest(name: summary.awayName, size: 30),
                      ],
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      'Ce match a été joué avec l\'ancien moteur. Le nouveau '
                      'match en 2D (arbitres, corners, coups francs, penalties, '
                      'remplacements, blessures) démarre dès votre prochain '
                      'match.',
                      textAlign: TextAlign.center,
                    ),
                    if (summary.stats != null) _StatsCard(stats: summary.stats!),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Tag extends StatelessWidget {
  const _Tag({required this.text, required this.icon, required this.color});

  final String text;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: Colors.white),
          const SizedBox(width: 6),
          Text(
            text,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}

/// Bandeau télé en bas à gauche (carton, remplacement, corner...).
class _LowerThird extends StatelessWidget {
  const _LowerThird({required this.banner});

  final _Banner banner;

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 420),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Container(
          color: const Color(0xEE0B1A12),
          child: IntrinsicHeight(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(width: 5, color: banner.color),
                Padding(
                  padding: const EdgeInsets.fromLTRB(10, 8, 6, 8),
                  child: Icon(banner.icon, color: banner.color, size: 22),
                ),
                Flexible(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(4, 8, 14, 8),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          banner.title,
                          style: TextStyle(
                            color: banner.color,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                            fontSize: 12,
                          ),
                        ),
                        Text(
                          banner.text,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Statistiques en direct (avant le coup de sifflet final).
class _LiveStatsCard extends StatelessWidget {
  const _LiveStatsCard({required this.stats});

  final Map<String, (int, int)> stats;

  @override
  Widget build(BuildContext context) {
    const keys = [
      'Tirs',
      'Cadrés',
      'Corners',
      'Fautes',
      'Hors-jeu',
      'Cartons jaunes',
      'Cartons rouges',
    ];
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Text('En direct', style: Theme.of(context).textTheme.titleSmall),
            for (final k in keys)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Row(
                  children: [
                    SizedBox(width: 40, child: Text('${stats[k]?.$1 ?? 0}')),
                    Expanded(child: Center(child: Text(k))),
                    SizedBox(
                      width: 40,
                      child: Text(
                        '${stats[k]?.$2 ?? 0}',
                        textAlign: TextAlign.end,
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/// Frise du match en secondes : buts, cartons, remplacements ; touchable.
class _Timeline extends StatelessWidget {
  const _Timeline({
    required this.t,
    required this.end,
    required this.log,
    required this.onSeek,
  });

  final double t;
  final double end;
  final List<LogEvent> log;
  final ValueChanged<double> onSeek;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, box) {
        final w = box.maxWidth;
        final total = max(1.0, end);
        double px(double s) => w * (s / total).clamp(0.0, 1.0);
        void seek(Offset p) => onSeek(p.dx / w * total);
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapDown: (d) => seek(d.localPosition),
          onHorizontalDragUpdate: (d) => seek(d.localPosition),
          child: SizedBox(
            height: 14,
            child: Stack(
              clipBehavior: Clip.none,
              alignment: Alignment.centerLeft,
              children: [
                Container(
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                Container(
                  width: px(t),
                  height: 4,
                  decoration: BoxDecoration(
                    color: const Color(0xFFF5C04A),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                Positioned(
                  left: px(2700) - 1,
                  child: Container(width: 2, height: 10, color: Colors.white54),
                ),
                for (final e in log)
                  if (e.code == 'GL' || e.code == 'RC' || e.code == 'YC')
                    Positioned(
                      left: px(e.t) - (e.code == 'GL' ? 5 : 3),
                      child: Container(
                        width: e.code == 'GL' ? 10 : 6,
                        height: e.code == 'GL' ? 10 : 8,
                        decoration: BoxDecoration(
                          shape: e.code == 'GL'
                              ? BoxShape.circle
                              : BoxShape.rectangle,
                          color: e.t > t
                              ? Colors.white38
                              : (e.code == 'GL'
                                  ? (e.home
                                      ? const Color(0xFF64B5F6)
                                      : const Color(0xFFEF9A9A))
                                  : (e.code == 'RC'
                                      ? const Color(0xFFE53935)
                                      : const Color(0xFFFFD600))),
                          border: e.code == 'GL'
                              ? Border.all(color: Colors.white, width: 1)
                              : null,
                        ),
                      ),
                    ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _RoundButton extends StatelessWidget {
  const _RoundButton({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.black.withAlpha(130),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Icon(icon, color: Colors.white, size: 20),
        ),
      ),
    );
  }
}

class _SpeedChip extends StatelessWidget {
  const _SpeedChip({
    required this.label,
    required this.selected,
    required this.onTap,
    this.icon,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    const gold = Color(0xFFF5C04A);
    return Padding(
      padding: const EdgeInsets.only(right: 4),
      child: Material(
        color: selected ? gold : Colors.black.withAlpha(130),
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (icon != null) ...[
                  Icon(icon, size: 14, color: selected ? Colors.black : Colors.white),
                  const SizedBox(width: 4),
                ],
                Text(
                  label,
                  style: TextStyle(
                    color: selected ? Colors.black : Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Tableau d'affichage façon télévision.
class _ScoreBug extends StatelessWidget {
  const _ScoreBug({
    required this.home,
    required this.away,
    required this.homeScore,
    required this.awayScore,
    required this.clock,
    this.homeColor = const Color(0xFF1E5BD8),
    this.awayColor = const Color(0xFFD32F2F),
  });

  final String home;
  final String away;
  final int homeScore;
  final int awayScore;
  final String clock;
  final Color homeColor;
  final Color awayColor;

  String _short(String name) {
    final words = name.split(' ').where((w) => w.length > 2).toList();
    final base = words.isEmpty ? name : words.last;
    return base.substring(0, min(3, base.length)).toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    const style = TextStyle(
      color: Colors.white,
      fontWeight: FontWeight.w900,
      fontSize: 15,
      letterSpacing: 1,
    );
    Widget team(String name, Color color, bool left) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          color: color,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (left) ...[ClubCrest(name: name, size: 18), const SizedBox(width: 6)],
              Text(_short(name), style: style),
              if (!left) ...[const SizedBox(width: 6), ClubCrest(name: name, size: 18)],
            ],
          ),
        );
    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          team(home, homeColor, true),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            color: const Color(0xFF101418),
            child: Text('$homeScore - $awayScore', style: style),
          ),
          team(away, awayColor, false),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            color: const Color(0xFFF5C04A),
            child: Text(
              clock,
              style: style.copyWith(color: Colors.black, fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }
}


/// Grande annonce animée d'un but.
class _GoalBanner extends StatelessWidget {
  const _GoalBanner({
    required this.goal,
    required this.team,
    required this.progress,
    required this.color,
  });

  final _Goal goal;
  final String team;

  /// De 1 (début) à 0 (fin de la célébration).
  final double progress;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final appear = ((1 - progress) * 6).clamp(0.0, 1.0);
    final fade = (progress * 4).clamp(0.0, 1.0);
    final opacity = min(appear, fade).toDouble();
    final scale = 0.7 + 0.3 * Curves.easeOutBack.transform(appear.toDouble());
    return Opacity(
      opacity: opacity,
      child: Center(
        child: Transform.scale(
          scale: scale,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 34, vertical: 14),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [color, Color.lerp(color, Colors.black, 0.45)!],
              ),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFFF5C04A), width: 2),
              boxShadow: const [BoxShadow(blurRadius: 30, color: Colors.black54)],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'BUT !',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 44,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 4,
                  ),
                ),
                Text(
                  "${goal.scorer}  ${goal.minute}'",
                  style: const TextStyle(
                    color: Color(0xFFF5C04A),
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  _goalSub(goal, team),
                  style: const TextStyle(color: Colors.white70, fontSize: 13),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Carte de mi-temps ou de fin de match.
class _BreakCard extends StatelessWidget {
  const _BreakCard({
    required this.title,
    required this.summary,
    required this.homeScore,
    required this.awayScore,
    required this.territory,
    required this.finished,
    required this.userHome,
    required this.onResume,
    required this.onStats,
    this.fanRating,
    this.onShare,
  });

  final VoidCallback? onShare;
  final int? fanRating;
  final String title;
  final MatchSummary summary;
  final int homeScore;
  final int awayScore;
  final int territory;
  final bool finished;
  final bool userHome;
  final VoidCallback onResume;
  final VoidCallback onStats;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    PlayerPerf? motm;
    for (final p in summary.perfs) {
      if (motm == null || p.ratingTenths > motm.ratingTenths) motm = p;
    }
    final mine = userHome ? homeScore : awayScore;
    final theirs = userHome ? awayScore : homeScore;
    final verdict = !finished
        ? 'Rendez-vous dans 15 minutes.'
        : (mine > theirs
            ? 'Victoire ! Les supporters exultent.'
            : (mine == theirs ? 'Match nul.' : 'Défaite. Le stade est déçu.'));
    final s = summary.stats;
    return Container(
      color: Colors.black.withAlpha(150),
      alignment: Alignment.center,
      child: Container(
        width: 420,
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: const Color(0xFF0F2419),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFFF5C04A).withAlpha(140)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              title.toUpperCase(),
              style: theme.textTheme.labelLarge?.copyWith(
                color: const Color(0xFFF5C04A),
                letterSpacing: 2,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ClubCrest(name: summary.homeName, size: 30),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                    '$homeScore - $awayScore',
                    style: theme.textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                ClubCrest(name: summary.awayName, size: 30),
              ],
            ),
            const SizedBox(height: 6),
            Text(verdict, style: theme.textTheme.bodyMedium),
            const SizedBox(height: 10),
            _LiveTerritory(
              home: summary.homeName,
              away: summary.awayName,
              value: territory,
            ),
            if (finished && s != null)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                  'Tirs ${s.homeShots}-${s.awayShots} · cadrés '
                  '${s.homeOnTarget}-${s.awayOnTarget} · possession '
                  '${s.homePossession}-${100 - s.homePossession} %',
                  style: theme.textTheme.bodySmall,
                ),
              ),
            if (finished && fanRating != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  'Note des supporters : $fanRating/10',
                  style: const TextStyle(
                    color: Color(0xFFF5C04A),
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            if (finished && motm != null)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.star, color: Color(0xFFF5C04A), size: 18),
                    const SizedBox(width: 6),
                    Text(
                      'Homme du match : ${motm.name} '
                      '(${(motm.ratingTenths / 10).toStringAsFixed(1)})',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 14),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                OutlinedButton.icon(
                  onPressed: onStats,
                  icon: const Icon(Icons.bar_chart, size: 18),
                  label: const Text('Statistiques'),
                ),
                if (finished && onShare != null) ...[
                  const SizedBox(width: 10),
                  OutlinedButton.icon(
                    onPressed: onShare,
                    icon: const Icon(Icons.share, size: 18),
                    label: const Text('Partager'),
                  ),
                ],
                const SizedBox(width: 10),
                FilledButton.icon(
                  onPressed: onResume,
                  icon: Icon(finished ? Icons.home : Icons.play_arrow, size: 18),
                  label: Text(finished ? 'Retour au club' : 'Seconde période'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Barre de territoire (part du jeu dans le camp adverse).
class _LiveTerritory extends StatelessWidget {
  const _LiveTerritory({
    required this.home,
    required this.away,
    required this.value,
  });

  final String home;
  final String away;
  final int value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Column(
        children: [
          Row(
            children: [
              Text('$value %',
                  style: const TextStyle(fontWeight: FontWeight.w800)),
              const Expanded(
                child: Text(
                  'Territoire',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white60, fontSize: 12),
                ),
              ),
              Text('${100 - value} %',
                  style: const TextStyle(fontWeight: FontWeight.w800)),
            ],
          ),
          const SizedBox(height: 4),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: Row(
              children: [
                Expanded(
                  flex: max(1, value),
                  child: Container(height: 6, color: const Color(0xFF1E5BD8)),
                ),
                Expanded(
                  flex: max(1, 100 - value),
                  child: Container(height: 6, color: const Color(0xFFD32F2F)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Décor : tribunes remplies selon l'affluence réelle, aux couleurs des
/// deux clubs, projecteurs en nocturne.
class _StandsPainter extends CustomPainter {
  const _StandsPainter({
    this.fill = 0.75,
    this.home = const Color(0xFF1E5BD8),
    this.away = const Color(0xFFD32F2F),
    this.night = false,
  });

  final double fill;
  final Color home;
  final Color away;
  final bool night;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = RadialGradient(
          center: const Alignment(0, -0.2),
          radius: 1.1,
          colors: night
              ? const [Color(0xFF10202E), Color(0xFF02060A)]
              : const [Color(0xFF173A28), Color(0xFF050D09)],
        ).createShader(rect),
    );
    final rnd = Random(5);
    final dot = Paint();
    final seats = (1400 * fill).round();
    for (var i = 0; i < 1400; i++) {
      final x = rnd.nextDouble() * size.width;
      final y = rnd.nextDouble() * size.height;
      final occupied = i < seats;
      if (!occupied) {
        dot.color = const Color(0x10FFFFFF);
      } else if (x > size.width * 0.78 && y < size.height * 0.3) {
        // Parcage visiteur.
        dot.color = away.withAlpha(120);
      } else {
        dot.color = [
          home.withAlpha(110),
          home.withAlpha(80),
          const Color(0x30FFFFFF),
          const Color(0x22F5C04A),
        ][i % 4];
      }
      canvas.drawCircle(Offset(x, y), occupied ? 1.6 : 1.1, dot);
    }
    if (night) {
      for (final c in [
        const Offset(0, 0),
        Offset(size.width, 0),
        Offset(0, size.height),
        Offset(size.width, size.height),
      ]) {
        canvas.drawCircle(
          c,
          size.shortestSide * 0.5,
          Paint()
            ..shader = RadialGradient(
              colors: const [Color(0x55FFF8E1), Color(0x00FFF8E1)],
            ).createShader(
              Rect.fromCircle(center: c, radius: size.shortestSide * 0.5),
            ),
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant _StandsPainter old) =>
      old.fill != fill || old.night != night || old.home != home;
}

/// Le président dans sa loge : ses réactions et le pouls des supporters.
class _PresidentBox extends StatelessWidget {
  const _PresidentBox({required this.mood, required this.fans});

  final (String, String) mood;
  final int fans;

  @override
  Widget build(BuildContext context) {
    final color = fans >= 65
        ? const Color(0xFF66BB6A)
        : (fans >= 40 ? const Color(0xFFF5C04A) : const Color(0xFFEF5350));
    return Container(
      width: 168,
      padding: const EdgeInsets.fromLTRB(10, 7, 10, 8),
      decoration: BoxDecoration(
        color: Colors.black.withAlpha(140),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Text(mood.$1, style: const TextStyle(fontSize: 20)),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  mood.$2,
                  maxLines: 2,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            'Tribunes : $fans/100',
            style: const TextStyle(color: Colors.white70, fontSize: 10),
          ),
          const SizedBox(height: 3),
          ClipRRect(
            borderRadius: BorderRadius.circular(3),
            child: LinearProgressIndicator(
              value: fans / 100,
              minHeight: 4,
              color: color,
              backgroundColor: Colors.white12,
            ),
          ),
        ],
      ),
    );
  }
}

class _StatsCard extends StatelessWidget {
  const _StatsCard({required this.stats});

  final MatchStats stats;

  Widget _row(String label, num home, num away, {String suffix = ''}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          SizedBox(width: 56, child: Text('$home$suffix')),
          Expanded(child: Center(child: Text(label))),
          SizedBox(
            width: 56,
            child: Text('$away$suffix', textAlign: TextAlign.end),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = stats;
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Text(
              'Statistiques du match',
              style: Theme.of(context).textTheme.titleSmall,
            ),
            _row('Possession', s.homePossession, 100 - s.homePossession,
                suffix: ' %'),
            if (s.homeXg + s.awayXg > 0)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  children: [
                    Text(
                      (s.homeXg / 100).toStringAsFixed(2),
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    const Expanded(
                      child: Text(
                        'Buts attendus (xG)',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 12),
                      ),
                    ),
                    Text(
                      (s.awayXg / 100).toStringAsFixed(2),
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ],
                ),
              ),
            _row('Tirs', s.homeShots, s.awayShots),
            _row('Tirs cadrés', s.homeOnTarget, s.awayOnTarget),
            _row('Corners', s.homeCorners, s.awayCorners),
            _row('Touches', s.homeThrowIns, s.awayThrowIns),
            _row('Passes', s.homePasses, s.awayPasses),
            _row('Précision des passes', s.homePassAcc, s.awayPassAcc,
                suffix: ' %'),
            _row('Fautes', s.homeFouls, s.awayFouls),
            _row('Hors-jeu', s.homeOffsides, s.awayOffsides),
            _row('Cartons jaunes', s.homeYellow, s.awayYellow),
            _row('Cartons rouges', s.homeRed, s.awayRed),
          ],
        ),
      ),
    );
  }
}

class _PerfCard extends StatelessWidget {
  const _PerfCard({required this.summary});

  final MatchSummary summary;

  Widget _team(BuildContext context, String title, bool home) {
    final list = [
      for (final p in summary.perfs)
        if (p.home == home) p,
    ];
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 8, bottom: 4),
          child: Text(title, style: theme.textTheme.titleSmall),
        ),
        for (final p in list)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 2),
            child: Row(
              children: [
                SizedBox(width: 36, child: Text(p.pos)),
                Expanded(
                  child: Text(
                    p.goals > 0
                        ? '${p.name}  ⚽${p.goals > 1 ? "x${p.goals}" : ""}'
                        : p.name,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                SizedBox(
                  width: 64,
                  child: Text(
                    '${p.distanceKm.toStringAsFixed(1)} km',
                    textAlign: TextAlign.end,
                  ),
                ),
                SizedBox(
                  width: 44,
                  child: Text(
                    p.rating.toStringAsFixed(1),
                    textAlign: TextAlign.end,
                    style: theme.textTheme.titleSmall?.copyWith(
                      color: p.rating >= 7.5
                          ? Colors.green
                          : (p.rating < 5.5 ? Colors.red : null),
                    ),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Notes et distance parcourue',
              style: Theme.of(context).textTheme.titleSmall,
            ),
            _team(context, summary.homeName, true),
            _team(context, summary.awayName, false),
          ],
        ),
      ),
    );
  }
}


/// Présentation d'avant-match : compositions et coup d'envoi.
class _IntroCard extends StatelessWidget {
  const _IntroCard({required this.summary, required this.onKickOff});

  final MatchSummary summary;
  final VoidCallback onKickOff;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final names = summary.names;
    Widget column(String club, String formation, Iterable<String> players,
        Color color, CrossAxisAlignment align) {
      return Expanded(
        child: Column(
          crossAxisAlignment: align,
          children: [
            ClubCrest(name: club, size: 46),
            const SizedBox(height: 6),
            Text(
              club,
              textAlign: TextAlign.center,
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w900,
              ),
            ),
            Text(formation, style: TextStyle(color: color, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            for (final n in players)
              Text(n, style: theme.textTheme.bodySmall, maxLines: 1),
          ],
        ),
      );
    }

    return Container(
      color: Colors.black.withAlpha(185),
      alignment: Alignment.center,
      child: Container(
        width: 620,
        constraints: const BoxConstraints(maxHeight: 340),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: const Color(0xFF0F2419),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFFF5C04A).withAlpha(150)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'ENTRÉE DES JOUEURS',
              style: theme.textTheme.labelLarge?.copyWith(
                color: const Color(0xFFF5C04A),
                letterSpacing: 2,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 10),
            Flexible(
              child: SingleChildScrollView(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    column(
                      summary.homeName,
                      summary.homeFormation,
                      names.length == 22 ? names.take(11) : const <String>[],
                      const Color(0xFF64B5F6),
                      CrossAxisAlignment.center,
                    ),
                    const Padding(
                      padding: EdgeInsets.only(top: 14),
                      child: Text(
                        'VS',
                        style: TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.w900,
                          color: Color(0xFFF5C04A),
                        ),
                      ),
                    ),
                    column(
                      summary.awayName,
                      summary.awayFormation,
                      names.length == 22 ? names.skip(11) : const <String>[],
                      const Color(0xFFEF9A9A),
                      CrossAxisAlignment.center,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: onKickOff,
              icon: const Icon(Icons.sports_soccer),
              label: const Text('Coup d\'envoi'),
            ),
          ],
        ),
      ),
    );
  }
}
