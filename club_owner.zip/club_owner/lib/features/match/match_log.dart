/// Lecture du journal du moteur de match v2.
///
/// Chaque ligne : « seconde|code|1 si domicile|a|b|x|y », coordonnées
/// 0..255 dans le repère de l'écran (déjà retournées après la mi-temps).
library;

const double kPitchW = 105;
const double kPitchH = 68;

class LogEvent {
  const LogEvent({
    required this.t,
    required this.code,
    required this.home,
    required this.a,
    required this.b,
    required this.x,
    required this.y,
  });

  /// Seconde de jeu (temps additionnel compris).
  final double t;

  /// KO coup d'envoi, HT, FT, FL faute, YC/RC cartons, IN blessure,
  /// SBA/SB remplacement, FK coup franc, CK corner, CR centre, CL
  /// dégagement, PK penalty sifflé, PKS penalty tiré, OF hors-jeu, TI
  /// touche, GK six mètres, SH tir, SV arrêt, GL but.
  final String code;
  final bool home;
  final String a;
  final String b;

  /// Position en mètres (repère de l'écran).
  final double x;
  final double y;

  static LogEvent? parse(String raw) {
    final p = raw.split('|');
    if (p.length < 7) return null;
    final t = double.tryParse(p[0]);
    if (t == null) return null;
    return LogEvent(
      t: t,
      code: p[1],
      home: p[2] == '1',
      a: p[3],
      b: p[4],
      x: (int.tryParse(p[5]) ?? 128) / 255 * kPitchW,
      y: (int.tryParse(p[6]) ?? 128) / 255 * kPitchH,
    );
  }
}

List<LogEvent> parseLog(List<String> raw) {
  final out = <LogEvent>[];
  for (final r in raw) {
    final e = LogEvent.parse(r);
    if (e != null) out.add(e);
  }
  out.sort((a, b) => a.t.compareTo(b.t));
  return out;
}

/// Noms des 22 joueurs sur le terrain à l'instant [t] (remplacements
/// compris), dans l'ordre des trajectoires.
List<String> namesAt(List<String> initial, List<LogEvent> log, double t) {
  final names = [...initial];
  if (names.length != 22) return names;
  for (final e in log) {
    if (e.t > t) break;
    if (e.code != 'SB') continue;
    final from = e.home ? 0 : 11;
    for (var i = from; i < from + 11; i++) {
      if (names[i] == e.a) {
        names[i] = e.b;
        break;
      }
    }
  }
  return names;
}

/// Numéros de maillot : 1 à 11 pour les titulaires (le gardien porte le 1),
/// 12, 13, 14… pour les remplaçants, dans l'ordre d'entrée.
Map<String, int> shirtNumbers(List<String> initial, List<LogEvent> log) {
  final numbers = <String, int>{};
  if (initial.length != 22) return numbers;
  for (var i = 0; i < 22; i++) {
    numbers[initial[i]] = (i % 11) + 1;
  }
  final next = [12, 12];
  for (final e in log) {
    if (e.code != 'SB') continue;
    final side = e.home ? 0 : 1;
    numbers[e.b] = next[side]++;
  }
  return numbers;
}

/// Minute affichée façon télévision : 45+2', 90+4'.
String clockLabel(double t) {
  if (t < 0) return "0'";
  if (t >= 5400) {
    final extra = ((t - 5400) / 60).floor() + 1;
    return "90+$extra'";
  }
  return "${(t / 60).floor()}'";
}

/// Minute entière (1 à 90) d'un événement.
int minuteOf(double t) => ((t / 60).floor() + 1).clamp(1, 90).toInt();
