import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/utils/format.dart';
import '../../domain/entities/division.dart';
import '../../engine/calendar/fixture_generator.dart';
import '../../engine/owner/board.dart';
import '../../engine/owner/infrastructure.dart';
import '../../engine/owner/season_goals.dart';
import '../../engine/season/season.dart';
import '../../core/utils/calendar.dart';
import '../../engine/world/facilities.dart';
import '../../engine/achievements/achievements.dart';
import '../../core/cloud/cloud_save.dart';
import '../cloud/google_account_card.dart';
import '../events/daily.dart';
import '../common/crest.dart';
import '../common/pro_page.dart';
import '../common/widgets.dart';
import '../game/game_state.dart';

class HomePage extends ConsumerWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();

    final theme = Theme.of(context);
    final season = game.season;
    final club = game.userClub;
    final standings = season.standings;
    final rank = standings.indexWhere((s) => s.clubId == club.id) + 1;
    final row = standings[rank - 1];
    final shownRound = season.isFinished
        ? season.totalRounds
        : season.currentRound;
    final next = season.nextUserFixture;
    final last = season.currentRound > 1
        ? season.userFixtureOfRound(season.currentRound - 1)
        : null;
    final canPlay = game.canPlayNextRound;
    final recentForm = <int>[];
    for (var r = season.currentRound - 1; r >= 1 && recentForm.length < 5; r--) {
      final f = season.userFixtureOfRound(r);
      final res = f == null ? null : season.resultOf(f);
      if (f == null || res == null) continue;
      final mine = f.homeId == club.id ? res.homeGoals : res.awayGoals;
      final theirs = f.homeId == club.id ? res.awayGoals : res.homeGoals;
      recentForm.insert(0, mine > theirs ? 1 : (mine < theirs ? -1 : 0));
    }
    final windowTag = game.transferWindowOpen ? 'mercato ouvert' : 'mercato fermé';

    return Scaffold(
      body: SafeArea(
        left: false,
        child: ProColumns(
        flex: const [7, 4],
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
        columns: [
          [
            if (game.owner.soldFor > 0)
              ProCard(
                highlight: true,
                child: Text(
                  'Vous avez vendu le club pour '
                  '${formatMoney(game.owner.soldFor)}. Votre carrière de '
                  'président est terminée : utilisez « Nouvelle partie » '
                  'dans les paramètres pour recommencer.',
                ),
              ),
            // En-tête sobre : le club, sa division, sa forme.
            Row(
              children: [
                ClubCrest(name: club.name, size: 44),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        club.name,
                        style: theme.textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      Text(
                        '${divisionName(game.division)} · saison '
                        '${seasonLabel(game.seasonNumber)} · journée '
                        '$shownRound/${season.totalRounds}',
                        style: theme.textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                if (recentForm.isNotEmpty) FormChips(results: recentForm),
              ],
            ),
            const SizedBox(height: 18),
            // Le prochain match : l'action principale de l'écran.
            if (!season.isFinished && next != null)
              _NextMatch(
                round: next.round,
                home: season.clubById(next.homeId).name,
                away: season.clubById(next.awayId).name,
                date: formatDateFr(roundDate(game.seasonNumber, next.round)),
                venue: _venue(game, season, next),
                canPlay: canPlay,
                onPlay: () => _showPlayOptions(context, ref, game),
              ),
            if (season.isFinished)
              ProCard(
                highlight: true,
                title: 'Saison terminée',
                icon: Icons.flag,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Vous terminez ${ordinalFr(rank)} sur '
                      '${standings.length}. ${_outcomeText(game)}',
                    ),
                    const SizedBox(height: 12),
                    _PlayButton(
                      label: 'Passer à la saison ${game.seasonNumber + 1}',
                      icon: Icons.flag,
                      onPressed: () =>
                          ref.read(gameProvider.notifier).startNextSeason(),
                    ),
                  ],
                ),
              ),
            if (last != null)
              Builder(
                builder: (context) {
                  final result = season.resultOf(last);
                  return ProCard(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 10,
                    ),
                    onTap: () => context.push('/match'),
                    child: Row(
                      children: [
                        Text(
                          'DERNIER MATCH',
                          style: theme.textTheme.labelSmall,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            '${season.clubById(last.homeId).name}  '
                            '${result == null ? '-' : '${result.homeGoals} - ${result.awayGoals}'}'
                            '  ${season.clubById(last.awayId).name}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                        ),
                        const Icon(Icons.play_circle_outline, size: 20),
                        const SizedBox(width: 4),
                        Text('Revoir', style: theme.textTheme.labelMedium),
                      ],
                    ),
                  );
                },
              ),
            if (game.owner.press != null)
              ProCard(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                onTap: () => context.push('/press'),
                child: Row(
                  children: [
                    const Icon(Icons.mic, size: 20, color: Color(0xFF26A69A)),
                    const SizedBox(width: 10),
                    const Expanded(
                      child: Text(
                        'La presse attend votre réaction',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
                    ),
                    const Icon(Icons.chevron_right),
                  ],
                ),
              ),
            const _CloudNudge(),
          ],
          [
            // Trois chiffres clés, pas plus.
            Row(
              children: [
                _Kpi(
                  label: 'Classement',
                  value: ordinalFr(rank),
                  sub: '${row.points} pts',
                ),
                const SizedBox(width: 8),
                _Kpi(
                  label: 'Trésorerie',
                  value: compactMoney(game.finance.treasury),
                  sub: game.transferWindowOpen ? 'Mercato ouvert' : windowTag,
                ),
                const SizedBox(width: 8),
                _Kpi(
                  label: 'Conseil',
                  value: '${game.owner.confidence}',
                  sub: 'objectif top ${game.boardObjective}',
                ),
              ],
            ),
            const SizedBox(height: 12),
            const _DailyCard(),
            const SizedBox(height: 12),
            _ObjectivesCard(game: game),
            const SizedBox(height: 12),
            _MiniTable(season: season),
            const SizedBox(height: 12),
            Builder(
              builder: (context) {
                final done = unlockedAchievements(game).length;
                return ProCard(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  onTap: () => context.push('/achievements'),
                  child: Row(
                    children: [
                      const Icon(Icons.emoji_events, color: Color(0xFFF5C04A)),
                      const SizedBox(width: 10),
                      Expanded(
                        child: ProMeter(
                          label: 'Succès du président',
                          value: done,
                          max: achievements.length,
                          color: const Color(0xFFF5C04A),
                          suffix: '$done/${achievements.length}',
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
            Row(
              children: [
                Expanded(child: _Quick(Icons.sports_soccer, 'Tactique', '/tactics')),
                const SizedBox(width: 8),
                Expanded(child: _Quick(Icons.swap_horiz, 'Mercato', '/transfers')),
                const SizedBox(width: 8),
                Expanded(
                  child: _Quick(Icons.apartment, 'Installations', '/infrastructure'),
                ),
                const SizedBox(width: 8),
                Expanded(child: _Quick(Icons.public, 'En ligne', '/online')),
              ],
            ),
          ],
        ],
      ),
      ),
    );
  }

  Future<void> _showPlayOptions(
    BuildContext context,
    WidgetRef ref,
    GameState game,
  ) async {
    final notifier = ref.read(gameProvider.notifier);
    final remaining = game.season.totalRounds - game.season.currentRound + 1;

    void simulate(int count) {
      Navigator.of(context).pop();
      final played = notifier.simulateRounds(count);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$played journée(s) simulée(s).')),
      );
    }

    void watch(double speed) {
      Navigator.of(context).pop();
      notifier.playNextRound();
      context.push('/match?speed=${speed.toInt()}');
    }

    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (sheetContext) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Journée ${game.season.currentRound}',
                style: Theme.of(sheetContext).textTheme.titleLarge,
              ),
              const SizedBox(height: 12),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.bolt),
                title: const Text('Simuler la journée'),
                subtitle: const Text('Le résultat tombe tout de suite.'),
                onTap: () => simulate(1),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.fast_forward),
                title: const Text('Simuler 5 journées'),
                subtitle: const Text('Pour avancer vite dans la saison.'),
                onTap: () => simulate(5),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.skip_next),
                title: const Text('Simuler jusqu\'à la fin de la saison'),
                subtitle: Text('$remaining journée(s) restantes.'),
                onTap: () => simulate(remaining),
              ),
              const Divider(),
              Text(
                'Regarder le match en 2D',
                style: Theme.of(sheetContext).textTheme.titleSmall,
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: [
                  for (final speed in const [1.0, 2.0, 4.0])
                    ActionChip(
                      avatar: const Icon(Icons.play_arrow, size: 18),
                      label: Text('Vitesse x${speed.toInt()}'),
                      onPressed: () => watch(speed),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _confirmReset(BuildContext context, WidgetRef ref) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Recommencer ?'),
        content: const Text('La partie en cours sera supprimée.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Annuler'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Supprimer et recommencer'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      ref.read(gameProvider.notifier).resetGame();
    }
  }
}

String _outcomeText(GameState game) {
  final outcome = game.seasonOutcomeNow;
  final target = divisionName(nextDivision(game.division, outcome));
  switch (outcome) {
    case SeasonOutcome.promoted:
      return 'Montée en $target !';
    case SeasonOutcome.relegated:
      return 'Descente en $target.';
    case SeasonOutcome.stayed:
      if (game.division == topDivision && game.season.userRank == 1) {
        return 'Champion de $target !';
      }
      return 'Maintien en $target.';
  }
}

String _venue(GameState game, Season season, Fixture fixture) {
  final home = season.clubById(fixture.homeId);
  if (home.isUser) {
    return game.owner.stadiumName.isEmpty
        ? 'À domicile'
        : 'À domicile · ${game.owner.stadiumName}';
  }
  return 'À l\'extérieur · ${facilitiesOf(home).stadiumName}';
}

String _matchLine(Season season, Fixture fixture) {
  final home = season.clubById(fixture.homeId).name;
  final away = season.clubById(fixture.awayId).name;
  final result = season.resultOf(fixture);
  if (result == null) return '$home - $away';
  return '$home ${result.homeGoals} - ${result.awayGoals} $away';
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.title, required this.lines, this.action});

  final String title;
  final List<String> lines;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: theme.textTheme.titleMedium),
            const SizedBox(height: 8),
            for (final line in lines)
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text(line),
              ),
            if (action != null) action!,
          ],
        ),
      ),
    );
  }
}

class _EmpireCard extends StatelessWidget {
  const _EmpireCard({required this.game});

  final GameState game;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final owner = game.owner;
    final work = owner.work;
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Votre empire', style: theme.textTheme.titleMedium),
            const SizedBox(height: 8),
            TweenAnimationBuilder<double>(
              tween: Tween<double>(
                begin: 0,
                end: game.finance.treasury.toDouble(),
              ),
              duration: const Duration(milliseconds: 600),
              builder: (context, value, _) => Text(
                formatMoney(value.round()),
                style: theme.textTheme.headlineSmall,
              ),
            ),
            const SizedBox(height: 12),
            Text('Réputation : ${owner.reputation} sur 100'),
            const SizedBox(height: 4),
            LinearProgressIndicator(
              value: owner.reputation / 100,
              minHeight: 8,
            ),
            const SizedBox(height: 12),
            Text(confidenceLabel(owner.confidence)),
            const SizedBox(height: 4),
            LinearProgressIndicator(
              value: owner.confidence / 100,
              minHeight: 8,
            ),
            const SizedBox(height: 12),
            Text(
              'Objectif du conseil : terminer dans les '
              '${game.boardObjective} premiers.',
            ),
            const SizedBox(height: 4),
            Text(
              'Stade ${owner.stadium}, entraînement ${owner.training}, '
              'formation ${owner.academy} (sur $maxInfraLevel).',
              style: theme.textTheme.bodySmall,
            ),
            if (work != null)
              Text(
                'Chantier : encore ${work.roundsLeft} journées.',
                style: theme.textTheme.bodySmall,
              ),
          ],
        ),
      ),
    );
  }
}

class _PlayButton extends StatelessWidget {
  const _PlayButton({
    required this.label,
    required this.onPressed,
    this.icon = Icons.sports_soccer,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null;
    return Material(
      borderRadius: BorderRadius.circular(16),
      clipBehavior: Clip.antiAlias,
      color: Colors.transparent,
      child: Ink(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
            colors: enabled
                ? const [Color(0xFF2FBF7A), Color(0xFF13804F)]
                : const [Color(0xFF37474F), Color(0xFF263238)],
          ),
          boxShadow: enabled
              ? const [BoxShadow(blurRadius: 14, color: Color(0x552FBF7A))]
              : null,
        ),
        child: InkWell(
          onTap: onPressed,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
            child: Row(
              children: [
                Icon(icon, color: Colors.white, size: 28),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    label.toUpperCase(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.8,
                      fontSize: 15,
                    ),
                  ),
                ),
                const Icon(Icons.chevron_right, color: Colors.white),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Quick extends StatelessWidget {
  const _Quick(this.icon, this.label, this.route);

  final IconData icon;
  final String label;
  final String route;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Theme.of(context).colorScheme.surfaceContainer,
      borderRadius: BorderRadius.circular(12),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => context.push(route),
        child: Padding(
          padding: const EdgeInsets.all(6),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: const Color(0xFFF5C04A)),
              const SizedBox(height: 4),
              Text(
                label,
                maxLines: 2,
                textAlign: TextAlign.center,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Extrait du classement autour du club.
class _MiniTable extends StatelessWidget {
  const _MiniTable({required this.season});

  final Season season;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final table = season.standings;
    final me = table.indexWhere((s) => s.clubId == season.userClub.id);
    var start = (me - 3).clamp(0, table.length).toInt();
    final end = (start + 7).clamp(0, table.length).toInt();
    start = (end - 7).clamp(0, table.length).toInt();
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 10, 10, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('CLASSEMENT', style: theme.textTheme.labelSmall),
            const SizedBox(height: 6),
            for (var i = start; i < end; i++)
              Container(
                padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 4),
                decoration: BoxDecoration(
                  color: i == me ? const Color(0x332FBF7A) : null,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  children: [
                    SizedBox(
                      width: 22,
                      child: Text(
                        '${i + 1}',
                        style: theme.textTheme.labelLarge,
                      ),
                    ),
                    ClubCrest(
                      name: season.clubById(table[i].clubId).name,
                      size: 16,
                    ),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        season.clubById(table[i].clubId).name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: i == me ? FontWeight.w800 : null,
                        ),
                      ),
                    ),
                    Text(
                      '${table[i].points}',
                      style: theme.textTheme.labelLarge,
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/// Carte du prochain match avec le bouton « Jouer ».
class _NextMatch extends StatelessWidget {
  const _NextMatch({
    required this.round,
    required this.home,
    required this.away,
    required this.date,
    required this.venue,
    required this.canPlay,
    required this.onPlay,
  });

  final int round;
  final String home;
  final String away;
  final String date;
  final String venue;
  final bool canPlay;
  final VoidCallback onPlay;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    Widget side(String name) => Expanded(
          child: Column(
            children: [
              ClubCrest(name: name, size: 54),
              const SizedBox(height: 6),
              Text(
                name,
                maxLines: 2,
                textAlign: TextAlign.center,
                style: theme.textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        );
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF14432D), Color(0xFF0A1F15)],
        ),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        children: [
          Text(
            'JOURNÉE $round · $date',
            style: theme.textTheme.labelSmall?.copyWith(
              letterSpacing: 1.2,
              color: Colors.white60,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              side(home),
              Text(
                'VS',
                style: theme.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w900,
                  color: const Color(0xFFF5C04A),
                ),
              ),
              side(away),
            ],
          ),
          const SizedBox(height: 4),
          Text(venue, style: theme.textTheme.bodySmall),
          const SizedBox(height: 14),
          _PlayButton(
            label: canPlay ? 'Jouer le match' : 'Le coach compose l\'équipe',
            onPressed: canPlay ? onPlay : null,
          ),
        ],
      ),
    );
  }
}

class _Kpi extends StatelessWidget {
  const _Kpi({required this.label, required this.value, required this.sub});

  final String label;
  final String value;
  final String sub;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Expanded(
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 8, 8, 8),
        decoration: BoxDecoration(
          color: theme.colorScheme.surfaceContainer,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label.toUpperCase(),
              style: theme.textTheme.labelSmall?.copyWith(
                color: Colors.white54,
                fontSize: 10,
              ),
            ),
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                value,
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            Text(
              sub,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.labelSmall?.copyWith(fontSize: 10),
            ),
          ],
        ),
      ),
    );
  }
}

String compactMoney(int v) {
  final a = v.abs();
  final sign = v < 0 ? '-' : '';
  if (a >= 1000000) return '$sign${(a / 1000000).toStringAsFixed(1)} M€';
  if (a >= 1000) return '$sign${(a / 1000).round()} k€';
  return '$sign$a €';
}


/// Rappel discret tant que la carrière n'est pas protégée par Google.
class _CloudNudge extends ConsumerWidget {
  const _CloudNudge();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cloud = ref.watch(cloudProvider);
    if (!cloud.available || cloud.signedIn) return const SizedBox.shrink();
    return const Padding(
      padding: EdgeInsets.only(top: 10),
      child: GoogleAccountCard(compact: true),
    );
  }
}


/// Contrat d'objectifs du conseil, avec la progression en direct.
class _ObjectivesCard extends StatelessWidget {
  const _ObjectivesCard({required this.game});

  final GameState game;

  @override
  Widget build(BuildContext context) {
    final list = seasonObjectives(game);
    final kept = list.where((o) => o.reached).length;
    final theme = Theme.of(context);
    return ProCard(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.flag_circle, size: 18, color: Color(0xFF26A69A)),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  "Contrat d'objectifs",
                  style: theme.textTheme.titleSmall
                      ?.copyWith(fontWeight: FontWeight.w800),
                ),
              ),
              Text('$kept/${list.length}', style: theme.textTheme.labelLarge),
            ],
          ),
          const SizedBox(height: 6),
          for (final o in list)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                children: [
                  Icon(
                    o.reached ? Icons.check_circle : Icons.radio_button_unchecked,
                    size: 16,
                    color: o.reached ? Colors.green : theme.hintColor,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(o.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                        Text(
                          o.status,
                          style: theme.textTheme.bodySmall,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 3),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(3),
                          child: LinearProgressIndicator(
                            value: o.progress,
                            minHeight: 4,
                            color: o.reached ? Colors.green : const Color(0xFFF5C04A),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          Text(
            'Prime du conseil : ${compactMoney(objectiveReward(game.division))} '
            'par objectif tenu en fin de saison.',
            style: theme.textTheme.bodySmall,
          ),
        ],
      ),
    );
  }
}


/// Événement de la semaine, défi du jour et série de connexion.
class _DailyCard extends ConsumerWidget {
  const _DailyCard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(dailyProvider);
    final theme = Theme.of(context);
    return ProCard(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.local_fire_department,
                  size: 18, color: Color(0xFFFF7043)),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  d.event.title,
                  style: theme.textTheme.titleSmall
                      ?.copyWith(fontWeight: FontWeight.w800),
                ),
              ),
              Text('🔥 ${d.streak} j', style: theme.textTheme.labelLarge),
            ],
          ),
          Text(d.event.text, style: theme.textTheme.bodySmall),
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(
                d.done ? Icons.check_circle : Icons.flag,
                size: 18,
                color: d.done ? Colors.green : const Color(0xFFF5C04A),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Défi du jour : ${d.challenge.title}',
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
              if (d.done)
                const Text('Réussi', style: TextStyle(color: Colors.green)),
            ],
          ),
        ],
      ),
    );
  }
}
