import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/entities/match_summary.dart';
import '../../engine/game/game_state.dart';
import '../game/game_repository.dart';
import '../game/game_state.dart';

/// Défi du jour.
class DailyChallenge {
  const DailyChallenge(this.id, this.title, this.test);

  final String id;
  final String title;

  /// Buts pour, buts contre → défi réussi ?
  final bool Function(int mine, int theirs) test;
}

final List<DailyChallenge> _challenges = [
  DailyChallenge('win', 'Gagner le prochain match', (m, t) => m > t),
  DailyChallenge('three', 'Marquer au moins 3 buts dans un match', (m, t) => m >= 3),
  DailyChallenge('clean', 'Garder sa cage inviolée', (m, t) => t == 0),
  DailyChallenge('big', 'Gagner avec 2 buts d\'écart', (m, t) => m - t >= 2),
  DailyChallenge('unbeaten', 'Ne pas perdre le prochain match', (m, t) => m >= t),
  DailyChallenge('score2', 'Marquer au moins 2 buts', (m, t) => m >= 2),
];

/// Événement de la semaine : un thème et un multiplicateur des primes.
class WeeklyEvent {
  const WeeklyEvent(this.title, this.text, this.multiplier);

  final String title;
  final String text;
  final double multiplier;
}

const List<WeeklyEvent> _events = [
  WeeklyEvent('Fièvre continentale',
      'Toute la région vibre pour le football : primes des défis x2.', 2),
  WeeklyEvent('Semaine des derbys',
      'Les sponsors misent sur l\'ambiance : primes des défis x1,5.', 1.5),
  WeeklyEvent('Mercato express',
      'Les investisseurs regardent votre club : primes des défis x1,5.', 1.5),
  WeeklyEvent('Semaine des jeunes talents',
      'Les académies sont à l\'honneur : primes des défis x1,25.', 1.25),
];

String _day(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

int _weekOfYear(DateTime d) {
  final start = DateTime(d.year);
  return (d.difference(start).inDays + start.weekday - 1) ~/ 7;
}

class DailyState {
  const DailyState({
    required this.day,
    required this.challenge,
    required this.done,
    required this.streak,
    required this.event,
    this.toast,
  });

  final String day;
  final DailyChallenge challenge;
  final bool done;

  /// Jours de connexion d'affilée.
  final int streak;
  final WeeklyEvent event;

  /// Annonce à afficher (prime gagnée...).
  final String? toast;

  DailyState copyWith({bool? done, int? streak, String? toast}) => DailyState(
        day: day,
        challenge: challenge,
        done: done ?? this.done,
        streak: streak ?? this.streak,
        event: event,
        toast: toast,
      );
}

/// Base des primes selon la division (plus on monte, plus c'est gros).
int bonusBase(int division) {
  switch (division) {
    case 1:
      return 400000;
    case 2:
      return 150000;
    case 3:
      return 60000;
    case 4:
      return 30000;
    default:
      return 15000;
  }
}

/// Défi du jour, prime de fidélité et événement de la semaine. Tout est
/// calculé hors ligne à partir de la date : le même défi pour tous les
/// joueurs le même jour.
class DailyController extends Notifier<DailyState> {
  static const _kDay = 'daily_day';
  static const _kDone = 'daily_done';
  static const _kStreak = 'daily_streak';
  static const _kLogin = 'daily_login';

  @override
  DailyState build() {
    final now = DateTime.now();
    final day = _day(now);
    final prefs = ref.read(sharedPreferencesProvider);
    final seed = now.year * 400 + now.month * 31 + now.day;
    return DailyState(
      day: day,
      challenge: _challenges[seed % _challenges.length],
      done: prefs.getString(_kDay) == day && (prefs.getBool(_kDone) ?? false),
      streak: prefs.getInt(_kStreak) ?? 0,
      event: _events[_weekOfYear(now) % _events.length],
    );
  }

  /// Première ouverture du jour : prime de fidélité (jusqu'à 7 jours).
  void checkLogin() {
    final prefs = ref.read(sharedPreferencesProvider);
    final game = ref.read(gameProvider);
    if (game == null) return;
    final last = prefs.getString(_kLogin);
    if (last == state.day) return;
    final yesterday = _day(DateTime.now().subtract(const Duration(days: 1)));
    final streak = last == yesterday ? (state.streak + 1).clamp(1, 365).toInt() : 1;
    prefs.setString(_kLogin, state.day);
    prefs.setInt(_kStreak, streak);
    final amount = bonusBase(game.division) * streak.clamp(1, 7) ~/ 7;
    ref.read(gameProvider.notifier).grantBonus(
          amount,
          'Prime de fidélité : jour $streak',
          'Votre assiduité rassure les sponsors : une prime est versée au '
              'club. Revenez demain pour une prime plus grosse (jusqu\'au '
              '7e jour d\'affilée).',
        );
    state = state.copyWith(
      streak: streak,
      toast: 'Prime de fidélité, jour $streak : +$amount',
    );
  }

  /// Après une journée jouée : le défi du jour est-il réussi ?
  void evaluate(GameState game) {
    if (state.done) return;
    final MatchSummary? m = game.lastMatch;
    if (m == null) return;
    final home = m.homeId == game.userClub.id;
    final mine = home ? m.homeGoals : m.awayGoals;
    final theirs = home ? m.awayGoals : m.homeGoals;
    if (!state.challenge.test(mine, theirs)) return;
    final prefs = ref.read(sharedPreferencesProvider);
    prefs.setString(_kDay, state.day);
    prefs.setBool(_kDone, true);
    final amount = (bonusBase(game.division) * 2 * state.event.multiplier).round();
    ref.read(gameProvider.notifier).grantBonus(
          amount,
          'Défi du jour réussi !',
          '« ${state.challenge.title} » : le conseil verse une prime '
              '(${state.event.title}).',
        );
    state = state.copyWith(
      done: true,
      toast: 'Défi du jour réussi : +$amount',
    );
  }

  void clearToast() => state = state.copyWith();
}

final dailyProvider =
    NotifierProvider<DailyController, DailyState>(DailyController.new);
