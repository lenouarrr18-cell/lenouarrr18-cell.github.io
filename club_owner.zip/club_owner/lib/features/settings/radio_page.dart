import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/audio/audio_service.dart';
import '../common/pro_page.dart';

const Color _accent = Color(0xFFE0A030);

/// Radio du club : musiques originales du jeu, son et bruitages.
class RadioPage extends ConsumerWidget {
  const RadioPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final audio = ref.watch(audioProvider);
    final ctrl = ref.read(audioProvider.notifier);
    final tracks = audio.tracks;
    final current = audio.current;

    return ProPage(
      title: 'Radio du club',
      subtitle: 'La bande-son du club',
      icon: Icons.graphic_eq,
      accent: _accent,
      stats: [
        ProStat('Morceaux', '${tracks.length}', icon: Icons.queue_music),
        ProStat('Musique', audio.music ? 'Activée' : 'Coupée',
            icon: audio.music ? Icons.music_note : Icons.music_off),
      ],
      children: [
        if (current == null)
          const ProEmpty(
            icon: Icons.library_music_outlined,
            title: 'Aucune musique pour le moment',
            message: 'La nouvelle bande-son arrive : les morceaux seront '
                'ajoutés dans une prochaine mise à jour.',
            accent: _accent,
          )
        else
        ProCard(
          accent: _accent,
          highlight: true,
          child: Row(
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  gradient: const LinearGradient(
                    colors: [Color(0xFFF5C04A), Color(0xFF8A5E0B)],
                  ),
                ),
                child: Icon(
                  audio.playing ? Icons.graphic_eq : Icons.music_note,
                  color: Colors.black87,
                  size: 32,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      audio.playing ? 'EN COURS' : 'EN PAUSE',
                      style: theme.textTheme.labelSmall?.copyWith(
                        color: _accent,
                        letterSpacing: 1,
                      ),
                    ),
                    Text(
                      current!.title,
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Text(
                      [current.artist, current.mood]
                          .where((e) => e.isNotEmpty)
                          .join(' · '),
                      style: theme.textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              IconButton.filled(
                iconSize: 30,
                onPressed: ctrl.togglePause,
                icon: Icon(audio.playing ? Icons.pause : Icons.play_arrow),
              ),
              const SizedBox(width: 6),
              IconButton(
                onPressed: ctrl.next,
                icon: const Icon(Icons.skip_next),
              ),
            ],
          ),
        ),
        const ProSection('Liste des morceaux'),
        if (tracks.isNotEmpty)
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Lecture aléatoire'),
            value: audio.shuffle,
            onChanged: ctrl.setShuffle,
          ),
        for (var i = 0; i < tracks.length; i++)
          ProCard(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            highlight: i == audio.track && audio.playing,
            accent: _accent,
            onTap: () => ctrl.play(i),
            child: Row(
              children: [
                SizedBox(
                  width: 28,
                  child: i == audio.track && audio.playing
                      ? const Icon(Icons.volume_up, size: 18, color: _accent)
                      : Text('${i + 1}', style: theme.textTheme.labelLarge),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        tracks[i].title,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      if (tracks[i].artist.isNotEmpty)
                        Text(tracks[i].artist, style: theme.textTheme.bodySmall),
                    ],
                  ),
                ),
                if (tracks[i].mood.isNotEmpty)
                  ProTag(tracks[i].mood, color: _accent),
              ],
            ),
          ),
        const ProSection('Son'),
        ProCard(
          child: Column(
            children: [
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Musique des menus'),
                value: audio.music,
                onChanged: ctrl.setMusic,
              ),
              Row(
                children: [
                  const Icon(Icons.volume_down, size: 20),
                  Expanded(
                    child: Slider(
                      value: audio.volume,
                      onChanged: ctrl.setVolume,
                    ),
                  ),
                  const Icon(Icons.volume_up, size: 20),
                ],
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Bruitages et ambiance du stade'),
                subtitle: const Text('Foule, sifflets, clameur des buts.'),
                value: audio.sfx,
                onChanged: ctrl.setSfx,
              ),
            ],
          ),
        ),
        if (tracks.any((t) => t.licence.isNotEmpty || t.artist.isNotEmpty)) ...[
          const ProSection('Crédits'),
          for (final t in tracks)
            if (t.artist.isNotEmpty || t.licence.isNotEmpty)
              Text(
                '${t.title}${t.artist.isEmpty ? '' : ' — ${t.artist}'}'
                '${t.licence.isEmpty ? '' : ' (${t.licence})'}',
                style: theme.textTheme.bodySmall,
              ),
        ],
      ],
    );
  }
}
