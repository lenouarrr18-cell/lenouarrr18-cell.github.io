import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/l10n.dart';
import '../../core/legal/legal_texts.dart';
import '../cloud/google_account_card.dart';
import '../common/crest.dart';
import '../common/pro_page.dart';
import '../game/game_state.dart';

class SettingsPage extends ConsumerWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = ref.watch(gameProvider);
    if (game == null) return const SizedBox.shrink();

    final theme = Theme.of(context);
    final notifier = ref.read(gameProvider.notifier);
    final lang = ref.watch(langProvider);

    Widget link(IconData icon, String title, String? subtitle, String route) {
      return ListTile(
        contentPadding: EdgeInsets.zero,
        leading: Icon(icon),
        title: Text(title),
        subtitle: subtitle == null ? null : Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => context.push(route),
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text(ref.t('settings.title'))),
      body: ProColumns(
        columns: [
          [
          const Center(child: AppLogo(size: 96)),
          const SizedBox(height: 8),
          Center(
            child: Text(
              'Club Owner',
              style: theme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          Center(
            child: Text(
              '${ref.t('about.version')} $appVersion',
              style: theme.textTheme.labelSmall,
            ),
          ),
          const SizedBox(height: 24),
          Text(ref.t('settings.language'), style: theme.textTheme.titleMedium),
          const SizedBox(height: 8),
          SegmentedButton<AppLang>(
            segments: [
              for (final l in AppLang.values)
                ButtonSegment<AppLang>(value: l, label: Text(appLangLabel(l))),
            ],
            selected: {lang},
            onSelectionChanged: (s) =>
                ref.read(langProvider.notifier).set(s.first),
          ),
          const SizedBox(height: 6),
          Text(ref.t('settings.languageNote'), style: theme.textTheme.bodySmall),
          const SizedBox(height: 20),
          Text(ref.t('settings.difficulty'), style: theme.textTheme.titleMedium),
          const SizedBox(height: 8),
          SegmentedButton<int>(
            segments: [
              ButtonSegment<int>(value: 0, label: Text(ref.t('settings.easy'))),
              ButtonSegment<int>(
                value: 1,
                label: Text(ref.t('settings.normal')),
              ),
              ButtonSegment<int>(value: 2, label: Text(ref.t('settings.hard'))),
            ],
            selected: {game.owner.difficulty},
            onSelectionChanged: (set) => notifier.setDifficulty(set.first),
          ),
          const SizedBox(height: 8),
          Text(
            ref.t('settings.difficultyNote'),
            style: theme.textTheme.bodySmall,
          ),
          const SizedBox(height: 16),
          ],
          [
          Text('Compte Google', style: theme.textTheme.titleMedium),
          const SizedBox(height: 8),
          const GoogleAccountCard(),
          const SizedBox(height: 8),
          link(
            Icons.cloud_outlined,
            ref.t('settings.cloud'),
            ref.t('settings.cloudNote'),
            '/cloud',
          ),
          link(
            Icons.graphic_eq,
            ref.t('settings.radio'),
            ref.t('settings.radioNote'),
            '/radio',
          ),
          link(
            Icons.menu_book_outlined,
            ref.t('settings.guide'),
            ref.t('settings.guideNote'),
            '/guide',
          ),
          link(
            Icons.save_outlined,
            ref.t('settings.saves'),
            ref.t('settings.savesNote'),
            '/saves',
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.delete_outline),
            title: Text(ref.t('settings.reset')),
            subtitle: Text(ref.t('settings.resetNote')),
            onTap: () => _confirmReset(context, ref),
          ),
          const Divider(height: 32),
          Text(ref.t('settings.legal'), style: theme.textTheme.titleMedium),
          link(Icons.gavel_outlined, ref.t('legal.terms'), null,
              '/legal/${LegalDoc.terms.name}'),
          link(Icons.privacy_tip_outlined, ref.t('legal.privacy'), null,
              '/legal/${LegalDoc.privacy.name}'),
          link(Icons.business_outlined, ref.t('legal.notice'), null,
              '/legal/${LegalDoc.notice.name}'),
          link(Icons.info_outline, ref.t('legal.about'), null, '/about'),
          ],
        ],
      ),
    );
  }

  Future<void> _confirmReset(BuildContext context, WidgetRef ref) async {
    final lang = ref.read(langProvider);
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(tr(lang, 'settings.resetTitle')),
        content: Text(tr(lang, 'settings.resetBody')),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text(tr(lang, 'common.cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text(tr(lang, 'common.restart')),
          ),
        ],
      ),
    );
    if (ok == true) ref.read(gameProvider.notifier).resetGame();
  }
}
