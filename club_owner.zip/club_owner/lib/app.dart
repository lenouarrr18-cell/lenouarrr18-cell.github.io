import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:flutter_localizations/flutter_localizations.dart';

import 'core/audio/audio_service.dart';
import 'core/cloud/cloud_save.dart';
import 'core/l10n/l10n.dart';
import 'core/router/app_router.dart';
import 'core/theme/app_theme.dart';
import 'features/legal/legal_page.dart';

class ClubOwnerApp extends ConsumerWidget {
  const ClubOwnerApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = ref.watch(routerProvider);
    final lang = ref.watch(langProvider);
    return MaterialApp.router(
      title: 'Club Owner',
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: ThemeMode.dark,
      routerConfig: router,
      debugShowCheckedModeBanner: false,
      locale: appLocale(lang),
      supportedLocales: [for (final l in AppLang.values) appLocale(l)],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      // Mise en page de gauche à droite tant que tout le jeu n'est pas
      // traduit en arabe (les textes arabes s'affichent correctement).
      builder: (context, child) => Directionality(
        textDirection: TextDirection.ltr,
        child: AudioHost(
            child: CloudHost(
              child: LegalGate(child: child ?? const SizedBox.shrink()),
            ),
          ),
        ),
    );
  }
}
