import 'dart:ui' as ui;

import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../features/game/game_repository.dart';

/// Langues proposées dans le jeu.
enum AppLang { fr, en, es, pt, ar }

String appLangLabel(AppLang l) {
  switch (l) {
    case AppLang.fr:
      return 'Français';
    case AppLang.en:
      return 'English';
    case AppLang.es:
      return 'Español';
    case AppLang.pt:
      return 'Português';
    case AppLang.ar:
      return 'العربية';
  }
}

/// L'arabe s'écrit de droite à gauche.
bool isRtl(AppLang l) => l == AppLang.ar;

Locale appLocale(AppLang l) => Locale(l.name);

const String _langKey = 'app_lang';
const String _legalKey = 'legal_accepted_v1';

/// Version affichée dans « À propos » (à garder en phase avec pubspec.yaml).
const String appVersion = '0.10.0';

AppLang _systemLang() {
  final code = ui.PlatformDispatcher.instance.locale.languageCode;
  for (final l in AppLang.values) {
    if (l.name == code) return l;
  }
  return code.isEmpty ? AppLang.fr : AppLang.en;
}

class LangNotifier extends Notifier<AppLang> {
  @override
  AppLang build() {
    final raw = ref.read(sharedPreferencesProvider).getString(_langKey);
    for (final l in AppLang.values) {
      if (l.name == raw) return l;
    }
    return _systemLang();
  }

  void set(AppLang lang) {
    state = lang;
    ref.read(sharedPreferencesProvider).setString(_langKey, lang.name);
  }
}

final langProvider = NotifierProvider<LangNotifier, AppLang>(LangNotifier.new);

/// Acceptation des conditions d'utilisation (une fois par version des textes).
class LegalNotifier extends Notifier<bool> {
  @override
  bool build() =>
      ref.read(sharedPreferencesProvider).getBool(_legalKey) ?? false;

  void accept() {
    state = true;
    ref.read(sharedPreferencesProvider).setBool(_legalKey, true);
  }
}

final legalAcceptedProvider =
    NotifierProvider<LegalNotifier, bool>(LegalNotifier.new);

/// Traduit une clé ; la clé elle-même est renvoyée si elle est inconnue.
String tr(AppLang lang, String key) {
  final table = switch (lang) {
    AppLang.fr => _fr,
    AppLang.en => _en,
    AppLang.es => _es,
    AppLang.pt => _pt,
    AppLang.ar => _ar,
  };
  // Texte manquant : l'anglais, puis le français.
  return table[key] ?? _en[key] ?? _fr[key] ?? key;
}

extension TrRef on WidgetRef {
  /// Texte traduit dans la langue choisie (reconstruit l'écran au changement).
  String t(String key) => tr(watch(langProvider), key);
}

const Map<String, String> _fr = {
  // Navigation
  'nav.home': 'Accueil',
  'nav.squad': 'Effectif',
  'nav.club': 'Club',
  'nav.finance': 'Finances',
  'nav.calendar': 'Calendrier',
  // Paramètres
  'settings.title': 'Paramètres',
  'settings.language': 'Langue',
  'settings.languageNote':
      'Menus, paramètres et textes légaux. Le reste du jeu sera traduit '
          'progressivement.',
  'settings.difficulty': 'Difficulté',
  'settings.easy': 'Facile',
  'settings.normal': 'Normal',
  'settings.hard': 'Difficile',
  'settings.difficultyNote':
      'La difficulté règle les prix demandés par les clubs lors des '
          'transferts.',
  'settings.delegate': 'Déléguer au directeur sportif',
  'settings.delegateNote':
      'Il gère seul les affaires courantes : promotion des jeunes, agents '
          'libres, prêts, libérations, prolongations et ventes avantageuses.',
  'settings.guide': 'Guide du débutant',
  'settings.guideNote': 'Tout comprendre en quelques minutes',
  'settings.saves': 'Sauvegardes',
  'settings.savesNote': '3 emplacements manuels',
  'settings.reset': 'Nouvelle partie',
  'settings.resetNote': 'Efface la partie en cours',
  'settings.resetTitle': 'Nouvelle partie ?',
  'settings.resetBody':
      'La partie en cours sera supprimée (vos sauvegardes manuelles sont '
          'conservées).',
  'settings.legal': 'Informations légales',
  'settings.radio': 'Radio du club et son',
  'settings.cloud': 'Compte Google et sauvegarde',
  'settings.cloudNote': 'Retrouvez votre carrière sur tous vos appareils',
  'settings.radioNote': 'Musiques originales, volume, bruitages',
  'common.cancel': 'Annuler',
  'common.restart': 'Recommencer',
  // Textes légaux
  'legal.terms': "Conditions d'utilisation",
  'legal.privacy': 'Politique de confidentialité',
  'legal.notice': 'Mentions légales',
  'legal.about': 'À propos et licences',
  'legal.licenses': 'Licences des logiciels libres',
  'legal.updated': 'Dernière mise à jour : 20 novembre 2026',
  'gate.title': 'Bienvenue, Président',
  'gate.intro':
      'Avant de prendre les commandes de votre club, lisez et acceptez les '
          "conditions d'utilisation et la politique de confidentialité.",
  'gate.check':
      "J'ai lu et j'accepte les conditions d'utilisation et la politique "
          'de confidentialité.',
  'gate.accept': 'Accepter et jouer',
  'about.tagline': 'Le jeu de gestion où vous êtes le président.',
  'about.version': 'Version',
  'about.offline': 'Jouable hors ligne, sans publicité. Compte Google facultatif pour sauvegarder sa carrière.',
  // Menu du club
  'club.staff': 'Staff',
  'club.transfers': 'Transferts',
  'club.infrastructure': 'Installations',
};

const Map<String, String> _en = {
  'nav.home': 'Home',
  'nav.squad': 'Squad',
  'nav.club': 'Club',
  'nav.finance': 'Finances',
  'nav.calendar': 'Calendar',
  'settings.title': 'Settings',
  'settings.language': 'Language',
  'settings.languageNote':
      'Menus, settings and legal texts. The rest of the game is being '
          'translated step by step.',
  'settings.difficulty': 'Difficulty',
  'settings.easy': 'Easy',
  'settings.normal': 'Normal',
  'settings.hard': 'Hard',
  'settings.difficultyNote':
      'Difficulty sets the prices other clubs ask in transfers.',
  'settings.delegate': 'Delegate to the sporting director',
  'settings.delegateNote':
      'He handles day-to-day business: youth promotions, free agents, loans, '
          'releases, renewals and profitable sales.',
  'settings.guide': "Beginner's guide",
  'settings.guideNote': 'Understand everything in a few minutes',
  'settings.saves': 'Saves',
  'settings.savesNote': '3 manual slots',
  'settings.reset': 'New game',
  'settings.resetNote': 'Deletes the current game',
  'settings.resetTitle': 'Start a new game?',
  'settings.resetBody':
      'The current game will be deleted (your manual saves are kept).',
  'settings.legal': 'Legal information',
  'settings.radio': 'Club radio and sound',
  'settings.cloud': 'Google account and cloud save',
  'settings.cloudNote': 'Keep your career on all your devices',
  'settings.radioNote': 'Original music, volume, sound effects',
  'common.cancel': 'Cancel',
  'common.restart': 'Start over',
  'legal.terms': 'Terms of use',
  'legal.privacy': 'Privacy policy',
  'legal.notice': 'Legal notice',
  'legal.about': 'About and licences',
  'legal.licenses': 'Open-source licences',
  'legal.updated': 'Last updated: 20 November 2026',
  'gate.title': 'Welcome, President',
  'gate.intro':
      'Before taking charge of your club, please read and accept the terms '
          'of use and the privacy policy.',
  'gate.check': 'I have read and accept the terms of use and the privacy '
      'policy.',
  'gate.accept': 'Accept and play',
  'about.tagline': 'The management game where you are the president.',
  'about.version': 'Version',
  'about.offline': 'Playable offline, no ads. Optional Google account to back up your career.',
  'club.staff': 'Staff',
  'club.transfers': 'Transfers',
  'club.infrastructure': 'Facilities',
};


const Map<String, String> _es = {
  'nav.home': 'Inicio',
  'nav.squad': 'Plantilla',
  'nav.club': 'Club',
  'nav.finance': 'Finanzas',
  'nav.calendar': 'Calendario',
  'settings.title': 'Ajustes',
  'settings.language': 'Idioma',
  'settings.languageNote':
      'Menús, ajustes y textos legales. El resto del juego se traduce poco a poco.',
  'settings.difficulty': 'Dificultad',
  'settings.easy': 'Fácil',
  'settings.normal': 'Normal',
  'settings.hard': 'Difícil',
  'settings.difficultyNote':
      'La dificultad fija los precios que piden los otros clubes en los fichajes.',
  'settings.guide': 'Guía del principiante',
  'settings.guideNote': 'Entiéndelo todo en unos minutos',
  'settings.saves': 'Partidas guardadas',
  'settings.savesNote': '3 espacios manuales',
  'settings.reset': 'Nueva partida',
  'settings.resetNote': 'Borra la partida actual',
  'settings.resetTitle': '¿Empezar una nueva partida?',
  'settings.resetBody':
      'La partida actual se borrará (tus guardados manuales se conservan).',
  'settings.legal': 'Información legal',
  'settings.radio': 'Radio del club y sonido',
  'settings.cloud': 'Cuenta de Google y guardado en la nube',
  'settings.cloudNote': 'Conserva tu carrera en todos tus dispositivos',
  'settings.radioNote': 'Música original, volumen, efectos de sonido',
  'common.cancel': 'Cancelar',
  'common.restart': 'Empezar de nuevo',
  'legal.terms': 'Condiciones de uso',
  'legal.privacy': 'Política de privacidad',
  'legal.notice': 'Aviso legal',
  'legal.about': 'Acerca de y licencias',
  'legal.licenses': 'Licencias de código abierto',
  'legal.updated': 'Última actualización: 20 de noviembre de 2026',
  'gate.title': 'Bienvenido, Presidente',
  'gate.intro':
      'Antes de tomar las riendas de tu club, lee y acepta las condiciones de '
          'uso y la política de privacidad.',
  'gate.check':
      'He leído y acepto las condiciones de uso y la política de privacidad.',
  'gate.accept': 'Aceptar y jugar',
  'about.tagline': 'El juego de gestión en el que tú eres el presidente.',
  'about.version': 'Versión',
  'about.offline':
      'Se juega sin conexión, sin anuncios. Cuenta de Google opcional para guardar tu carrera.',
  'club.staff': 'Personal',
  'club.transfers': 'Fichajes',
  'club.infrastructure': 'Instalaciones',
};

const Map<String, String> _pt = {
  'nav.home': 'Início',
  'nav.squad': 'Elenco',
  'nav.club': 'Clube',
  'nav.finance': 'Finanças',
  'nav.calendar': 'Calendário',
  'settings.title': 'Definições',
  'settings.language': 'Idioma',
  'settings.languageNote':
      'Menus, definições e textos legais. O resto do jogo está a ser traduzido aos poucos.',
  'settings.difficulty': 'Dificuldade',
  'settings.easy': 'Fácil',
  'settings.normal': 'Normal',
  'settings.hard': 'Difícil',
  'settings.difficultyNote':
      'A dificuldade define os preços pedidos pelos outros clubes nas transferências.',
  'settings.guide': 'Guia do iniciante',
  'settings.guideNote': 'Entenda tudo em poucos minutos',
  'settings.saves': 'Jogos guardados',
  'settings.savesNote': '3 espaços manuais',
  'settings.reset': 'Novo jogo',
  'settings.resetNote': 'Apaga o jogo atual',
  'settings.resetTitle': 'Começar um novo jogo?',
  'settings.resetBody':
      'O jogo atual será apagado (os seus jogos guardados manualmente ficam).',
  'settings.legal': 'Informação legal',
  'settings.radio': 'Rádio do clube e som',
  'settings.cloud': 'Conta Google e guardar na nuvem',
  'settings.cloudNote': 'Guarde a sua carreira em todos os seus dispositivos',
  'settings.radioNote': 'Música original, volume, efeitos sonoros',
  'common.cancel': 'Cancelar',
  'common.restart': 'Recomeçar',
  'legal.terms': 'Termos de utilização',
  'legal.privacy': 'Política de privacidade',
  'legal.notice': 'Aviso legal',
  'legal.about': 'Sobre e licenças',
  'legal.licenses': 'Licenças de código aberto',
  'legal.updated': 'Última atualização: 20 de novembro de 2026',
  'gate.title': 'Bem-vindo, Presidente',
  'gate.intro':
      'Antes de assumir o seu clube, leia e aceite os termos de utilização e a '
          'política de privacidade.',
  'gate.check':
      'Li e aceito os termos de utilização e a política de privacidade.',
  'gate.accept': 'Aceitar e jogar',
  'about.tagline': 'O jogo de gestão em que o presidente é você.',
  'about.version': 'Versão',
  'about.offline':
      'Jogável offline, sem anúncios. Conta Google opcional para guardar a sua carreira.',
  'club.staff': 'Equipa técnica',
  'club.transfers': 'Transferências',
  'club.infrastructure': 'Instalações',
};

const Map<String, String> _ar = {
  'nav.home': 'الرئيسية',
  'nav.squad': 'التشكيلة',
  'nav.club': 'النادي',
  'nav.finance': 'المالية',
  'nav.calendar': 'الجدول',
  'settings.title': 'الإعدادات',
  'settings.language': 'اللغة',
  'settings.languageNote':
      'القوائم والإعدادات والنصوص القانونية. تتم ترجمة بقية اللعبة تدريجيًا.',
  'settings.difficulty': 'مستوى الصعوبة',
  'settings.easy': 'سهل',
  'settings.normal': 'عادي',
  'settings.hard': 'صعب',
  'settings.difficultyNote':
      'يحدد مستوى الصعوبة الأسعار التي تطلبها الأندية الأخرى في الانتقالات.',
  'settings.guide': 'دليل المبتدئ',
  'settings.guideNote': 'افهم كل شيء في دقائق',
  'settings.saves': 'الحفظ',
  'settings.savesNote': '3 خانات يدوية',
  'settings.reset': 'لعبة جديدة',
  'settings.resetNote': 'يحذف اللعبة الحالية',
  'settings.resetTitle': 'بدء لعبة جديدة؟',
  'settings.resetBody': 'سيتم حذف اللعبة الحالية (يتم الاحتفاظ بالحفظ اليدوي).',
  'settings.legal': 'المعلومات القانونية',
  'settings.radio': 'راديو النادي والصوت',
  'settings.cloud': 'حساب Google والحفظ السحابي',
  'settings.cloudNote': 'احتفظ بمسيرتك على جميع أجهزتك',
  'settings.radioNote': 'موسيقى أصلية، مستوى الصوت، المؤثرات',
  'common.cancel': 'إلغاء',
  'common.restart': 'البدء من جديد',
  'legal.terms': 'شروط الاستخدام',
  'legal.privacy': 'سياسة الخصوصية',
  'legal.notice': 'إشعار قانوني',
  'legal.about': 'حول اللعبة والتراخيص',
  'legal.licenses': 'تراخيص المصادر المفتوحة',
  'legal.updated': 'آخر تحديث: 20 نوفمبر 2026',
  'gate.title': 'مرحبًا بك أيها الرئيس',
  'gate.intro':
      'قبل تولي إدارة ناديك، يرجى قراءة شروط الاستخدام وسياسة الخصوصية والموافقة عليها.',
  'gate.check': 'لقد قرأت شروط الاستخدام وسياسة الخصوصية وأوافق عليها.',
  'gate.accept': 'موافق، لنلعب',
  'about.tagline': 'لعبة الإدارة التي تكون فيها أنت الرئيس.',
  'about.version': 'الإصدار',
  'about.offline':
      'تُلعب بدون إنترنت وبدون إعلانات. حساب Google اختياري لحفظ مسيرتك.',
  'club.staff': 'الطاقم',
  'club.transfers': 'الانتقالات',
  'club.infrastructure': 'المنشآت',
};
