import '../l10n/l10n.dart';

/// Informations sur l'éditeur, à compléter avant toute publication.
class Publisher {
  /// Nom ou pseudonyme public de l'éditeur (affiché sur les boutiques).
  static const String name = 'Manuel_deki';
  static const String status = 'Éditeur indépendant (particulier)';
  static const String address = 'Abidjan';
  static const String country = 'Côte d\'Ivoire';
  static const String email = 'dekigiannisemmanuels@gmail.com';
  static const String director = name;

  /// Page web publique de la politique de confidentialité (exigée par
  /// Google Play et l'App Store).
  static const String privacyUrl = 'https://lenouarrr18-cell.github.io/club-owner/privacy.html';
}

enum LegalDoc { terms, privacy, notice }

class LegalSection {
  const LegalSection(this.title, this.body);

  final String title;
  final String body;
}

String legalDocTitleKey(LegalDoc d) {
  switch (d) {
    case LegalDoc.terms:
      return 'legal.terms';
    case LegalDoc.privacy:
      return 'legal.privacy';
    case LegalDoc.notice:
      return 'legal.notice';
  }
}

List<LegalSection> legalSections(LegalDoc doc, AppLang lang) {
  final fr = lang == AppLang.fr;
  switch (doc) {
    case LegalDoc.terms:
      return fr ? _termsFr : _termsEn;
    case LegalDoc.privacy:
      return fr ? _privacyFr : _privacyEn;
    case LegalDoc.notice:
      return fr ? _noticeFr : _noticeEn;
  }
}

// ---------------------------------------------------------------------------
// Conditions d'utilisation
// ---------------------------------------------------------------------------

const List<LegalSection> _termsFr = [
  LegalSection(
    '1. Objet',
    'Club Owner (« le Jeu ») est un jeu vidéo de simulation dans lequel vous '
        'incarnez le président et propriétaire d\'un club de football '
        'fictif. Les présentes conditions encadrent son utilisation.',
  ),
  LegalSection(
    '2. Acceptation',
    'En utilisant le Jeu, vous acceptez ces conditions. Si vous ne les '
        'acceptez pas, n\'utilisez pas le Jeu et désinstallez-le.',
  ),
  LegalSection(
    '3. Accès au Jeu',
    'Le Jeu fonctionne entièrement hors ligne, sans création de compte. '
        'Il est fourni gratuitement, sans publicité ni achat intégré à ce '
        'jour. Si des achats ou des services en ligne sont ajoutés, des '
        'conditions spécifiques vous seront présentées avant tout paiement.',
  ),
  LegalSection(
    '4. Contenu fictif',
    'Les clubs, joueurs, entraîneurs, dirigeants, résultats, déclarations et '
        'articles de presse du Jeu sont fictifs et générés automatiquement. '
        'Toute ressemblance avec des personnes réelles serait fortuite. '
        'Les noms de pays, de villes, de compétitions ou de distinctions sont '
        'utilisés à titre descriptif : le Jeu n\'est ni affilié, ni approuvé, '
        'ni sponsorisé par la FIFA, l\'UEFA, la CAF, la CONMEBOL, la CONCACAF, '
        'l\'AFC, une ligue, un club ou un organisateur de distinction. Les '
        'marques citées appartiennent à leurs titulaires.',
  ),
  LegalSection(
    '5. Licence d\'utilisation',
    'L\'éditeur vous accorde une licence personnelle, gratuite, non '
        'exclusive et non transférable pour utiliser le Jeu à des fins de '
        'divertissement privé. Il est interdit de le revendre, de le louer, '
        'de le modifier, de le décompiler (sauf dans les cas permis par la '
        'loi), d\'en extraire le contenu ou de contourner ses protections.',
  ),
  LegalSection(
    '6. Vos contenus',
    'Les noms que vous choisissez (club, stade) et les messages que vous '
        'publiez dans le Jeu restent sur votre appareil. Vous vous engagez à '
        'ne pas utiliser de contenu injurieux, diffamatoire, discriminatoire '
        'ou portant atteinte aux droits d\'autrui.',
  ),
  LegalSection(
    '7. Sauvegardes',
    'Votre progression est enregistrée uniquement sur votre appareil. La '
        'désinstallation du Jeu, l\'effacement de ses données ou un '
        'changement d\'appareil peuvent entraîner sa perte. L\'éditeur fait '
        'ses meilleurs efforts pour conserver la compatibilité des '
        'sauvegardes entre versions, sans pouvoir le garantir.',
  ),
  LegalSection(
    '8. Responsabilité',
    'Le Jeu est fourni « en l\'état ». L\'éditeur ne garantit pas qu\'il soit '
        'exempt d\'erreurs ni qu\'il fonctionne sur tous les appareils. Les '
        'mécanismes économiques et sportifs du Jeu sont des simulations : '
        'ils ne constituent ni un conseil financier, ni un conseil sportif. '
        'Dans les limites permises par la loi, la responsabilité de l\'éditeur '
        'ne saurait être engagée pour un dommage indirect.',
  ),
  LegalSection(
    '9. Mises à jour et modifications',
    'Le Jeu et ces conditions peuvent évoluer. En cas de changement '
        'important, une nouvelle acceptation pourra vous être demandée.',
  ),
  LegalSection(
    '10. Droit applicable',
    'Ces conditions sont régies par le droit de ${Publisher.country}. Les '
        'dispositions protectrices du droit de votre pays de résidence '
        's\'appliquent lorsqu\'elles vous sont plus favorables. En cas de '
        'litige, une solution amiable sera recherchée avant toute action.',
  ),
  LegalSection(
    '11. Contact',
    'Pour toute question : ${Publisher.email}.',
  ),
];

const List<LegalSection> _termsEn = [
  LegalSection(
    '1. Purpose',
    'Club Owner ("the Game") is a simulation video game in which you play '
        'the president and owner of a fictional football club. These terms '
        'govern its use.',
  ),
  LegalSection(
    '2. Acceptance',
    'By using the Game you accept these terms. If you do not accept them, '
        'do not use the Game and uninstall it.',
  ),
  LegalSection(
    '3. Access',
    'The Game works fully offline, without an account. It is currently free, '
        'with no ads and no in-app purchases. If purchases or online services '
        'are added, specific terms will be shown to you before any payment.',
  ),
  LegalSection(
    '4. Fictional content',
    'Clubs, players, coaches, executives, results, statements and press '
        'articles in the Game are fictional and automatically generated. Any '
        'resemblance to real persons is coincidental. Names of countries, '
        'cities, competitions or awards are used descriptively: the Game is '
        'not affiliated with, endorsed or sponsored by FIFA, UEFA, CAF, '
        'CONMEBOL, CONCACAF, AFC, any league, club or award organiser. '
        'Trademarks belong to their respective owners.',
  ),
  LegalSection(
    '5. Licence',
    'The publisher grants you a personal, free, non-exclusive and '
        'non-transferable licence to use the Game for private entertainment. '
        'You may not resell, rent, modify, decompile (except where permitted '
        'by law), extract its content or circumvent its protections.',
  ),
  LegalSection(
    '6. Your content',
    'Names you choose (club, stadium) and messages you post in the Game stay '
        'on your device. You agree not to use abusive, defamatory, '
        'discriminatory or infringing content.',
  ),
  LegalSection(
    '7. Saves',
    'Your progress is stored only on your device. Uninstalling the Game, '
        'clearing its data or changing device may cause it to be lost. The '
        'publisher does its best to keep saves compatible across versions '
        'but cannot guarantee it.',
  ),
  LegalSection(
    '8. Liability',
    'The Game is provided "as is". The publisher does not guarantee that it '
        'is error-free or works on every device. Its economic and sporting '
        'systems are simulations and are not financial or sporting advice. '
        'To the extent permitted by law, the publisher is not liable for '
        'indirect damage.',
  ),
  LegalSection(
    '9. Updates and changes',
    'The Game and these terms may change. In case of a significant change, '
        'you may be asked to accept them again.',
  ),
  LegalSection(
    '10. Governing law',
    'These terms are governed by the law of ${Publisher.country}. Mandatory '
        'consumer protections of your country of residence apply where more '
        'favourable to you. Any dispute will first be settled amicably where '
        'possible.',
  ),
  LegalSection('11. Contact', 'For any question: ${Publisher.email}.'),
];

// ---------------------------------------------------------------------------
// Politique de confidentialité
// ---------------------------------------------------------------------------

const List<LegalSection> _privacyFr = [
  LegalSection(
    'En bref',
    'Club Owner se joue sans compte, sans publicité et sans outil de mesure '
        'd\'audience. Si vous choisissez de vous connecter avec Google pour '
        'sauvegarder votre carrière en ligne, seules les données nécessaires '
        'à ce service sont utilisées (voir ci-dessous).',
  ),
  LegalSection(
    'Compte Google et sauvegarde en ligne (facultatif)',
    'Si vous vous connectez avec Google, nous recevons votre adresse e-mail, '
        'votre nom et un identifiant de compte, fournis par Google. Votre '
        'sauvegarde de carrière (club, joueurs, finances, succès) est alors '
        'stockée sur les serveurs de Google Firebase (Google LLC) pour que '
        'vous la retrouviez sur un autre appareil. Ces données ne sont ni '
        'vendues, ni partagées, ni utilisées à des fins publicitaires. Vous '
        'pouvez vous déconnecter à tout moment et demander la suppression de '
        'votre sauvegarde en ligne en écrivant à ${Publisher.email}.',
  ),
  LegalSection(
    'Ligue des présidents et rapports de plantage',
    'Si vous êtes connecté, votre prénom (tiré de votre compte Google), le nom '
        'de votre club, votre division, votre classement et votre Indice '
        'Président apparaissent dans le classement en ligne et dans les ligues '
        'privées que vous rejoignez ; seuls les joueurs connectés peuvent les '
        'voir. Votre adresse e-mail n\'est jamais affichée. En cas de '
        'plantage, un rapport technique anonyme (message d\'erreur, version du '
        'jeu, système) est envoyé pour corriger le problème. Écrivez à '
        '${Publisher.email} pour faire retirer votre fiche.',
  ),
  LegalSection(
    'Données enregistrées sur votre appareil',
    'Pour fonctionner, le Jeu enregistre localement : votre progression '
        '(club, effectif, finances, historique), vos réglages (langue, '
        'difficulté), les noms que vous saisissez et votre acceptation des '
        'conditions. Ces données restent sur votre appareil et ne sont '
        'jamais transmises à l\'éditeur ni à des tiers.',
  ),
  LegalSection(
    'Permissions',
    'Le Jeu ne demande aucune permission sensible (localisation, contacts, '
        'appareil photo, micro, fichiers).',
  ),
  LegalSection(
    'Conservation et suppression',
    'Vous pouvez supprimer vos données à tout moment : Paramètres > Nouvelle '
        'partie, effacement des données de l\'application dans les réglages '
        'du téléphone, ou désinstallation.',
  ),
  LegalSection(
    'Enfants',
    'Le Jeu ne collectant aucune donnée, il peut être utilisé par tous. Les '
        'parents restent responsables de l\'usage fait par leurs enfants.',
  ),
  LegalSection(
    'Vos droits',
    'Conformément à la loi ivoirienne n° 2013-450 relative à la protection '
        'des données à caractère personnel et, le cas échéant, au règlement '
        'européen (RGPD), vous disposez de droits d\'accès, de rectification '
        'et de suppression. L\'éditeur ne détenant aucune donnée vous '
        'concernant, ces droits s\'exercent directement sur votre appareil. '
        'Pour toute question : ${Publisher.email}.',
  ),
  LegalSection(
    'Évolutions',
    'Si des services en ligne (sauvegarde dans le nuage, classements, '
        'achats) sont ajoutés, cette politique sera mise à jour et votre '
        'accord vous sera demandé avant toute collecte.',
  ),
];

const List<LegalSection> _privacyEn = [
  LegalSection(
    'In short',
    'Club Owner can be played without an account, ads or analytics. If you '
        'choose to sign in with Google to back up your career online, only the '
        'data needed for that service is used (see below).',
  ),
  LegalSection(
    'Google account and cloud save (optional)',
    'If you sign in with Google, we receive your email address, name and an '
        'account identifier from Google. Your career save (club, players, '
        'finances, achievements) is then stored on Google Firebase servers '
        '(Google LLC) so you can restore it on another device. This data is '
        'never sold, shared or used for advertising. You can sign out at any '
        'time and request deletion of your online save at ${Publisher.email}.',
  ),
  LegalSection(
    "Presidents' league and crash reports",
    'If you are signed in, your first name (from your Google account), club '
        'name, division, rank and President Index appear in the online ranking '
        'and in the private leagues you join; only signed-in players can see '
        'them. Your email address is never shown. If the Game crashes, an '
        'anonymous technical report (error message, game version, system) is '
        'sent so the problem can be fixed. Write to ${Publisher.email} to have '
        'your entry removed.',
  ),
  LegalSection(
    'Data stored on your device',
    'To work, the Game stores locally: your progress (club, squad, finances, '
        'history), your settings (language, difficulty), the names you type '
        'and your acceptance of the terms. This data stays on your device and '
        'is never sent to the publisher or third parties.',
  ),
  LegalSection(
    'Permissions',
    'The Game asks for no sensitive permission (location, contacts, camera, '
        'microphone, files).',
  ),
  LegalSection(
    'Retention and deletion',
    'You can delete your data at any time: Settings > New game, clearing the '
        'app data in your phone settings, or uninstalling.',
  ),
  LegalSection(
    'Children',
    'As the Game collects no data, it can be used by everyone. Parents remain '
        'responsible for their children\'s use.',
  ),
  LegalSection(
    'Your rights',
    'Under Ivorian law no. 2013-450 on personal data protection and, where '
        'applicable, the EU GDPR, you have rights of access, rectification and '
        'erasure. As the publisher holds no data about you, these rights are '
        'exercised directly on your device. Contact: ${Publisher.email}.',
  ),
  LegalSection(
    'Changes',
    'If online services (cloud saves, leaderboards, purchases) are added, '
        'this policy will be updated and your consent requested before any '
        'collection.',
  ),
];

// ---------------------------------------------------------------------------
// Mentions légales
// ---------------------------------------------------------------------------

const List<LegalSection> _noticeFr = [
  LegalSection(
    'Éditeur',
    '${Publisher.name}\n${Publisher.status}\n${Publisher.address}\n'
        '${Publisher.country}\nContact : ${Publisher.email}',
  ),
  LegalSection('Directeur de la publication', Publisher.director),
  LegalSection(
    'Distribution et hébergement',
    'L\'application est distribuée sur Google Play (Google LLC) et sur '
        'l\'App Store (Apple Inc.). Aucune donnée utilisateur n\'est hébergée '
        'par l\'éditeur.',
  ),
  LegalSection(
    'Propriété intellectuelle',
    'Le code, le logo, les graphismes et les textes du Jeu sont protégés. '
        'Toute reproduction sans autorisation est interdite. Le Jeu utilise '
        'des logiciels libres dont les licences sont consultables dans '
        '« À propos et licences ».',
  ),
  LegalSection(
    'Marques et contenus fictifs',
    'Les noms de compétitions, de distinctions et d\'organisations sont '
        'cités à titre descriptif et appartiennent à leurs titulaires. Les '
        'clubs et joueurs du Jeu sont fictifs.',
  ),
];

const List<LegalSection> _noticeEn = [
  LegalSection(
    'Publisher',
    '${Publisher.name}\n${Publisher.status}\n${Publisher.address}\n'
        '${Publisher.country}\nContact: ${Publisher.email}',
  ),
  LegalSection('Publication director', Publisher.director),
  LegalSection(
    'Distribution and hosting',
    'The app is distributed on Google Play (Google LLC) and the App Store '
        '(Apple Inc.). No user data is hosted by the publisher.',
  ),
  LegalSection(
    'Intellectual property',
    'The Game\'s code, logo, graphics and texts are protected. Any '
        'reproduction without permission is prohibited. The Game uses '
        'open-source software whose licences are listed in "About and '
        'licences".',
  ),
  LegalSection(
    'Trademarks and fictional content',
    'Names of competitions, awards and organisations are cited descriptively '
        'and belong to their owners. Clubs and players in the Game are '
        'fictional.',
  ),
];
