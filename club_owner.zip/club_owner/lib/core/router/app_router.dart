import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/calendar/calendar_page.dart';
import '../../features/club/club_page.dart';
import '../../features/finance/finance_page.dart';
import '../../features/game/game_state.dart';
import '../../features/home/home_page.dart';
import '../../features/guide/guide_page.dart';
import '../../features/honours/cups_page.dart';
import '../../features/honours/honours_page.dart';
import '../../features/leagues/leagues_page.dart';
import '../../features/achievements/achievements_page.dart';
import '../../features/cloud/cloud_page.dart';
import '../../features/legal/legal_page.dart';
import '../../features/settings/radio_page.dart';
import '../legal/legal_texts.dart';
import '../../features/match/match_replay_page.dart';
import '../../features/press/news_page.dart';
import '../../features/press/press_page.dart';
import '../../features/honours/international_page.dart';
import '../../features/settings/settings_page.dart';
import '../../features/social/social_page.dart';
import '../../features/tactics/tactics_page.dart';
import '../../features/transfers/clubs_page.dart';
import '../../features/transfers/transfers_page.dart';
import '../../features/onboarding/create_club_page.dart';
import '../../features/shell/app_scaffold.dart';
import '../../features/business/business_page.dart';
import '../../features/inbox/inbox_page.dart';
import '../../features/office/office_page.dart';
import '../../features/office/advisor_page.dart';
import '../../features/office/intro_page.dart';
import '../../features/infrastructure/infrastructure_page.dart';
import '../../features/online/online_page.dart';
import '../../features/saves/saves_page.dart';
import '../../features/squad/squad_page.dart';
import '../../features/staff/staff_page.dart';

final routerProvider = Provider<GoRouter>((ref) {
  final refresh = ValueNotifier<int>(0);
  ref.listen(gameProvider, (previous, next) => refresh.value++);
  ref.onDispose(refresh.dispose);

  return GoRouter(
    initialLocation: '/home',
    refreshListenable: refresh,
    redirect: (context, state) {
      final hasGame = ref.read(gameProvider) != null;
      final loc = state.matchedLocation;
      final creating = loc == '/create-club';
      // Sans partie : création du club, compte Google et textes légaux.
      final open = loc == '/cloud' || loc.startsWith('/legal') || loc == '/about';
      if (!hasGame && !creating && !open) return '/create-club';
      if (hasGame && creating) return '/intro';
      return null;
    },
    routes: [
      GoRoute(
        path: '/create-club',
        builder: (context, state) => const CreateClubPage(),
      ),
      GoRoute(
        path: '/transfers',
        builder: (context, state) => const TransfersPage(),
      ),
      GoRoute(
        path: '/market',
        builder: (context, state) => const TransfersPage(),
      ),
      GoRoute(path: '/clubs', builder: (context, state) => const ClubsPage()),
      GoRoute(path: '/guide', builder: (context, state) => const GuidePage()),
      GoRoute(path: '/cups', builder: (context, state) => const CupsPage()),
      GoRoute(path: '/press', builder: (context, state) => const PressPage()),
      GoRoute(path: '/news', builder: (context, state) => const NewsPage()),
      GoRoute(
        path: '/match',
        builder: (context, state) => MatchReplayPage(
          initialSpeed:
              double.tryParse(state.uri.queryParameters['speed'] ?? '') ?? 1,
        ),
      ),
      GoRoute(
        path: '/leagues',
        builder: (context, state) => const LeaguesPage(),
      ),
      GoRoute(
        path: '/leagues/:id',
        builder: (context, state) =>
            LeaguePage(leagueId: state.pathParameters['id'] ?? ''),
      ),
      GoRoute(
        path: '/clubs/:id',
        builder: (context, state) =>
            ClubDetailPage(clubId: state.pathParameters['id'] ?? ''),
      ),
      GoRoute(
        path: '/tactics',
        builder: (context, state) => const TacticsPage(),
      ),
      GoRoute(path: '/social', builder: (context, state) => const SocialPage()),
      GoRoute(
        path: '/honours',
        builder: (context, state) => const HonoursPage(),
      ),
      GoRoute(
        path: '/international',
        builder: (context, state) => const InternationalPage(),
      ),
      GoRoute(
        path: '/settings',
        builder: (context, state) => const SettingsPage(),
      ),
      GoRoute(path: '/staff', builder: (context, state) => const StaffPage()),
      GoRoute(
        path: '/infrastructure',
        builder: (context, state) => const InfrastructurePage(),
      ),
      GoRoute(
        path: '/business',
        builder: (context, state) => const BusinessPage(),
      ),
      GoRoute(path: '/inbox', builder: (context, state) => const InboxPage()),
      GoRoute(path: '/office', builder: (context, state) => const OfficePage()),
      GoRoute(
        path: '/advisor',
        builder: (context, state) => const AdvisorPage(),
      ),
      GoRoute(path: '/intro', builder: (context, state) => const IntroPage()),
      GoRoute(path: '/saves', builder: (context, state) => const SavesPage()),
      GoRoute(path: '/about', builder: (context, state) => const AboutPage()),
      GoRoute(path: '/radio', builder: (context, state) => const RadioPage()),
      GoRoute(path: '/cloud', builder: (context, state) => const CloudPage()),
      GoRoute(path: '/online', builder: (context, state) => const OnlinePage()),
      GoRoute(
        path: '/achievements',
        builder: (context, state) => const AchievementsPage(),
      ),
      GoRoute(
        path: '/legal/:doc',
        builder: (context, state) {
          final name = state.pathParameters['doc'];
          final doc = LegalDoc.values.firstWhere(
            (d) => d.name == name,
            orElse: () => LegalDoc.terms,
          );
          return LegalDocPage(doc: doc);
        },
      ),
      StatefulShellRoute.indexedStack(
        builder: (context, state, shell) => AppScaffold(navigationShell: shell),
        branches: [
          _branch('/home', const HomePage()),
          _branch('/squad', const SquadPage()),
          _branch('/club', const ClubPage()),
          _branch('/finance', const FinancePage()),
          _branch('/calendar', const CalendarPage()),
        ],
      ),
    ],
  );
});

StatefulShellBranch _branch(String path, Widget page) {
  return StatefulShellBranch(
    routes: [GoRoute(path: path, builder: (context, state) => page)],
  );
}
