import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/entities/division.dart';
import '../../engine/game/game_state.dart';

/// Un président dans le classement en ligne.
class PresidentEntry {
  const PresidentEntry({
    required this.uid,
    required this.name,
    required this.club,
    required this.division,
    required this.season,
    required this.rank,
    required this.score,
    required this.titles,
    required this.leagues,
  });

  factory PresidentEntry.fromDoc(String uid, Map<String, dynamic> d) {
    return PresidentEntry(
      uid: uid,
      name: (d['name'] as String?) ?? 'Président',
      club: (d['club'] as String?) ?? '?',
      division: (d['division'] as num?)?.toInt() ?? 5,
      season: (d['season'] as num?)?.toInt() ?? 1,
      rank: (d['rank'] as num?)?.toInt() ?? 0,
      score: (d['score'] as num?)?.toInt() ?? 0,
      titles: (d['titles'] as num?)?.toInt() ?? 0,
      leagues: [
        for (final x in (d['leagues'] as List<dynamic>? ?? const [])) '$x',
      ],
    );
  }

  final String uid;
  final String name;
  final String club;
  final int division;
  final int season;
  final int rank;
  final int score;
  final int titles;
  final List<String> leagues;
}

class LeagueInfo {
  const LeagueInfo(this.code, this.name, this.owner);

  final String code;
  final String name;
  final String owner;
}

/// Indice Président : la réussite d'une carrière en un seul nombre, pour
/// comparer les présidents du monde entier (division, classement, titres,
/// montées, supporters, confiance du conseil, santé financière).
int presidentScore(GameState g) {
  final titles = g.history.where((r) => r.rank == 1).length;
  final ups =
      g.history.where((r) => r.outcome == SeasonOutcome.promoted).length;
  final clubs = g.season.clubs.length;
  final cash = g.finance.treasury;
  final money = cash >= 0 ? min(500, cash ~/ 100000) : -200;
  return (6 - g.division).clamp(1, 5).toInt() * 1000 +
      (clubs - g.season.userRank + 1) * 25 +
      titles * 400 +
      ups * 250 +
      g.owner.fanMood * 3 +
      g.owner.confidence * 2 +
      money;
}

class OnlineState {
  const OnlineState({
    this.busy = false,
    this.global = const [],
    this.leagues = const [],
    this.standings = const {},
    this.me,
    this.message,
  });

  final bool busy;
  final List<PresidentEntry> global;
  final List<LeagueInfo> leagues;
  final Map<String, List<PresidentEntry>> standings;
  final PresidentEntry? me;
  final String? message;

  OnlineState copyWith({
    bool? busy,
    List<PresidentEntry>? global,
    List<LeagueInfo>? leagues,
    Map<String, List<PresidentEntry>>? standings,
    PresidentEntry? me,
    String? message,
  }) {
    return OnlineState(
      busy: busy ?? this.busy,
      global: global ?? this.global,
      leagues: leagues ?? this.leagues,
      standings: standings ?? this.standings,
      me: me ?? this.me,
      message: message,
    );
  }
}

/// Ligue des présidents : classement mondial et ligues privées entre amis
/// (Firestore). Il faut être connecté avec Google.
class OnlineController extends Notifier<OnlineState> {
  @override
  OnlineState build() => const OnlineState();

  User? get _user {
    if (Firebase.apps.isEmpty) return null;
    return FirebaseAuth.instance.currentUser;
  }

  bool get available => _user != null;

  FirebaseFirestore get _db => FirebaseFirestore.instance;

  DocumentReference<Map<String, dynamic>> _me(String uid) =>
      _db.collection('presidents').doc(uid);

  /// Publie (ou met à jour) la fiche du président.
  Future<void> publish(GameState g) async {
    final user = _user;
    if (user == null) return;
    try {
      await _me(user.uid).set({
        'name': (user.displayName ?? 'Président').split(' ').first,
        'club': g.userClub.name,
        'division': g.division,
        'season': g.seasonNumber,
        'rank': g.season.userRank,
        'score': presidentScore(g),
        'titles': g.history.where((r) => r.rank == 1).length,
        'at': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    } catch (_) {}
  }

  Future<void> refresh(GameState g) async {
    final user = _user;
    if (user == null) return;
    state = state.copyWith(busy: true);
    try {
      await publish(g);
      final top = await _db
          .collection('presidents')
          .orderBy('score', descending: true)
          .limit(50)
          .get();
      final global = [
        for (final d in top.docs) PresidentEntry.fromDoc(d.id, d.data()),
      ];
      final mine = await _me(user.uid).get();
      final me = PresidentEntry.fromDoc(user.uid, mine.data() ?? const {});
      final leagues = <LeagueInfo>[];
      final standings = <String, List<PresidentEntry>>{};
      for (final code in me.leagues.take(10)) {
        final l = await _db.collection('leagues').doc(code).get();
        if (!l.exists) continue;
        final data = l.data() ?? const {};
        leagues.add(LeagueInfo(
          code,
          (data['name'] as String?) ?? 'Ligue $code',
          (data['owner'] as String?) ?? '',
        ));
        final members = await _db
            .collection('presidents')
            .where('leagues', arrayContains: code)
            .limit(50)
            .get();
        standings[code] = [
          for (final d in members.docs) PresidentEntry.fromDoc(d.id, d.data()),
        ]..sort((a, b) => b.score.compareTo(a.score));
      }
      state = state.copyWith(
        busy: false,
        global: global,
        leagues: leagues,
        standings: standings,
        me: me,
      );
    } catch (e) {
      state = state.copyWith(
        busy: false,
        message: 'Connexion au serveur impossible pour le moment.',
      );
    }
  }

  static String _newCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final r = Random.secure();
    return [for (var i = 0; i < 6; i++) chars[r.nextInt(chars.length)]].join();
  }

  /// Crée une ligue privée ; renvoie son code à partager.
  Future<String?> createLeague(String name, GameState g) async {
    final user = _user;
    if (user == null) return null;
    try {
      final code = _newCode();
      await _db.collection('leagues').doc(code).set({
        'name': name.trim().isEmpty ? 'Ligue de ${g.userClub.name}' : name.trim(),
        'owner': user.uid,
        'at': FieldValue.serverTimestamp(),
      });
      await _me(user.uid).set({
        'leagues': FieldValue.arrayUnion([code]),
      }, SetOptions(merge: true));
      await refresh(g);
      return code;
    } catch (_) {
      state = state.copyWith(message: 'Création impossible pour le moment.');
      return null;
    }
  }

  Future<bool> joinLeague(String raw, GameState g) async {
    final user = _user;
    if (user == null) return false;
    final code = raw.trim().toUpperCase();
    if (code.length != 6) {
      state = state.copyWith(message: 'Le code fait 6 caractères.');
      return false;
    }
    try {
      final l = await _db.collection('leagues').doc(code).get();
      if (!l.exists) {
        state = state.copyWith(message: 'Aucune ligue avec ce code.');
        return false;
      }
      await _me(user.uid).set({
        'leagues': FieldValue.arrayUnion([code]),
      }, SetOptions(merge: true));
      await refresh(g);
      state = state.copyWith(message: 'Bienvenue dans la ligue !');
      return true;
    } catch (_) {
      state = state.copyWith(message: 'Impossible de rejoindre la ligue.');
      return false;
    }
  }

  Future<void> leaveLeague(String code, GameState g) async {
    final user = _user;
    if (user == null) return;
    try {
      await _me(user.uid).set({
        'leagues': FieldValue.arrayRemove([code]),
      }, SetOptions(merge: true));
      await refresh(g);
    } catch (_) {}
  }
}

final onlineProvider =
    NotifierProvider<OnlineController, OnlineState>(OnlineController.new);
