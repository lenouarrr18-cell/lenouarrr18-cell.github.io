import 'dart:async';
import 'dart:convert';
import 'dart:io' show gzip;

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../../engine/game/game_codec.dart';
import '../../engine/game/game_state.dart';
import '../../features/game/game_state.dart';
import 'firebase_config.dart';

/// Informations sur la sauvegarde distante.
class RemoteSave {
  const RemoteSave({
    required this.club,
    required this.season,
    required this.updated,
  });

  final String club;
  final int season;
  final DateTime? updated;
}

class CloudState {
  const CloudState({
    this.available = false,
    this.email,
    this.name,
    this.busy = false,
    this.lastSync,
    this.message,
    this.remote,
  });

  /// Firebase est configuré et initialisé.
  final bool available;
  final String? email;
  final String? name;
  final bool busy;
  final DateTime? lastSync;
  final String? message;
  final RemoteSave? remote;

  bool get signedIn => email != null;

  CloudState copyWith({
    bool? available,
    String? email,
    String? name,
    bool clearUser = false,
    bool? busy,
    DateTime? lastSync,
    String? message,
    RemoteSave? remote,
  }) {
    return CloudState(
      available: available ?? this.available,
      email: clearUser ? null : (email ?? this.email),
      name: clearUser ? null : (name ?? this.name),
      busy: busy ?? this.busy,
      lastSync: lastSync ?? this.lastSync,
      message: message,
      remote: remote ?? this.remote,
    );
  }
}

/// Connexion avec un compte Google et sauvegarde de la carrière dans le
/// cloud (Firebase Auth + Firestore). La progression survit à une
/// réinstallation ou à un changement de téléphone.
class CloudController extends Notifier<CloudState> {
  static const int _chunk = 700000;
  bool _initDone = false;

  @override
  CloudState build() => const CloudState();

  Future<void> init() async {
    if (_initDone) return;
    _initDone = true;
    if (!FirebaseConfig.configured) return;
    try {
      if (Firebase.apps.isEmpty) {
        await Firebase.initializeApp(options: FirebaseConfig.options);
      }
      final user = FirebaseAuth.instance.currentUser;
      state = state.copyWith(
        available: true,
        email: user?.email,
        name: user?.displayName,
      );
      if (user != null) await refreshRemote();
    } catch (e) {
      state = state.copyWith(message: 'Service indisponible : $e');
    }
  }

  /// Nouvelle tentative d'initialisation (réseau absent au lancement...).
  Future<void> retryInit() async {
    _initDone = false;
    await init();
  }

  DocumentReference<Map<String, dynamic>> _doc(String uid) =>
      FirebaseFirestore.instance.collection('saves').doc(uid);

  Future<void> signIn() async {
    if (!state.available) return;
    state = state.copyWith(busy: true);
    try {
      final UserCredential cred;
      if (FirebaseConfig.webClientId.isNotEmpty) {
        // Connexion native : le téléphone propose ses comptes Google, sans
        // ouvrir de navigateur (le passage par le navigateur échoue sur
        // certains téléphones : « missing initial state »).
        final google = GoogleSignIn.instance;
        if (!_googleReady) {
          await google.initialize(serverClientId: FirebaseConfig.webClientId);
          _googleReady = true;
        }
        final account = await google.authenticate();
        final idToken = account.authentication.idToken;
        if (idToken == null) throw StateError('Jeton Google absent');
        cred = await FirebaseAuth.instance.signInWithCredential(
          GoogleAuthProvider.credential(idToken: idToken),
        );
      } else {
        cred = await FirebaseAuth.instance
            .signInWithProvider(GoogleAuthProvider());
      }
      final user = cred.user;
      state = state.copyWith(
        busy: false,
        email: user?.email,
        name: user?.displayName,
        message: 'Connecté avec Google.',
      );
      await refreshRemote();
    } catch (e) {
      state = state.copyWith(busy: false, message: 'Connexion annulée ou impossible.');
    }
  }

  bool _googleReady = false;

  Future<void> signOut() async {
    try {
      await FirebaseAuth.instance.signOut();
    } catch (_) {}
    try {
      if (_googleReady) await GoogleSignIn.instance.signOut();
    } catch (_) {}
    state = state.copyWith(clearUser: true, message: 'Déconnecté.');
  }

  Future<void> refreshRemote() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    try {
      final snap = await _doc(user.uid).get();
      final data = snap.data();
      if (data == null) return;
      final ts = data['updated'];
      state = state.copyWith(
        remote: RemoteSave(
          club: data['club'] as String? ?? '',
          season: (data['season'] as num?)?.toInt() ?? 1,
          updated: ts is Timestamp ? ts.toDate() : null,
        ),
      );
    } catch (_) {}
  }

  /// Envoie la carrière dans le cloud (compressée, découpée si besoin).
  Future<bool> upload(GameState game) async {
    final user = state.available ? FirebaseAuth.instance.currentUser : null;
    if (user == null) return false;
    state = state.copyWith(busy: true);
    try {
      final raw = jsonEncode(encodeGame(game, includeWorld: false));
      final packed = base64Encode(gzip.encode(utf8.encode(raw)));
      final parts = <String>[
        for (var i = 0; i < packed.length; i += _chunk)
          packed.substring(i, i + _chunk > packed.length ? packed.length : i + _chunk),
      ];
      final doc = _doc(user.uid);
      final batch = FirebaseFirestore.instance.batch();
      for (var i = 0; i < parts.length; i++) {
        batch.set(doc.collection('chunks').doc('$i'), {'d': parts[i]});
      }
      batch.set(doc, {
        'club': game.userClub.name,
        'season': game.seasonNumber,
        'round': game.season.currentRound,
        'chunks': parts.length,
        'version': saveVersion,
        'updated': FieldValue.serverTimestamp(),
      });
      await batch.commit();
      state = state.copyWith(
        busy: false,
        lastSync: DateTime.now(),
        remote: RemoteSave(
          club: game.userClub.name,
          season: game.seasonNumber,
          updated: DateTime.now(),
        ),
      );
      return true;
    } catch (e) {
      state = state.copyWith(busy: false, message: 'Sauvegarde cloud impossible.');
      return false;
    }
  }

  /// Récupère la carrière enregistrée dans le cloud et la charge.
  Future<bool> restore() async {
    final user = state.available ? FirebaseAuth.instance.currentUser : null;
    if (user == null) return false;
    state = state.copyWith(busy: true);
    try {
      final doc = _doc(user.uid);
      final meta = (await doc.get()).data();
      if (meta == null) {
        state = state.copyWith(busy: false, message: 'Aucune sauvegarde dans le cloud.');
        return false;
      }
      final n = (meta['chunks'] as num?)?.toInt() ?? 0;
      final buffer = StringBuffer();
      for (var i = 0; i < n; i++) {
        final part = (await doc.collection('chunks').doc('$i').get()).data();
        buffer.write(part?['d'] as String? ?? '');
      }
      final raw = utf8.decode(gzip.decode(base64Decode(buffer.toString())));
      final ok = ref.read(gameProvider.notifier).loadFromRaw(raw);
      state = state.copyWith(
        busy: false,
        message: ok ? 'Carrière restaurée.' : 'Sauvegarde illisible.',
      );
      return ok;
    } catch (e) {
      state = state.copyWith(busy: false, message: 'Restauration impossible.');
      return false;
    }
  }
}

final cloudProvider =
    NotifierProvider<CloudController, CloudState>(CloudController.new);

/// Initialise le cloud au lancement et sauvegarde automatiquement la
/// carrière (au plus toutes les 45 secondes, et quand le jeu passe en
/// arrière-plan).
class CloudHost extends ConsumerStatefulWidget {
  const CloudHost({required this.child, super.key});

  final Widget child;

  @override
  ConsumerState<CloudHost> createState() => _CloudHostState();
}

class _CloudHostState extends ConsumerState<CloudHost>
    with WidgetsBindingObserver {
  Timer? _debounce;
  DateTime _lastUpload = DateTime.fromMillisecondsSinceEpoch(0);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) ref.read(cloudProvider.notifier).init();
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  void _uploadNow() {
    final game = ref.read(gameProvider);
    final cloud = ref.read(cloudProvider);
    if (game == null || !cloud.signedIn || cloud.busy) return;
    _lastUpload = DateTime.now();
    ref.read(cloudProvider.notifier).upload(game);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.paused) _uploadNow();
  }

  @override
  Widget build(BuildContext context) {
    ref.listen(gameProvider, (previous, next) {
      if (next == null || !ref.read(cloudProvider).signedIn) return;
      _debounce?.cancel();
      final since = DateTime.now().difference(_lastUpload).inSeconds;
      _debounce = Timer(Duration(seconds: since > 45 ? 5 : 45), _uploadNow);
    });
    return widget.child;
  }
}
