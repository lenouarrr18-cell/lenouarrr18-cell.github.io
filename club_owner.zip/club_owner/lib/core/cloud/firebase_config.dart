import 'package:firebase_core/firebase_core.dart';

/// Paramètres du projet Firebase du jeu (console Firebase > Paramètres du
/// projet > Vos applications > Android). Tant qu'ils sont vides, la
/// connexion Google et la sauvegarde dans le cloud restent désactivées.
class FirebaseConfig {
  static const String apiKey = 'AIzaSyDoOk7s4487B7kvForbzDIwe_Li57X4Rx4';
  static const String appId = '1:923120242420:android:3a87fd48577b3e49f118a1';
  static const String messagingSenderId = '923120242420';
  static const String projectId = 'club-owner-9a9f0';
  static const String storageBucket = 'club-owner-9a9f0.firebasestorage.app';

  /// « ID client Web » (OAuth, type 3) du projet Firebase : nécessaire pour
  /// la connexion Google native d'Android (sélecteur de compte du téléphone,
  /// sans passer par le navigateur).
  static const String webClientId =
      '923120242420-30era90hr26vjlcrrvr7tatmbgfrlnnv.apps.googleusercontent.com';

  static bool get configured =>
      apiKey.isNotEmpty && appId.isNotEmpty && projectId.isNotEmpty;

  static FirebaseOptions get options => const FirebaseOptions(
        apiKey: apiKey,
        appId: appId,
        messagingSenderId: messagingSenderId,
        projectId: projectId,
        storageBucket: storageBucket,
      );
}
