import 'dart:io' show Platform;
import 'dart:ui' show PlatformDispatcher;

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

import '../l10n/l10n.dart';

/// Remontée des plantages : chaque erreur du jeu est envoyée (anonymement,
/// sans donnée personnelle) dans la collection « crashes » de Firestore,
/// pour corriger les bugs avant qu'ils coûtent une mauvaise note.
class ErrorReporter {
  static int _sent = 0;
  static final Set<String> _seen = {};

  static bool get _testing {
    try {
      return Platform.environment.containsKey('FLUTTER_TEST');
    } catch (_) {
      return true;
    }
  }

  /// À appeler une fois au démarrage.
  static void install() {
    if (_testing) return;
    final previous = FlutterError.onError;
    FlutterError.onError = (details) {
      previous?.call(details);
      report(details.exceptionAsString(), details.stack);
    };
    PlatformDispatcher.instance.onError = (error, stack) {
      report('$error', stack);
      return true;
    };
  }

  static String _cut(String v, int max) =>
      v.length <= max ? v : v.substring(0, max);

  static Future<void> report(String message, StackTrace? stack) async {
    // Au plus 5 rapports par session, sans doublon.
    if (_sent >= 5 || !_seen.add(_cut(message, 200))) return;
    if (Firebase.apps.isEmpty) return;
    _sent++;
    try {
      await FirebaseFirestore.instance.collection('crashes').add({
        'msg': _cut(message, 1500),
        'stack': _cut(stack?.toString() ?? '', 3000),
        'v': appVersion,
        'os': _cut(Platform.operatingSystem, 20),
        'at': FieldValue.serverTimestamp(),
      });
    } catch (_) {}
  }
}
