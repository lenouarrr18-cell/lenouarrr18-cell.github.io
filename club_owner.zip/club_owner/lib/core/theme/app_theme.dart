import 'package:flutter/material.dart';

/// Identité visuelle : « nuit de stade ». Vert pelouse profond, or des
/// trophées, titres de presse en empattement et libellés sportifs.
abstract final class AppTheme {
  static const Color seed = Color(0xFF1B8A5A);
  static const Color gold = Color(0xFFE8B93F);
  static const Color night = Color(0xFF08140E);
  static const Color panel = Color(0xFF12271C);
  static const Color panelHigh = Color(0xFF1A3626);
  static const Color chalk = Color(0xFFEAF3EC);
  static const Color grass = Color(0xFF3DDC84);

  static ThemeData light() => dark();

  static ThemeData dark() {
    final scheme = ColorScheme.fromSeed(
      seedColor: seed,
      brightness: Brightness.dark,
    ).copyWith(
      primary: grass,
      onPrimary: const Color(0xFF04210F),
      primaryContainer: const Color(0xFF1F4D33),
      onPrimaryContainer: chalk,
      secondary: gold,
      onSecondary: const Color(0xFF2A1E00),
      tertiaryContainer: const Color(0xFF3A2F0E),
      onTertiaryContainer: const Color(0xFFFFE9A8),
      surface: night,
      onSurface: chalk,
      surfaceContainerLow: panel,
      surfaceContainer: panel,
      surfaceContainerHigh: panelHigh,
      surfaceContainerHighest: panelHigh,
      outlineVariant: const Color(0xFF2B4A38),
    );
    final base = ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: scheme,
    );
    final text = base.textTheme;
    return base.copyWith(
      scaffoldBackgroundColor: night,
      textTheme: text.copyWith(
        headlineMedium: text.headlineMedium?.copyWith(
          fontFamily: 'serif',
          fontWeight: FontWeight.w800,
        ),
        headlineSmall: text.headlineSmall?.copyWith(
          fontFamily: 'serif',
          fontWeight: FontWeight.w800,
        ),
        titleLarge: text.titleLarge?.copyWith(
          fontWeight: FontWeight.w800,
          letterSpacing: 0.3,
        ),
        titleMedium: text.titleMedium?.copyWith(fontWeight: FontWeight.w700),
        titleSmall: text.titleSmall?.copyWith(fontWeight: FontWeight.w700),
        labelLarge: text.labelLarge?.copyWith(
          fontWeight: FontWeight.w800,
          letterSpacing: 0.8,
        ),
        labelSmall: text.labelSmall?.copyWith(
          fontWeight: FontWeight.w800,
          letterSpacing: 1.2,
        ),
      ),
      visualDensity: VisualDensity.compact,
      bottomSheetTheme: const BottomSheetThemeData(
        constraints: BoxConstraints(maxWidth: 640),
      ),
      appBarTheme: AppBarTheme(
        toolbarHeight: 50,
        centerTitle: false,
        backgroundColor: night,
        elevation: 0,
        scrolledUnderElevation: 0,
        titleTextStyle: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.4,
          color: scheme.onSurface,
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: const Color(0xFF0A1B12),
        indicatorColor: const Color(0xFF24543A),
        height: 68,
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          textStyle: const TextStyle(
            fontWeight: FontWeight.w800,
            letterSpacing: 0.5,
          ),
        ),
      ),
      pageTransitionsTheme: const PageTransitionsTheme(
        builders: {TargetPlatform.android: ZoomPageTransitionsBuilder()},
      ),
      dividerTheme: DividerThemeData(color: scheme.outlineVariant),
    );
  }
}
