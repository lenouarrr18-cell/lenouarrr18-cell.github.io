import 'dart:async';
import 'dart:io' show Platform;

import 'dart:convert';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../features/game/game_repository.dart';

/// Un morceau de la « radio du club ». Les morceaux sont déposés dans
/// assets/audio/music/ et décrits dans playlist.json (titre, artiste,
/// licence) : le jeu les découvre au démarrage.
class Track {
  const Track(
    this.file,
    this.title, {
    this.artist = '',
    this.licence = '',
    this.mood = '',
    this.use = 'menu',
  });

  /// Chemin relatif à assets/ (ex. audio/music/titre.mp3).
  final String file;
  final String title;
  final String artist;
  final String licence;
  final String mood;

  /// menu (radio), matchIntro (entrée des joueurs) ou celebration (victoire).
  final String use;
}

String _titleFromFile(String path) {
  final name = path.split('/').last.replaceAll(RegExp(r'\.mp3$'), '');
  final words = name.replaceAll(RegExp(r'[_-]+'), ' ').trim();
  return words.isEmpty ? name : words[0].toUpperCase() + words.substring(1);
}

/// Lit playlist.json et ajoute les MP3 non listés.
Future<List<Track>> loadPlaylist(AssetBundle bundle) async {
  final out = <Track>[];
  final known = <String>{};
  try {
    final raw = await bundle.loadString('assets/audio/music/playlist.json');
    final data = jsonDecode(raw) as Map<String, dynamic>;
    for (final t in (data['tracks'] as List<dynamic>? ?? const [])) {
      final m = t as Map<String, dynamic>;
      final file = 'audio/music/${m['file']}';
      known.add(file);
      out.add(Track(
        file,
        m['title'] as String? ?? _titleFromFile(file),
        artist: m['artist'] as String? ?? '',
        licence: m['licence'] as String? ?? '',
        mood: m['mood'] as String? ?? '',
        use: m['use'] as String? ?? 'menu',
      ));
    }
  } catch (_) {}
  try {
    final manifest = await AssetManifest.loadFromAssetBundle(bundle);
    for (final asset in manifest.listAssets()) {
      if (!asset.startsWith('assets/audio/music/') ||
          !asset.toLowerCase().endsWith('.mp3')) {
        continue;
      }
      final file = asset.substring('assets/'.length);
      if (known.add(file)) out.add(Track(file, _titleFromFile(file)));
    }
  } catch (_) {}
  return out;
}

/// Bruitages disponibles.
enum Sfx { whistleShort, whistleHalf, whistleFinal, goalCheer, groan, tap }

String _sfxFile(Sfx s) {
  switch (s) {
    case Sfx.whistleShort:
      return 'whistle_short';
    case Sfx.whistleHalf:
      return 'whistle_half';
    case Sfx.whistleFinal:
      return 'whistle_final';
    case Sfx.goalCheer:
      return 'goal_cheer';
    case Sfx.groan:
      return 'crowd_groan';
    case Sfx.tap:
      return 'ui_tap';
  }
}

class AudioSettings {
  const AudioSettings({
    this.music = true,
    this.sfx = true,
    this.volume = 0.5,
    this.track = 0,
    this.playing = false,
    this.tracks = const [],
    this.shuffle = false,
  });

  final bool music;
  final bool sfx;
  final double volume;
  final int track;
  final bool playing;
  final List<Track> tracks;
  final bool shuffle;

  Track? get current => tracks.isEmpty ? null : tracks[track % tracks.length];

  AudioSettings copyWith({
    bool? music,
    bool? sfx,
    double? volume,
    int? track,
    bool? playing,
    List<Track>? tracks,
    bool? shuffle,
  }) {
    return AudioSettings(
      music: music ?? this.music,
      sfx: sfx ?? this.sfx,
      volume: volume ?? this.volume,
      track: track ?? this.track,
      playing: playing ?? this.playing,
      tracks: tracks ?? this.tracks,
      shuffle: shuffle ?? this.shuffle,
    );
  }
}

const String _kMusic = 'audio_music';
const String _kSfx = 'audio_sfx';
const String _kVolume = 'audio_volume';

/// Musique des menus, ambiance du stade et bruitages. Toutes les erreurs de
/// lecture sont ignorées : le son ne doit jamais bloquer le jeu.
class AudioController extends Notifier<AudioSettings>
    with WidgetsBindingObserver {
  /// Coupé pendant les tests automatiques (pas de lecteur audio).
  static bool get _disabled {
    try {
      return Platform.environment.containsKey('FLUTTER_TEST');
    } catch (_) {
      return false;
    }
  }

  AudioPlayer? _music;
  AudioPlayer? _crowd;
  final List<AudioPlayer> _fx = [];
  int _fxIndex = 0;
  bool _booted = false;
  bool _inMatch = false;
  StreamSubscription<void>? _done;

  @override
  AudioSettings build() {
    final prefs = ref.read(sharedPreferencesProvider);
    return AudioSettings(
      music: prefs.getBool(_kMusic) ?? true,
      sfx: prefs.getBool(_kSfx) ?? true,
      volume: prefs.getDouble(_kVolume) ?? 0.5,
    );
  }

  Future<void> _safe(Future<void> Function() f) async {
    if (_disabled) return;
    try {
      await f();
    } catch (_) {}
  }

  /// Démarre la musique des menus (appelé une fois au lancement).
  Future<void> boot() async {
    if (_booted || _disabled) return;
    _booted = true;
    WidgetsBinding.instance.addObserver(this);
    await _safe(() async {
      await AudioPlayer.global.setAudioContext(
        AudioContext(
          android: const AudioContextAndroid(
            audioFocus: AndroidAudioFocus.none,
          ),
          iOS: AudioContextIOS(category: AVAudioSessionCategory.ambient),
        ),
      );
    });
    try {
      final list = await loadPlaylist(rootBundle);
      _all = list;
      // La radio propose tous les morceaux ; l'entrée des joueurs et la
      // victoire gardent en plus leur musique dédiée.
      final menu = [for (final t in list) if (t.use == 'menu') t];
      final others = [for (final t in list) if (t.use != 'menu') t];
      state = state.copyWith(tracks: [...menu, ...others]);
    } catch (_) {}
  }

  bool _started = false;

  /// Lance la musique quand la partie commence vraiment (club créé, écran
  /// principal du jeu). Rien ne joue pendant la création du club.
  Future<void> startGameMusic() async {
    await boot();
    if (_started || _disabled) return;
    _started = true;
    if (state.music && !_inMatch) await _playTrack(state.track);
  }

  /// Retour à la création d'un club : la musique s'arrête.
  void stopGameMusic() {
    _started = false;
    state = state.copyWith(playing: false);
    _safe(() async {
      await _music?.stop();
    });
    _safe(() async {
      await _musicB?.stop();
    });
  }

  AudioPlayer? _musicB;
  AudioPlayer? _jingle;
  List<Track> _all = const [];

  Track? _byUse(String use) {
    for (final t in _all) {
      if (t.use == use) return t;
    }
    return null;
  }

  /// Musique d'entrée des joueurs (avant le coup d'envoi).
  void playIntro() => _playJingle('matchIntro', 0.8);

  /// Musique de victoire (fin de match gagné, trophée).
  void playCelebration() => _playJingle('celebration', 0.7);

  void stopJingle() {
    _safe(() async {
      await _jingle?.stop();
    });
  }

  void _playJingle(String use, double gain) {
    final t = _byUse(use);
    if (t == null || !state.music) return;
    _safe(() async {
      _jingle ??= AudioPlayer();
      await _jingle!.stop();
      await _jingle!.play(AssetSource(t.file), volume: state.volume * gain + 0.1);
    });
  }
  Timer? _fade;

  /// Fondu enchaîné entre deux morceaux (1,5 s).
  Future<void> _playTrack(int index) async {
    final tracks = state.tracks;
    if (tracks.isEmpty) {
      state = state.copyWith(playing: false);
      return;
    }
    final i = index % tracks.length;
    state = state.copyWith(track: i, playing: true);
    await _safe(() async {
      _music ??= AudioPlayer();
      _musicB ??= AudioPlayer();
      final old = _music!;
      final fresh = _musicB!;
      _music = fresh;
      _musicB = old;
      await _done?.cancel();
      _done = fresh.onPlayerComplete.listen((_) => next());
      await fresh.setReleaseMode(ReleaseMode.release);
      await fresh.play(AssetSource(tracks[i].file), volume: 0);
      _fade?.cancel();
      var step = 0;
      _fade = Timer.periodic(const Duration(milliseconds: 100), (t) {
        step++;
        final k = (step / 15).clamp(0.0, 1.0);
        _safe(() async {
          await fresh.setVolume(state.volume * k);
        });
        _safe(() async {
          await old.setVolume(state.volume * (1 - k));
        });
        if (k >= 1) {
          t.cancel();
          _safe(() async {
            await old.stop();
          });
        }
      });
    });
  }

  Future<void> play(int index) async {
    _started = true;
    if (!state.music) setMusic(true);
    if (_inMatch) {
      state = state.copyWith(track: index);
      return;
    }
    await _playTrack(index);
  }

  Future<void> next() {
    final n = state.tracks.length;
    if (state.shuffle && n > 2) {
      var pick = state.track;
      final seed = DateTime.now().microsecondsSinceEpoch;
      pick = (state.track + 1 + seed % (n - 1)) % n;
      return play(pick);
    }
    return play(state.track + 1);
  }

  void setShuffle(bool on) => state = state.copyWith(shuffle: on);

  Future<void> togglePause() async {
    if (state.playing) {
      state = state.copyWith(playing: false);
      await _safe(() async {
      await _music?.pause();
    });
    } else {
      await play(state.track);
    }
  }

  void setMusic(bool on) {
    state = state.copyWith(music: on);
    ref.read(sharedPreferencesProvider).setBool(_kMusic, on);
    if (on) {
      if (!_inMatch && _started) _playTrack(state.track);
    } else {
      state = state.copyWith(playing: false);
      _safe(() async {
      await _music?.stop();
    });
    }
  }

  void setSfx(bool on) {
    state = state.copyWith(sfx: on);
    ref.read(sharedPreferencesProvider).setBool(_kSfx, on);
    if (!on) _safe(() async {
      await _crowd?.stop();
    });
  }

  void setVolume(double v) {
    state = state.copyWith(volume: v);
    ref.read(sharedPreferencesProvider).setDouble(_kVolume, v);
    _safe(() async {
      await _music?.setVolume(v);
    });
  }

  /// Bruitage ponctuel.
  void sfx(Sfx s, {double volume = 0.9}) {
    if (!state.sfx) return;
    _safe(() async {
      while (_fx.length < 3) {
        _fx.add(AudioPlayer());
      }
      final p = _fx[_fxIndex++ % _fx.length];
      await p.stop();
      await p.play(AssetSource('audio/sfx/${_sfxFile(s)}.mp3'), volume: volume);
    });
  }

  /// Entrée au stade : la musique s'arrête, la foule prend le relais.
  void enterMatch() {
    _inMatch = true;
    _safe(() async {
      await _music?.pause();
    });
    if (!state.sfx) return;
    _safe(() async {
      _crowd ??= AudioPlayer();
      await _crowd!.setReleaseMode(ReleaseMode.loop);
      await _crowd!.play(AssetSource('audio/sfx/crowd_loop.mp3'), volume: 0.35);
    });
  }

  /// Intensité de la foule (0 à 1), selon l'action.
  void crowdLevel(double level) {
    if (!_inMatch || !state.sfx) return;
    _safe(() async {
      await _crowd?.setVolume(level.clamp(0.0, 1.0).toDouble());
    });
  }

  /// Sortie du stade : retour de la musique des menus.
  void leaveMatch() {
    _inMatch = false;
    stopJingle();
    _safe(() async {
      await _crowd?.stop();
    });
    if (state.music && _started) _playTrack(state.track);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.paused) stopJingle();
    if (s == AppLifecycleState.paused || s == AppLifecycleState.inactive) {
      _safe(() async {
      await _music?.pause();
    });
      _safe(() async {
      await _crowd?.pause();
    });
    } else if (s == AppLifecycleState.resumed) {
      if (_inMatch) {
        if (state.sfx) _safe(() async {
      await _crowd?.resume();
    });
      } else if (state.music && state.playing && _started) {
        _safe(() async {
      await _music?.resume();
    });
      }
    }
  }
}

final audioProvider =
    NotifierProvider<AudioController, AudioSettings>(AudioController.new);

/// Lance la musique au démarrage de l'application.
class AudioHost extends ConsumerStatefulWidget {
  const AudioHost({required this.child, super.key});

  final Widget child;

  @override
  ConsumerState<AudioHost> createState() => _AudioHostState();
}

class _AudioHostState extends ConsumerState<AudioHost> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) ref.read(audioProvider.notifier).boot();
    });
  }

  @override
  Widget build(BuildContext context) => widget.child;
}
