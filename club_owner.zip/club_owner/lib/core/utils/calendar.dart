/// Calendrier du jeu : chaque journée est un samedi, de la mi-août à mai.
const List<String> _weekdays = [
  'lundi',
  'mardi',
  'mercredi',
  'jeudi',
  'vendredi',
  'samedi',
  'dimanche',
];

const List<String> _months = [
  'janvier',
  'février',
  'mars',
  'avril',
  'mai',
  'juin',
  'juillet',
  'août',
  'septembre',
  'octobre',
  'novembre',
  'décembre',
];

/// Année de départ du jeu.
const int firstSeasonYear = 2026;

/// Date de la journée [round] de la saison [seasonNumber].
DateTime roundDate(int seasonNumber, int round) {
  final year = firstSeasonYear + seasonNumber - 1;
  var start = DateTime.utc(year, 8, 15);
  while (start.weekday != DateTime.saturday) {
    start = start.add(const Duration(days: 1));
  }
  return start.add(Duration(days: 7 * (round - 1)));
}

/// Par exemple « samedi 15 août 2026 ».
String formatDateFr(DateTime date) {
  final day = date.day == 1 ? '1er' : '${date.day}';
  return '${_weekdays[date.weekday - 1]} $day ${_months[date.month - 1]} '
      '${date.year}';
}

/// Par exemple « 15 août ».
String shortDateFr(DateTime date) {
  final day = date.day == 1 ? '1er' : '${date.day}';
  return '$day ${_months[date.month - 1]}';
}

/// Par exemple « 2026-2027 ».
String seasonLabel(int seasonNumber) {
  final year = firstSeasonYear + seasonNumber - 1;
  return '$year-${year + 1}';
}

/// Période de mercato selon la journée.
String transferWindowLabel(int round) {
  if (round <= 3) return "Mercato d'été";
  if (round >= 18 && round <= 21) return "Mercato d'hiver";
  return 'Saison en cours';
}
