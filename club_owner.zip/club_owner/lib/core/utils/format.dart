String ordinalFr(int n) => n == 1 ? '1er' : '${n}e';

String signed(int n) => n > 0 ? '+$n' : '$n';

/// Population exprimée en milliers d'habitants.
String formatPopulation(int thousands) {
  if (thousands >= 1000) {
    return '${(thousands / 1000).toStringAsFixed(1)} M hab.';
  }
  return '$thousands 000 hab.';
}

/// Montant en euros avec séparateur de milliers (ex. 1 250 000 €).
String formatMoney(int amount) {
  final digits = amount.abs().toString();
  final buffer = StringBuffer();
  for (var i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 == 0) buffer.write(' ');
    buffer.write(digits[i]);
  }
  final sign = amount < 0 ? '-' : '';
  return '$sign$buffer €';
}
