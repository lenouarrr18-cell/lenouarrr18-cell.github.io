# Activer la connexion Google et la sauvegarde en ligne

1. Va sur https://console.firebase.google.com et crée un projet « Club Owner ».
2. Ajoute une application **Android** :
   - nom du package : `com.clubowner.club_owner`
   - empreinte **SHA-1** :
     `25:E1:11:BA:1B:F6:90:85:C1:2D:0C:97:D5:F8:50:45:D6:D4:62:0F`
   - empreinte **SHA-256** (Paramètres du projet > Empreintes) :
     `2C:AA:74:A2:27:38:36:9D:B8:55:32:78:0C:D7:D6:1C:78:8E:DE:A0:21:38:79:39:C0:97:7C:02:62:4B:FE:A1`
3. Télécharge le fichier `google-services.json` proposé et envoie-le-moi :
   j'en recopie les valeurs dans `lib/core/cloud/firebase_config.dart`.
4. Menu **Authentication** > Commencer > Fournisseurs > **Google** : activer.
5. Menu **Firestore Database** > Créer une base (région europe-west) >
   onglet Règles : coller le contenu de `firebase/firestore.rules` > Publier.
6. Quand le jeu sera sur Google Play : Play Console > Intégrité de
   l'application > copie la SHA-1 de la « clé de signature d'application »
   et ajoute-la aussi dans Firebase (étape 2), sinon la connexion Google ne
   marchera pas pour les joueurs qui installent depuis le Play Store.
