# Architecture – Club Owner

## 1. Couches et règles de dépendance

```
features  ->  domain  <-  data (à venir)
   |            ^
   v            |
 engine --------+
```

- `domain` : entités et règles métier. Aucune dépendance à Flutter.
- `engine` : simulation (match, calendrier, économie à venir). Dart pur, testable sans interface, reproductible via une graine aléatoire.
- `features` : écrans et états Riverpod, organisés par fonctionnalité (home, squad, club, finance, calendar).
- `data` (prochaine étape) : Drift (SQLite), repositories, synchronisation cloud.
- `core` : thème, routeur, utilitaires.

Règle : `domain` et `engine` n'importent jamais `package:flutter`.

## 2. Décisions techniques

| Sujet | Choix | Raison |
|---|---|---|
| État | Riverpod | Testable, sans contexte, injection simple |
| Navigation | go_router, shell à 5 onglets | Navigation déclarative, état conservé par onglet |
| Données locales | Drift (SQLite) | Données très relationnelles (joueurs, contrats, matchs, saisons) |
| Modèles | Classes Dart simples puis freezed | Évite la génération de code tant que les modèles bougent |
| Backend | Firebase | Auth, sauvegarde cloud, config à distance, crash reports, sans serveur à gérer |
| CI | GitHub Actions | Analyse et tests à chaque PR |

## 3. Moteur de match (v0)

45 séquences par match. À chaque séquence : possession (milieux, avantage à domicile de 5 %), tir (attaque contre défense), cadrage (50 %), but (attaque contre gardien). Résultat identique pour une même graine. Paramètres à régler pendant l'équilibrage.

## 4. Avancement et backlog

**Sprint 0 – Squelette : fait.** Moteur de match, calendrier, navigation, CI, APK construit via GitHub Actions.

**Sprint 1 – Fondations jouables : fait.** Création du club, championnat de 20 clubs fictifs, saison jouable, Accueil et Calendrier.

**Sprint 2 – Persistance et effectif : fait.** Sauvegarde automatique, effectif de 22 joueurs, composition 4-4-2.

**Sprint 3 – Cycle complet : fait (v0.4).**
- Fin de saison : 4 divisions, les 2 premiers montent, les 3 derniers descendent, nouveau championnat à chaque saison.
- Évolution des joueurs : les jeunes progressent, les anciens déclinent, retraite à 36 ans, deux jeunes arrivent chaque année.
- Finances : billetterie (ville, division, classement), sponsors, salaires, trésorerie, bilan de saison.
- Mercato : achat et vente (appui long sur un joueur), effectif entre 16 et 30 joueurs, minimum par poste.
- Palmarès dans l'onglet Club.

Toute la logique de jeu est dans `engine/game/game_state.dart` (Dart pur, testé hors Flutter). La couche `features` ne fait qu'afficher et sauvegarder.

**Sprint 4 – Club (à faire)**
1. Stade (capacité, confort), centre de formation, staff, sponsors au choix.
2. Plusieurs emplacements de sauvegarde.
3. Écrans de match plus vivants (résumé des buts).

**Sprint 5 – Compétitions et lancement (à faire)**
1. Coupe nationale, puis compétitions continentales et mondiales (noms originaux, pas de marques officielles).
2. Pages légales (CGU, confidentialité, mentions), icône, écran de démarrage, signature Android, fiche Play Store.
3. Publicités et achats optionnels, selon le cahier des charges.
