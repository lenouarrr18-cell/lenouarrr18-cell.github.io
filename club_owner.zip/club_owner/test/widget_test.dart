import 'package:club_owner/app.dart';
import 'package:club_owner/features/game/game_repository.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> _start(WidgetTester tester, Map<String, Object> prefsValues) async {
  SharedPreferences.setMockInitialValues(prefsValues);
  final prefs = await SharedPreferences.getInstance();
  await tester.pumpWidget(
    ProviderScope(
      overrides: [sharedPreferencesProvider.overrideWithValue(prefs)],
      child: const ClubOwnerApp(),
    ),
  );
  await tester.pumpAndSettle();
}

void main() {
  testWidgets('au premier lancement, les conditions sont à accepter',
      (tester) async {
    await _start(tester, {'app_lang': 'fr'});
    expect(find.byType(CheckboxListTile), findsOneWidget);
    expect(find.text('Accepter et jouer'), findsOneWidget);

    await tester.tap(find.byType(CheckboxListTile));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Accepter et jouer'));
    await tester.pumpAndSettle();
    expect(find.byType(TextField), findsWidgets);
  });

  testWidgets('l\'application démarre sur la création du club', (tester) async {
    await _start(tester, {'legal_accepted_v1': true, 'app_lang': 'fr'});
    expect(find.byType(TextField), findsWidgets);
  });

  testWidgets('la langue anglaise traduit l\'écran légal', (tester) async {
    await _start(tester, {'app_lang': 'en'});
    expect(find.text('Accept and play'), findsOneWidget);
  });
}
