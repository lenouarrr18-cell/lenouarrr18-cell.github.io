import 'package:club_owner/core/l10n/l10n.dart';
import 'package:club_owner/core/legal/legal_texts.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('chaque document légal existe dans les deux langues', () {
    for (final doc in LegalDoc.values) {
      final fr = legalSections(doc, AppLang.fr);
      final en = legalSections(doc, AppLang.en);
      expect(fr, isNotEmpty);
      expect(en.length, fr.length, reason: '$doc');
    }
  });

  test('les clés de traduction sont toutes traduites', () {
    for (final key in [
      'nav.home',
      'settings.title',
      'legal.terms',
      'gate.accept',
      'club.infrastructure',
    ]) {
      expect(tr(AppLang.en, key), isNot(tr(AppLang.fr, key)), reason: key);
    }
    expect(tr(AppLang.en, 'clé.inconnue'), 'clé.inconnue');
    // Espagnol, portugais et arabe : menus traduits.
    for (final lang in [AppLang.es, AppLang.pt, AppLang.ar]) {
      expect(tr(lang, 'nav.home'), isNot(tr(AppLang.fr, 'nav.home')));
      expect(appLangLabel(lang), isNotEmpty);
    }
  });
}
