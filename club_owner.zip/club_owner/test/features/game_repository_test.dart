import 'package:club_owner/domain/data/world_data.dart';
import 'package:club_owner/engine/game/game_state.dart';
import 'package:club_owner/features/game/game_repository.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('sauvegarde puis rechargement identiques', () async {
    final country = worldCountries.first;
    final game = GameState.newGame(
      clubName: 'Mon Club',
      country: country,
      city: country.cities.first,
      seed: 11,
    ).playNextRound().playNextRound();

    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final repository = GameRepository(prefs);

    await repository.save(game);
    final loaded = repository.load();

    expect(loaded, isNotNull);
    expect(loaded!.season.currentRound, 3);
    expect(loaded.finance.treasury, game.finance.treasury);
    expect(loaded.userClub.squad.length, game.userClub.squad.length);

    await repository.clear();
    expect(repository.load(), isNull);
  });

  test('une sauvegarde illisible est ignorée', () async {
    SharedPreferences.setMockInitialValues({GameRepository.key: 'pas du json'});
    final prefs = await SharedPreferences.getInstance();

    expect(GameRepository(prefs).load(), isNull);
  });
}
