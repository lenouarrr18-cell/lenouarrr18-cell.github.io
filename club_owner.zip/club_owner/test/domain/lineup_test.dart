import 'package:club_owner/domain/entities/lineup.dart';
import 'package:club_owner/domain/entities/player.dart';
import 'package:club_owner/engine/squad/squad_factory.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('un effectif compte 22 joueurs aux noms uniques, reproductible', () {
    final a = generateSquad(level: 50, seed: 5);
    final b = generateSquad(level: 50, seed: 5);

    expect(a.length, 22);
    expect(a.map((p) => p.name).toSet().length, 22);
    expect(a.map((p) => p.name).toList(), b.map((p) => p.name).toList());
    expect(a.map((p) => p.skill).toList(), b.map((p) => p.skill).toList());
  });

  test('la composition automatique respecte le 4-4-2', () {
    final squad = generateSquad(level: 50, seed: 6);
    final ids = pickBestStarters(squad);
    final starters = squad.where((p) => ids.contains(p.id)).toList();

    // Le coach compose par poste précis (GB, DC, MC...) : un joueur
    // polyvalent peut jouer hors de sa ligne, mais il y a toujours
    // 11 titulaires dont un seul gardien.
    expect(ids.length, startingXiSize);
    expect(
      starters.where((p) => p.position == PlayerPosition.goalkeeper).length,
      1,
    );
  });

  test('les titulaires sont les meilleurs de leur poste', () {
    final squad = generateSquad(level: 50, seed: 7);
    final ids = pickBestStarters(squad);

    for (final position in PlayerPosition.values) {
      final atPosition = squad.where((p) => p.position == position).toList();
      final startersSkills = atPosition
          .where((p) => ids.contains(p.id))
          .map((p) => p.skill)
          .toList();
      final benchSkills = atPosition
          .where((p) => !ids.contains(p.id))
          .map((p) => p.skill)
          .toList();
      if (benchSkills.isEmpty) continue;

      final worstStarter = startersSkills.reduce((a, b) => a < b ? a : b);
      final bestBench = benchSkills.reduce((a, b) => a > b ? a : b);
      expect(worstStarter, greaterThanOrEqualTo(bestBench));
    }
  });
}
