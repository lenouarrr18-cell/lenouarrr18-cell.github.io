import 'package:club_owner/domain/entities/division.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('les deux premiers montent, sauf en première division', () {
    expect(seasonOutcome(rank: 1, division: 4), SeasonOutcome.promoted);
    expect(seasonOutcome(rank: 2, division: 2), SeasonOutcome.promoted);
    expect(seasonOutcome(rank: 1, division: 1), SeasonOutcome.stayed);
  });

  test('les trois derniers descendent, sauf en division amateur', () {
    expect(seasonOutcome(rank: 18, division: 2), SeasonOutcome.relegated);
    expect(seasonOutcome(rank: 20, division: 1), SeasonOutcome.relegated);
    expect(seasonOutcome(rank: 17, division: 2), SeasonOutcome.stayed);
    expect(seasonOutcome(rank: 20, division: 4), SeasonOutcome.stayed);
  });

  test('la division suivante suit le résultat', () {
    expect(nextDivision(4, SeasonOutcome.promoted), 3);
    expect(nextDivision(2, SeasonOutcome.relegated), 3);
    expect(nextDivision(3, SeasonOutcome.stayed), 3);
  });

  test('le niveau des adversaires monte avec la division', () {
    expect(divisionBase(1), greaterThan(divisionBase(2)));
    expect(divisionBase(3), greaterThan(divisionBase(4)));
    expect(divisionName(4), 'Championnat amateur');
    expect(divisionName(1), 'Première division');
  });
}
