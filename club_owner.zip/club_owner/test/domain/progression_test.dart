import 'package:club_owner/domain/entities/player.dart';
import 'package:club_owner/engine/squad/progression.dart';
import 'package:club_owner/engine/squad/squad_factory.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('chaque joueur vieillit d\'un an et deux jeunes arrivent', () {
    final squad = generateSquad(level: 55, seed: 3);
    final next = developSquad(squad: squad, seed: 1, seasonNumber: 2);
    final retired = squad.where((p) => p.age + 1 >= retirementAge).length;

    expect(next.length, squad.length - retired + 2);
    expect(next.map((p) => p.id).toSet().length, next.length);
    for (final p in next.where((p) => !p.id.startsWith('y'))) {
      final before = squad.firstWhere((x) => x.id == p.id);
      expect(p.age, before.age + 1);
    }
  });

  test('un joueur de 35 ans prend sa retraite', () {
    const old = Player(
      id: 'old',
      name: 'Vieux',
      position: PlayerPosition.defender,
      skill: 60,
      age: 35,
    );
    final next = developSquad(squad: [old], seed: 1, seasonNumber: 2);

    expect(next.any((p) => p.id == 'old'), isFalse);
  });

  test('la progression est reproductible', () {
    final squad = generateSquad(level: 55, seed: 3);
    final a = developSquad(squad: squad, seed: 9, seasonNumber: 2);
    final b = developSquad(squad: squad, seed: 9, seasonNumber: 2);

    expect(a.map((p) => p.skill).toList(), b.map((p) => p.skill).toList());
    expect(a.map((p) => p.name).toList(), b.map((p) => p.name).toList());
  });

  test('les jeunes progressent en moyenne, les anciens déclinent', () {
    var youngGain = 0;
    var oldGain = 0;
    for (var seed = 0; seed < 200; seed++) {
      final young = [
        const Player(
          id: 'a',
          name: 'A',
          position: PlayerPosition.forward,
          skill: 50,
          age: 19,
        ),
      ];
      final old = [
        const Player(
          id: 'b',
          name: 'B',
          position: PlayerPosition.forward,
          skill: 50,
          age: 33,
        ),
      ];
      youngGain +=
          developSquad(
            squad: young,
            seed: seed,
            seasonNumber: 2,
          ).firstWhere((p) => p.id == 'a').skill -
          50;
      oldGain +=
          developSquad(
            squad: old,
            seed: seed,
            seasonNumber: 2,
          ).firstWhere((p) => p.id == 'b').skill -
          50;
    }

    expect(youngGain, greaterThan(0));
    expect(oldGain, lessThan(0));
  });
}
