import 'package:club_owner/engine/calendar/fixture_generator.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  final teams = List.generate(8, (i) => 'team$i');
  final fixtures = generateRoundRobin(teams);

  test('nombre de matchs attendu pour 8 équipes', () {
    expect(fixtures.length, 56);
  });

  test('chaque équipe joue une fois par journée', () {
    for (var round = 1; round <= 14; round++) {
      final playing = fixtures
          .where((f) => f.round == round)
          .expand((f) => [f.homeId, f.awayId])
          .toList();

      expect(playing.length, 8);
      expect(playing.toSet().length, 8);
    }
  });

  test(
    'chaque confrontation existe une fois à domicile et une fois dehors',
    () {
      final pairs = fixtures.map((f) => '${f.homeId}-${f.awayId}').toSet();

      expect(pairs.length, 56);
    },
  );

  test('un nombre impair d\'équipes donne un repos par journée', () {
    final odd = generateRoundRobin(List.generate(5, (i) => 't$i'));

    expect(odd.length, 20);
  });
}
