import 'dart:convert';

import 'package:club_owner/domain/data/world_data.dart';
import 'package:club_owner/engine/game/game_codec.dart';
import 'package:club_owner/engine/game/game_state.dart';
import 'package:club_owner/engine/game/governance.dart';
import 'package:club_owner/engine/owner/board.dart';
import 'package:club_owner/domain/entities/owner.dart';
import 'package:club_owner/domain/entities/team_strength.dart';
import 'package:club_owner/engine/game/owner_actions.dart';
import 'package:club_owner/engine/match/match_engine.dart';
import 'package:club_owner/engine/owner/advisor.dart';
import 'package:club_owner/engine/owner/goals.dart';
import 'package:club_owner/engine/owner/infrastructure.dart';
import 'package:club_owner/engine/match/pitch_sim.dart';
import 'package:flutter_test/flutter_test.dart';

GameState newGame() {
  final country = worldCountries.first;
  return GameState.newGame(
    clubName: 'Mon Club',
    country: country,
    city: country.cities.first,
    seed: 5,
  );
}

void main() {
  test('le veto retire la décision et pèse sur la confiance', () {
    var game = newGame();
    final player = game.userClub.squad.first;
    game = game.proposeDecision(
      kind: 'release',
      playerId: player.id,
      playerName: player.name,
      text: 'Libérer ${player.name}',
      round: 1,
    );
    expect(game.owner.decisions.length, 1);
    final id = game.owner.decisions.first.id;
    final blocked = game.blockDecision(id);
    expect(blocked.owner.decisions, isEmpty);
    expect(blocked.owner.vetoCount, 1);
    expect(blocked.owner.dsTrust, lessThan(game.owner.dsTrust));
    expect(blocked.userClub.squad.any((p) => p.id == player.id), isTrue);
  });

  test('les messages se suppriment et la sauvegarde garde la gouvernance', () {
    var game = newGame().postMessage('ds', 'Titre', 'Corps', 1);
    final before = game.owner.inbox.length;
    expect(game.deleteMessage(0).owner.inbox.length, before - 1);
    game = game.completeMission('finance').seeTip('inbox');
    final back = decodeGame(
      jsonDecode(jsonEncode(encodeGame(game))) as Map<String, dynamic>,
    )!;
    expect(back.owner.missionsDone, contains('finance'));
    expect(back.owner.seenTips, contains('inbox'));
    expect(back.owner.inbox.first.sender, 'ds');
  });

  test('le rapport du conseil sanctionne des finances négatives', () {
    final bad = boardReport(
      treasury: -5,
      debt: 0,
      fanMood: 20,
      infraLevels: 3,
      tension: 80,
      vetoCount: 7,
    );
    final good = boardReport(
      treasury: 1000,
      debt: 0,
      fanMood: 80,
      infraLevels: 12,
      tension: 0,
      vetoCount: 0,
    );
    expect(bad.delta, lessThan(0));
    expect(good.delta, greaterThan(0));
    expect(bad.lines, isNotEmpty);
  });

  test('les nouveaux bâtiments existent et se sauvegardent', () {
    var game = newGame();
    expect(game.owner.medical, 0);
    game = game.copyWith(owner: game.owner.withLevel(InfraKind.medical, 2));
    final back = decodeGame(
      jsonDecode(jsonEncode(encodeGame(game))) as Map<String, dynamic>,
    )!;
    expect(back.owner.medical, 2);
    expect(injuryAvoidChance(2), greaterThan(0));
    expect(vipFactor(3), greaterThan(1));
    expect(upgradeCost(InfraKind.vip, 1), greaterThan(0));
  });

  test('le conseiller détecte une trésorerie négative', () {
    var game = newGame();
    game = game.copyWith(finance: game.finance.copyWith(treasury: -1000));
    final advice = adviseClub(game);
    expect(advice.first.level, AdviceLevel.critical);
  });

  test('les objectifs longs sont définis sur 3, 5 et 10 ans', () {
    expect(longGoals.map((g) => g.years).toSet(), {3, 5, 10});
    final game = newGame();
    for (final goal in longGoals) {
      expect(goalStatus(game, goal), isNot(GoalStatus.failed));
    }
  });

  test('les statistiques de match sont cohérentes', () {
    const t = TeamStrength(attack: 70, midfield: 70, defense: 70, goalkeeper: 70);
    final r = MatchEngine(seed: 9).simulate(home: t, away: t);
    final s = r.stats!;
    expect(s.homePossession, inInclusiveRange(25, 75));
    expect(s.homeShots, greaterThanOrEqualTo(s.homeOnTarget));
    expect(s.awayShots, greaterThanOrEqualTo(s.awayOnTarget));
  });

  test('le match joueur par joueur est cohérent', () {
    final game = newGame();
    final home = game.userClub;
    final away = game.season.clubs.firstWhere((c) => !c.isUser);
    final r = PitchSim(seed: 11).simulate(home: home, away: away);
    final d = r.detail!;
    expect(d.perfs.length, greaterThanOrEqualTo(22));
    expect(d.goals.length, r.homeGoals + r.awayGoals);
    expect(r.homeGoals + r.awayGoals, lessThan(10));
    expect(d.track.length, greaterThan(pitchFrameBytes * 5000));
    expect(d.track.length % pitchFrameBytes, 0);
    for (final raw in d.subs) {
      expect(raw.split('|').length, 4);
    }
    expect(d.subs.length, lessThanOrEqualTo(6));
    final s = r.stats!;
    expect(s.homePossession, inInclusiveRange(10, 90));
    for (final p in d.perfs) {
      expect(p.rating, inInclusiveRange(3.0, 10.0));
      expect(p.distanceKm, greaterThan(1.0));
    }
    final again = PitchSim(seed: 11).simulate(home: home, away: away);
    expect(again.homeGoals, r.homeGoals);
    expect(again.awayGoals, r.awayGoals);
  });

  test('les scores simulés restent réalistes sur 12 matchs', () {
    final game = newGame();
    final home = game.userClub;
    final away = game.season.clubs.firstWhere((c) => !c.isUser);
    var goals = 0;
    var shots = 0;
    for (var i = 0; i < 12; i++) {
      final r = PitchSim(seed: 100 + i)
          .simulate(home: home, away: away, homeGoals: i % 4, awayGoals: i % 3);
      expect(r.homeGoals, i % 4);
      expect(r.awayGoals, i % 3);
      expect(r.stats!.homeShots, greaterThanOrEqualTo(r.stats!.homeOnTarget));
      expect(r.stats!.homeOnTarget, greaterThanOrEqualTo(r.homeGoals));
      goals += r.homeGoals + r.awayGoals;
      shots += r.stats!.homeShots + r.stats!.awayShots;
      expect(r.homeGoals + r.awayGoals, lessThan(10));
    }
    expect(goals / 12, inInclusiveRange(1.2, 4.5));
    expect(shots / 12, inInclusiveRange(10, 40));
  });
}
