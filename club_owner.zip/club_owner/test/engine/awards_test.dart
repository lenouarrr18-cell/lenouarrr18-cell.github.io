import 'package:club_owner/engine/awards/awards.dart';
import 'package:flutter_test/flutter_test.dart';

import 'owner_test.dart' show newGame;

void main() {
  test('les grandes distinctions exigent une coupe continentale ou une '
      'sélection', () {
    final clubs = newGame().season.clubs.take(4).toList();
    final cupClub = clubs[2];
    final result = computeSeasonAwards(
      clubs: clubs,
      season: 1,
      clubBonus: {cupClub.id: 3},
    );
    final names = {for (final p in cupClub.squad) p.name};
    for (final r in result.records) {
      if (r.category == "Ballon d'or" ||
          r.category == 'Golden Boy' ||
          r.category == 'Trophée Kopa' ||
          r.category == 'Trophée Yachine') {
        expect(names.contains(r.playerName), isTrue, reason: r.category);
        expect(r.clubName, cupClub.name);
      }
    }
    expect(result.records.any((r) => r.category == "Ballon d'or"), isTrue);
  });

  test('un international peut gagner sans coupe continentale', () {
    final clubs = newGame().season.clubs.take(3).toList();
    final star = clubs[1].squad.first;
    final result = computeSeasonAwards(
      clubs: clubs,
      season: 1,
      bonus: {star.id: 2},
    );
    final ballon = result.records.firstWhere((r) => r.category == "Ballon d'or");
    expect(ballon.playerName, star.name);
  });

  test('sans aucune compétition, tout le monde reste éligible', () {
    final clubs = newGame().season.clubs.take(3).toList();
    final result = computeSeasonAwards(clubs: clubs, season: 1);
    expect(result.records.any((r) => r.category == "Ballon d'or"), isTrue);
    expect(awardCatalog.where((a) => a.elite).length, 4);
  });
}
