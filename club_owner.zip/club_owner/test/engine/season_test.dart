import 'package:club_owner/engine/season/league_factory.dart';
import 'package:club_owner/engine/season/season.dart';
import 'package:flutter_test/flutter_test.dart';

Season newSeason(int seed) {
  final clubs = generateLeagueClubs(
    userClubName: 'Mon Club',
    userCityWealth: 5,
    seed: seed,
  );
  return Season.create(clubs: clubs, seed: seed);
}

void main() {
  test('la ligue compte 20 clubs dont un seul club du joueur', () {
    final clubs = generateLeagueClubs(
      userClubName: 'Mon Club',
      userCityWealth: 5,
      seed: 1,
    );

    expect(clubs.length, 20);
    expect(clubs.where((c) => c.isUser).length, 1);
    expect(clubs.map((c) => c.id).toSet().length, 20);
    expect(clubs.map((c) => c.name).toSet().length, 20);
  });

  test('le club du joueur a un effectif et une composition complète', () {
    final season = newSeason(1);
    final club = season.userClub;

    expect(club.squad.length, 22);
    expect(club.starters.length, 11);
    expect(club.hasFullLineup, isTrue);
    expect(
      season.clubs.where((c) => !c.isUser).every((c) => c.squad.length >= 20),
      isTrue,
    );
  });

  test('une saison compte 38 journées et 380 matchs', () {
    final season = newSeason(1);

    expect(season.totalRounds, 38);
    expect(season.fixtures.length, 380);
    expect(season.isFinished, isFalse);
  });

  test('jouer une journée avance le calendrier', () {
    final season = newSeason(2).playNextRound();

    expect(season.currentRound, 2);
    expect(season.results.length, 10);
  });

  test('le joueur a un match à chaque journée', () {
    final season = newSeason(3);

    for (var round = 1; round <= 38; round++) {
      expect(season.userFixtureOfRound(round), isNotNull);
    }
  });

  test('saison complète : le classement est cohérent', () {
    var season = newSeason(4);
    while (!season.isFinished) {
      season = season.playNextRound();
    }
    final table = season.standings;

    expect(table.every((r) => r.played == 38), isTrue);
    expect(
      table.fold<int>(0, (sum, r) => sum + r.goalsFor),
      table.fold<int>(0, (sum, r) => sum + r.goalsAgainst),
    );
    expect(
      table.fold<int>(0, (sum, r) => sum + r.won),
      table.fold<int>(0, (sum, r) => sum + r.lost),
    );
    expect(table.first.points, greaterThanOrEqualTo(table.last.points));
  });

  test('même graine, même classement', () {
    Season play(int seed) {
      var season = newSeason(seed);
      while (!season.isFinished) {
        season = season.playNextRound();
      }
      return season;
    }

    final a = play(9).standings;
    final b = play(9).standings;

    expect(a.first.clubId, b.first.clubId);
    expect(a.first.points, b.first.points);
    expect(a.last.clubId, b.last.clubId);
  });
}
