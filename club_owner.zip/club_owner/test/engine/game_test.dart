import 'package:club_owner/domain/data/world_data.dart';
import 'package:club_owner/domain/entities/division.dart';
import 'package:club_owner/domain/entities/lineup.dart';
import 'package:club_owner/domain/entities/player.dart';
import 'package:club_owner/engine/finance/finance.dart';
import 'package:club_owner/engine/game/game_state.dart';
import 'package:flutter_test/flutter_test.dart';

GameState newGame([int seed = 3]) {
  final country = worldCountries.first;
  return GameState.newGame(
    clubName: 'Mon Club',
    country: country,
    city: country.cities.first,
    seed: seed,
  );
}

GameState playSeason(GameState game) {
  var current = game;
  while (!current.season.isFinished) {
    current = current.playNextRound();
  }
  return current;
}

void main() {
  test('une nouvelle partie démarre en championnat amateur', () {
    final game = newGame();

    expect(game.division, lowestDivision);
    expect(game.seasonNumber, 1);
    expect(game.finance.treasury, startingTreasury(game.city.wealth));
    expect(game.market.length, 30);
    expect(game.history.length, 0);
    expect(game.canPlayNextRound, isTrue);
  });

  test('jouer une journée applique salaires et sponsors', () {
    final game = newGame();
    final next = game.playNextRound();

    expect(next.season.currentRound, 2);
    expect(next.finance.wages, greaterThan(0));
    expect(next.finance.sponsors, greaterThan(0));
    expect(
      next.finance.treasury,
      game.finance.treasury +
          next.finance.tickets +
          next.finance.sponsors +
          next.finance.extras -
          next.finance.wages -
          next.finance.infrastructure,
    );
  });

  test('saison complète : le bilan est cohérent', () {
    final game = newGame();
    final end = playSeason(game);

    expect(end.finance.tickets, greaterThan(0));
    expect(
      end.finance.treasury,
      game.finance.treasury + end.finance.seasonResult,
    );
  });

  test("le président ne titularise personne : c'est le coach", () {
    final game = newGame();
    final bench = game.userClub.squad.firstWhere(
      (p) => !game.userClub.starterIds.contains(p.id),
    );
    expect(game.validateToggleStarter(bench.id), isNotNull);
    final same = game.toggleStarter(bench.id);
    expect(same.userClub.starterIds, game.userClub.starterIds);
  });

  test('acheter un joueur', () {
    final game = newGame();
    final player = game.market.reduce(
      (a, b) => playerValue(a) <= playerValue(b) ? a : b,
    );
    final price = playerValue(player);
    final bought = game.buyPlayer(player.id);

    expect(game.validateBuy(player.id), isNull);
    expect(bought.userClub.squad.length, 23);
    expect(bought.market.length, 29);
    expect(bought.finance.treasury, game.finance.treasury - price);
    expect(bought.finance.transfers, -price);
  });

  test('acheter est refusé sans trésorerie suffisante', () {
    final game = newGame().copyWith(finance: const FinanceBook(treasury: 0));

    expect(game.validateBuy(game.market.first.id), isNotNull);
    expect(game.buyPlayer(game.market.first.id).userClub.squad.length, 22);
  });

  test('vendre un joueur', () {
    final game = newGame();
    final club = game.userClub;
    final defender = club.squad.firstWhere(
      (p) => p.position == PlayerPosition.defender,
    );
    final sold = game.sellPlayer(defender.id);

    expect(sold.userClub.squad.length, 21);
    expect(sold.userClub.starterIds.contains(defender.id), isFalse);
    expect(sold.finance.treasury, game.finance.treasury + sellPrice(defender));
  });

  test('vendre est refusé sous le minimum du poste', () {
    var game = newGame();
    final keepers = game.userClub.squad
        .where((p) => p.position == PlayerPosition.goalkeeper)
        .toList();

    expect(keepers.length, 3);
    expect(game.validateSell(keepers[0].id), isNull);
    game = game.sellPlayer(keepers[0].id);
    expect(game.validateSell(keepers[1].id), isNotNull);
    expect(game.sellPlayer(keepers[1].id).userClub.squad.length, 21);
  });

  test('la nouvelle saison applique montée, descente et progression', () {
    final end = playSeason(newGame());
    final outcome = end.seasonOutcomeNow;
    final agesBefore = {for (final p in end.userClub.squad) p.id: p.age};
    final next = end.startNextSeason(99);

    expect(next.seasonNumber, 2);
    expect(next.history.length, 1);
    expect(next.history.first.outcome, outcome);
    expect(next.division, nextDivision(end.division, outcome));
    expect(next.season.currentRound, 1);
    expect(next.season.clubs.length, 20);
    expect(next.userClub.hasFullLineup, isTrue);
    expect(next.finance.tickets, 0);
    expect(next.finance.treasury, end.finance.treasury);
    expect(next.market.length, greaterThanOrEqualTo(30));
    for (final p in next.userClub.squad) {
      final before = agesBefore[p.id];
      if (before != null) expect(p.age, before + 1);
    }
  });

  test('passer à la saison suivante avant la fin ne fait rien', () {
    final game = newGame();

    expect(identical(game.startNextSeason(1), game), isTrue);
  });
}
