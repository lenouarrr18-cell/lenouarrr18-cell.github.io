import 'dart:convert';

import 'package:club_owner/domain/data/world_data.dart';
import 'package:club_owner/domain/entities/staff.dart';
import 'package:club_owner/engine/finance/finance.dart';
import 'package:club_owner/engine/game/game_codec.dart';
import 'package:club_owner/engine/game/game_state.dart';
import 'package:club_owner/engine/staff/staff_factory.dart';
import 'package:flutter_test/flutter_test.dart';

GameState newGame([int seed = 3]) {
  final country = worldCountries.first;
  return GameState.newGame(
    clubName: 'Mon Club',
    country: country,
    city: country.cities.first,
    seed: seed,
  );
}

String firstCandidate(GameState game, StaffRole role) =>
    game.staffCandidates.firstWhere((c) => c.role == role).id;

GameState withDirector(GameState game) =>
    game.hireStaff(firstCandidate(game, StaffRole.sportingDirector));

void main() {
  test('sans directeur sportif, seuls manager, directeur et CM sont proposés', () {
    final game = newGame();
    final roles = game.staffCandidates.map((c) => c.role).toSet();

    expect(roles.contains(StaffRole.manager), isTrue);
    expect(roles.contains(StaffRole.sportingDirector), isTrue);
    expect(roles.contains(StaffRole.communityManager), isTrue);
    expect(roles.contains(StaffRole.scout), isFalse);
    expect(roles.contains(StaffRole.coachFirst), isFalse);
  });

  test('le directeur sportif débloque recruteurs et coachs', () {
    final game = withDirector(newGame());
    final roles = game.staffCandidates.map((c) => c.role).toSet();

    expect(game.sportingDirector, isNotNull);
    expect(roles.contains(StaffRole.scout), isTrue);
    expect(roles.contains(StaffRole.coachFirst), isTrue);
    expect(roles.contains(StaffRole.coachAcademy), isTrue);
    // Division amateur : pas d'équipe réserve, donc pas de coach réserve.
    expect(roles.contains(StaffRole.coachReserve), isFalse);
  });

  test('embaucher un manager coûte la prime, un seul à la fois', () {
    final game = newGame();
    final id = firstCandidate(game, StaffRole.manager);
    final candidate = game.staffCandidates.firstWhere((c) => c.id == id);

    final hired = game.hireStaff(id);

    expect(hired.manager?.id, id);
    expect(hired.finance.treasury, game.finance.treasury - hiringFee(candidate));
    expect(hired.staffCandidates.any((c) => c.id == id), isFalse);
    expect(
      hired.validateHire(firstCandidate(hired, StaffRole.manager)),
      isNotNull,
    );
  });

  test('licencier coûte une indemnité', () {
    final game = newGame();
    final hired = game.hireStaff(firstCandidate(game, StaffRole.manager));
    final member = hired.manager!;

    final fired = hired.fireStaff(member.id);

    expect(fired.manager, isNull);
    expect(
      fired.finance.treasury,
      hired.finance.treasury - severancePay(member),
    );
  });

  test('les salaires du staff sont payés à chaque journée', () {
    final game = newGame();
    final hired = game.hireStaff(firstCandidate(game, StaffRole.manager));

    final next = hired.playNextRound();
    final rounds = hired.season.totalRounds;
    final expected =
        (squadAnnualWages(hired.userClub.squad) +
            staffAnnualWages(hired.staff)) ~/
        rounds;

    expect(next.finance.wages - hired.finance.wages, expected);
  });

  test('la prospection demande un recruteur et ajoute des joueurs', () {
    final game = withDirector(newGame());
    expect(game.validateProspecting(), isNotNull);

    final hired = game.hireStaff(firstCandidate(game, StaffRole.scout));
    expect(hired.validateProspecting(), isNull);

    final found = hired.prospect();
    expect(found.market.length, hired.market.length + prospectsPerRun);
    expect(found.finance.treasury, hired.finance.treasury - prospectingCost);

    final ids = found.market.map((p) => p.id).toSet();
    expect(ids.length, found.market.length);
  });

  test('le staff survit à la sauvegarde', () {
    final game = withDirector(newGame());
    final raw = jsonEncode(encodeGame(game));
    final back = decodeGame(jsonDecode(raw) as Map<String, dynamic>)!;

    expect(back.staff.map((m) => m.id), game.staff.map((m) => m.id));
  });
}
