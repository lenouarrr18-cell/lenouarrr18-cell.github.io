import 'dart:convert';

import 'package:club_owner/domain/data/world_data.dart';
import 'package:club_owner/domain/entities/owner.dart';
import 'package:club_owner/engine/game/game_codec.dart';
import 'package:club_owner/engine/game/game_state.dart';
import 'package:club_owner/engine/game/owner_actions.dart';
import 'package:club_owner/engine/owner/infrastructure.dart';
import 'package:flutter_test/flutter_test.dart';

GameState newGame([int seed = 3]) {
  final country = worldCountries.first;
  return GameState.newGame(
    clubName: 'Mon Club',
    country: country,
    city: country.cities.first,
    seed: seed,
  );
}

GameState playRounds(GameState game, int count) {
  var current = game;
  for (var i = 0; i < count; i++) {
    current = current.playNextRound();
  }
  return current;
}

void main() {
  test('une nouvelle partie démarre avec un message et un objectif', () {
    final game = newGame();

    expect(game.owner.inbox, isNotEmpty);
    expect(game.owner.unreadCount, 1);
    expect(game.owner.objectiveRank, inInclusiveRange(2, 14));
    expect(game.owner.stadium, 1);
  });

  test('les travaux coûtent de l\'argent puis livrent le niveau', () {
    final game = newGame();
    expect(game.validateUpgrade(InfraKind.stadium), isNull);

    final started = game.startUpgrade(InfraKind.stadium);
    expect(started.owner.work, isNotNull);
    expect(
      started.finance.treasury,
      game.finance.treasury - upgradeCost(InfraKind.stadium, 2),
    );
    expect(started.validateUpgrade(InfraKind.training), isNotNull);

    final done = playRounds(started, upgradeRounds(InfraKind.stadium, 2));
    expect(done.owner.stadium, 2);
    expect(done.owner.work, isNull);
  });

  test('un sponsor principal verse de l\'argent à chaque journée', () {
    final game = newGame();
    final offer = game.sponsorOffers.first;
    final signed = game.signSponsor(offer.id);

    expect(signed.owner.deal?.id, offer.id);
    expect(signed.validateSignSponsor(offer.id), isNotNull);

    final plain = game.playNextRound();
    final withDeal = signed.playNextRound();
    expect(withDeal.finance.sponsors, greaterThan(plain.finance.sponsors));
  });

  test('un prêt apporte du cash puis se rembourse', () {
    final game = newGame();
    final loan = game.takeLoan(100000);

    expect(loan.finance.treasury, game.finance.treasury + 100000);
    expect(loan.owner.debt, greaterThan(100000));

    final later = playRounds(loan, 3);
    expect(later.owner.debt, lessThan(loan.owner.debt));

    expect(game.validateLoan(maxDebt), isNotNull);
  });

  test('l\'état du propriétaire survit à la sauvegarde', () {
    final game = newGame().startUpgrade(InfraKind.academy);
    final raw = jsonEncode(encodeGame(game));
    final back = decodeGame(jsonDecode(raw) as Map<String, dynamic>)!;

    expect(back.owner.work?.kind, InfraKind.academy);
    expect(back.owner.inbox.length, game.owner.inbox.length);

    final old = jsonDecode(raw) as Map<String, dynamic>..remove('owner');
    expect(decodeGame(old)!.owner.stadium, 1);
  });
}
