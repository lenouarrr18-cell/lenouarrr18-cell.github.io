import 'dart:convert';

import 'package:club_owner/domain/entities/owner.dart';
import 'package:club_owner/domain/entities/staff.dart';
import 'package:club_owner/engine/finance/finance.dart';
import 'package:club_owner/engine/game/game_state.dart';
import 'package:club_owner/engine/game/recruitment.dart';
import 'package:flutter_test/flutter_test.dart';

import 'owner_test.dart' show newGame;

GameState withDs(GameState g) => g.copyWith(
      staff: [
        ...g.staff,
        const StaffMember(
          id: 'ds-test',
          name: 'Directeur Test',
          role: StaffRole.sportingDirector,
          level: 70,
        ),
      ],
      finance: g.finance.copyWith(treasury: 50000000),
    );

void main() {
  test('sans directeur sportif, le président ne peut rien lancer', () {
    final g = newGame();
    final target = g.market.first;
    expect(g.validateRecruit(target.id, 1000000), isNotNull);
  });

  test('le directeur sportif signe un agent libre dans le budget', () {
    var g = withDs(newGame());
    expect(g.transferWindowOpen, isTrue);
    final target = [...g.market]..sort((a, b) => b.skill.compareTo(a.skill));
    final player = target.first;
    g = g.requestRecruit(player.id, playerValue(player) * 2);
    final req = g.owner.recruits.first;
    if (req.status == RecruitStatus.refusedByCoach) {
      g = g.insistRecruit(req.id);
    }
    expect(g.owner.recruits.first.open, isTrue);
    // Rien n'est signé tant que le directeur sportif n'a pas agi.
    expect(g.userClub.allPlayers.any((p) => p.id == player.id), isFalse);
    g = g.processRecruits(1);
    expect(g.userClub.allPlayers.any((p) => p.id == player.id), isTrue);
    expect(g.owner.recruits.first.status, RecruitStatus.done);
  });

  test('un budget trop faible fait échouer le dossier', () {
    var g = withDs(newGame());
    final player = g.market.first;
    final price = playerValue(player);
    g = g.copyWith(finance: g.finance.copyWith(treasury: price * 3));
    g = g.requestRecruit(player.id, (price * 0.5).round());
    final req = g.owner.recruits.first;
    if (req.status == RecruitStatus.refusedByCoach) {
      g = g.insistRecruit(req.id);
    }
    g = g.processRecruits(1);
    expect(g.userClub.allPlayers.any((p) => p.id == player.id), isFalse);
    expect(g.owner.recruits.first.status, RecruitStatus.failed);
  });

  test('les dossiers sont sauvegardés', () {
    var g = withDs(newGame());
    final player = g.market.first;
    g = g.requestRecruit(player.id, playerValue(player) * 2);
    final back = OwnerState.fromJson(
      jsonDecode(jsonEncode(g.owner.toJson())) as Map<String, dynamic>,
    );
    expect(back.recruits.length, 1);
    expect(back.recruits.first.playerId, player.id);
  });
}
