import 'package:club_owner/engine/match/pitch_sim.dart';
import 'package:flutter_test/flutter_test.dart';

import 'owner_test.dart' show newGame;

void main() {
  test('le moteur calcule des buts attendus réalistes', () {
    final game = newGame();
    final home = game.userClub;
    final away = game.season.clubs.firstWhere((c) => !c.isUser);
    var xg = 0;
    var goals = 0;
    for (var i = 0; i < 10; i++) {
      final r = PitchSim(seed: 300 + i).simulate(home: home, away: away);
      final s = r.stats!;
      expect(s.homeXg, greaterThanOrEqualTo(0));
      expect(s.homeXg, lessThan(800));
      xg += s.homeXg + s.awayXg;
      goals += r.homeGoals + r.awayGoals;
    }
    // Sur 10 matchs, l'xG total reste positif et borné.
    expect(xg, greaterThan(0));
    expect(xg / 100, lessThan(goals * 4.0 + 60));
  });

  test('les cartons sont journalisés avec la minute et le joueur', () {
    final game = newGame();
    final home = game.userClub;
    final away = game.season.clubs.firstWhere((c) => !c.isUser);
    var yellows = 0;
    var logged = 0;
    for (var i = 0; i < 8; i++) {
      final r = PitchSim(seed: 500 + i).simulate(home: home, away: away);
      yellows += r.stats!.homeYellow + r.stats!.awayYellow;
      for (final raw in r.detail!.cards) {
        final p = raw.split('|');
        expect(p.length, 4);
        expect(int.parse(p[0]), inInclusiveRange(1, 90));
        expect(p[3], anyOf('Y', 'R'));
        if (p[3] == 'Y') logged++;
      }
    }
    expect(logged, greaterThanOrEqualTo(yellows));
  });
}
