import 'package:club_owner/engine/match/pitch_sim.dart';
import 'package:club_owner/features/match/match_log.dart';
import 'package:flutter_test/flutter_test.dart';

import 'owner_test.dart' show newGame;

void main() {
  test('moteur v2 : journal complet et images chaque seconde', () {
    final game = newGame();
    final home = game.userClub;
    final away = game.season.clubs.firstWhere((c) => !c.isUser);
    for (var seed = 1; seed <= 6; seed++) {
      final r = PitchSim(seed: seed * 97).simulate(home: home, away: away);
      final d = r.detail!;
      final s = r.stats!;
      expect(d.trackVersion, pitchTrackVersion);
      expect(d.track.length % pitchFrameBytes, 0);
      final frames = d.track.length ~/ pitchFrameBytes;
      // 90 minutes et le temps additionnel, une image par seconde.
      expect(frames, inInclusiveRange(5400, 6300));

      final log = parseLog(d.log);
      expect(log.first.code, 'KO');
      expect(log.last.code, 'FT');
      expect(log.where((e) => e.code == 'HT').length, 1);

      // Chaque faute et chaque corner du score apparaissent au journal.
      expect(log.where((e) => e.code == 'FL').length,
          s.homeFouls + s.awayFouls);
      expect(log.where((e) => e.code == 'CK').length,
          s.homeCorners + s.awayCorners);
      expect(log.where((e) => e.code == 'OF').length,
          lessThanOrEqualTo(s.homeOffsides + s.awayOffsides));

      // Les buts vus sur le terrain correspondent au score.
      final seen = log.where((e) => e.code == 'GL').length;
      expect(seen, lessThanOrEqualTo(r.homeGoals + r.awayGoals));

      // Remplacements : annoncés puis effectués, au plus 3 par équipe.
      final done = log.where((e) => e.code == 'SB').toList();
      expect(done.length, d.subs.length);
      expect(done.where((e) => e.home).length, lessThanOrEqualTo(3));
      expect(done.where((e) => !e.home).length, lessThanOrEqualTo(3));
      for (final sb in done) {
        expect(
          log.any((e) => e.code == 'SBA' && e.a == sb.a && e.t <= sb.t),
          isTrue,
        );
      }

      // Chaque penalty sifflé est tiré.
      final pk = log.where((e) => e.code == 'PK').length;
      final pks = log.where((e) => e.code == 'PKS').length;
      expect(pks, lessThanOrEqualTo(pk));
      expect(pk - pks, lessThanOrEqualTo(1));

      // Les positions de l'arbitre et des assistants sont enregistrées.
      final mid = (frames ~/ 2) * pitchFrameBytes;
      expect(d.track[mid + 46] + d.track[mid + 47], greaterThan(0));
      expect(d.track[mid + 49], 0);
      expect(d.track[mid + 51], 255);

      // Le journal reste dans l'ordre du temps.
      for (var i = 1; i < d.log.length; i++) {
        final a = double.parse(d.log[i - 1].split('|')[0]);
        final b = double.parse(d.log[i].split('|')[0]);
        expect(b, greaterThanOrEqualTo(a));
      }
    }
  });

  test('le score imposé est respecté et les buts se voient', () {
    final game = newGame();
    final home = game.userClub;
    final away = game.season.clubs.firstWhere((c) => !c.isUser);
    var shown = 0;
    var total = 0;
    for (var i = 0; i < 8; i++) {
      final r = PitchSim(seed: 700 + i)
          .simulate(home: home, away: away, homeGoals: 2, awayGoals: 1);
      expect(r.homeGoals, 2);
      expect(r.awayGoals, 1);
      final log = parseLog(r.detail!.log);
      shown += log.where((e) => e.code == 'GL').length;
      total += 3;
    }
    // Presque tous les buts sont joués sur le terrain.
    expect(shown, greaterThanOrEqualTo((total * 0.8).round()));
  });

  test('scores réalistes quand le terrain décide (pas de score fleuve)', () {
    final game = newGame();
    final home = game.userClub;
    final away = game.season.clubs.firstWhere((c) => !c.isUser);
    var goals = 0;
    var big = 0;
    var pens = 0;
    var penGoals = 0;
    const n = 30;
    for (var i = 0; i < n; i++) {
      final r = PitchSim(seed: 4000 + i).simulate(home: home, away: away);
      final total = r.homeGoals + r.awayGoals;
      final log = parseLog(r.detail!.log);
      pens += log.where((e) => e.code == 'PK').length;
      penGoals += log.where((e) => e.code == 'PKS' && e.b == 'G').length;
      goals += total;
      if (total >= 7) big++;
    }
    // Environ 2,5 buts par match, comme dans les vrais championnats.
    expect(goals / n, inInclusiveRange(1.2, 3.8));
    expect(big, lessThanOrEqualTo(2));
    // Un penalty tous les deux ou trois matchs ; la plupart des buts
    // viennent du jeu.
    expect(pens / n, lessThanOrEqualTo(0.7));
    expect(penGoals, lessThan(goals / 3));
  });

  test('horloge façon télévision', () {
    expect(clockLabel(0), "0'");
    expect(clockLabel(61), "1'");
    expect(clockLabel(5400), "90+1'");
    expect(clockLabel(5530), "90+3'");
  });
}
