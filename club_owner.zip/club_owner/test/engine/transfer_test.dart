import 'dart:convert';

import 'package:club_owner/domain/data/world_data.dart';
import 'package:club_owner/domain/entities/player.dart';
import 'package:club_owner/domain/entities/staff.dart';
import 'package:club_owner/domain/entities/transfer.dart';
import 'package:club_owner/engine/finance/finance.dart';
import 'package:club_owner/engine/game/game_codec.dart';
import 'package:club_owner/engine/game/game_state.dart';
import 'package:club_owner/engine/game/transfer_actions.dart';
import 'package:flutter_test/flutter_test.dart';

GameState newGame([int seed = 3]) {
  final country = worldCountries.first;
  return GameState.newGame(
    clubName: 'Mon Club',
    country: country,
    city: country.cities.first,
    seed: seed,
  );
}

GameState withDirector(GameState game) {
  final id = game.staffCandidates
      .firstWhere((c) => c.role == StaffRole.sportingDirector)
      .id;
  return game.hireStaff(id);
}

void main() {
  test('tous les clubs ont un effectif complet', () {
    final game = newGame();
    for (final club in game.season.clubs) {
      expect(club.squad.length, greaterThanOrEqualTo(20));
      expect(club.starters.length, 11);
      expect(club.academy, isNotEmpty);
    }
  });

  test('une offre exige un directeur sportif', () {
    final game = newGame();
    final target = game.otherClubs.first.squad.first;

    expect(
      game.validateOffer(
        playerId: target.id,
        kind: OfferKind.transfer,
        fee: 50000,
      ),
      isNotNull,
    );
  });

  test('une offre très élevée finit par être acceptée', () {
    final game = withDirector(newGame());
    var accepted = false;

    for (final club in game.otherClubs.take(4)) {
      final target = club.squad.firstWhere((p) => p.skill < 62);
      final fee = playerValue(target) * 4;
      if (game.validateOffer(
            playerId: target.id,
            kind: OfferKind.transfer,
            fee: fee,
          ) !=
          null) {
        continue;
      }
      final after = game.makeOffer(
        playerId: target.id,
        kind: OfferKind.transfer,
        fee: fee,
      );
      if (after.userClub.allPlayers.any((p) => p.id == target.id)) {
        accepted = true;
        expect(after.finance.treasury, lessThan(game.finance.treasury));
        break;
      }
    }
    expect(accepted, isTrue);
  });

  test('une offre ridicule est refusée', () {
    final game = withDirector(newGame());
    final target = game.otherClubs.first.squad.first;
    final after = game.makeOffer(
      playerId: target.id,
      kind: OfferKind.transfer,
      fee: 1000,
    );

    expect(after.userClub.allPlayers.any((p) => p.id == target.id), isFalse);
  });

  test('libérer un joueur coûte une indemnité et le rend libre', () {
    final game = newGame();
    final player = game.userClub.squad.firstWhere(
      (p) => p.position == PlayerPosition.defender,
    );
    final released = game.releasePlayer(player.id);

    expect(released.userClub.squad.any((p) => p.id == player.id), isFalse);
    expect(released.market.any((p) => p.id == player.id), isTrue);
    expect(
      released.finance.treasury,
      game.finance.treasury - releaseCost(player),
    );
  });

  test('promouvoir un jeune du centre de formation en équipe première', () {
    final game = newGame();
    final youth = game.userClub.academy.first;
    final moved = game.moveToTeam(youth.id, SquadSlot.first);

    expect(moved.userClub.squad.any((p) => p.id == youth.id), isTrue);
    expect(moved.userClub.academy.any((p) => p.id == youth.id), isFalse);
  });

  test('le monde vieillit : retraites et regens à chaque saison', () {
    var game = newGame();
    for (var season = 0; season < 3; season++) {
      var guard = 0;
      while (!game.season.isFinished && guard < 100) {
        if (!game.canPlayNextRound) game = game.autoPickStarters();
        game = game.playNextRound();
        guard++;
      }
      expect(game.season.isFinished, isTrue);
      game = game.startNextSeason(100 + season);
    }

    expect(game.seasonNumber, 4);
    for (final club in game.season.clubs) {
      expect(
        club.squad.length,
        greaterThanOrEqualTo(12),
        reason: '${club.name} manque de joueurs',
      );
      expect(
        club.starters.length,
        greaterThanOrEqualTo(9),
        reason: '${club.name} manque de titulaires',
      );
    }
    expect(game.userClub.hasFullLineup, isTrue);
    expect(game.awards, isNotEmpty);
  });

  test('offres, prêts et palmarès survivent à la sauvegarde', () {
    var game = withDirector(newGame());
    final target = game.otherClubs.first.squad.first;
    game = game.makeOffer(
      playerId: target.id,
      kind: OfferKind.transfer,
      fee: 1000,
    );
    final raw = jsonEncode(encodeGame(game));
    final back = decodeGame(jsonDecode(raw) as Map<String, dynamic>)!;

    expect(back.offers.length, game.offers.length);
    expect(back.userClub.academy.length, game.userClub.academy.length);
    expect(
      back.season.clubs.length,
      game.season.clubs.length,
    );
  });
}
