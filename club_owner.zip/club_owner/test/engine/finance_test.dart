import 'package:club_owner/domain/entities/player.dart';
import 'package:club_owner/engine/finance/finance.dart';
import 'package:flutter_test/flutter_test.dart';

Player player(int skill, int age) {
  return Player(
    id: 'x',
    name: 'X',
    position: PlayerPosition.midfielder,
    skill: skill,
    age: age,
  );
}

void main() {
  test('la valeur croît avec le niveau et baisse avec l\'âge', () {
    expect(
      playerValue(player(65, 25)),
      greaterThan(playerValue(player(55, 25))),
    );
    expect(
      playerValue(player(60, 20)),
      greaterThan(playerValue(player(60, 25))),
    );
    expect(
      playerValue(player(60, 25)),
      greaterThan(playerValue(player(60, 33))),
    );
  });

  test('le prix de revente est inférieur à la valeur', () {
    final p = player(62, 24);

    expect(sellPrice(p), lessThan(playerValue(p)));
    expect(sellPrice(p), greaterThan(0));
  });

  test(
    'la billetterie dépend du classement, de la ville et de la division',
    () {
      final first = ticketRevenue(
        populationThousands: 800,
        division: 4,
        rank: 1,
      );
      final last = ticketRevenue(
        populationThousands: 800,
        division: 4,
        rank: 20,
      );
      final bigCity = ticketRevenue(
        populationThousands: 5600,
        division: 4,
        rank: 10,
      );
      final smallCity = ticketRevenue(
        populationThousands: 200,
        division: 4,
        rank: 10,
      );
      final upper = ticketRevenue(
        populationThousands: 800,
        division: 2,
        rank: 1,
      );

      expect(first, greaterThan(last));
      expect(bigCity, greaterThan(smallCity));
      expect(upper, greaterThan(first));
    },
  );

  test('le sponsoring augmente avec la division et la richesse', () {
    expect(
      sponsorIncomePerSeason(wealth: 5, division: 1),
      greaterThan(sponsorIncomePerSeason(wealth: 5, division: 4)),
    );
    expect(
      sponsorIncomePerSeason(wealth: 9, division: 4),
      greaterThan(sponsorIncomePerSeason(wealth: 2, division: 4)),
    );
  });

  test('le bilan de saison se remet à zéro, pas la trésorerie', () {
    const book = FinanceBook(
      treasury: 1000,
      tickets: 5,
      sponsors: 6,
      wages: 7,
      transfers: -8,
    );
    final reset = book.resetSeason();

    expect(book.seasonResult, 5 + 6 - 7 - 8);
    expect(reset.treasury, 1000);
    expect(reset.seasonResult, 0);
  });
}
