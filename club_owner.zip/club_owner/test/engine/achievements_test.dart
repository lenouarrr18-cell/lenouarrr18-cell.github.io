import 'package:club_owner/core/audio/audio_service.dart';
import 'package:club_owner/engine/achievements/achievements.dart';
import 'package:flutter_test/flutter_test.dart';

import 'owner_test.dart' show newGame;

void main() {
  test('une nouvelle partie n\'a presque aucun succès', () {
    final g = newGame();
    final done = unlockedAchievements(g);
    expect(done.contains('champion'), isFalse);
    expect(done.contains('empire'), isFalse);
    expect(achievements.map((a) => a.id).toSet().length, achievements.length);
  });

  test('les succès suivent la partie', () {
    final g = newGame();
    final rich = g.copyWith(
      finance: g.finance.copyWith(treasury: 12000000),
      owner: g.owner.copyWith(stadium: 4, followers: 20000),
    );
    final done = unlockedAchievements(rich);
    expect(done, containsAll(['million', 'empire', 'stadium2', 'stadium4', 'fans']));
  });

  test('les titres de morceaux se déduisent des noms de fichiers', () {
    const t = Track('audio/music/a.mp3', 'Titre', artist: 'Artiste');
    expect(t.artist, 'Artiste');
  });
}
