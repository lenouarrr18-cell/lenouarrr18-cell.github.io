import 'dart:convert';

import 'package:club_owner/domain/data/world_data.dart';
import 'package:club_owner/engine/game/game_codec.dart';
import 'package:club_owner/engine/game/game_state.dart';
import 'package:flutter_test/flutter_test.dart';

GameState newGame(int seed) {
  final country = worldCountries[1];
  return GameState.newGame(
    clubName: 'Mon Club',
    country: country,
    city: country.cities[1],
    seed: seed,
  );
}

GameState roundTrip(GameState game) {
  final raw = jsonEncode(encodeGame(game));
  return decodeGame(jsonDecode(raw) as Map<String, dynamic>)!;
}

void main() {
  test('sauvegarde en cours de saison : aller-retour JSON identique', () {
    var game = newGame(5);
    game = game.buyPlayer(game.market.first.id);
    for (var i = 0; i < 5; i++) {
      game = game.playNextRound();
    }
    final back = roundTrip(game);

    expect(back.country.id, game.country.id);
    expect(back.city.name, game.city.name);
    expect(back.division, game.division);
    expect(back.seasonNumber, game.seasonNumber);
    expect(back.season.currentRound, 6);
    expect(back.finance.treasury, game.finance.treasury);
    expect(back.finance.transfers, game.finance.transfers);
    expect(back.market.length, game.market.length);
    expect(back.userClub.squad.length, game.userClub.squad.length);
    expect(back.userClub.starterIds, game.userClub.starterIds);

    final a = game.season.standings;
    final b = back.season.standings;
    for (var i = 0; i < a.length; i++) {
      expect(b[i].clubId, a[i].clubId);
      expect(b[i].points, a[i].points);
    }

    final nextA = game.playNextRound().season.standings;
    final nextB = back.playNextRound().season.standings;
    for (var i = 0; i < nextA.length; i++) {
      expect(nextB[i].clubId, nextA[i].clubId);
      expect(nextB[i].points, nextA[i].points);
    }
  });

  test('sauvegarde après une saison : le palmarès est conservé', () {
    var game = newGame(8);
    while (!game.season.isFinished) {
      game = game.playNextRound();
    }
    game = game.startNextSeason(77);
    final back = roundTrip(game);

    expect(back.history.length, 1);
    expect(back.history.first.rank, game.history.first.rank);
    expect(back.history.first.outcome, game.history.first.outcome);
    expect(back.seasonNumber, 2);
  });

  test('une version plus récente que le jeu est ignorée', () {
    // Les anciennes versions (1 à saveVersion) se chargent désormais.
    final json = encodeGame(newGame(1));
    json['version'] = 999;

    expect(
      decodeGame(jsonDecode(jsonEncode(json)) as Map<String, dynamic>),
      isNull,
    );
  });
}
