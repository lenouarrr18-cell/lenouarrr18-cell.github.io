import 'dart:convert';

import 'package:club_owner/domain/data/world_data.dart';
import 'package:club_owner/domain/entities/lineup.dart';
import 'package:club_owner/domain/entities/player.dart';
import 'package:club_owner/domain/entities/spots.dart';
import 'package:club_owner/domain/entities/tactic.dart';
import 'package:club_owner/engine/game/game_codec.dart';
import 'package:club_owner/engine/game/game_state.dart';
import 'package:club_owner/engine/match/pitch_sim.dart';
import 'package:club_owner/engine/squad/coach.dart';
import 'package:flutter_test/flutter_test.dart';

GameState newGame() {
  final country = worldCountries.first;
  return GameState.newGame(
    clubName: 'Mon Club',
    country: country,
    city: country.cities.first,
    seed: 5,
  );
}

void main() {
  test('chaque formation a 11 postes cohérents', () {
    for (final f in Formation.values) {
      final slots = layoutOf(f);
      expect(slots.length, 11, reason: f.label);
      expect(slots.where((s) => s.spot == Spot.gb).length, 1);
      // Le nom de la formation correspond aux lignes réelles.
      final parts = f.label.split('-').map(int.parse).toList();
      final lines = f.slots;
      expect(lines[PlayerPosition.defender], parts[0], reason: f.label);
      expect(lines[PlayerPosition.forward], parts[parts.length - 1]);
      expect(
        lines[PlayerPosition.midfielder],
        10 - parts[0] - parts[parts.length - 1],
      );
      // Aucun doublon de position, coordonnées dans le terrain.
      final seen = <String>{};
      for (final s in slots) {
        expect(s.x, inInclusiveRange(0.0, 1.0));
        expect(s.y, inInclusiveRange(0.0, 1.0));
        expect(seen.add('${s.x}-${s.y}'), isTrue, reason: '${f.label} ${s.spot}');
        // Gauche à gauche, droite à droite, axiaux dans l'axe.
        if (s.spot.side < 0) expect(s.y, lessThan(0.5), reason: s.spot.label);
        if (s.spot.side > 0) expect(s.y, greaterThan(0.5), reason: s.spot.label);
        if (s.spot == Spot.mdc || s.spot == Spot.moc || s.spot == Spot.gb) {
          expect(s.y, 0.5, reason: '${f.label} ${s.spot.label} doit être axial');
        }
      }
    }
  });

  test('le 4-4-2 respecte les postes du cahier des charges', () {
    final labels = layoutOf(Formation.f442).map((s) => s.spot.label).toList();
    expect(labels, [
      'GB', 'DG', 'DC', 'DC', 'DD', 'MG', 'MC', 'MC', 'MD', 'BU', 'BU',
    ]);
  });

  test('la composition du coach couvre chaque formation', () {
    final club = newGame().userClub;
    for (final f in Formation.values) {
      final ids = pickBestStarters(club.squad, f);
      expect(ids.length, 11, reason: f.label);
      expect(ids.toSet().length, 11);
      final players = club.squad.where((p) => ids.contains(p.id)).toList();
      expect(
        players.where((p) => p.position == PlayerPosition.goalkeeper).length,
        1,
      );
      final xi = lineupSlots(players, f);
      expect(xi.every((p) => p != null), isTrue);
    }
  });

  test('le coach ménage les joueurs fatigués et la fatigue évolue', () {
    var club = newGame().userClub;
    final starters = club.starterIds.toSet();
    club = applyMatchLoad(club);
    for (final p in club.squad) {
      if (starters.contains(p.id)) {
        expect(p.fitness, lessThan(100));
      } else {
        expect(p.fitness, 100);
      }
    }
    // Tous les titulaires épuisés : le coach ne peut pas rester à l'identique
    // si un remplaçant au même poste est quasi aussi bon.
    final tired = club.copyWith(
      squad: [
        for (final p in club.squad)
          starters.contains(p.id) ? p.copyWith(fitness: 30) : p,
      ],
    );
    final pick = coachSelects(tired);
    expect(pick.club.starterIds.length, 11);
    expect(pick.club.starterIds.toSet().length, 11);
  });

  test('le président ne peut pas titulariser', () {
    final game = newGame();
    final bench = game.userClub.squad.firstWhere(
      (p) => !game.userClub.starterIds.contains(p.id),
    );
    expect(game.validateToggleStarter(bench.id), isNotNull);
  });

  test('changer de formation recompose automatiquement', () {
    final game = newGame().setTactic(
      newGame().userClub.tactic.copyWith(formation: Formation.f343),
    );
    expect(game.userClub.tactic.formation, Formation.f343);
    expect(game.userClub.starters.length, 11);
    expect(game.userClub.hasFullLineup, isTrue);
  });

  test('rôles, consignes et configurations sont sauvegardés', () {
    var game = newGame();
    var t = game.userClub.tactic.copyWith(
      formation: Formation.f433,
      style: TacticStyle.veryAttacking,
      pressing: Pressing.veryHigh,
      playStyle: PlayStyle.wings,
      lineHeight: 4,
      width: 3,
      transition: Transition.counterPress,
    );
    t = t.withRole(5, Role.sentinelle).withInstruction(1, Instruction.joinAttack);
    game = game.setTactic(t).savePreset(1);
    final back = decodeGame(
      jsonDecode(jsonEncode(encodeGame(game))) as Map<String, dynamic>,
    )!;
    final bt = back.userClub.tactic;
    expect(bt.formation, Formation.f433);
    expect(bt.style, TacticStyle.veryAttacking);
    expect(bt.pressing, Pressing.veryHigh);
    expect(bt.playStyle, PlayStyle.wings);
    expect(bt.lineHeight, 4);
    expect(bt.width, 3);
    expect(bt.transition, Transition.counterPress);
    expect(bt.roleAt(5), Role.sentinelle);
    expect(bt.instructionAt(1), Instruction.joinAttack);
    expect(bt.presets.length, 3);
    expect(back.userClub.starterIds, game.userClub.starterIds);
  });

  test("une ancienne sauvegarde sans nouveaux champs se charge", () {
    final t = Tactic.fromJson(const {
      'formation': 'f352',
      'style': 'attacking',
      'pressing': 'high',
    });
    expect(t.formation, Formation.f352);
    expect(t.lineHeight, 2);
    expect(t.roles, isEmpty);
    expect(t.playStyle, PlayStyle.balanced);
  });

  test("l'équilibre tactique est calculé, pas attribué", () {
    final club = newGame().userClub;
    final b442 = tacticalBalance(
      club.starters,
      club.tactic.copyWith(formation: Formation.f442),
    );
    expect(b442.total, inInclusiveRange(0, 100));
    expect(
      b442.notes.any((n) => n.contains('Aucun milieu défensif')),
      isTrue,
    );
    final withSentinel = tacticalBalance(
      club.starters,
      club.tactic.copyWith(formation: Formation.f442).withRole(6, Role.sentinelle),
    );
    expect(withSentinel.solidity, greaterThan(b442.solidity));
  });

  test('les tactiques sont transmises au moteur de match', () {
    final game = newGame();
    final home = game.userClub;
    final away = game.season.clubs.firstWhere((c) => !c.isUser);
    for (final f in Formation.values) {
      final h = home.copyWith(
        tactic: home.tactic.copyWith(formation: f),
        starterIds: pickBestStarters(home.squad, f),
      );
      final r = PitchSim(seed: 3).simulate(home: h, away: away);
      expect(r.detail!.perfs.length, greaterThanOrEqualTo(22), reason: f.label);
      final firstHome = r.detail!.perfs.where((p) => p.home).first;
      expect(firstHome.pos, 'GB');
      final labels = r.detail!.perfs.where((p) => p.home).take(11).map((p) => p.pos).toSet();
      // Les postes affichés viennent de la formation.
      final expected = layoutOf(f).map((s) => s.spot.label).toSet();
      expect(labels.difference(expected), isEmpty, reason: f.label);
    }
    // Un style très offensif change la force de l'équipe.
    final attacking = home.copyWith(
      tactic: home.tactic.copyWith(style: TacticStyle.veryAttacking),
    );
    expect(
      attacking.matchStrength.attack,
      greaterThan(home.matchStrength.attack),
    );
  });

  test('une sauvegarde d\'une version plus ancienne se charge', () {
    final game = newGame();
    final json = jsonDecode(jsonEncode(encodeGame(game))) as Map<String, dynamic>;
    json['version'] = 1;
    expect(decodeGame(json), isNotNull);
    json['version'] = 999;
    expect(decodeGame(json), isNull);
  });
}
