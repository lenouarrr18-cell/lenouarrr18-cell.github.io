import 'dart:convert';

import 'package:club_owner/domain/data/world_data.dart';
import 'package:club_owner/engine/calendar/transfer_window.dart';
import 'package:club_owner/engine/game/game_codec.dart';
import 'package:club_owner/engine/game/game_state.dart';
import 'package:club_owner/engine/game/world_codec.dart';
import 'package:club_owner/engine/world/facilities.dart';
import 'package:club_owner/engine/world/world_factory.dart';
import 'package:flutter_test/flutter_test.dart';

GameState newGame([int seed = 5]) {
  final country = worldCountries.first;
  return GameState.newGame(
    clubName: 'Mon Club',
    country: country,
    city: country.cities.first,
    seed: seed,
  );
}

void main() {
  test('le mercato suit le calendrier réel', () {
    bool open(int round) => isTransferWindowOpen(
      seasonNumber: 1,
      round: round,
      finished: false,
    );

    expect(open(1), isTrue); // mi-août
    expect(open(3), isTrue); // fin août
    expect(open(4), isFalse); // septembre
    expect(open(12), isFalse); // automne
    expect(open(22), isTrue); // janvier
    expect(open(30), isFalse); // printemps
    expect(
      isTransferWindowOpen(seasonNumber: 1, round: 38, finished: true),
      isTrue,
    );
  });

  test('hors mercato, on ne peut ni acheter ni recevoir d\'offre', () {
    var game = newGame();
    expect(game.transferWindowOpen, isTrue);
    for (var i = 0; i < 8 && game.canPlayNextRound; i++) {
      game = game.playNextRound();
    }

    expect(game.transferWindowOpen, isFalse);
    final id = game.market.first.id;
    expect(game.validateBuy(id), isNotNull);
    expect(game.transferWindowMessage, contains('fermé'));
  });

  test('chaque club a un stade, une fan zone et un nom de stade', () {
    final game = newGame();
    final clubs = game.everyClub.where((c) => !c.isUser).toList();
    final names = <String>{};
    for (final club in clubs.take(100)) {
      final f = facilitiesOf(club);
      expect(f.stadium, inInclusiveRange(1, 5));
      expect(f.capacity, greaterThan(0));
      expect(f.stadiumName, isNotEmpty);
      names.add(f.stadiumName);
    }
    expect(names.length, greaterThan(10));

    final big = clubs.reduce((a, b) => a.prestige >= b.prestige ? a : b);
    final small = clubs.reduce((a, b) => a.prestige <= b.prestige ? a : b);
    expect(facilitiesOf(big).stadium, greaterThanOrEqualTo(facilitiesOf(small).stadium));
  });

  test('les effectifs du monde sont fournis', () {
    final game = newGame();
    for (final league in game.world.take(20)) {
      for (final club in league.season.clubs) {
        expect(club.squad.length, greaterThanOrEqualTo(squadSizeFor(league.division) - 1));
      }
    }
  });

  test('le dernier match garde les vrais buteurs', () {
    var game = newGame();
    for (var i = 0; i < 6; i++) {
      game = game.playNextRound();
      final match = game.lastMatch!;
      expect(match.goals.length, match.homeGoals + match.awayGoals);
      for (final g in match.goals) {
        expect(g.scorer, isNotEmpty);
        expect(g.minute, inInclusiveRange(1, 95));
      }
    }
  });

  test('le codec compact du monde est fidèle', () {
    final game = newGame().playNextRound();
    final league = game.world.first;

    final json = encodeLeague(league);
    final back = decodeLeague(jsonDecode(jsonEncode(json)) as Map<String, dynamic>);

    expect(jsonEncode(encodeLeague(back)), jsonEncode(json));
    expect(back.season.currentRound, league.season.currentRound);

    final snapshot = encodeWorldSnapshot(game);
    final decoded = decodeWorldSnapshot(
      jsonDecode(jsonEncode(snapshot)) as Map<String, dynamic>,
      seasonNumber: game.seasonNumber,
    );
    expect(decoded, isNotNull);
    expect(decoded!.length, game.world.length);
    expect(
      decodeWorldSnapshot(snapshot.map((k, v) => MapEntry(k, v)), seasonNumber: 99),
      isNull,
    );
  });

  test('la sauvegarde principale ne contient pas le monde', () {
    final game = newGame();
    final light = jsonEncode(encodeGame(game, includeWorld: false));
    final full = jsonEncode(encodeGame(game));

    expect(light.length, lessThan(full.length));
    final back = decodeGame(jsonDecode(light) as Map<String, dynamic>)!;
    expect(back.world, isEmpty);
  });
}
