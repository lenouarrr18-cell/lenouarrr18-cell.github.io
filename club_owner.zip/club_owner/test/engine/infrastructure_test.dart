import 'dart:convert';

import 'package:club_owner/domain/entities/owner.dart';
import 'package:club_owner/engine/game/game_state.dart';
import 'package:club_owner/engine/game/owner_actions.dart';
import 'package:club_owner/engine/owner/infrastructure.dart';
import 'package:flutter_test/flutter_test.dart';

import 'owner_test.dart' show newGame, playRounds;

GameState rich(GameState g) => g.copyWith(
      finance: g.finance.copyWith(treasury: 50000000),
      owner: g.owner.copyWith(reputation: 30),
    );

GameState withLevels(GameState g, Map<InfraKind, int> levels) {
  var owner = g.owner;
  levels.forEach((k, v) => owner = owner.withLevel(k, v));
  return g.copyWith(owner: owner);
}

void main() {
  test('chaque bâtiment a une fiche complète sur 5 niveaux', () {
    for (final kind in InfraKind.values) {
      final spec = infraCatalog[kind];
      expect(spec, isNotNull, reason: '$kind sans fiche');
      expect(spec!.costs.length, 6, reason: '$kind coûts');
      expect(spec.rounds.length, 6, reason: '$kind durées');
      expect(spec.names.length, 6, reason: '$kind noms');
      expect(spec.maintenance, greaterThan(0));
      expect(spec.staffPerLevel, greaterThan(0));
      for (var l = 2; l <= 5; l++) {
        expect(spec.costs[l], greaterThan(spec.costs[l - 1]),
            reason: '$kind coût niveau $l');
        expect(spec.rounds[l], greaterThan(0));
        expect(infraEffect(kind, l), isNotEmpty);
      }
      for (var l = 1; l <= 5; l++) {
        expect(spec.names[l], isNotEmpty, reason: '$kind nom niveau $l');
      }
    }
  });

  test('le cahier des charges est couvert : sport, commerce, administration',
      () {
    expect(infraOfCategory(InfraCategory.sport).length, 9);
    expect(infraOfCategory(InfraCategory.commercial).length, 10);
    expect(infraOfCategory(InfraCategory.admin).length, 5);
    expect(infraOfCategory(InfraCategory.stadium).length, 5);
    expect(InfraKind.values.length, 29);
  });

  test('les nouveaux bâtiments sont enregistrés dans la sauvegarde', () {
    var g = rich(newGame());
    g = withLevels(g, {InfraKind.hq: 2, InfraKind.pitch: 1});
    g = g.startUpgrade(InfraKind.hq);
    expect(g.owner.works.length, 1);
    expect(g.owner.infraLog, isNotEmpty);

    final raw = jsonDecode(jsonEncode(g.owner.toJson())) as Map<String, dynamic>;
    final back = OwnerState.fromJson(raw);
    expect(back.levelOf(InfraKind.hq), 2);
    expect(back.levelOf(InfraKind.pitch), 1);
    expect(back.works.single.kind, InfraKind.hq);
    expect(back.infraLog, g.owner.infraLog);
  });

  test('une ancienne sauvegarde sans les nouveaux champs se charge', () {
    final raw = jsonDecode(jsonEncode(newGame().owner.toJson()))
        as Map<String, dynamic>;
    raw
      ..remove('levels')
      ..remove('extraWorks')
      ..remove('infraLog')
      ..remove('seatColor');
    final back = OwnerState.fromJson(raw);
    expect(back.levelOf(InfraKind.mall), 0);
    expect(back.works, isEmpty);
    expect(back.seatColor, 0);
    expect(back.stadium, 1);
  });

  test('les conditions de déblocage sont vérifiées', () {
    var g = rich(newGame());
    // Le recrutement du personnel demande le siège administratif.
    expect(g.validateUpgrade(InfraKind.hrCenter), isNotNull);
    expect(infraBlockers(g.owner, InfraKind.hrCenter), isNotEmpty);
    g = withLevels(g, {InfraKind.hq: 1});
    expect(g.validateUpgrade(InfraKind.hrCenter), isNull);

    // La rééducation demande un centre médical de niveau 2.
    expect(g.validateUpgrade(InfraKind.rehab), isNotNull);
    g = withLevels(g, {InfraKind.medical: 2});
    expect(g.validateUpgrade(InfraKind.rehab), isNull);

    // Le centre commercial demande stade 4, parking 2 et réputation 40.
    expect(g.validateUpgrade(InfraKind.mall), isNotNull);
  });

  test('un niveau de partie du stade ne dépasse pas les tribunes', () {
    var g = rich(newGame());
    g = withLevels(g, {InfraKind.pitch: 2});
    // Tribunes niveau 1 : la pelouse ne peut pas aller au niveau 3.
    expect(g.validateUpgrade(InfraKind.pitch), isNotNull);
    g = withLevels(g, {InfraKind.stadium: 2});
    expect(g.validateUpgrade(InfraKind.pitch), isNull);
  });

  test('le personnel limite les constructions', () {
    var g = rich(newGame());
    g = withLevels(g, {
      InfraKind.stadium: 5,
      InfraKind.training: 5,
      InfraKind.academy: 5,
      InfraKind.medical: 5,
      InfraKind.vip: 5,
      InfraKind.shop: 5,
    });
    expect(infraEmployees(g.owner), greaterThan(staffCapacity(g.owner)));
    final reasons = infraBlockers(g.owner, InfraKind.fanZone);
    expect(reasons.any((r) => r.contains('Personnel')), isTrue);

    g = withLevels(g, {InfraKind.hq: 5, InfraKind.hrCenter: 5});
    expect(infraEmployees(g.owner), lessThanOrEqualTo(staffCapacity(g.owner)));
  });

  test('le centre des opérations permet plusieurs chantiers et accélère',
      () {
    var g = rich(newGame());
    expect(maxConcurrentWorks(g.owner), 1);
    g = withLevels(g, {InfraKind.hq: 3, InfraKind.operations: 2});
    expect(maxConcurrentWorks(g.owner), 2);
    expect(
      effectiveRounds(g.owner, InfraKind.stadium, 2),
      lessThan(upgradeRounds(InfraKind.stadium, 2)),
    );

    g = g.startUpgrade(InfraKind.stadium);
    expect(g.validateUpgrade(InfraKind.training), isNull);
    g = g.startUpgrade(InfraKind.training);
    expect(g.owner.works.length, 2);
    // Un troisième chantier est refusé.
    expect(g.validateUpgrade(InfraKind.academy), isNotNull);
    // Le même bâtiment ne peut pas être amélioré deux fois en même temps.
    expect(g.validateUpgrade(InfraKind.stadium), isNotNull);
  });

  test('les travaux sont livrés, enregistrés dans l\'historique', () {
    var g = rich(newGame());
    g = g.startUpgrade(InfraKind.stadium);
    final done = playRounds(g, upgradeRounds(InfraKind.stadium, 2));
    expect(done.owner.stadium, 2);
    expect(done.owner.works, isEmpty);
    expect(done.owner.infraLog.length, 2);
    expect(done.owner.infraLog.first, contains('terminé'));
  });

  test('construire un bâtiment coûte de l\'argent et augmente l\'entretien',
      () {
    var g = rich(newGame());
    g = withLevels(g, {InfraKind.hq: 2});
    final before = infrastructureUpkeepPerSeason(g.owner);
    final treasury = g.finance.treasury;
    final started = g.startUpgrade(InfraKind.conference);
    expect(started.finance.treasury,
        treasury - upgradeCost(InfraKind.conference, 1));
    final done = playRounds(started, effectiveRounds(g.owner, InfraKind.conference, 1));
    expect(done.owner.levelOf(InfraKind.conference), 1);
    // Le siège réduit les frais, mais le nouveau bâtiment coûte plus cher.
    expect(infrastructureUpkeepPerSeason(done.owner), greaterThan(before));
  });

  test('les effets chiffrés progressent avec le niveau', () {
    var o = newGame().owner;
    expect(homeExtraIncome(o, division: 3), 0);
    expect(mallIncomePerRound(o, division: 3), 0);
    expect(ticketMultiplier(o), 1.0);

    o = o
        .withLevel(InfraKind.boxes, 2)
        .withLevel(InfraKind.ads, 2)
        .withLevel(InfraKind.mall, 2)
        .withLevel(InfraKind.lighting, 3)
        .withLevel(InfraKind.partners, 2)
        .withLevel(InfraKind.fitness, 3)
        .withLevel(InfraKind.rehab, 2)
        .withLevel(InfraKind.youth, 3);
    expect(homeExtraIncome(o, division: 3), greaterThan(0));
    expect(mallIncomePerRound(o, division: 3), greaterThan(0));
    expect(ticketMultiplier(o), greaterThan(1.0));
    expect(sponsorMultiplier(o), greaterThan(1.0));
    expect(fitnessRestBonus(o), 6);
    expect(rehabRecovery(o), greaterThan(0));
    expect(youthAcademyExtra(o), 1);
    expect(medicalProtection(o), greaterThan(o.medical));
  });

  test('les revenus des bâtiments entrent dans la trésorerie', () {
    final base = rich(newGame());
    final built = withLevels(base, {
      InfraKind.stadium: 3,
      InfraKind.vip: 2,
      InfraKind.boxes: 3,
      InfraKind.mall: 3,
      InfraKind.restaurant: 3,
    });
    // Même saison, mêmes résultats : seule l'économie change.
    final a = playRounds(base, 4);
    final b = playRounds(built, 4);
    expect(b.finance.extras, greaterThan(a.finance.extras));
  });
}
