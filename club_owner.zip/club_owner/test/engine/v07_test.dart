import 'dart:convert';

import 'package:club_owner/domain/entities/owner.dart';
import 'package:club_owner/domain/entities/honours.dart';
import 'package:club_owner/engine/game/budgets.dart';
import 'package:club_owner/engine/international/international.dart';
import 'package:club_owner/engine/match/pitch_sim.dart';
import 'package:flutter_test/flutter_test.dart';

import 'owner_test.dart' show newGame;

InboxMessage _m(String t) =>
    InboxMessage(title: t, body: 'corps', season: 1, round: 1);

void main() {
  test('messagerie : lu à l\'ouverture, non lu, archive, suppression', () {
    var o = newGame().owner.copyWith(inbox: [_m('a'), _m('b'), _m('c')]);
    expect(o.unreadCount, 3);
    o = o.flagMessages({0}, read: true);
    expect(o.inbox[0].read, isTrue);
    o = o.flagMessages({0}, read: false);
    expect(o.inbox[0].read, isFalse);
    o = o.flagMessages({1}, archived: true);
    expect(o.inbox[1].archived, isTrue);
    expect(o.unreadCount, 2);
    o = o.removeMessages({0, 2});
    expect(o.inbox.single.title, 'b');
    final back = OwnerState.fromJson(
      jsonDecode(jsonEncode(o.toJson())) as Map<String, dynamic>,
    );
    expect(back.inbox.single.archived, isTrue);
  });

  test('les archives sont gardées quand la boîte déborde', () {
    var o = newGame().owner.copyWith(inbox: [_m('archive')]);
    o = o.flagMessages({0}, archived: true);
    for (var i = 0; i < maxInboxMessages + 10; i++) {
      o = o.addMessage(_m('m$i'));
    }
    expect(o.inbox.length, maxInboxMessages);
    expect(o.inbox.any((m) => m.title == 'archive'), isTrue);
  });

  test('budgets du président : dépenses suivies et plafond', () {
    var g = newGame();
    g = g.copyWith(finance: g.finance.copyWith(treasury: 1000000));
    expect(g.transferBudgetTotal, 300000);
    g = g.setBudgets(transfer: 200000);
    g = g.spendTransfer(50000);
    expect(g.transferBudgetLeft, 150000);
    expect(g.wageBudget, greaterThan(g.wageBill));
    final id = g.userClub.squad.first.id;
    g = g.toggleSellList(id);
    expect(g.owner.sellList, [id]);
  });

  test('classement mondial : un titre fait monter une nation', () {
    final base = worldRanking(const [], 3);
    final last = base.last.nation.name;
    final after = worldRanking(
      [
        TournamentResult(
          season: 2,
          name: 'Coupe du monde',
          champion: last,
          runnerUp: base.first.nation.name,
          userPlayers: const [],
        ),
      ],
      3,
    );
    final before = base.indexWhere((r) => r.nation.name == last);
    final now = after.indexWhere((r) => r.nation.name == last);
    expect(now, lessThan(before));
  });

  test('le moteur enregistre les occasions et les noms des titulaires', () {
    final game = newGame();
    final home = game.userClub;
    final away = game.season.clubs.firstWhere((c) => !c.isUser);
    final r = PitchSim(seed: 42).simulate(home: home, away: away);
    final d = r.detail!;
    expect(d.names.length, 22);
    expect(d.chances, isNotEmpty);
    expect(
      d.chances.length,
      lessThanOrEqualTo(r.stats!.homeShots + r.stats!.awayShots),
    );
    for (final c in d.chances) {
      expect(c.split('|').length, 5);
    }
  });
}
