import 'dart:convert';

import 'package:club_owner/core/utils/calendar.dart';
import 'package:club_owner/domain/data/world_data.dart';
import 'package:club_owner/domain/entities/owner.dart';
import 'package:club_owner/domain/entities/player.dart';
import 'package:club_owner/domain/entities/roles.dart';
import 'package:club_owner/domain/entities/staff.dart';
import 'package:club_owner/engine/game/game_codec.dart';
import 'package:club_owner/engine/game/game_state.dart';
import 'package:club_owner/engine/game/delegation.dart';
import 'package:club_owner/engine/game/press_actions.dart';
import 'package:club_owner/engine/game/transfer_actions.dart';
import 'package:club_owner/engine/owner/press.dart';
import 'package:club_owner/engine/squad/mood.dart';
import 'package:flutter_test/flutter_test.dart';

GameState newGame([int seed = 3]) {
  final country = worldCountries.first;
  return GameState.newGame(
    clubName: 'Mon Club',
    country: country,
    city: country.cities.first,
    seed: seed,
  );
}

GameState withDirector(GameState game) {
  final id = game.staffCandidates
      .firstWhere((c) => c.role == StaffRole.sportingDirector)
      .id;
  return game.hireStaff(id);
}

void main() {
  test('le monde compte plusieurs championnats complets', () {
    final game = newGame();

    expect(game.world.length, greaterThan(60));
    final ids = game.world.map((l) => l.id).toSet();
    expect(ids.length, game.world.length);
    for (final league in game.world) {
      expect(league.season.clubs.length, 20);
      for (final club in league.season.clubs) {
        expect(club.starters.length, 11);
      }
    }
    // Beaucoup de premières divisions dans le monde.
    expect(game.world.where((l) => l.division == 1).length, greaterThan(50));
  });

  test('les autres championnats jouent en même temps que le vôtre', () {
    final game = newGame();
    final next = game.playNextRound();

    expect(next.season.currentRound, 2);
    for (final league in next.world) {
      expect(league.season.currentRound, 2);
    }
    final scorers = next.world
        .expand((l) => l.season.clubs)
        .expand((c) => c.squad)
        .where((p) => p.goals > 0);
    expect(scorers, isNotEmpty);
  });

  test('une ancienne sauvegarde sans monde est complétée', () {
    final game = newGame().playNextRound();
    final json = jsonDecode(jsonEncode(encodeGame(game))) as Map<String, dynamic>
      ..remove('world');
    final loaded = decodeGame(json)!;

    expect(loaded.world, isEmpty);
    final fixed = loaded.ensureWorld();
    expect(fixed.world.length, greaterThan(60));
    expect(fixed.world.first.season.currentRound, loaded.season.currentRound);
  });

  test('le monde survit à la sauvegarde', () {
    final game = newGame().playNextRound();
    final raw = jsonEncode(encodeGame(game));
    final back = decodeGame(jsonDecode(raw) as Map<String, dynamic>)!;

    expect(back.world.length, game.world.length);
    expect(
      back.world.first.season.clubs.first.squad.length,
      game.world.first.season.clubs.first.squad.length,
    );
  });

  test('plusieurs saisons : le monde reste complet', () {
    var game = newGame();
    final initialLeagues = game.world.length;
    for (var season = 0; season < 2; season++) {
      var guard = 0;
      while (!game.season.isFinished && guard < 100) {
        if (!game.canPlayNextRound) game = game.autoPickStarters();
        game = game.playNextRound();
        guard++;
      }
      game = game.startNextSeason(300 + season);
    }

    expect(game.seasonNumber, 3);
    expect(game.world.length, initialLeagues);
    for (final league in game.world) {
      expect(league.season.clubs.length, 20);
    }
    expect(game.owner.news, isNotEmpty);
    expect(game.cups, isNotEmpty);
  });

  test('un joueur frustré finit par réclamer son départ', () {
    final game = newGame();
    var club = game.userClub;
    final bench = club.squad.firstWhere((p) => !club.starterIds.contains(p.id));
    final strong = bench.copyWith(skill: 90);
    club = club.copyWith(
      squad: [for (final p in club.squad) p.id == bench.id ? strong : p],
    );

    var wantsOut = false;
    for (var i = 0; i < 60; i++) {
      final report = updateMoods(club: club, outcome: -1, season: 1, round: i + 1);
      club = report.club;
      wantsOut = club.squad.firstWhere((p) => p.id == bench.id).wantsOut;
      if (wantsOut) break;
    }
    expect(wantsOut, isTrue);
  });

  test('répondre à la presse change les supporters et fait la une', () {
    final game = newGame();
    PressQuestion? question;
    for (var round = 1; round < 40 && question == null; round++) {
      question = makePressQuestion(
        seed: 3,
        season: 1,
        round: round,
        clubName: 'Mon Club',
        opponent: 'Rival',
        goalsFor: 4,
        goalsAgainst: 0,
        rank: 1,
      );
    }
    expect(question, isNotNull);
    expect(question!.options.length, 3);

    final waiting = game.copyWith(owner: game.owner.copyWith(press: question));
    final answered = waiting.answerPress(1);

    expect(answered.owner.press, isNull);
    expect(answered.owner.news.length, waiting.owner.news.length + 1);
    expect(answered.owner.news.first.kind, NewsKind.press);
  });

  test('le calendrier a des dates réelles', () {
    final first = roundDate(1, 1);
    final second = roundDate(1, 2);

    expect(first.weekday, DateTime.saturday);
    expect(second.difference(first).inDays, 7);
    expect(formatDateFr(first), contains('samedi'));
    expect(seasonLabel(1), '2026-2027');
  });

  test('les postes détaillés sont cohérents et stables', () {
    final game = newGame();
    for (final p in game.userClub.squad) {
      final role = roleOf(p);
      expect(roleOf(p), role);
      switch (p.position) {
        case PlayerPosition.goalkeeper:
          expect(role, PlayerRole.goalkeeper);
          break;
        case PlayerPosition.defender:
          expect(
            [PlayerRole.centreBack, PlayerRole.leftBack, PlayerRole.rightBack],
            contains(role),
          );
          break;
        case PlayerPosition.midfielder:
          expect(
            [
              PlayerRole.defensiveMid,
              PlayerRole.centralMid,
              PlayerRole.attackingMid,
            ],
            contains(role),
          );
          break;
        case PlayerPosition.forward:
          expect(
            [
              PlayerRole.striker,
              PlayerRole.leftWinger,
              PlayerRole.rightWinger,
            ],
            contains(role),
          );
          break;
      }
    }
  });

  test('prêter un jeune exige un directeur sportif puis le déplace', () {
    final game = newGame();
    final youth = game.userClub.academy.first;
    final host = game.otherClubs.first;

    expect(game.validateSendOnLoan(youth.id, host.id), isNotNull);

    final ready = withDirector(game);
    expect(ready.validateSendOnLoan(youth.id, host.id), isNull);
    final lent = ready.sendOnLoan(youth.id, host.id);

    expect(lent.userClub.allPlayers.any((p) => p.id == youth.id), isFalse);
    expect(lent.loans.any((l) => l.playerId == youth.id), isTrue);
  });

  test('sans directeur sportif, personne ne gère l\'effectif', () {
    final game = newGame();
    expect(identical(game.dsRoutine(1), game), isTrue);

    // Le staff agit toujours : le président ne gère plus les contrats.
    final withDs = withDirector(game);
    final acted = withDs.dsRoutine(1);
    expect(acted.userClub.squad.length, greaterThanOrEqualTo(18));
  });
}
