import 'dart:math';

import 'package:club_owner/domain/data/names_data.dart';
import 'package:club_owner/engine/squad/squad_factory.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('chaque nationalité a des noms de sa culture', () {
    final random = Random(3);
    for (final nation in ['Sénégal', 'Afrique du Sud', 'Costa Rica', 'Japon', 'Argentine']) {
      final group = nameGroupsByNation[nation]!;
      final used = <String>{};
      for (var i = 0; i < 30; i++) {
        final name = randomPlayerNameFor(nation, random, used);
        expect(group.last.any((l) => name.contains(l)), isTrue,
            reason: '$nation : $name');
      }
      // Les noms d'un même effectif restent uniques.
      expect(used.length, 30);
    }
  });

  test('nom de famille en premier pour la Corée', () {
    final name = randomPlayerNameFor('Corée du Sud', Random(1), <String>{});
    final group = nameGroupsByNation['Corée du Sud']!;
    expect(group.last.contains(name.split(' ').first), isTrue);
  });

  test('binationaux : des Français aux noms d\'Afrique de l\'Ouest', () {
    final random = Random(9);
    final used = <String>{};
    final french = nameGroupsByNation['France']!;
    var other = 0;
    for (var i = 0; i < 200; i++) {
      final name = randomPlayerNameFor('France', random, used);
      if (!french.last.any((l) => name.endsWith(l))) other++;
    }
    // Environ un tiers, mais la majorité garde un nom français.
    expect(other, inInclusiveRange(30, 100));
  });

  test('nationalité inconnue : liste générale', () {
    final name = randomPlayerNameFor('Atlantide', Random(1), <String>{});
    expect(name.split(' ').length, greaterThanOrEqualTo(2));
  });
}
