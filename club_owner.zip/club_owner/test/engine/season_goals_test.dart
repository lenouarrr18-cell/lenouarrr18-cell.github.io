import 'package:club_owner/engine/owner/season_goals.dart';
import 'package:flutter_test/flutter_test.dart';

import 'owner_test.dart' show newGame;

void main() {
  test("contrat d'objectifs : trois objectifs suivis en direct", () {
    final game = newGame();
    final list = seasonObjectives(game);
    expect(list.length, 3);
    for (final o in list) {
      expect(o.progress, inInclusiveRange(0.0, 1.0));
      expect(o.title, isNotEmpty);
    }
    expect(objectiveReward(1), greaterThan(objectiveReward(5)));
  });
}
