import numpy as np, subprocess, os
from scipy.signal import butter, sosfilt
SR=44100
rng=np.random.default_rng(7)
OUT='/tmp/audio/out'; os.makedirs(OUT,exist_ok=True)

def note(n):  # midi -> Hz
    return 440*2**((n-69)/12)
def env(n, a=0.01, d=0.2, s=0.6, r=0.2, length=None):
    L=n; t=np.arange(L)/SR; e=np.ones(L)*s
    A=int(a*SR); D=int(d*SR); R=int(r*SR)
    A=min(A,L); e[:A]=np.linspace(0,1,A,endpoint=False)
    D2=min(D,L-A); e[A:A+D2]=np.linspace(1,s,D2,endpoint=False)
    if R<L: e[L-R:]*=np.linspace(1,0,R)
    return e
def lp(x,f,o=2):
    return sosfilt(butter(o,f,'low',fs=SR,output='sos'),x)
def hp(x,f,o=2):
    return sosfilt(butter(o,f,'high',fs=SR,output='sos'),x)
def bp(x,f1,f2,o=2):
    return sosfilt(butter(o,[f1,f2],'band',fs=SR,output='sos'),x)
def epiano(f,dur,vel=0.5):
    n=int(dur*SR); t=np.arange(n)/SR
    x=np.sin(2*np.pi*f*t)+0.35*np.sin(2*np.pi*2*f*t)*np.exp(-t*3)+0.15*np.sin(2*np.pi*3.01*f*t)*np.exp(-t*5)
    return vel*x*np.exp(-t*1.6)*env(n,0.005,0.05,1,0.08)
def pad(f,dur,vel=0.3,bright=1800):
    n=int(dur*SR); t=np.arange(n)/SR
    x=np.zeros(n)
    for det in (-0.12,0,0.11):
        ph=2*np.pi*f*(1+det/100)*t
        x+= (2*((ph/(2*np.pi))%1)-1)   # saw
    x=lp(x/3,bright)
    return vel*x*env(n,0.4,0.5,0.8,0.6)
def bass(f,dur,vel=0.5,cut=600):
    n=int(dur*SR); t=np.arange(n)/SR
    ph=f*t; x=2*(ph%1)-1
    x=lp(x,cut)+0.6*np.sin(2*np.pi*f*t)
    return vel*x*env(n,0.005,0.1,0.7,0.05)
def brass(f,dur,vel=0.4):
    n=int(dur*SR); t=np.arange(n)/SR
    vib=1+0.004*np.sin(2*np.pi*5.5*t)
    ph=np.cumsum(f*vib)/SR
    x=2*(ph%1)-1
    e=env(n,0.06,0.2,0.75,0.15)
    x=lp(x,900)*(1-e)+lp(x,3000)*e
    return vel*x*e
def kick(vel=1.0):
    n=int(0.35*SR); t=np.arange(n)/SR
    f=50+120*np.exp(-t*30); ph=2*np.pi*np.cumsum(f)/SR
    return vel*np.sin(ph)*np.exp(-t*9)
def snare(vel=0.6):
    n=int(0.22*SR); t=np.arange(n)/SR
    no=rng.standard_normal(n); no=bp(no,1500,7000)
    return vel*(0.7*no*np.exp(-t*18)+0.4*np.sin(2*np.pi*190*t)*np.exp(-t*25))
def hat(vel=0.25,open_=False):
    n=int((0.25 if open_ else 0.06)*SR); t=np.arange(n)/SR
    no=hp(rng.standard_normal(n),7000)
    return vel*no*np.exp(-t*(10 if open_ else 60))
def clap(vel=0.5):
    n=int(0.2*SR); t=np.arange(n)/SR
    no=bp(rng.standard_normal(n),1000,4000)
    e=np.exp(-t*25); e[:int(0.01*SR)]*=1.5
    return vel*no*e

def place(buf,x,t):
    i=int(t*SR)
    if i>=len(buf): return
    j=min(len(buf),i+len(x)); buf[i:j]+=x[:j-i]

def reverb(x,mix=0.25):
    out=x.copy()
    for d,g in ((0.029,0.5),(0.037,0.45),(0.041,0.42),(0.053,0.38),(0.067,0.33),(0.089,0.28)):
        k=int(d*SR); y=np.zeros_like(x); y[k:]=x[:-k]*g
        out+=lp(y,4000)*mix
    return out

def master(st, name, target=-1.0):
    st=st/ (np.max(np.abs(st))+1e-9) * 10**(target/20)
    st=np.tanh(st*1.15)/np.tanh(1.15)
    # fade out end, fade in start
    n=len(st); f=int(1.5*SR)
    st[:int(0.02*SR)]*=np.linspace(0,1,int(0.02*SR))[:,None] if st.ndim==2 else 1
    wav=f'{OUT}/{name}.wav'
    import wave
    data=(np.clip(st,-1,1)*32767).astype(np.int16)
    with wave.open(wav,'wb') as w:
        w.setnchannels(2 if st.ndim==2 else 1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(data.tobytes())
    return wav

def stereo(l,r=None):
    if r is None: r=l
    return np.stack([l,r],axis=1)

def song(bpm, bars, chords, style, seed):
    global rng
    rng=np.random.default_rng(seed)
    beat=60/bpm; bar=4*beat; total=bars*bar+2
    n=int(total*SR)
    drums=np.zeros(n); keys=np.zeros(n); bs=np.zeros(n); pads=np.zeros(n); lead=np.zeros(n)
    scale=[0,2,3,5,7,8,10] if style!='anthem' and style!='funk' else [0,2,4,5,7,9,11]
    for b in range(bars):
        t0=b*bar
        root, quality = chords[b % len(chords)]
        tri=[0,3,7,10] if quality=='m7' else ([0,4,7,11] if quality=='M7' else ([0,4,7] if quality=='M' else [0,3,7]))
        section = 0 if b<4 else (1 if b<bars-4 else 2)
        # pad / keys
        if style=='lofi':
            for k,iv in enumerate(tri):
                place(keys, epiano(note(root+48+iv),bar*0.95,0.22), t0+k*0.012)
            if b%2==1:
                place(keys, epiano(note(root+60+tri[1]),beat*1.5,0.15), t0+2.5*beat)
        elif style=='anthem':
            for iv in tri:
                place(pads, pad(note(root+48+iv),bar,0.18,1400), t0)
            if section>=1:
                mel=[tri[2],tri[1],tri[0],tri[1]] if b%2==0 else [tri[0],tri[1],tri[2],tri[2]+5]
                for k,iv in enumerate(mel):
                    place(lead, brass(note(root+60+iv),beat*0.95,0.28), t0+k*beat)
        else:
            for iv in tri:
                place(pads, pad(note(root+48+iv),bar,0.12 if style=='derby' else 0.1,2200), t0)
        # bass
        if style in ('derby','funk'):
            pattern=[0,0.5,1.5,2,2.75,3.5] if style=='funk' else [0,0.5,1,1.5,2,2.5,3,3.5]
            for k,p in enumerate(pattern):
                iv = 12 if (style=='funk' and k%3==2) else 0
                place(bs, bass(note(root+36+iv),beat*0.45,0.5,500 if style=='derby' else 900), t0+p*beat)
        else:
            place(bs, bass(note(root+36),beat*1.8,0.45,300), t0)
            place(bs, bass(note(root+36+7),beat*0.9,0.35,300), t0+2.5*beat)
        # lead melody (derby/funk)
        if style in ('derby','funk') and section>=1:
            r2=np.random.default_rng(seed*100+b%4)
            steps=8
            for s in range(steps):
                if r2.random()<0.55:
                    deg=scale[r2.integers(0,len(scale))]
                    place(lead, brass(note(root+60+deg),beat*0.45,0.16) if style=='funk' else pad(note(root+72+deg),beat*0.45,0.08,3500), t0+s*beat/2)
        # drums
        if section==0 and style!='lofi' and b<2:
            place(drums,hat(0.2),t0); continue
        for q in range(4):
            tq=t0+q*beat
            if style=='derby':
                place(drums,kick(0.95),tq)
                if q%2==1: place(drums,clap(0.5),tq)
                place(drums,hat(0.22,True),tq+beat/2)
            elif style=='funk':
                if q in (0,2): place(drums,kick(0.9),tq)
                if q==2: place(drums,kick(0.6),tq+0.75*beat)
                if q in (1,3): place(drums,snare(0.55),tq)
                for s in range(4): place(drums,hat(0.14 if s%2 else 0.2),tq+s*beat/4)
            elif style=='anthem':
                if q in (0,2): place(drums,kick(0.8),tq)
                if q in (1,3) and section>=1: place(drums,snare(0.45),tq)
                if section>=1: place(drums,hat(0.12),tq+beat/2)
            else:  # lofi swing
                if q==0 or (q==2 and b%2==0): place(drums,kick(0.7),tq)
                if q==2 and b%2==1: place(drums,kick(0.5),tq+0.66*beat)
                if q in (1,3): place(drums,snare(0.35),tq)
                place(drums,hat(0.12),tq); place(drums,hat(0.08),tq+0.66*beat)
    if style=='lofi':
        drums=lp(drums,5000); keys=lp(keys,3000)
        vinyl=lp(rng.standard_normal(n)*0.01,4000)
        crack=(rng.random(n)>0.9997)*rng.standard_normal(n)*0.2
        drums+=vinyl+crack
    mixL=drums*0.9+bs*0.8+keys*0.9+pads*0.9+lead*0.8
    mixR=drums*0.9+bs*0.8+np.roll(keys,int(0.011*SR))*0.9+np.roll(pads,int(0.017*SR))*0.9+np.roll(lead,int(0.007*SR))*0.8
    mixL=reverb(mixL,0.22); mixR=reverb(mixR,0.22)
    fo=int(2*SR); env_=np.ones(n); env_[-fo:]=np.linspace(1,0,fo)
    return stereo(mixL*env_, mixR*env_)

tracks=[
 ('bureau_du_president', 82, 24, [(57,'m7'),(62,'m7'),(55,'M7'),(60,'M7')], 'lofi', 1),
 ('nuit_de_derby', 124, 40, [(57,'m'),(53,'M'),(48,'M'),(55,'M')], 'derby', 2),
 ('mercato_express', 108, 32, [(48,'M'),(57,'m'),(53,'M'),(55,'M')], 'funk', 3),
 ('hymne_du_club', 92, 28, [(48,'M'),(55,'M'),(57,'m'),(53,'M')], 'anthem', 4),
]
for name,bpm,bars,ch,style,seed in tracks:
    st=song(bpm,bars,ch,style,seed)
    wav=master(st,name,-1.5)
    subprocess.run(['ffmpeg','-y','-loglevel','error','-i',wav,'-codec:a','libmp3lame','-b:a','112k',f'{OUT}/{name}.mp3'],check=True)
    print(name, len(st)/SR)

# --- SFX ---
def whistle(dur=0.6,blasts=1):
    parts=[]
    for b in range(blasts):
        n=int(dur*SR); t=np.arange(n)/SR
        f=2900+60*np.sin(2*np.pi*28*t)  # trill
        ph=2*np.pi*np.cumsum(f)/SR
        x=np.sin(ph)+0.3*np.sin(2*ph)+0.05*rng.standard_normal(n)
        x*=env(n,0.02,0.05,0.9,0.08)
        parts.append(x); parts.append(np.zeros(int(0.12*SR)))
    return np.concatenate(parts)*0.5
for name,(d,b) in {'whistle_short':(0.35,1),'whistle_half':(0.45,2),'whistle_final':(0.5,3)}.items():
    x=reverb(whistle(d,b),0.2)
    wav=master(stereo(x),name,-3)
    subprocess.run(['ffmpeg','-y','-loglevel','error','-i',wav,'-codec:a','libmp3lame','-b:a','96k',f'{OUT}/{name}.mp3'],check=True)

def crowd(dur, excite=None, seed=11):
    r=np.random.default_rng(seed); n=int(dur*SR); t=np.arange(n)/SR
    base=np.zeros(n)
    # many voices = band-limited noise with slow modulations
    for k in range(6):
        no=bp(r.standard_normal(n), 250+k*120, 900+k*350)
        mod=1+0.35*np.sin(2*np.pi*(0.07+0.05*k)*t+r.random()*6)
        base+=no*mod
    base/=6
    if excite is not None: base*=excite
    # chant: rhythmic vowel-like
    return base
loopd=24.0
amb=crowd(loopd)
# make seamless loop by crossfade
cf=int(1.5*SR); a=amb.copy(); a[:cf]=a[:cf]*np.linspace(0,1,cf)+amb[-cf:]*np.linspace(1,0,cf); a=a[:-cf]
wav=master(stereo(a,np.roll(a,int(0.02*SR))),'crowd_loop',-6)
subprocess.run(['ffmpeg','-y','-loglevel','error','-i',wav,'-codec:a','libmp3lame','-b:a','96k',f'{OUT}/crowd_loop.mp3'],check=True)

# goal cheer: rising roar + claps
n=int(5*SR); t=np.arange(n)/SR
ex=np.clip(t/0.35,0,1)*np.exp(-np.maximum(t-1.8,0)*0.9)*2.4+0.3
roar=crowd(5,ex,seed=12)+0.5*bp(rng.standard_normal(n),600,3000)*ex*0.4
claps=np.zeros(n)
for i in range(60):
    place(claps,clap(0.25*rng.random()),1.0+rng.random()*3.5)
x=reverb(roar+claps,0.3)
wav=master(stereo(x,np.roll(x,int(0.015*SR))),'goal_cheer',-1)
subprocess.run(['ffmpeg','-y','-loglevel','error','-i',wav,'-codec:a','libmp3lame','-b:a','112k',f'{OUT}/goal_cheer.mp3'],check=True)
# groan (away goal / miss)
n=int(2.5*SR); t=np.arange(n)/SR
ex=np.clip(t/0.2,0,1)*np.exp(-t*1.2)*1.6+0.2
x=lp(crowd(2.5,ex,seed=13),900)
wav=master(stereo(x),'crowd_groan',-4)
subprocess.run(['ffmpeg','-y','-loglevel','error','-i',wav,'-codec:a','libmp3lame','-b:a','96k',f'{OUT}/crowd_groan.mp3'],check=True)
# ui tap
n=int(0.08*SR); t=np.arange(n)/SR
x=np.sin(2*np.pi*1200*t)*np.exp(-t*60)*0.6
wav=master(stereo(x),'ui_tap',-8)
subprocess.run(['ffmpeg','-y','-loglevel','error','-i',wav,'-codec:a','libmp3lame','-b:a','96k',f'{OUT}/ui_tap.mp3'],check=True)
print('done')
