"""Génère les pages web légales (docs/) à partir de lib/core/legal/legal_texts.dart.

Usage : python3 tool/legal/build_pages.py
Les pages peuvent être publiées gratuitement avec GitHub Pages (dossier docs/).
"""
import html, os, re

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
src = open(os.path.join(ROOT, 'lib/core/legal/legal_texts.dart'), encoding='utf-8').read()

pub = dict(re.findall(r"static const String (\w+) = '((?:[^'\\]|\\.)*)';", src))
pub = {k: v.replace("\\'", "'") for k, v in pub.items()}
pub['director'] = pub.get('director', pub.get('name', ''))
if pub['director'] == 'name':
    pub['director'] = pub['name']

STR = r"'(?:[^'\\]|\\.)*'"

def dart_str(chunk):
    parts = re.findall(STR, chunk)
    text = ''.join(p[1:-1] for p in parts)
    text = text.replace("\\'", "'").replace('\\n', '\n')
    return re.sub(r"\$\{Publisher\.(\w+)\}", lambda m: pub.get(m.group(1), ''), text)

def sections(name):
    block = src[src.index(f'const List<LegalSection> {name} = ['):]
    block = block[:block.index('\n];')]
    out = []
    for m in re.finditer(r"LegalSection\(\s*((?:%s\s*)+),\s*((?:%s\s*|Publisher\.\w+\s*)+),?\s*\)" % (STR, STR), block):
        title = dart_str(m.group(1))
        body_raw = m.group(2).strip()
        body = pub.get(body_raw.split('.')[1], '') if body_raw.startswith('Publisher.') else dart_str(body_raw)
        out.append((title, body))
    return out

CSS = """body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;max-width:760px;margin:0 auto;padding:24px;
background:#07140d;color:#e8f0ea;line-height:1.55}h1{color:#f5c04a}h2{color:#2fbf7a;font-size:1.1em;margin-top:1.6em}
a{color:#f5c04a}.muted{color:#9fb3a7;font-size:.9em}nav a{margin-right:14px}"""

def page(fname, title, secs, lang):
    nav = ('<nav><a href="index.html">Club Owner</a><a href="privacy.html">Confidentialité</a>'
           '<a href="terms.html">Conditions</a><a href="legal.html">Mentions légales</a>'
           '<a href="privacy-en.html">English</a></nav>')
    body = ''.join(f'<h2>{html.escape(t)}</h2><p>{html.escape(b).replace(chr(10), "<br>")}</p>' for t, b in secs)
    doc = (f'<!DOCTYPE html><html lang="{lang}"><head><meta charset="utf-8">'
           f'<meta name="viewport" content="width=device-width,initial-scale=1">'
           f'<title>{html.escape(title)} – Club Owner</title><style>{CSS}</style></head><body>'
           f'{nav}<h1>{html.escape(title)}</h1><p class="muted">Dernière mise à jour : 20 novembre 2026</p>'
           f'{body}</body></html>')
    open(os.path.join(ROOT, 'docs', fname), 'w', encoding='utf-8').write(doc)

os.makedirs(os.path.join(ROOT, 'docs'), exist_ok=True)
page('privacy.html', 'Politique de confidentialité', sections('_privacyFr'), 'fr')
page('privacy-en.html', 'Privacy policy', sections('_privacyEn'), 'en')
page('terms.html', "Conditions d'utilisation", sections('_termsFr'), 'fr')
page('terms-en.html', 'Terms of use', sections('_termsEn'), 'en')
page('legal.html', 'Mentions légales', sections('_noticeFr'), 'fr')
page('index.html', 'Club Owner', [
    ('Le jeu', "Club Owner est un jeu de gestion où vous êtes le président d'un club de football : stade, finances, staff, mercato."),
    ('Assistance', f"Une question ou un problème ? Écrivez à {pub.get('email', '')}."),
], 'fr')
print('Pages générées dans docs/')
