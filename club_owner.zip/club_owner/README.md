# Club Owner

Jeu mobile de gestion de club de football (Flutter / Dart). Le joueur fonde un club, grimpe les divisions et vise les compétitions continentales et mondiales.

Cahier des charges : v1 validée. Les évolutions sont prévues en v2.

## Démarrer

Prérequis : Flutter stable (Dart 3.4 ou plus récent).

```bash
# 1. Générer les dossiers de plateforme (une seule fois)
flutter create . --project-name club_owner --org com.tonorg --platforms android,ios

# 2. Dépendances, formatage, analyse, tests
flutter pub get
dart format .
flutter analyze
flutter test

# 3. Lancer
flutter run
```

Remplacez `com.tonorg` par l'identifiant de votre organisation : il devient l'identifiant d'application sur les stores et ne se change pas facilement ensuite.

## Structure

```
lib/
  core/       thème, routeur, utilitaires transverses
  domain/     entités et règles métier (Dart pur)
  engine/     simulation de match, calendrier (Dart pur)
  features/   écrans et états par fonctionnalité
```

Voir `docs/ARCHITECTURE.md`.


## Version actuelle

Jeu de propriétaire de club complet : staff (manager, directeur sportif,
recruteurs, coachs, community manager), mercato mondial avec offres, prêts et
libérations, équipes première / réserve / formation, retraites et regens,
installations (stade modulaire, entraînement, formation, fan zone, parking,
boutique), sponsors et banque, supporters et réseau social, tactique,
palmarès (Ballon d'or, Soulier d'or, Kopa, Yachine, GOAT) et compétitions
internationales.

Pour l'icône et le nom de l'application, utiliser le workflow
`build-apk.yml` fourni (il copie les icônes de `tool/icons`).


## Mise à jour : monde vivant

- Guide du débutant (premier lancement, puis Paramètres ou Accueil).
- Calendrier daté (journées chaque samedi, mercato d'été et d'hiver).
- Autres championnats simulés en même temps : toutes les divisions de
  votre pays et la première division de 5 pays étrangers.
- Distinctions réservées aux joueurs de première division du monde.
- Postes détaillés (GB, DC, ArG, ArD, MDC, MC, MO, AG, AD, BU).
- Humeur des joueurs, altercations, demandes de départ, discussions.
- Conférences de presse et journal (« Le Quotidien du Foot »).
- Prêts de développement, délégation au directeur sportif.
- Replay du match en 2D avec les pions.


## Mise à jour : monde élargi et nouveau design

- Plus de 90 championnats simulés : toutes les divisions de votre pays,
  la première division de 60 nations, la deuxième de 20 et la troisième de 8.
- Effectifs plus fournis dans les divisions supérieures.
- Compétitions de clubs : Ligue des champions, Ligue Europa, Conférence,
  compétitions africaines, sud-américaines, nord-américaines, asiatiques et
  Coupe du monde des clubs.
- Mercato réaliste : été (jusqu'au 1er septembre) et hiver (janvier).
- Stade, fan zone, parking et boutique déduits du prestige pour chaque club.
- Replay du match avec les vrais buteurs ; simulation directe, 5 journées,
  saison complète, ou match en 2D à la vitesse choisie.
- Sauvegarde du monde compressée et différée (toutes les 5 journées).
- Nouveau design « nuit de stade ».

## Gouvernance du président
- Le directeur sportif propose ventes et libérations ; sans réponse, elles
  s'exécutent 2 journées plus tard. Le président peut valider, bloquer
  (veto) ou demander une autre solution (prêt) depuis le « Bureau du président ».
- Confiance du directeur sportif / manager, tensions internes, vetos comptés.
- Messagerie par expéditeur, suppression (glisser ou « messages lus »).
- Missions de bienvenue facultatives et « Conseils du président » désactivables.
- Courbe de trésorerie dans l'onglet Finances.

## Audit (lot 1)
Projet Flutter/Dart (pas Godot). Moteur de match : simulation statistique par phases
(`match_engine.dart`), rejeu 2D visuel des événements — pas de simulation spatiale
joueur par joueur. Stade : dessin 2D, pas de 3D. Lot 1 : rapport de confiance
multicritères de fin de saison + historique/graphique (Bureau du président).

## Lot 2
- Centre médical (blessures évitées), centre de recrutement (talents détectés), installations VIP (billetterie), 5 niveaux chacun.
- Objectifs présidentiels sur 3, 5 et 10 ans (Bureau du président).
- Conseiller basé sur les vraies données du club (page Conseiller + alertes dans la messagerie).
- Statistiques de match détaillées (possession, tirs, corners, fautes, cartons, hors-jeu, passes), affichées dans le rejeu 2D. Elles sont estimées à partir de la simulation par phases : ce n'est pas une simulation spatiale joueur par joueur.
- Introduction narrative adaptée au club, avant le guide.

## Lot 3
- `pitch_sim.dart` : match du président simulé joueur par joueur (22 joueurs, positions en mètres, passes, interceptions, tacles, fautes, cartons, hors-jeu, tirs, corners, penalties). Buts, buteurs, passeurs, statistiques, notes et distances viennent de ce moteur. Les autres matchs du monde restent simulés par phases. Paramètres non calibrés : à ajuster après des parties réelles.
- Stade 3D (`stadium_3d.dart`) : rendu logiciel en perspective (pas de moteur 3D, pas de textures), évolue selon les niveaux (tribunes, toits, projecteurs, VIP, fan zone, parking, boutique).
- Événements d'investissement et d'offre de rachat du club (vente = fin de carrière).

## Correctifs moteur 2D / stade 3D
- Stade 3D : sol, pelouse et parking dessinés d'abord, puis tri en profondeur des objets (tribunes visibles), spectateurs, panneaux, cages, arbres, tableau d'affichage.
- PitchSim : tirs espacés (délai mini 70 s), probabilités de tir et de but réduites, passes plus fiables, amortisseur en cas d'écart >= 3 buts.
- Rejeu 2D : positions réelles des 22 joueurs et du ballon enregistrées toutes les 6 s (`track`), anciennes sauvegardes = rejeu schématique.

## Lot réalisme (match)
- Scénario de tirs : le score vient de la simulation par phases (scores de football), PitchSim décide qui tire, où et quand (8 à 22 tirs, issues buts/arrêts/ratés/contrés).
- Mi-temps : changement de côté dans le rejeu. Remplacements (3 par équipe, joueurs les plus fatigués) et touches (statistique « Touches »).
- Rejeu en paysage (orientation forcée pendant le match), terrain en damier, pions numérotés, bandeau de commentaire.

## Refonte tactique et rôle du coach
Audit de départ : formations = simples compteurs par ligne (4 postes larges), pions placés « au hasard » dans la ligne, aucun rôle, 3 réglages, composition choisie par le président.
Refonte :
- `spots.dart` : 18 postes précis (GB, DG, DD, DC, PG, PD, MDC, MC, MCG, MCD, MOC, MG, MD, AG, AD, BU, AC, BT), disposition propre à chaque formation en coordonnées normalisées, rôles (21) et consignes individuelles (14). Poste naturel déduit de l'identifiant (aucune migration de sauvegarde), adéquation poste/joueur.
- Le coach (`engine/squad/coach.dart`) compose l'équipe à chaque journée (poste, forme, fatigue, rotation) ; le président ne titularise plus. Condition physique (`fitness`) : les titulaires se fatiguent, le banc récupère (staff médical accélère).
- Force par ligne calculée à partir des postes réellement occupés ; indicateur d'équilibre tactique (solidité, contrôle, puissance).
- Le moteur de match utilise formation, rôles, consignes, mentalité, style, pressing, ligne, largeur et transitions.
- Page Tactique : terrain, cartes de joueurs animées, rôles/consignes, trois configurations (appui long pour enregistrer).
Non fait : changements tactiques pendant le match (le match est simulé d'une traite), glisser-déposer des joueurs (le coach choisit).

## Garder la sauvegarde à chaque mise à jour
- Cause réelle des pertes : `flutter create` en CI fabrique une clé de signature différente à chaque construction, donc Android refuse la mise à jour par-dessus et oblige à désinstaller (ce qui efface la sauvegarde). Correctif : clé fixe `tool/signing/debug.keystore` copiée dans `~/.android` avant la construction, et `--build-number` croissant (voir `build-apk.yml`).
- Format de sauvegarde : toute version antérieure se charge (champs ajoutés avec valeurs par défaut) ; seule une version plus récente que l'application est refusée. Ne jamais renommer ni retirer un champ sans migration.
- Copie de sécurité (`game_save_backup_v1`) : la sauvegarde précédente est conservée ; si la principale est illisible, elle est utilisée.
- Tactique et installations : affichage paysage forcé sur ces écrans (`LandscapeScope`).

## Installations (lot « complexe du club »)

- 29 bâtiments sur 5 niveaux : 9 sportifs, 5 pour le stade (tribunes, pelouse,
  éclairage, écrans, toiture), 10 commerciaux, 5 administratifs
  (`lib/engine/owner/infrastructure.dart`, catalogue `infraCatalog`).
- Chaque bâtiment a un coût, une durée, un entretien, des employés, des
  conditions de déblocage et un effet réel branché sur l'économie et le sportif
  existants (billetterie, sponsors, merchandising, loges, musée, loyers,
  fatigue, blessures, formation, détection, réputation).
- Personnel : capacité = 60 + 20 × siège + 30 × recrutement du personnel.
- Centre des opérations : jusqu'à 3 chantiers en parallèle, travaux plus courts.
- Historique des constructions, couleur des sièges et niveaux des nouveaux
  bâtiments enregistrés dans la sauvegarde (champs optionnels, anciennes
  sauvegardes compatibles).
- Écran en paysage : plan isométrique du complexe (`campus_view.dart`) avec
  zoom au doigt et boutons, jour/nuit/pluie, bâtiments et parties du stade à
  toucher, panneau Détail (avant/après), Chantiers, Comptes, Historique.
- Tests : `test/engine/infrastructure_test.dart`.

## Lot « design pro et distinctions »

- `lib/features/common/pro_page.dart` : gabarit commun en paysage plein écran
  (colonne d'identité + chiffres clés à gauche, contenu à droite, onglets),
  cartes, jauges, étiquettes, états vides illustrés, grille responsive.
- Écrans refaits avec ce gabarit : Supporters, Salle de presse, Journal (une
  de quotidien), Coupes continentales, Palmarès, Sponsors et banque, Staff,
  Mercato. `LandscapeScope` masque désormais les barres système.
- Installations : le plan remplit tout l'écran (décor élargi, quartier autour).
- Distinctions réalistes (`engine/awards/awards.dart`) : Ballon d'or, Golden
  Boy, Kopa et Yachine réservés aux joueurs de D1 engagés en coupe
  continentale ou appelés en sélection ; le parcours continental, le titre de
  champion et la sélection pèsent dans le score ; podium du Ballon d'or.
  Les coupes continentales sont désormais jouées avant la cérémonie.
- Palmarès : onglet « Course au Ballon d'or » (projection en direct).
- Tests : `test/engine/awards_test.dart`.

## Lot « identité, légal et langues » (v0.5.0)

- Logo : `tool/branding/logo.svg` (source), icônes Android dans `tool/icons/`,
  logo dans l'application `assets/branding/logo.png` (widget `AppLogo`).
- Textes légaux FR/EN : `lib/core/legal/legal_texts.dart` (CGU, politique de
  confidentialité, mentions légales). **Compléter la classe `Publisher`**
  (nom, statut, adresse, e-mail, directeur de publication) avant publication.
- Acceptation au premier lancement (`LegalGate`), écrans `/legal/:doc` et
  `/about` (version, licences des logiciels libres).
- Langues : `lib/core/l10n/l10n.dart` (français, anglais), choix dans les
  Paramètres et sur l'écran d'accueil légal. Traduits : navigation,
  paramètres, textes légaux, à propos, menu du club (début).

## Lot « tout en paysage »

- Paysage plein écran pour tout le jeu (`main.dart`), y compris au lancement
  (`android:screenOrientation="sensorLandscape"` ajouté par `build-apk.yml`).
- Navigation : barre latérale (logo, club, trésorerie, 5 onglets, messages,
  bureau, paramètres) à la place de la barre du bas.
- `ProColumns` (pro_page.dart) : colonnes défilantes indépendantes.
- Écrans réorganisés en colonnes : accueil (tableau de bord à 3 colonnes avec
  bouton de match, mini-classement, accès rapides), effectif, club, finances,
  calendrier, paramètres, bureau, conseiller, messagerie, sauvegardes,
  sélections, championnats, clubs ; création du club, introduction et guide
  en écran partagé. Feuilles du bas centrées et défilantes.

## Lot « match vivant, son et design épuré »

- Son : `lib/core/audio/audio_service.dart` (paquet `audioplayers`). Musique
  des menus (radio du club, 4 compositions originales), ambiance de stade,
  sifflets, clameur des buts. Réglages et liste des morceaux : `/radio`.
  Les fichiers viennent de `tool/audio/synth.py` (voir assets/audio/LICENCE.txt).
- Match 2D : terrain plein écran sur fond de tribunes, tableau d'affichage
  télé, frise touchable des buts, vitesses x1 à x8, mode « Temps forts »,
  annonce animée des buts avec ralenti, cartes de mi-temps et de fin (homme
  du match), territoire en direct, traînée du ballon, panneau Stats/Joueurs/
  Faits escamotable, foule qui réagit à l'action.
- Design épuré : accueil en 2 colonnes (prochain match au centre, 3 chiffres
  clés), barre latérale allégée, menu du club en 4 sections.
- Succès du président (17, calculés depuis la partie) : `/achievements`,
  notification à chaque déblocage.

## Lot v0.6.0 « président, pas négociateur »

- Recrutement : le président signale un joueur et fixe un budget
  (`recruit_dialog.dart`). Le manager donne son avis (`coachOpinion`), le
  directeur sportif négocie à chaque journée (`engine/game/recruitment.dart`),
  compte rendu dans la messagerie et l'onglet Offres. Le président peut
  insister (la confiance du manager baisse) ou abandonner.
- Moteur : buts attendus (xG) et journal des cartons (minute, joueur).
- Match : rendu avec le moteur de jeu Flame (`match_game.dart`), caméra télé
  qui suit le ballon ou vue d'ensemble ; xG et cartons dans le panneau.
- Musique : les morceaux de synthèse sont retirés. Déposer les MP3 dans
  assets/audio/music/ et les décrire dans playlist.json (voir LISEZMOI.txt) ;
  fondu enchaîné, lecture aléatoire, crédits dans la radio du club.
- Légal : éditeur particulier ; pages web `docs/` (confidentialité FR/EN,
  conditions, mentions légales, assistance) générées par
  `tool/legal/build_pages.py`, à publier avec GitHub Pages.

## v0.7.0

- Musiques : So Bad (Manuel_deki) + 5 morceaux Pixabay. Champ `use` dans
  playlist.json : `menu` (radio), `matchIntro` (entrée des joueurs),
  `celebration` (victoire).
- Mises à jour sans désinstaller : la clé de signature est imposée à Gradle
  (`android.injected.signing.*`), plus de clé aléatoire possible. Bundle AAB
  pour Google Play produit en plus de l'APK.
- Sauvegarde Google (Firebase Auth + Firestore) : `lib/core/cloud/`, page
  `/cloud`, envoi automatique. Activée quand `firebase_config.dart` est
  rempli (voir firebase/GUIDE.md et firebase/firestore.rules).
- Match : rythme lisible (x1 ≈ 4 min 30 le match), mode Temps forts par
  défaut qui ralentit chaque occasion, entrée des joueurs avec compositions,
  annonce puis ralenti de chaque but, noms du porteur et du tireur sur le
  terrain, commentaire des occasions. Le moteur enregistre occasions et noms.
- Messagerie : lu seulement à l'ouverture, garder non lu, archiver,
  supprimer, sélection multiple, volet de lecture.
- Effectif géré par le staff : budgets transferts et plafond salarial fixés
  par le président (Finances) ; le directeur sportif prolonge, recrute,
  vend (liste de vente demandée par le président) dans ces budgets.
- International : classement mondial des nations, calendrier du cycle,
  chances de sélection de vos joueurs, palmarès.
